<?php
/**
 *  2023 TOOLE - Inter-soft.COM
 *  All rights reserved.
 *
 *  DISCLAIMER
 *
 *  Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketCatalogFiltersManufacturersController extends TooleBaseAdminController
{
    private $entityId;

    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'catalog/filters/';
        $this->tpl_folder = 'catalog/filters/';
        $this->bootstrap = true;
        $this->table = 'manufacturer';
        $this->identifier = 'id_manufacturer';
        $this->submit_action = 'submitAdd' . $this->table;
        $this->class_name = 'ToolEAmazonMarketCatalogFiltersManufacturers';
        $this->lang = false;
        $this->deleted = false;
        $this->colorOnBackground = false;

        $this->explicitSelect = true;
        $this->addRowAction('view');
        $this->addRowAction('preview');
        if (!Tools::getValue('id_manufacturer')) {
            $this->multishop_context_group = false;
        }
        $this->imageType = 'gif';
        $this->fieldImageSettings = [
            'name' => 'icon',
            'dir' => 'os',
        ];
        $this->_defaultOrderBy = $this->identifier = 'id_manufacturer';
        $this->deleted = false;
        $this->_orderBy = null;
        $this->list_no_link = true;
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);

        $this->_join =
            ' JOIN `' . _DB_PREFIX_ . 'manufacturer_shop` sa ON
            (a.`id_manufacturer` = sa.`id_manufacturer` AND sa.id_shop = ' . $this->shop_id . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` ms ON
            (ms.id_manufacturer = a.`id_manufacturer` AND ms.id_shop = ' . $this->shop_id . ' AND ms.id_entity = ' . $this->entityId . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` ae ON
            (ms.id_entity = ae.`id_entity`)';

        $this->bulk_actions = [
            'enableAmzToPs' => [
                'text' => $this->module->l('Amazon - Enable selected'),
                'confirm' => $this->module->l('Enable selected items?'),
                'icon' => 'icon-check',
            ],
            'disableAmzToPs' => [
                'text' => $this->module->l('Amazon - Disable selected'),
                'confirm' => $this->module->l('Disable selected items?'),
                'icon' => 'icon-times',
            ],
            'divider' => [
                'text' => 'divider',
            ],
            'enablePsToAmz' => [
                'text' => $this->module->l('Prestashop - Enable selected'),
                'confirm' => $this->module->l('Enable selected items?'),
                'icon' => 'icon-check',
            ],
            'disablePsToAmz' => [
                'text' => $this->module->l('Prestashop - Disable selected'),
                'confirm' => $this->module->l('Disable selected items?'),
                'icon' => 'icon-times',
            ],
            'divider2' => [
                'text' => 'divider',
            ],
            'enableFbaToPs' => [
                'text' => $this->module->l('FBA - Enable selected'),
                'confirm' => $this->module->l('Enable selected items?'),
                'icon' => 'icon-check',
            ],
            'disableFbaToPs' => [
                'text' => $this->module->l('FBA -  Disable selected'),
                'confirm' => $this->module->l('Disable selected items?'),
                'icon' => 'icon-times',
            ],
            'enableAll' => [
                'text' => $this->module->l('ENABLE ALL'),
                'confirm' => $this->module->l('Enable all manufacturers?'),
                'icon' => 'icon-check',
            ],
        ];

        $this->fields_list = [];
        $this->fields_list['id_manufacturer'] = [
            'title' => $this->module->l('Id'),
            'align' => 'text-center',
            'class' => 'fixed-width-sm',
        ];
        $this->fields_list['name'] = [
            'title' => $this->module->l('Name'),
            'width' => 'auto',
            'filter_key' => 'a!name',
        ];

        $this->fields_list['enabled_amz_ps'] = [
            'title' => $this->module->l('Amazon Sync'),
            'align' => 'text-center',
            'active' => 'submitUpdateEnabledAmzToPs',
            'type' => 'bool',
            'ajax' => false,
            'orderby' => false,
            'search' => false,
        ];

        $this->fields_list['enabled_ps_amz'] = [
            'title' => $this->module->l('Prestashop Sync'),
            'align' => 'text-center',
            'active' => 'submitUpdateEnabledPsToAmz',
            'type' => 'bool',
            'ajax' => false,
            'orderby' => false,
            'search' => false,
        ];

        $this->fields_list['enabled_fba_ps'] = [
            'title' => $this->module->l('FBA Sync'),
            'align' => 'text-center',
            'active' => 'submitUpdateEnabledFbaToPs',
            'type' => 'bool',
            'ajax' => false,
            'orderby' => false,
            'search' => false,
        ];

        $this->toolbar_title = $this->module->l('Amazon Manufacturers');

        $this->warningCatalogFilter();
    }

    public function getList(
        $id_lang,
        $orderBy = null,
        $orderWay = null,
        $start = 0,
        $limit = null,
        $id_lang_shop = null
    ) {
        $id_lang_shop = Shop::isFeatureActive() && Shop::getContext() == Shop::CONTEXT_SHOP ?
            (int) $this->context->shop->id : 'sa.id_shop';
        parent::getList($id_lang, $orderBy, $orderWay, $start, $limit, $id_lang_shop);
    }

    public function postProcess()
    {
        if (Tools::isSubmit($this->table . 'Orderby') || Tools::isSubmit($this->table . 'Orderway')) {
            $this->filter = true;
        } elseif (Tools::isSubmit('submitUpdateEnabledPsToAmz' . $this->table)) {
            TooleAmazonMarketFilterManufacturer::updateEnabled(Tools::getValue('id_manufacturer'), null,
                TooleAmazonMarketFilterManufacturer::ENABLED_PS_AMZ, $this->entityId);
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitUpdateEnabledAmzToPs' . $this->table)) {
            TooleAmazonMarketFilterManufacturer::updateEnabled(Tools::getValue('id_manufacturer'), null,
                TooleAmazonMarketFilterManufacturer::ENABLED_AMZ_PS, $this->entityId);
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitUpdateEnabledFbaToPs' . $this->table)) {
            TooleAmazonMarketFilterManufacturer::updateEnabled(Tools::getValue('id_manufacturer'), null,
                TooleAmazonMarketFilterManufacturer::ENABLED_FBA_PS, $this->entityId);
            $this->redirectAdminToole();
        } elseif ((Tools::isSubmit('submitBulkenablePsToAmz' . $this->table) || Tools::isSubmit('submitBulkenableAmzToPs' . $this->table) || Tools::isSubmit('submitBulkenableFbaToPs' . $this->table)) && Tools::getValue($this->table . 'Box')) {
            $type = $this->getType();
            foreach ((array) Tools::getValue($this->table . 'Box') as $id_manufacturer) {
                TooleAmazonMarketFilterManufacturer::updateEnabled($id_manufacturer, 1, $type, $this->entityId);
            }
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitBulkenableAll' . $this->table) && Tools::getValue($this->table . 'Box')) {
            TooleAmazonMarketFilterManufacturer::enableAll(Tools::getValue($this->table . 'Box'), $this->shop_id, $this->shop_id_group, $this->entityId);
            $this->redirectAdminToole();
        } elseif ((Tools::isSubmit('submitBulkdisablePsToAmz' . $this->table) || Tools::isSubmit('submitBulkdisableAmzToPs' . $this->table) || Tools::isSubmit('submitBulkdisableFbaToPs' . $this->table)) && Tools::getValue($this->table . 'Box')) {
            $type = $this->getType();
            foreach ((array) Tools::getValue($this->table . 'Box') as $id_manufacturer) {
                TooleAmazonMarketFilterManufacturer::updateEnabled($id_manufacturer, 0, $type, $this->entityId);
            }
            $this->redirectAdminToole();
        }

        return parent::postProcess();
    }

    public function displayPreviewLink($token, $id)
    {
        $tpl = $this->createTemplate('list_action_preview.tpl');
        $tpl->assign([
            'href' => $this->context->link->getManufacturerLink(
                $id,
                null,
                null,
                null,
                $this->context->language->id
            ),
            'id_manufacturer' => $id,
        ]);

        return $tpl->fetch();
    }

    public function displayViewLink($token, $id)
    {
        $tpl = $this->createTemplate('list_action_cs_view.tpl');

        $tpl->assign([
            'href' => $this->context->link->getAdminLink('AdminManufacturers', true, ['action' => 'index', 'id_manufacturer' => (int) $id]),
        ]);

        return $tpl->fetch();
    }

    public function getType()
    {
        switch (true) {
            case Tools::isSubmit('submitBulkenablePsToAmz' . $this->table):
            case Tools::isSubmit('submitBulkdisablePsToAmz' . $this->table):
                return TooleAmazonMarketFilterManufacturer::ENABLED_PS_AMZ;
            case Tools::isSubmit('submitBulkenableFbaToPs' . $this->table):
            case Tools::isSubmit('submitBulkdisableFbaToPs' . $this->table):
                return TooleAmazonMarketFilterManufacturer::ENABLED_FBA_PS;
            default:
                return TooleAmazonMarketFilterManufacturer::ENABLED_AMZ_PS;
        }
    }
}
