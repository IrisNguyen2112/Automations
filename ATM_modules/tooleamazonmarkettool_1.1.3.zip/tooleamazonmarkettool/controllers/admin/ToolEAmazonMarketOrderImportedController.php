<?php
/**
 * ToolEAmazonMarketOrderImported
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\Model\Order as ISOrderModel;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderCancellation;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderFulfillment;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponse;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketOrderImportedController extends TooleBaseAdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->context = Context::getContext();
        $this->multishop = true;
        $this->tpl_folder = 'order/';
        $this->bootstrap = true;
        $this->list_no_link = true;
        $this->class_name = 'ToolEAmazonMarketOrderImported';

        $this->table = Database::TABLE_AMAZON_ORDERS;
        $this->identifier = 'id_order';
        $this->_defaultOrderBy = 'id_order';

        $ffCon = 'a.mp_status = "' . ISOrderModel::ORDER_STATUS_UNSHIPPED . '" OR a.mp_status = "' . ISOrderModel::ORDER_STATUS_PARTIALLY_SHIPPED . '"';
        $this->_select = ' o.date_add, IF(' . $ffCon . ', "#ffc107", "#4ad550") as fulfillable_color';
        $this->_join = ' INNER JOIN `' . _DB_PREFIX_ . 'orders` o ON o.id_order = a.ps_order_id';
        $this->_orderBy = 'a.id_order';
        $this->_orderWay = 'DESC';

        if ($this->availableMarketplaces) {
            $this->_where .= ' AND a.marketplace_id IN ("' . implode('","', $this->availableMarketplaces) . '")';
        }

        $this->fields_list = [
            'ps_order_id' => [
                'title' => $this->module->l('ID'),
                'align' => 'center',
                'class' => 'fixed-width-sm',
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
            ],
            'mp_order_id' => [
                'title' => $this->module->l('Order ID'),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'mp_status' => [
                'title' => $this->module->l('Amazon Order Status'),
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
                'order_key' => 'a!mp_status',
                'color' => 'fulfillable_color',
                'align' => 'center',
            ],
            'channel' => [
                'title' => $this->module->l('Channel'),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'marketplace_id' => [
                'title' => $this->module->l('Marketplace ID'),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'buyer_name' => [
                'title' => $this->module->l('Customer'),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'sales_channel' => [
                'title' => $this->module->l('Sales Channel'),
                'width' => 'auto',
                'orderby' => false,
                'search' => false,
                'align' => 'center',
            ],
            'date_add' => [
                'title' => $this->module->l('Imported date'),
                'width' => 100,
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'date',
                'align' => 'center',
            ],
            'is_prime' => [
                'title' => $this->module->l('Prime Order'),
                'width' => 'auto',
                'type' => 'bool',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
        ];

        // Handle the optional columns
        $currentOptionalColumns = json_decode(Configuration::get(OrderKey::CONFIG_IMPORTED_ORDERS_OPTIONAL_COLUMNS, null, null, null, '')) ?? [];
        $optional_fields_list = array_filter($this->module->order_import_optional_columns, function ($column) use ($currentOptionalColumns) {
            return in_array($column, $currentOptionalColumns);
        }, ARRAY_FILTER_USE_KEY);
        $this->fields_list = array_merge($this->fields_list, $optional_fields_list);

        $this->bulk_actions = [
            'fulfillAll' => [
                'text' => $this->module->l('Fulfill selected'),
                'confirm' => $this->module->l('Fulfill selected items?'),
                'icon' => 'icon-check',
            ],
            'divider' => [
                'text' => 'divider',
            ],
            'cancelMulti' => [
                'text' => $this->module->l('Cancel selected'),
                'icon' => 'icon-check',
            ],
        ];

        $lastImport = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_LAST_ORDER_IMPORT_TIME);
        if (!empty($lastImport) && !empty($lastImport[$this->active_region])) {
            $this->informations[] = sprintf('%s: %s', $this->module->l('Last Imported By Cron'), $lastImport[$this->active_region] ?? null);
        }

        $this->addRowAction('viewOrder');
        $this->addRowAction('fulfillment');
        $this->addRowAction('cancelOrder');
    }

    /**
     * @throws Exception
     */
    public function postProcess()
    {
        if (Tools::isSubmit('submitBulkfulfillAll' . $this->table)) {
            if (Tools::getValue($this->table . 'Box')) {
                $this->handleFulfill((array) Tools::getValue($this->table . 'Box'));
                $this->redirectAdminToole();
            }
        }

        if (Tools::isSubmit('submitBulkcancelMulti' . $this->table)) {
            if (Tools::getValue('success') && Tools::getValue('logId')) {
                $this->confirmations[] = '<a href="' . $this->context->link->getAdminLink('ToolEAmazonMarketLogsSummary') . '&id-log=' . Tools::getValue('logId') . '">' . $this->l('The orders cancellation process have completed. Details of the process are in the Activity Logs > Summaries') . '</a>';
                $this->redirectAdminToole();
            }

            if (Tools::getValue($this->table . 'Box')) {
                try {
                    $cancelReason = Tools::getValue('cancel_reason_name');

                    $this->handleCancelOrder((array) Tools::getValue($this->table . 'Box'), $cancelReason, true);

                    exit(new AjaxResponse($this->errors, $this->warnings, $this->confirmations, true, false,
                        [
                            'redirect' => $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported') .
                                '&submitBulkcancelMulti' . $this->table . '&success=1&logId=' . $this->module->log->getScheduler(),
                            'logId' => $this->module->log->getScheduler(),
                        ]
                    ));
                } catch (Exception $e) {
                    $this->module->log->error(sprintf('Error: %s', $e->getMessage()));

                    exit(new AjaxResponse($this->errors, [], [], true, false,
                        [
                            'logId' => $this->module->log->getScheduler(),
                        ]
                    ));
                }
            }
        }

        return parent::postProcess();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $cssLink = $this->module->getMediaLink('/views/css/order/imported_order.css');
        $this->context->controller->addCSS($cssLink);
    }

    public function displayCancelOrderLink($token, $id)
    {
        $teOrder = new TooleAmazonMarketAmazonOrder($id);
        $psOrder = new Order($teOrder->ps_order_id);
        if (Validate::isLoadedObject($psOrder)) {
            $disabled = false;
            $disabled_text = '';
            if ($teOrder->isAFNChannel() || $teOrder->mp_status == \Toole\Module\Amazon\Client\Model\Order::ORDER_STATUS_CANCELED) {
                $disabled_text = $this->module->l('Cancellation Unavailable - Cancelled by Amazon');
                $disabled = true;
            } elseif (!TooleAmazonMarketAmazonOrder::isExistingOrderItemByOrderId($teOrder->id_order)) {
                $disabled_text = $this->module->l('Cancellation Unavailable - Order Items not found');
                $disabled = true;
            } else {
                $cancelStatus = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_OUTGOING_ORDER_STATUS_CANCEL);
                if ($cancelStatus != $psOrder->getCurrentState()) {
                    $disabled_text = $this->module->l('Cancellation Unavailable - Incorrect Prestashop Status');
                    $disabled = true;
                }
            }

            return $this->context->smarty->createTemplate(
                $this->getTemplatePath() . 'order/cancel_link.tpl'
            )->assign([
                'action' => $this->module->l('Cancellation'),
                'disabled' => $disabled,
                'action_text' => $this->module->l('Cancel'),
                'action_disabled_text' => $disabled_text,
                'href' => $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported') .
                    $this->submit_action . '&id=' . $id . '&action=cancelOrder',
            ])->fetch();
        }

        return '';
    }

    public function displayViewOrderLink($token, $id)
    {
        $teOrder = new TooleAmazonMarketAmazonOrder($id);

        return $this->context->smarty->createTemplate($this->getTemplatePath() . 'order/view_order_link.tpl')
            ->assign([
                'action' => $this->module->l('View'),
                'href' => $this->context->link->getAdminLink('AdminOrders', true, [], ['id_order' => $teOrder->ps_order_id, 'vieworder' => 1]),
            ])->fetch();
    }

    /**
     * @throws PrestaShopException
     * @throws PrestaShopDatabaseException
     * @throws SmartyException
     */
    public function displayFulfillmentLink($token, $id)
    {
        $teOrder = new TooleAmazonMarketAmazonOrder($id);
        $psOrder = new Order($teOrder->ps_order_id);
        if (Validate::isLoadedObject($psOrder)) {
            $disabled = false;
            $disabled_text = '';
            if ($teOrder->isAFNChannel()) {
                $disabled_text = $this->module->l('Fulfillment Unavailable - Fulfilled by Amazon');
                $disabled = true;
            } elseif (!$teOrder->isFulfillable()) {
                $disabled_text = $this->module->l('Fulfillment Unavailable - Amazon Order Status Not Supported');
                $disabled = true;
            } else {
                $fulfillStatus = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_ORDER_STATUS_FULFILL);
                if ($fulfillStatus != $psOrder->getCurrentState()) {
                    $disabled_text = $this->module->l('Fulfillment Unavailable - Incorrect Prestashop Status');
                    $disabled = true;
                }
            }

            return $this->context->smarty->createTemplate(
                $this->getTemplatePath() . 'order/fulfill_link.tpl'
            )->assign([
                'action' => $this->module->l('Fulfillment'),
                'disabled' => $disabled,
                'action_text' => $this->module->l('Fulfill'),
                'action_disabled_text' => $disabled_text,
                'href' => $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported') .
                    $this->submit_action . '&id=' . $id . '&action=fulfillment',
            ])->fetch();
        }

        return '';
    }

    public function ajaxProcessFulfillment(): void
    {
        try {
            $id = Tools::getValue('id');
            $this->handleFulfill([$id], true);

            exit(new AjaxResponse([], $this->warnings, $this->confirmations, true, false,
                [
                    'mp_status' => ISOrderModel::ORDER_STATUS_SHIPPED,
                    'logId' => $this->module->log->getScheduler(),
                ]
            ));
        } catch (Exception $e) {
            $this->module->log->error(sprintf('Error: %s', $e->getMessage()));

            exit(new AjaxResponse($this->errors, [], [], true, false,
                [
                    'logId' => $this->module->log->getScheduler(),
                ]
            ));
        }
    }

    public function ajaxProcessCancelOrder(): void
    {
        try {
            $id = Tools::getValue('id');
            $cancelReason = Tools::getValue('cancel_reason_name');
            $teOrder = new TooleAmazonMarketAmazonOrder($id);

            $this->handleCancelOrder([$id], $cancelReason, true);

            exit(new AjaxResponse([], $this->warnings, $this->confirmations, true, false,
                [
                    'mp_status' => ISOrderModel::ORDER_STATUS_CANCELED,
                    'logId' => $this->module->log->getScheduler(),
                    'redirect' => $this->context->link->getAdminLink('AdminOrders', true, [], ['id_order' => $teOrder->ps_order_id, 'vieworder' => 1, 'amtAction' => 'cancelOrder', 'success' => 1])
                ]
            ));
        } catch (Exception $e) {
            $this->module->log->error(sprintf('Error: %s', $e->getMessage()));

            exit(new AjaxResponse($this->errors, [], [], true, false,
                [
                    'logId' => $this->module->log->getScheduler(),
                ]
            ));
        }
    }

    public function processCancelOrder(): void
    {
        $id = Tools::getValue('id');
        $cancelReason = Tools::getValue('cancel_reason_name');

        $this->handleCancelOrder([$id], $cancelReason);
        $this->redirectAdminToole();
    }

    public function handleCancelOrder($ids, $cancelReason, $isAjax = false)
    {
        if (is_array($ids) && count($ids) > 0) {
            $isSingle = 1 === count($ids);
            $this->module->log->setLog(sprintf('Cancellation Order ID(s) (%s)', implode(',', $ids)));
            $cancelOrder = new OrderCancellation($this->saasHelper, $ids, $this->module, false, $cancelReason);
            try {
                $cancelOrder->doCancel();
                $this->module->log->error($cancelOrder->getErrors())->warning($cancelOrder->getWarnings());
                $this->errors = array_merge($this->errors, $cancelOrder->getErrors());
                $this->warnings = array_merge($this->warnings, $cancelOrder->getWarnings());
                if (!$this->errors && !$this->warnings) {
                    if ($isSingle) {
                        $this->confirmations[] = '<a style="color: blue;" href="' . $this->context->link->getAdminLink('ToolEAmazonMarketLogsSummary') . '&id-log=' . $this->module->log->getScheduler() . '">' . $this->module->l('The order cancellation process has completed. Details of the process are in the Activity Logs > Summaries') . '</a>';
                    } else {
                        $this->confirmations[] = '<a style="color: blue;" href="' . $this->context->link->getAdminLink('ToolEAmazonMarketLogsSummary') . '&id-log=' . $this->module->log->getScheduler() . '">' . $this->module->l('The orders cancellation process have completed. Details of the process are in the Activity Logs > Summaries') . '</a>';
                    }
                }
            } catch (Exception $e) {
                $this->module->log->error(sprintf('Error: %s', $e->getMessage()));
                $this->errors[] = sprintf('An unexpected error has occurred: %s', $e->getMessage());
            }
        } else {
            $this->errors[] = $this->module->l('Unable to cancel order');
        }

        if (!$isAjax) {
            $this->redirectAdminToole();
        }
    }

    /**
     * @throws Exception
     */
    public function processFulfillment(): void
    {
        $id = Tools::getValue('id');
        $this->handleFulfill([$id]);
        $this->redirectAdminToole();
    }

    /**
     * @throws Exception
     */
    public function handleFulfill($ids, $isAjax = false)
    {
        if (is_array($ids) && count($ids) > 0) {
            $isSingle = 1 === count($ids);
            $this->module->log->setLog(sprintf('Fulfillment Order ID(s) (%s)', implode(',', $ids)));
            $fulfillOrder = new OrderFulfillment($this->saasHelper, $ids, $this->module);
            try {
                $fulfillOrder->doFulfill();
                $this->module->log->error($fulfillOrder->getErrors())->warning($fulfillOrder->getWarnings());
                $this->errors = array_merge($this->errors, $fulfillOrder->getErrors());
                $this->warnings = array_merge($this->warnings, $fulfillOrder->getWarnings());
                if (!$this->errors && !$this->warnings) {
                    $confirmation = $isSingle
                        ? $this->module->l('The order fulfillment process has completed. Details of the process are in the Activity Logs > Summaries')
                        : $this->module->l('The orders fulfillment process have completed. Details of the process are in the Activity Logs > Summaries');
                    $this->confirmations[] = '<a href="' . $this->context->link->getAdminLink('ToolEAmazonMarketLogsSummary', true, [], ['id-log' => $this->module->log->getScheduler()]) . '">' .
                        $confirmation . '</a>';
                }
            } catch (Exception $e) {
                $this->module->log->error(sprintf('Error: %s', $e->getMessage()))->error($e->getTraceAsString());
                $this->errors[] = sprintf('An unexpected error has occurred: %s', $e->getMessage());
                $this->errors[] = $e->getTraceAsString();
            }
        } else {
            $this->errors[] = $this->module->l('Unable to fulfill order');
        }

        if (!$isAjax) {
            $this->redirectAdminToole();
        }
    }

    public function processSaveOptionalColumns(): void
    {
        $optionalColumns = Tools::getValue('optionalColumns', []);
        Configuration::updateValue(OrderKey::CONFIG_IMPORTED_ORDERS_OPTIONAL_COLUMNS, json_encode(array_values($optionalColumns)));
        $this->redirectAdminToole();
    }
}
