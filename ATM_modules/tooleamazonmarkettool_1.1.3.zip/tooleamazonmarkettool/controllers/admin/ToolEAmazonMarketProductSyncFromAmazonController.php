<?php
/**
 * ToolEAmazonMarketProductSyncFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\ReportType;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\CatalogSyncFromAmazon;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Log\Log;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponse;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketProductSyncFromAmazonController extends TooleBaseAdminController
{
    private $entityId;

    protected $isFBA = false;
    protected $reportTypeName = 'Amazon';
    protected $importedCtl = 'ToolEAmazonMarketProductsImportedFromAmazon';
    protected $reportTypeAmazonApi = ReportType::GET_MERCHANT_LISTINGS_ALL_DATA;
    protected $lastFetchReport = ConfigurationConstant::AMT_START_TIME_REPORT_LISTINGS_ALL_DATA;

    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'catalog/amazon_sync/';
        $this->tpl_folder = 'catalog/amazon_sync/';
        $this->bootstrap = true;
        $this->class_name = 'ToolEAmazonMarketProductSyncFromAmazon';
        $this->module->log = new Log(Tools::getValue('logId', null));
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitBulksyncAll' . $this->table)) {
            $ids = Tools::getValue('idBox');
            if (!empty($ids) && $this->entityId) {
                $this->module->log->setLog(sprintf('Start bulk synchronizing all amazon products'));
                $productType = $this->isFBA ? TooleAmazonMarketAmazonProduct::FBA_PRODUCT : TooleAmazonMarketAmazonProduct::AMAZON_PRODUCT;
                foreach ($ids as $id) {
                    TooleAmazonMarketAmazonProduct::syncProduct($id, $this->entityId, $productType, $this->module->log);
                }
            }
            $this->redirectAdminToole();
        }
        parent::postProcess();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $cssLink = $this->module->getMediaLink('/views/css/catalog/amazon_sync.css');
        $jsLink = $this->module->getMediaLink('/views/js/catalog/amazon_sync.js?v=' . $this->module->version);
        $this->context->controller->addCSS($cssLink);
        $this->context->controller->addJS($jsLink);
    }

    public function renderList()
    {
        $lastStatistic = Configuration::get(Key::LAST_STATISTICS_REPORT_DATA, null, $this->shop_id_group, $this->shop_id);
        if ($lastStatistic) {
            $lastStatistic = json_decode($lastStatistic);
            $lastReport = $lastStatistic->{$this->reportTypeAmazonApi['name']} ?? null;
            $statistic = $lastReport->{$this->active_marketplace} ?? null;

            if ($statistic) {
                $flow = new CatalogSyncFromAmazon($this->module, $this->saasHelper, Tools::getShopDomain(), null, $this->reportTypeAmazonApi, null, $this->entityId, $this->isFBA);

                // add warning for inactive item count
                // $flow->addWarningForInactiveItemCount($statistic->inactiveItemCount);

                if ($statistic->inactiveItemCount == 1) {
                    $warnings[] = $this->module->l('1 inactive item has been filtered out');
                } elseif ($statistic->inactiveItemCount > 1) {
                    $warnings[] = sprintf(
                        $this->module->l('%d inactive items have been filtered out'),
                        $statistic->inactiveItemCount
                    );
                }

                // add Warning For Rejected Not Exist Count
                // $flow->addWarningForRejectedNotExistCount($statistic->rejectedNotExist);
                if (!$statistic->rejectedNotExist) {
                    $warnings[] = $this->module->l('1 Amazon offer has been ignored because it does not exist in Prestashop');
                } elseif ($statistic->rejectedNotExist > 1) {
                    $warnings[] = sprintf(
                        $this->module->l('%d Amazon offers have been ignored because they do not exist in Prestashop'),
                        $statistic->rejectedNotExist
                    );
                }

                // add Warning For Rejected Not Enable Sync Count
                // $flow->addWarningForRejectedNotEnableSyncCount($statistic->rejectedNotEnableSync);
                if ($statistic->rejectedNotEnableSync === 1) {
                    $warnings[] = $this->module->l('1 Amazon offer has been ignored because sync is not enabled for this product.');
                } elseif ($statistic->rejectedNotEnableSync > 1) {
                    $warnings[] = sprintf(
                        $this->module->l('%d Amazon offers have been ignored because sync is not enabled.'),
                        $statistic->rejectedNotEnableSync
                    );
                }

                // add warning / confirmation for imported offers
                // $flow->addNotificationsForImportedOffers($statistic->imported);
                if ($statistic->imported < 1) {
                    $warnings[] = $this->module->l('No offers have been imported');
                } elseif ($statistic->imported == 1) {
                    $confirmations[] = $this->module->l('1 Amazon offer has been imported');
                } else {
                    $confirmations[] = sprintf(
                        $this->module->l('%d Amazon offers have been imported'),
                        $statistic->imported
                    );
                }

                $lastFetch = AmazonMarketConfiguration::get($this->lastFetchReport);
                if ($lastFetch) {
                    $lastFetch = gmdate('Y-m-d H:i:s', is_int($lastFetch) ? $lastFetch : strtotime($lastFetch));
                    $infos[] = sprintf(
                        $this->module->l('The last statistic report was fetched at %s'),
                        $lastFetch
                    );
                }
                $lastReportMsgs = [
                    'infos' => $infos ?? [],
                    'errors' => $flow->getErrors(),
                    'warnings' => $warnings ?? [],
                    'confirmations' => $confirmations ?? [],
                ];
            }
        }

        return $this->context->smarty->createTemplate(
            $this->getTemplatePath() . 'catalog/amazon_sync/manual_sync.tpl'
        )->assign([
            'img_loader' => $this->images . 'loading.gif',
            'imported_tab' => $this->context->link->getAdminLink($this->importedCtl),
            'lastReportMsgs' => $lastReportMsgs ?? [],
        ])->fetch();
    }

    public function ajaxProcessFetchData()
    {
        $this->module->log->setLog(sprintf('Refresh the offer list from %s.', $this->reportTypeName));
        $uuid = Tools::getValue('uuid', '');
        $additionalParams = Tools::getValue('params', []);
        if ($uuid) {
            // All subsequence calls must wait for the report to complete
            sleep(15);
        }

        $reportType = $this->reportTypeAmazonApi;
        $flow = new CatalogSyncFromAmazon($this->module, $this->saasHelper, Tools::getShopDomain(), $uuid, $reportType, null, $this->entityId, $this->isFBA, $additionalParams);
        try {
            if ($flow->requestReport()) {
                $this->module->log->message([
                    'Processing data, please wait.',
                    sprintf('uuid: %s', $flow->getReportResult()->getUuid()),
                    'action: parseData',
                    sprintf('resourceUrl: %s', $flow->getReportResult()->getDocumentUrl()),
                    sprintf('contentType: %s', $reportType['contentType']),
                    sprintf('compressAlgorithm: %s', $flow->getReportResult()->getDocumentCompressionAlgorithm()),
                ]);
                exit(new AjaxResponse(
                    [], [],
                    [$this->module->l('Processing data, please wait.')],
                    true,
                    true,
                    [
                        'uuid' => $flow->getReportResult()->getUuid(),
                        'action' => 'parseData',
                        'resourceUrl' => $flow->getReportResult()->getDocumentUrl(),
                        'contentType' => $reportType['contentType'],
                        'compressAlgorithm' => $flow->getReportResult()->getDocumentCompressionAlgorithm(),
                        'data' => $flow->getReportResult()->getData(),
                        'logId' => $this->module->log->getScheduler(),
                    ]
                ));
            }

            $this->module->log->message([
                'Retrieving data, please wait.',
                sprintf('uuid: %s', $flow->getReportResult()->getUuid()),
            ]);
            exit(new AjaxResponse(
                [],
                [],
                [$this->module->l('Retrieving data, please wait.')],
                true,
                true,
                [
                    'uuid' => $flow->getReportResult()->getUuid(),
                    'logId' => $this->module->log->getScheduler(),
                ]
            ));
        } catch (Exception $exception) {
            $this->module->log->error(sprintf('Failed to retrieve data from %s: %s', $this->reportTypeName, $exception->getMessage()));

            if ($flow->getReportResult()) {
                $errMsg = sprintf(
                    $this->module->l('Processing Status: %s'),
                    $flow->getReportResult()->getProcessingStatus()
                );
                $this->module->log->error($errMsg);
            }

            if ($this->isFBA) {
                $message = $this->module->l('Failed to retrieve data from FBA');
            } else {
                $message = $this->module->l('Failed to retrieve data from Amazon');
            }
            exit(new AjaxResponse(
                [$message, $exception->getMessage(), $errMsg ?? ''],
                [], [], true, false, ['logId' => $this->module->log->getScheduler()]
            ));
        }
    }

    public function ajaxProcessParseData()
    {
        $this->module->log->setLog('Processing product list');
        $data = Tools::getValue('data');
        $contentType = Tools::getValue('contentType');
        $uuid = Tools::getValue('uuid');
        if (!$data) {
            $this->module->log->error('Invalid request');
            exit(new AjaxResponse(
                [$this->module->l('Invalid request')],
                [], [], true, false, ['logId' => $this->module->log->getScheduler()]
            ));
        }
        $page = (int) $data['next_page'] ?? null;

        $flow = new CatalogSyncFromAmazon($this->module, $this->saasHelper, Tools::getShopDomain(), $uuid, $this->reportTypeAmazonApi, null, $this->entityId, $this->isFBA);
        try {
            $flow->importAmazonOffers($data['data'] ?? []); // parse data

            if ($page > 0) { // get parse data with next_page
                $response = new AjaxResponse(
                    $flow->getErrors(),
                    $flow->getWarnings(),
                    $flow->getConfirmations(),
                    true,
                    false,
                    [
                        'statistics' => $flow->getStatistic(),
                        'logId' => $this->module->log->getScheduler(),
                    ]
                );
                $this->module->log->extractFromAjaxResponse($response);

                $statistics = $flow->updateStatistics($flow->getStatistic(), $data['statistic'] ?? []);
                exit(new AjaxResponse(
                    $flow->getErrors(),
                    $flow->getWarnings(),
                    $flow->getConfirmations(),
                    true,
                    true,
                    [
                        'uuid' => $uuid,
                        'action' => 'fetchData',
                        'contentType' => $contentType,
                        'params' => ['page' => $page, 'statistic' => $statistics],
                        'logId' => $this->module->log->getScheduler(),
                    ]
                ));
            }
        } catch (Exception $exception) {
            $this->module->log->error($exception->getMessage());
            exit(new AjaxResponse([$exception->getMessage()], [], [], true, false, ['logId' => $this->module->log->getScheduler()]));
        }

        // Update is_mapped all record after import
        $productType = $this->isFBA ? TooleAmazonMarketAmazonProduct::FBA_PRODUCT : TooleAmazonMarketAmazonProduct::AMAZON_PRODUCT;
        $products = TooleAmazonMarketAmazonProduct::getTooleProductsWithMappingStatus($this->entityId, $productType) ?? [];
        foreach ($products as $product) {
            TooleAmazonMarketAmazonProduct::markAsNotSyncAndUpdateMappingStatus($product['id'], $product['mapping_status']);
        }

        /* storage last statistic report data */
        $flow->storageLastStatisticReportData($this->active_marketplace, $data['statistic'] ?? []);

        $response = new AjaxResponse(
            $flow->getErrors(),
            $flow->getWarnings(),
            $flow->getConfirmations(),
            true,
            false,
            [
                'statistics' => $flow->getStatistic(),
                'logId' => $this->module->log->getScheduler(),
            ]
        );
        $this->module->log->extractFromAjaxResponse($response);

        AmazonMarketConfiguration::updateValue($this->lastFetchReport, time());

        exit($response);
    }
}
