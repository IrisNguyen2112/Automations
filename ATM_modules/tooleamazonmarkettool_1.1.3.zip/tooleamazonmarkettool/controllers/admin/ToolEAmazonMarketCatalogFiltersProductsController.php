<?php
/**
 *  2023 TOOLE - Inter-soft.COM
 *  All rights reserved.
 *
 *  DISCLAIMER
 *
 *  Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketCatalogFiltersProductsController extends TooleBaseAdminController
{
    private $entityId;

    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'catalog/filters/';
        $this->tpl_folder = 'catalog/filters/';
        $this->bootstrap = true;
        $this->table = 'product';
        $this->identifier = 'id_product';
        $this->submit_action = 'submitAdd' . $this->table;
        $this->class_name = 'ToolEAmazonMarketCatalogFiltersProducts';
        $this->lang = true;
        $this->deleted = false;
        $this->colorOnBackground = false;

        $this->explicitSelect = true;
        $this->addRowAction('view');
        $this->addRowAction('preview');
        if (!Tools::getValue('id_product')) {
            $this->multishop_context_group = false;
        }
        $this->imageType = 'gif';
        $this->fieldImageSettings = [
            'name' => 'icon',
            'dir' => 'os',
        ];
        $this->_defaultOrderBy = $this->identifier = 'id_product';
        $this->deleted = false;
        $this->list_no_link = true;
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);

        $categories = Category::getAllCategoriesName(
            2,
            $this->context->language->id,
            false
        );

        $category_array = [];
        foreach ($categories as $row) {
            $category_array[$row['id_category']] = $row['name'];
        }

        $this->_select .=
            'shop.`name` AS `shop_name`,a.`id_shop_default`,a.`id_category_default`,cl.name as category_name,';

        $this->_join =
            ' JOIN `' . _DB_PREFIX_ . 'product_shop` sa ON
            (a.`id_product` = sa.`id_product` AND sa.id_shop = ' . $this->shop_id . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` pq ON
            (pq.id_product = a.`id_product` AND pq.id_shop = ' . $this->shop_id . ' AND pq.id_entity = ' . $this->entityId . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` ae ON
            (pq.id_entity = ae.`id_entity`)
            LEFT JOIN `' . _DB_PREFIX_ . 'category_lang` cl ON
            (cl.id_lang = ' . (int) $this->context->language->id . ' AND
            cl.id_category = a.id_category_default AND cl.id_shop =' . $this->shop_id . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'shop` shop ON
            (shop.id_shop = ' . $this->shop_id . ')';

        $this->bulk_actions = [
            'enableAmzToPs' => [
                'text' => $this->module->l('Amazon - Enable selected'),
                'confirm' => $this->module->l('Enable selected items?'),
                'icon' => 'icon-check',
            ],
            'disableAmzToPs' => [
                'text' => $this->module->l('Amazon - Disable selected'),
                'confirm' => $this->module->l('Disable selected items?'),
                'icon' => 'icon-times',
            ],
            'divider' => [
                'text' => 'divider',
            ],
            'enablePsToAmz' => [
                'text' => $this->module->l('Prestashop - Enable selected'),
                'confirm' => $this->module->l('Enable selected items?'),
                'icon' => 'icon-check',
            ],
            'disablePsToAmz' => [
                'text' => $this->module->l('Prestashop -  Disable selected'),
                'confirm' => $this->module->l('Disable selected items?'),
                'icon' => 'icon-times',
            ],
            'divider2' => [
                'text' => 'divider',
            ],
            'enableFbaToPs' => [
                'text' => $this->module->l('FBA - Enable selected'),
                'confirm' => $this->module->l('Enable selected items?'),
                'icon' => 'icon-check',
            ],
            'disableFbaToPs' => [
                'text' => $this->module->l('FBA -  Disable selected'),
                'confirm' => $this->module->l('Disable selected items?'),
                'icon' => 'icon-times',
            ],
            'divider3' => [
                'text' => 'divider',
            ],
            'enableAll' => [
                'text' => $this->module->l('ENABLE ALL'),
                'confirm' => $this->module->l('Enable all products?'),
                'icon' => 'icon-check',
            ],
        ];

        $this->fields_list = [];
        $this->fields_list['id_product'] = [
            'title' => $this->module->l('Id'),
            'align' => 'text-center',
            'class' => 'fixed-width-sm',
        ];
        $this->fields_list['name'] = [
            'title' => $this->module->l('Name'),
            'width' => 'auto',
            'filter_key' => 'b!name',
        ];
        $this->fields_list['category_name'] = [
            'title' => $this->module->l('Default Category'),
            'width' => 'auto',
            'color' => 'color',
            'type' => 'select',
            'list' => $category_array,
            'filter_key' => 'a!id_category_default',
            'filter_type' => 'int',
            'order_key' => 'category_name',
        ];

        $this->fields_list['reference'] = [
            'title' => $this->module->l('Reference'),
            'width' => 'auto',
            'filter_key' => 'a!reference',
        ];

        $this->fields_list['enabled_amz_ps'] = [
            'title' => $this->module->l('Amazon Sync'),
            'align' => 'text-center',
            'active' => 'submitUpdateEnabledAmzToPs',
            'type' => 'bool',
            'ajax' => false,
            'orderby' => false,
            'search' => false,
        ];

        $this->fields_list['enabled_ps_amz'] = [
            'title' => $this->module->l('Prestashop Sync'),
            'align' => 'text-center',
            'active' => 'submitUpdateEnabledPsToAmz',
            'type' => 'bool',
            'ajax' => false,
            'orderby' => false,
            'search' => false,
        ];

        $this->fields_list['enabled_fba_ps'] = [
            'title' => $this->module->l('FBA Sync'),
            'align' => 'text-center',
            'active' => 'submitUpdateEnabledFbaToPs',
            'type' => 'bool',
            'ajax' => false,
            'orderby' => false,
            'search' => false,
        ];

        if (Shop::isFeatureActive() && Shop::getContext() != Shop::CONTEXT_ALL) {
            $this->fields_list['shop_name'] = [
                'title' => $this->module->l('Store'),
                'filter_key' => 'shop!name',
                'order_key' => 'shop_name',
            ];
        }

        $this->toolbar_title = $this->module->l('Amazon Products');

        $this->warningCatalogFilter();
    }

    public function getList(
        $id_lang,
        $orderBy = null,
        $orderWay = null,
        $start = 0,
        $limit = null,
        $id_lang_shop = null
    ) {
        $id_lang_shop = Shop::isFeatureActive() && Shop::getContext() == Shop::CONTEXT_SHOP ?
            (int) $this->context->shop->id : 'a.id_shop_default';
        parent::getList($id_lang, $orderBy, $orderWay, $start, $limit, $id_lang_shop);
    }

    public function postProcess()
    {
        if (Tools::isSubmit($this->table . 'Orderby') || Tools::isSubmit($this->table . 'Orderway')) {
            $this->filter = true;
        } elseif (Tools::isSubmit('submitUpdateEnabledPsToAmz' . $this->table)) {
            TooleAmazonMarketFilterProduct::updateEnabled(Tools::getValue('id_product'), null,
                TooleAmazonMarketFilterProduct::ENABLED_PS_AMZ, $this->entityId);
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitUpdateEnabledAmzToPs' . $this->table)) {
            TooleAmazonMarketFilterProduct::updateEnabled(Tools::getValue('id_product'), null,
                TooleAmazonMarketFilterProduct::ENABLED_AMZ_PS, $this->entityId);
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitUpdateEnabledFbaToPs' . $this->table)) {
            TooleAmazonMarketFilterProduct::updateEnabled(Tools::getValue('id_product'), null,
                TooleAmazonMarketFilterProduct::ENABLED_FBA_PS, $this->entityId);
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitBulkenableAll' . $this->table) && Tools::getValue($this->table . 'Box')) {
            TooleAmazonMarketFilterProduct::enableAll(Tools::getValue($this->table . 'Box'), $this->shop_id, $this->shop_id_group, $this->entityId);
            $this->redirectAdminToole();
        } elseif ((Tools::isSubmit('submitBulkenablePsToAmz' . $this->table) || Tools::isSubmit('submitBulkenableAmzToPs' . $this->table) || Tools::isSubmit('submitBulkenableFbaToPs' . $this->table)) && Tools::getValue($this->table . 'Box')) {
            $type = $this->getType();
            foreach ((array) Tools::getValue($this->table . 'Box') as $id_product) {
                TooleAmazonMarketFilterProduct::updateEnabled($id_product, 1, $type, $this->entityId);
            }
            $this->redirectAdminToole();
        } elseif ((Tools::isSubmit('submitBulkdisablePsToAmz' . $this->table) || Tools::isSubmit('submitBulkdisableAmzToPs' . $this->table) || Tools::isSubmit('submitBulkdisableFbaToPs' . $this->table)) && Tools::getValue($this->table . 'Box')) {
            $type = $this->getType();
            foreach ((array) Tools::getValue($this->table . 'Box') as $id_product) {
                TooleAmazonMarketFilterProduct::updateEnabled($id_product, 0, $type, $this->entityId);
            }
            $this->redirectAdminToole();
        }

        return parent::postProcess();
    }

    public function displayViewLink($token, $id)
    {
        $tpl = $this->createTemplate('list_action_cs_view.tpl');

        $tpl->assign([
            'href' => $this->context->link->getAdminLink('AdminProducts', true, ['id_product' => (int) $id]),
        ]);

        return $tpl->fetch();
    }

    public function displayPreviewLink($token, $id)
    {
        $tpl = $this->createTemplate('list_action_preview.tpl');
        $tpl->assign([
            'href' => $this->context->link->getProductLink(
                $id,
                null,
                null,
                null,
                $this->context->language->id
            ),
            'id_product' => $id,
        ]);

        return $tpl->fetch();
    }

    public function getType()
    {
        switch (true) {
            case Tools::isSubmit('submitBulkenablePsToAmz' . $this->table):
            case Tools::isSubmit('submitBulkdisablePsToAmz' . $this->table):
                return TooleAmazonMarketFilterProduct::ENABLED_PS_AMZ;
            case Tools::isSubmit('submitBulkenableFbaToPs' . $this->table):
            case Tools::isSubmit('submitBulkdisableFbaToPs' . $this->table):
                return TooleAmazonMarketFilterProduct::ENABLED_FBA_PS;
            default:
                return TooleAmazonMarketFilterProduct::ENABLED_AMZ_PS;
        }
    }
}
