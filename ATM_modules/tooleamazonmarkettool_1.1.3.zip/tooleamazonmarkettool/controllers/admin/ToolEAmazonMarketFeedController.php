<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\PsGetFeedSubmissionResult;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketFeedController extends TooleBaseAdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->context = Context::getContext();
        $this->bootstrap = true;
        $this->list_no_link = true;
        $this->class_name = 'ToolEAmazonMarketFeed';
        $this->multishop = true;
        $this->override_folder = 'logs/feeds/';
        $this->tpl_folder = 'logs/feeds/';

        $this->table = Database::TABLE_FEEDS;
        $this->list_id = 'id';
        $this->identifier = 'id';
        $this->_select = ' IF(status = 1, "Submitted", "Done") as status, IF(status = 1, "#e0e045", "#34a84c") as color
        , "#e51a1a" as error_color, "#e0d859" as warning_color, "#4ad550" as success_color';
        $this->_orderBy = 'id';
        $this->_orderWay = 'DESC';
        $this->fields_list = [
            'id' => [
                'title' => $this->module->l('Id'),
                'align' => 'center',
                'class' => 'fixed-width-sm',
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
                'filter_key' => 'a!id',
            ],
            'marketplace_id' => [
                'title' => $this->module->l('Marketplace'),
                'align' => 'center',
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
                'filter_key' => 'a!marketplace_id',
            ],
            'feed_type' => [
                'title' => $this->module->l('Type'),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'a!feed_type',
            ],
            'feed_id' => [
                'title' => $this->module->l('Feed ID'),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'a!feed_id',
            ],
            'status' => [
                'title' => $this->module->l('Status'),
                'width' => 'auto',
                'orderby' => false,
                'search' => false,
                'color' => 'color',
            ],
            'messages_status_code' => [
                'title' => $this->module->l('Status Code'),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'a!messages_status_code',
            ],
            'messages_processed' => [
                'title' => $this->module->l('Processed'),
                'width' => 'auto',
                'align' => 'center',
                'orderby' => false,
                'search' => false,
                'filter_key' => 'a!messages_processed',
            ],
            'messages_successful' => [
                'title' => $this->module->l('Successful'),
                'width' => 'auto',
                'align' => 'center',
                'orderby' => false,
                'search' => false,
                'filter_key' => 'a!messages_successful',
                'color' => 'success_color',
            ],
            'messages_with_error' => [
                'title' => $this->module->l('Errors'),
                'width' => 'auto',
                'align' => 'center',
                'orderby' => false,
                'search' => false,
                'filter_key' => 'a!messages_with_error',
                'color' => 'error_color',
            ],
            'messages_with_warning' => [
                'title' => $this->module->l('Warnings'),
                'width' => 'auto',
                'align' => 'center',
                'orderby' => false,
                'search' => false,
                'filter_key' => 'a!messages_with_warning',
                'color' => 'warning_color',
            ],
            'date_add' => [
                'title' => $this->module->l('Created Date'),
                'width' => 80,
                'class' => 'fixed-width-sm',
                'orderby' => true,
                'search' => true,
                'type' => 'datetime',
                'filter_key' => 'a!date_add',
            ],
        ];

        $this->addRowAction('downloadFeedSubmission');
        $this->addRowAction('downloadFeedResult');
    }

    public function displayDownloadFeedSubmissionLink($token, $id)
    {
        // Fetch all, not filter by date
        $sql = (new DbQuery())->from(Database::TABLE_FEEDS, 'f')
            ->select('f.`date_add`')
            ->where('f.`id` = ' . $id);
        $feedDate = Db::getInstance()->getValue($sql);

        if (empty($feedDate)) {
            return '';
        }

        return $this->createTemplate('download_link.tpl')
            ->assign([
                'action' => $this->module->l('Feed'),
                'href' => $this->context->link->getAdminLink('ToolEAmazonMarketFeed') .
                    $this->submit_action . '&id=' . $id . '&action=downloadFeed&token=' .
                    $this->token,
            ])->fetch();
    }

    public function displayDownloadFeedResultLink($token, $id)
    {
        $sql = (new DbQuery())->from(Database::TABLE_FEEDS, 'f')
            ->select('f.`status`, f.`messages_status_code`')
            ->where('f.`id` = ' . $id);
        $row = Db::getInstance()->getRow($sql);
        $status = $row['status'];
        $statusCode = $row['messages_status_code'];

        $disabled = $status == TooleAmazonMarketAmazonFeed::SENT_STATUS || !$statusCode;

        return $this->createTemplate('download_result_link.tpl')
            ->assign([
                'disabled' => $disabled,
                'action' => $this->module->l('Result'),
                'href' => $this->context->link->getAdminLink('ToolEAmazonMarketFeed', true, [], ['id' => $id, 'action' => 'downloadResult'])
                    . $this->submit_action,
            ])->fetch();
    }

    /**
     * @throws Exception
     */
    public function processDownloadFeed(): void
    {
        $sql = new DbQuery();
        $sql->from(Database::TABLE_FEEDS, 'f');
        $sql->select('f.`content_location`');
        $sql->where('f.`id` = ' . Tools::getValue('id'));

        if ($link = Db::getInstance()->getValue($sql)) {
            $this->downloadFile($link);
        } else {
            $this->errors[] = $this->module->l('Download not found');
            $this->redirectAdminToole();
        }
    }

    /**
     * @throws Exception
     */
    public function processDownloadResult(): void
    {
        $sql = new DbQuery();
        $sql->from(Database::TABLE_FEEDS, 'f');
        $sql->select('f.`result_location`');
        $sql->where('f.`id` = ' . Tools::getValue('id'));

        if ($link = Db::getInstance()->getValue($sql)) {
            $this->downloadFile($link);
        } else {
            $this->errors[] = $this->module->l('Download not found');
            $this->redirectAdminToole();
        }
    }

    private function downloadFile($url): void
    {
        try {
            header('Content-Type: text/xml');
            header('Content-Disposition: attachment; filename=' . basename($url));
            // PHP readfile() causing corrupt file downloads
            // https://stackoverflow.com/questions/13311790/php-readfile-causing-corrupt-file-downloads
            while (ob_get_level()) {
                ob_end_clean();
            }
            flush();
            readfile($url);

            exit;
        } catch (Exception $e) {
            $this->errors[] = $e->getMessage();
            $this->redirectAdminToole();
        }
    }

    public function initPageHeaderToolbar(): void
    {
        $this->page_header_toolbar_btn['toole_feed_request'] = [
            'href' => $this->context->link->getAdminLink('ToolEAmazonMarketFeed') .
                $this->submit_action . '&action=getSubmission&token=' .
                $this->token,
            'desc' => $this->module->l('Get Feed Submission Result'),
            'icon' => 'process-icon-download',
        ];

        parent::initPageHeaderToolbar();
    }

    public function processGetSubmission(): void
    {
        $res = PsGetFeedSubmissionResult::getFeedSubmissionResult();
        $this->{$res['status'] ? 'confirmations' : 'errors'} = $res['message'];
        $this->redirectAdminToole();
    }
}
