<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use PrestaShop\PrestaShop\Core\Domain\Product\ValueObject\ProductType;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketProductsImportedFromAmazonController extends TooleBaseAdminController
{
    const MAPPING_NOT_EXIST_ON_PS = 0;
    const MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED = 1;
    const MAPPING_EXIST_ON_PS_AND_ENABLED = 2;
    protected $entityId;
    protected $isFBA = false;
    protected $productType = TooleAmazonMarketAmazonProduct::AMAZON_PRODUCT;
    protected $lastFetchReport = ConfigurationConstant::AMT_START_TIME_REPORT_LISTINGS_ALL_DATA;
    protected $mappingName;

    public static $errorMsgs = [];
    public static $warningMsgs = [];
    public static $orders = [];

    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'catalog/amazon_sync/';
        $this->tpl_folder = 'catalog/amazon_sync/';
        $this->bootstrap = true;
        $this->class_name = 'TooleAmazonMarketAmazonProduct';

        $this->table = Database::TABLE_AMAZON_PRODUCTS;
        $this->identifier = 'id';
        $this->colorOnBackground = false;
        $this->multishop = true;
        $this->toolbar_title = $this->module->l('Amazon Products');
        $this->_defaultOrderBy = 'id';
        $this->list_id = 'id';
        $this->use_distinct = true;
        $this->_use_found_rows = false;
        $this->list_no_link = true;
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);
        $this->mappingName = [
            TooleAmazonMarketAmazonProduct::MAPPING_NOT_EXIST_ON_PS => $this->module->l('Unavailable'),
            TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED => $this->module->l('Not enabled'),
            TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_AND_ENABLED => $this->module->l('Can be synced'),
        ];

        $this->bulk_actions = [
            'syncAll' => [
                'text' => $this->module->l('Sync Selected'),
                'confirm' => $this->module->l('Are you sure you want to synchronize all selected products?'),
            ],
            'createAll' => [
                'text' => $this->module->l('Create Selected'),
                'confirm' => $this->module->l('Are you sure you want to create all selected products?'),
            ],
        ];
        $this->_orderBy = 'id';
        $this->_orderWay = 'ASC';
        $this->_select = ' IF(is_synced = 0, "#ff2614", "#54ff81") as color, CASE
            WHEN is_mapped = ' . TooleAmazonMarketAmazonProduct::MAPPING_NOT_EXIST_ON_PS . ' THEN "#e0e045"
            WHEN is_mapped = ' . TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED . ' THEN "#25b9d7"
            WHEN is_mapped = ' . TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_AND_ENABLED . ' THEN "#54ff81"
            ELSE ""#ff2614"
        END AS mapping_color';

        $this->_where .= (' AND `id_entity` = ' . (int) $this->entityId);
        $this->_where .= (' AND `type` = ' . (int) $this->productType);

        // Don't filter by time, just show all the listing

        $this->fields_list = [
            'id' => [
                'title' => $this->module->l('Id'),
                'align' => 'left',
                'width' => 'auto',
                'orderby' => true,
                'search' => false,
            ],
            'sku' => [
                'title' => $this->module->l('Amazon SKU'),
                'width' => 'auto',
            ],
            'amz_product_name' => [
                'title' => $this->module->l('Name'),
                'align' => 'left',
                'width' => 'auto',
            ],
            'amz_product_desc' => [
                'title' => $this->module->l('Description'),
                'align' => 'left',
                'width' => 'auto',
                'orderby' => false,
                'search' => false,
            ],
            'qty' => [
                'title' => $this->module->l('Quantity'),
                'align' => 'text-center',
                'search' => false,
                'width' => 'auto',
            ],
            'price' => [
                'title' => $this->module->l('Price'),
                'align' => 'text-center',
                'search' => false,
                'width' => 'auto',
            ],
            'is_mapped' => [
                'title' => $this->module->l('Mapping'),
                'color' => 'mapping_color',
                'align' => 'text-center',
                'type' => 'select',
                'orderby' => false,
                'filter_key' => 'a!is_mapped',
                'filter_type' => 'int',
                'list' => array_values($this->mappingName),
            ],
            'is_synced' => [
                'title' => $this->module->l('Sync'),
                'color' => 'color',
                'align' => 'text-center',
                'type' => 'bool',
                'orderby' => false,
                'filter_type' => 'bool',
                'filter_key' => 'a!is_synced',
            ],
            'date_upd' => [
                'title' => $this->module->l('Adjustment Date'),
                'align' => 'text-center',
                'width' => 'auto',
                'search' => false,
            ],
        ];
        $this->addRowAction('sync');
        $this->addRowAction('create');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitBulksyncAll' . $this->table)) {
            $ids = Tools::getValue('idBox');
            if (!empty($ids)) {
                $this->module->log->setLog(sprintf('Start bulk synchronizing all amazon products'));
                foreach ($ids as $id) {
                    TooleAmazonMarketAmazonProduct::syncProduct($id, $this->entityId, $this->productType, $this->module->log);
                }
            }
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitBulkcreateAll' . $this->table)) {
            $ids = Tools::getValue($this->table . 'Box');
            if (!empty($ids)) {
                foreach ($ids as $id_toole_product) {
                    /** @var TooleAmazonMarketAmazonProduct $toole_product */
                    $toole_product = new TooleAmazonMarketAmazonProduct($id_toole_product);
                    $this->createProduct(
                        $id_toole_product,
                        $toole_product->sku,
                        $toole_product->asin,
                        $toole_product->price,
                        $toole_product->qty
                    );
                }
            }
            $this->redirectAdminToole();
        }
        parent::postProcess();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $cssLink = $this->module->getMediaLink('/views/css/catalog/amazon_sync.css');
        $jsLink = $this->module->getMediaLink('/views/js/catalog/amazon_sync.js?v=' . $this->module->version);
        $this->context->controller->addCSS($cssLink);
        $this->context->controller->addJS($jsLink);
    }

    // Custom callback function to render tooltips
    public function renderMappingStatusTooltip($value, $item)
    {
        switch ($value) {
            case self::MAPPING_NOT_EXIST_ON_PS:
                $title = $this->module->l('Not available in catalog');
                break;
            case self::MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED:
                $title = $this->module->l('Exists catalog but not enabled');
                break;
            case self::MAPPING_EXIST_ON_PS_AND_ENABLED:
                $title = $this->module->l('Enabled and can be synced');
                break;
            default:
                $title = '';
        }
        $tpl = $this->context->smarty->createTemplate($this->getTemplatePath() . '/common/tooltip.tpl')->assign([
            'title' => $title,
            'value' => $this->getMappingStatusName($value),
        ]);

        return $tpl->fetch();
    }

    public function renderList()
    {
        $lastFetch = AmazonMarketConfiguration::get($this->lastFetchReport);
        if ($lastFetch) {
            $lastFetch = gmdate('Y-m-d H:i:s', is_int($lastFetch) ? $lastFetch : strtotime($lastFetch));
            $this->informations[] = sprintf(
                $this->module->l('The list was refreshed at %s'),
                $lastFetch
            );
        }
        $this->informations[] = $this->module->l('There is a scheduled task available that will update this list automatically.  You can enable it in Module Configuration > Scheduled Tasks');

        // Add the custom rendering for mapping tooltips
        $this->fields_list['is_mapped']['callback'] = 'renderMappingStatusTooltip';

        return parent::renderList();
    }

    public function displaySyncLink($token, $id)
    {
        $sql = TooleAmazonMarketAmazonProduct::commonDbQuery((int) $this->entityId, (int) $this->productType, 'pa.is_synced, pa.is_mapped');
        $sql->where('pa.id = ' . pSQL($id));
        $result = Db::getInstance()->getRow($sql);

        $isSync = (int) ($result['is_mapped'] ?? false) !== TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_AND_ENABLED;

        return $this->context->smarty->createTemplate(
            $this->getTemplatePath() . 'catalog/amazon_sync/list_action_sync_amazon_product.tpl'
        )->assign([
            'id' => $id,
            'action' => $this->module->l('Sync Product'),
            'is_sync' => $isSync,
            'href' => $this->context->link->getAdminLink($this->controller_name) .
                $this->submit_action . '&id=' . $id . '&action=sync',
        ])->fetch();
    }

    /**
     * @throws SmartyException
     */
    public function displayCreateLink($token, $id)
    {
        $sql = new DbQuery();
        $sql->select('*');
        $sql->from(Database::TABLE_AMAZON_PRODUCTS, 'p');
        $sql->where('p.`id` = ' . pSQL($id));

        if ($row = Db::getInstance()->getRow($sql)) {
            return $this->context->smarty->createTemplate(
                $this->getTemplatePath() . 'catalog/amazon_sync/list_action_create_amazon_product.tpl'
            )->assign([
                'id' => $id,
                'action' => $this->module->l('Import Product'),
                'is_mapped' => $row['is_mapped'],
                'href' => $this->context->link->getAdminLink('ToolEAmazonMarketProductsImportedFromAmazon')
                    . $this->submit_action . '&id=' . $id . '&sku=' . $row['sku'] . '&asin=' . $row['asin'] . '&action=create',
            ])->fetch();
        }
    }

    public static function getTooleProductById($id)
    {
        $sql = new DbQuery();
        $sql->select('p.`sku`, p.`asin`, p.`qty`, p.`price`, p.`amz_product_name`, p.`amz_product_desc`, p.`id_product`, p.`id_product_attribute`, p.`is_synced`');
        $sql->from(Database::TABLE_AMAZON_PRODUCTS, 'p');
        $sql->where('p.`id` = \'' . pSQL($id) . '\'');
        return Db::getInstance()->getRow($sql);
    }

    public static function getProductBySku($sku)
    {
        $sql = new DbQuery();
        $sql->select('p.*');
        $sql->from('product', 'p');
        $sql->where('p.`reference` = \'' . pSQL($sku) . '\'');
        return Db::getInstance()->getRow($sql);
    }

    public static function getProductByAsin($sku)
    {
        $sql = new DbQuery();
        $sql->select('p.id_product');
        $sql->from('product', 'p');
        $sql->where('p.`mpn` = \'' . pSQL($sku) . '\'');  // TODO - this should be a custom field on an Amazon tab in the product sheet
        return Db::getInstance()->getValue($sql);
    }

    public function processCreate()
    {
        $id_toole_product = Tools::getValue('id');
        /** @var TooleAmazonMarketAmazonProduct $toole_product */
        $toole_product = new TooleAmazonMarketAmazonProduct($id_toole_product);
        $this->createProduct(
            $id_toole_product,
            $toole_product->sku,
            $toole_product->asin,
            $toole_product->price,
            $toole_product->qty
        );

        $this->redirectAdminToole();
    }

    public function processSync()
    {
        $id = Tools::getValue('id');
        $this->module->log->setLog(sprintf('Synchronizing a product'));
        TooleAmazonMarketAmazonProduct::syncProduct($id, $this->entityId, $this->productType, $this->module->log);
        $this->redirectAdminToole();
    }

    private function createProduct($id_toole_product, $sku, $asin, $price, $qty)
    {
        try {
            if (!self::getProductBySku($sku)) {
                $this->createPsProduct(
                    $id_toole_product,
                    $sku,
                    $asin,
                    $price,
                    $qty,
                    true
                );
            }
            // TooleAmazonMarketAmazonProduct::syncProduct($id_toole_product, $this->entityId, $this->productType, $this->module->log);
        } catch (Exception $e) {
            $this->errors = [$e->getMessage()];
            return;
        }
    }

    public function initPageHeaderToolbar(): void
    {
        $this->page_header_toolbar_btn['toole_feed_request'] = [
            'href' => $this->context->link->getAdminLink($this->controller_name) .
                      $this->submit_action . '&action=updateMappingStatusForProducts&token=' .
                      $this->token,
            'desc' => $this->module->l('Update Mapping State'),
            'icon' => 'process-icon-download',
        ];
        parent::initPageHeaderToolbar();
    }

    public function processUpdateMappingStatusForProducts(): void
    {
        $products = TooleAmazonMarketAmazonProduct::getTooleProductsWithMappingStatus($this->entityId, $this->productType);

        if (!empty($products)) {
            foreach ($products as $product) {
                TooleAmazonMarketAmazonProduct::markAsNotSyncAndUpdateMappingStatus($product['id'], $product['mapping_status']);
            }
        }
    }

    public function getAmazonProduct($asin)
    {
        try {
            $included_data = [
                'summaries',
                'relationships',
                'attributes',
                'dimensions',
                'identifiers',
                'images',
                'productTypes',
                'salesRanks',
            ];

            /*$amzResponse = $this->saasHelper->searchCatalogItems(
                [],
                [$searchKey],
                [$searchType],
                null,
                null,
                $included_data,
                10
            );

            $items = $amzResponse->getAmazonData();*/

            $getCatalogItemResponse = $this->saasHelper->getCatalogItem(
                [],
                $asin,
                null,
                $included_data
            );
            if ($item = $getCatalogItemResponse->getAmazonData()) {
                $title = '';
                $desc = '';
                $ean = '';
                $gtin = '';
                $upc = '';
                $brand = '';
                $part_number = '';
                $parent_asin = null;
                $variation_theme = null;
                $variation_attribute = null;
                $variation_attr_value = null;
                $product_type = '';
                $asin = $item->getAsin();
                $attributes = $item->getAttributes();
                $item_classification = null;

                $dimensions = $item->getDimensions();
                $identifiers = $item->getIdentifiers();
                if ($identifiers && count($identifiers)) {
                    $identifiers = $identifiers[0]->getIdentifiers();
                    foreach ($identifiers as $identifier) {
                        $identifierType = $identifier->getIdentifierType();
                        if ($identifierType == 'EAN') {
                            $ean = $identifier->getIdentifier();
                        } elseif ($identifierType == 'GTIN') {
                            $gtin = $identifier->getIdentifier();
                        } elseif ($identifierType == 'UPC') {
                            $upc = $identifier->getIdentifier();
                        }
                    }
                }
                $images = $item->getImages();
                $imageData = [];
                if ($images && count($images)) {
                    $imagesByMarketplace = $images[0];
                    $images = $imagesByMarketplace->getImages();
                    if ($images && count($images)) {
                        foreach ($images as $image) {
                            $image_variant = $image->getVariant();
                            $image_link = $image->getLink();
                            $image_height = $image->getHeight();
                            $image_width = $image->getWidth();
                            $imageData[] = [
                                'variant' => $image_variant,
                                'url' => $image_link,
                                'height' => $image_height,
                                'width' => $image_width,
                            ];
                        }
                    }
                }

                $productTypes = $item->getProductTypes();
                if (count($productTypes)) {
                    $product_type = $productTypes[0]->getProductType();

                    $summariesByMarketplace = $item->getSummaries();
                    if (count($summariesByMarketplace)) {
                        $summary = $summariesByMarketplace[0];
                        $title = $summary->getItemName();
                        $brand = $summary->getBrand();
                        $part_number = $summary->getPartNumber();
                        $item_classification = $summary->getItemClassification();
                    }
                }

                // Item class VARIATION_PARENT for a root item.
                // TODO - Check in FR marketplace for item that seems to be variant but isn't
                // VARIATION will be a variant
                // BASE_PRODUCT can be used for non-variant products, theme will be null?
                // VARIANT_PARENT the root product, could be used to generate all combinations.

                $variant_parent = false;
                $relationshipsByMarketplace = $item->getRelationships();
                if (count($relationshipsByMarketplace)) {
                    $relationships = $relationshipsByMarketplace[0]->getRelationships();
                    if (count($relationships)) {
                        if ($variationTheme = $relationships[0]->getVariationTheme()) {
                            $variation_attributes = $variationTheme->getAttributes();
                            if (count($variation_attributes)) {
                                $variation_attribute = $variation_attributes[0];
                            }
                            $variation_theme = $variationTheme->getTheme();
                            if ($item_classification == 'BASE_PRODUCT') {
                                $parentAsins = $relationships[0]->getParentAsins();
                                if (isset($parentAsins) && count($parentAsins)) {
                                    $parent_asin = $parentAsins[0];
                                }
                            } elseif ($item_classification == 'VARIATION_PARENT') {
                                $variant_parent = true;
                            }
                        }
                    }
                }

                foreach ($attributes as $key => $attribute) {
                    if ($key == 'product_description') {
                        $item_name = $attribute[0];  // TODO - $item_name['language_tag'] contains the name lang (ex. fr_FR)
                        $desc = $item_name->value;
                    }

                    if (!empty($variation_theme) && (strtolower($key) == strtolower($variation_attribute))) {
                        $item_name = $attribute[0];  // TODO - $item_name['language_tag'] contains the name lang (ex. fr_FR)
                        $variation_attr_value = $item_name->value;
                    }

                    // TODO - process other attributes as per the mappings
                }

                return [
                    'title' => $title,
                    'desc' => $desc,
                    'ean' => $ean,
                    'gtin' => $gtin,
                    'upc' => $upc,
                    'brand' => $brand,
                    'part_number' => $part_number,
                    'parent_asin' => $parent_asin,
                    'variant_parent' => $variant_parent,
                    'variation_theme' => $variation_theme,
                    'variation_attribute' => $variation_attribute,
                    'variation_attribute_value' => $variation_attr_value,
                    'product_type' => $product_type,
                    'images' => $imageData,
                ];
            }
            throw new Exception('Unable to retrieve product details.');
        } catch (Exception $exception) {
            self::$errorMsgs[] = $exception->getMessage();
            $this->module->log->error($exception->getMessage());

            return null;
        }
    }

    /**
     * @throws PrestaShopException
     * @throws PrestaShopDatabaseException
     * @throws Exception
     */
    public function createPsProduct($id_toole_product, $sku, $asin, $price, $qty, $update_stock = true)
    {
        $context = Context::getContext();
        if (!$amazon_product = $this->getAmazonProduct(
            $asin
        )) {
            throw new Exception(sprintf('An error occurred retrieving the details for product asin %s.', $asin));
        }

        $id_product_attribute = 0;
        if (isset($amazon_product['parent_asin'])) {
            if (!$id_product = self::getProductByAsin($amazon_product['parent_asin'])) {
                $product = $this->createPsProduct(
                    $id_toole_product,
                    null,
                    $amazon_product['parent_asin'],
                    $price,
                    0,
                    false
                );
            } else {
                $product = new Product($id_product);
            }

            $sql = new DbQuery();
            $sql->select('pa.id_product_attribute')
                ->from('product_attribute', 'pa')
                ->where('pa.reference="' . $sku . '"')
                ->where('pa.id_product=' . (int) $id_product);
            if (!$id_product_attribute = Db::getInstance()->getValue($sql)) {
                $id_product_attribute = $product->addCombinationEntity(
                    0, // $wholesale_price,
                    $price, // $price,
                    0, // $weight,
                    0, // $unit_impact,
                    0, // $ecotax,
                    0, // $quantity,
                    [0], // $id_images,
                    $sku, // $reference,
                    0, // $id_supplier,
                    null, // $ean13,
                    !$id_product ? 1 : 0, // $default,
                    null, // $location = null,
                    null, // $upc = null,
                    1, // $minimal_quantity = 1,
                    [], // array $id_shop_list = [],
                    null, // $available_date = null,
                    '', // $isbn = '',
                    null, // $low_stock_threshold = null,
                    false, // $low_stock_alert = false,
                    $amazon_product['parent_asin'] // $mpn = null
                );
            }

            // search for attr_group by variation_theme lowercase + amz_
            // add attr value into group
            // get the id
            $sql = new DbQuery();
            $sql->select('id_attribute_group')
                ->from('attribute_group_lang', 'agl')
                ->where('agl.name="' . 'amz_' . pSQL(strtolower($amazon_product['variation_theme'])) . '"')
                ->where('agl.id_lang=' . (int) $this->context->language->id);
            if (!$id_attribute_group = Db::getInstance()->getValue($sql)) {
                throw new Exception(sprintf('Attribute group for variation theme %s missing, product type %s.  You can import this in the module configuration.', $amazon_product['variation_theme'], $amazon_product['product_type']));
            }

            $id_attribute = 0;  // TODO - should have a backup here
            if (isset($amazon_product['variation_attribute_value'])) {
                $sql = new DbQuery();
                $sql->select('id_attribute')
                    ->from('attribute_lang', 'al')
                    ->where('al.name="' . pSQL($amazon_product['variation_attribute_value']) . '"')
                    ->where('al.id_lang=' . (int) $this->context->language->id);
                if (!$id_attribute = Db::getInstance()->getValue($sql)) {
                    if (version_compare(_PS_VERSION_, '8', '<') === true) {
                        $attr = new Attribute();
                    } else {
                        $attr = new ProductAttribute();
                    }

                    $attr->id_attribute_group = $id_attribute_group;
                    $attr->name[$this->context->language->id] = $amazon_product['variation_attribute_value'];
                    $attr->save();
                    $id_attribute = $attr->id;
                }
            }
            $sql = new DbQuery();
            $sql->select('pac.id_attribute')
                ->from('product_attribute_combination', 'pac')
                ->where('pac.id_attribute=' . (int) $id_attribute)
                ->where('pac.id_product_attribute=' . (int) $id_product_attribute);
            $id_product_attribute_combination = Db::getInstance()->getValue($sql);

            if ($id_attribute && !$id_product_attribute_combination) {
                Db::getInstance()->execute('
                INSERT IGNORE INTO ' . _DB_PREFIX_ . 'product_attribute_combination (id_attribute, id_product_attribute)
                VALUES (' . (int) $id_attribute . ',' . (int) $id_product_attribute . ')', false);
            }

            StockAvailable::setQuantity(
                $product->id,
                $id_product_attribute,
                $qty,
                $context->shop->id,
                false
            );

            $amz_product = new TooleAmazonMarketAmazonProduct($id_toole_product);
            $amz_product->is_mapped = TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED;
            $amz_product->save();

            return $product;
        } else {
            if (!empty($amazon_product['variation_theme'])) {
                $sql = new DbQuery();
                $sql->select('id_attribute_group')
                    ->from('attribute_group_lang', 'agl')
                    ->where('agl.name="' . 'amz_' . pSQL(strtolower($amazon_product['variation_theme'])) . '"')
                    ->where('agl.id_lang=' . (int) $this->context->language->id);
                if (!Db::getInstance()->getValue($sql)) {
                    throw new Exception(sprintf('Attribute group for variation theme %s missing, product type %s.  You can import this in the module configuration.', $amazon_product['variation_theme'], $amazon_product['product_type']));
                }
            }

            $product = new Product();
            $product->active = false;
            $product->id_category_default = AmazonMarketConfiguration::get(
                Key::CONFIG_AMAZON_PRODUCT_CATEGORY,
                null,
                null,
                2
            );
            foreach (Language::getLanguages(true) as $lang) {
                $product->name[$lang['id_lang']] = substr($amazon_product['title'], 0, 125) . '...';
                $product->description[$lang['id_lang']] = $amazon_product['desc'];
                $product->link_rewrite[$lang['id_lang']] = Tools::str2url($amazon_product['title']);
            }
            $product->is_virtual = 0;
            $product->reference = $sku;
            $product->mpn = $asin;
            $product->cache_is_pack = 0;
            $product->price = ($amazon_product['variant_parent']) ? 0 : $price;  // if combination, set to 0 and set combo price.  If not a variant, set price here.
            $product->wholesale_price = 0;
            if (version_compare(_PS_VERSION_, '1.7.7', '>=')) {
                $product->product_type = ProductType::TYPE_STANDARD;
            }
            $product->active = 1;
            $product->available_for_order = 1;
            $product->visibility = 'none';
            if ($product->add()) {
                $product->addToCategories([$product->id_category_default]);
                foreach ($amazon_product['images'] as $image) {
                    $image_data = $this->getImage($image['url']);
                    $this->createPsImage(
                        $product->id,
                        $image_data
                    );
                }

                if ($update_stock) {
                    StockAvailable::setQuantity(
                        $product->id,
                        $id_product_attribute,
                        $qty,
                        $context->shop->id,
                        false
                    );
                }

                $amz_product = new TooleAmazonMarketAmazonProduct($id_toole_product);
                $amz_product->is_mapped = TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED;
                $amz_product->save();

                return $product;
            }
        }
    }

    private function getSchema($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        if ($info['http_code'] == 200) {
            return [
                'data' => $data,
            ];
        }

        return false;
    }

    private function getImage($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $attachment_data = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        if ($info['http_code'] == 200) {
            $path = parse_url($url, PHP_URL_PATH);
            $image_name = basename($path);

            $tmp_image_name = uniqid();
            $img_path = _PS_TMP_IMG_DIR_ . $image_name;
            if (!file_put_contents(
                $img_path,
                $attachment_data
            )) {
                return false;
            }

            return [
                'type' => $info['content_type'],
                'tmp_name' => $img_path,
                'image_name' => $image_name,
                'image_data' => $attachment_data,
                'size' => $info['size_download'],
                'save_path' => $img_path,
            ];
        }

        return false;
    }

    private function createPsImage(
        $id_product,
        $file
    ) {
        $image = new Image();
        $image->id_product = (int) $id_product;
        $image->position = Image::getHighestPosition($id_product) + 1;

        /*foreach ($legends as $key => $legend) {
            if (!empty($legend)) {
                $image->legend[(int) $key] = $legend;
            }
        }*/

        if (!Image::getCover($image->id_product)) {
            $image->cover = 1;
        } else {
            $image->cover = 0;
        }

        if (($validate = $image->validateFieldsLang(false, true)) !== true) {
            $file['error'] = $validate;
        }

        if (isset($file['error']) && (!is_numeric($file['error']) || $file['error'] != 0)) {
            return;
        }

        if (!$image->add()) {
            $file['error'] = $this->module->l('Error while creating additional image');
        } else {
            if (!$new_path = $image->getPathForCreation()) {
                $file['error'] = $this->module->l('An error occurred while attempting to create a new folder.');

                return;
            }

            $error = 0;

            if (!ImageManager::resize($file['save_path'], $new_path . '.' . $image->image_format, null, null, 'jpg', false, $error)) {
                switch ($error) {
                    case ImageManager::ERROR_FILE_NOT_EXIST:
                        $file['error'] = $this->module->l('An error occurred while copying image, the file does not exist anymore.');
                        break;
                    case ImageManager::ERROR_FILE_WIDTH:
                        $file['error'] = $this->module->l('An error occurred while copying image, the file width is 0px.');
                        break;
                    case ImageManager::ERROR_MEMORY_LIMIT:
                        $file['error'] = $this->module->l('An error occurred while copying image, check your memory limit.');

                        break;

                    default:
                        $file['error'] = $this->module->l('An error occurred while copying the image.');

                        break;
                }

                return;
            } else {
                $imagesTypes = ImageType::getImagesTypes('products');
                $generate_hight_dpi_images = (bool) Configuration::get('PS_HIGHT_DPI');

                foreach ($imagesTypes as $imageType) {
                    if (!ImageManager::resize($file['save_path'], $new_path . '-' . stripslashes($imageType['name']) . '.' . $image->image_format, $imageType['width'], $imageType['height'], $image->image_format)) {
                        $file['error'] = $this->module->l('An error occurred while copying this image:') . ' ' . stripslashes($imageType['name']);

                        continue;
                    }

                    if ($generate_hight_dpi_images) {
                        if (!ImageManager::resize($file['save_path'], $new_path . '-' . stripslashes($imageType['name']) . '2x.' . $image->image_format, (int) $imageType['width'] * 2, (int) $imageType['height'] * 2, $image->image_format)) {
                            $file['error'] = $this->module->l('An error occurred while copying this image:') . ' ' . stripslashes($imageType['name']);

                            continue;
                        }
                    }
                }
            }

            unlink($file['save_path']);
            // Necesary to prevent hacking
            unset($file['save_path']);
            Hook::exec('actionWatermark', ['id_image' => $image->id, 'id_product' => $id_product]);

            if (!$image->update()) {
                $file['error'] = $this->module->l('Error while updating the status.');

                return;
            }

            // Associate image to shop from context
            $shops = Shop::getContextListShopID();
            $image->associateTo($shops);
            $json_shops = [];

            foreach ($shops as $id_shop) {
                $json_shops[$id_shop] = true;
            }

            $file['status'] = 'ok';
            $file['id'] = $image->id;
            $file['position'] = $image->position;
            $file['cover'] = $image->cover;
            $file['legend'] = $image->legend;
            $file['path'] = $image->getExistingImgPath();
            $file['shops'] = $json_shops;

            @unlink(_PS_TMP_IMG_DIR_ . 'product_' . (int) $id_product . '.jpg');
            @unlink(_PS_TMP_IMG_DIR_ . 'product_mini_' . (int) $id_product . '_' . $this->context->shop->id . '.jpg');
        }
    }

    public function getMappingStatusName($mappedStatus): string
    {
        switch ($mappedStatus) {
            case TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED:
                return $this->mappingName[TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED];
            case TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_AND_ENABLED:
                return $this->mappingName[TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_AND_ENABLED];
            case TooleAmazonMarketAmazonProduct::MAPPING_NOT_EXIST_ON_PS:
            default:
                return $this->mappingName[TooleAmazonMarketAmazonProduct::MAPPING_NOT_EXIST_ON_PS];
        }
    }
}
