<?php
/**
 * TooleAmazonMarketOrderFulfillCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\Amazon\Client\V4\Constant\CronConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderFulfillment;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketOrderFulfillCronModuleFrontController extends TooleBaseFrontController
{
    public function __construct()
    {
        $this->active_region = Tools::getValue('region', AmazonConstant::MKP_REGION_EU);
        parent::__construct();

        $cronConfig = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_CONFIG_CRON);
        $enableFulfill = $cronConfig[CronConstant::CRON_AMT_TYPE_ORDERS_FULFILL]['enable'];
        if (!$enableFulfill) {
            exit(new AjaxResponseOnce(
                ['This feature is not enabled'],
                [],
                [],
                null
            ));
        }

        $this->ajax = true;
    }

    /**
     * URL: http://hostname/index.php?action=orderFulfill&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketOrderFulfillCron&id_subscription=
     *
     * @return void
     */
    public function displayAjaxOrderFulfill()
    {
        $this->module->log->setLog('Running order fulfilment', true);
        $fulfillOrder = new OrderFulfillment($this->saasHelper, [], $this->module, true);
        try {
            $fulfillOrder->doFulfill();
            $response = new AjaxResponseOnce($fulfillOrder->getErrors(), $fulfillOrder->getWarnings(), [], $fulfillOrder->getShipmentData());
        } catch (Exception $e) {
            $response = new AjaxResponseOnce([$e->getMessage(), $e->getTraceAsString()], [], [], ['logId' => $this->module->log->getScheduler()]);
        }

        $this->module->log->extractFromAjaxResponse($response);

        exit($response);
    }
}
