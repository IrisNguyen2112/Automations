<?php
/**
 * TooleamazonmarkettoolTooleAmazonMarketplaceFrontController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketplaceFrontController extends ModuleFrontController
{
    public function __construct()
    {
        parent::__construct();
    }
}
