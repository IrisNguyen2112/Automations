<?php
/**
 * TooleAmazonMarketCatalogSyncFromPsCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\Amazon\Client\V4\Constant\CronConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\CatalogSyncFromPs;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Product as ProductHelper;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Log\Log;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketCatalogSyncFromPsCronModuleFrontController extends TooleBaseFrontController
{
    protected $warnings = [];
    protected $confirmations = [];

    private $since;
    private $activeItemOnly = true;

    public function __construct()
    {
        $this->use_region = false;
        $this->active_marketplace = Tools::getValue('mkp_id', '');
        parent::__construct();

        $cronConfig = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_CONFIG_CRON);
        $enableSync = $cronConfig[CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS]['enable'];
        if (!$enableSync) {
            exit(new AjaxResponseOnce(['This feature is not enabled'], [], [], null));
        }

        $this->module->log = new Log(Tools::getValue('logId', null));
        $this->ajax = true;
        $this->since = Tools::getValue('since', null);
    }

    /**
     * URL: http://hostname/index.php?action=export&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketCatalogSyncFromPsCron&id_subscription=
     *    &since: 1684903029
     *    &mkp_id: ATVPDKIKX0DER, A2EUQ1WTGCTBG2, ...
     *
     * @return void
     * @throws PrestaShopDatabaseException|PrestaShopException
     */
    public function displayAjaxExport()
    {
        // Validate mkp
        $mkpId = Tools::getValue('mkp_id');
        $this->module->log->setLog(sprintf('Export product - All marketplaces are activated'), true);

        $langId = $this->resolveLang($mkpId);
        if (!$langId) {
            $this->module->log->error('No language available.');
            exit(AjaxResponseOnce::onlyAnError(
                $this->module->l('No language available.')
            ));
        }

        $identifiers = [];
        $entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);
        $products = ProductHelper::marketplaceGetAllProducts($langId, $entityId, $this->activeItemOnly, $this->convertTimeStamp($this->since));

        $this->module->log->message([
            sprintf('Get products since %s - Marketplace (%s)', $this->convertTimeStamp($this->since), $mkpId),
            sprintf('Total %s products', count($products)),
        ]);

        if (!empty($products)) {
            foreach ($products as $product) {
                if (Combination::isFeatureActive()) {
                    $psProduct = new Product($product['id_product']);
                    if ($psProduct->hasCombinations()) {
                        $combinations = $psProduct->getAttributeCombinations();
                        foreach ($combinations as $combination) {
                            $identifiers[] = [
                                'id_product' => (int) $product['id_product'],
                                'id_product_attribute' => (int) $combination['id_product_attribute'],
                            ];
                        }
                        continue;
                    }
                }
                $identifiers[] = [
                    'id_product' => (int) $product['id_product'],
                    'id_product_attribute' => 0,
                ];
            }
        }

        try {
            $flow = new CatalogSyncFromPs($this->saasHelper, $identifiers, $mkpId, $this->context, $this->module, true);
            $flow->doExport();
            $response = new AjaxResponseOnce(
                array_merge($this->errors, $flow->getErrors()),
                array_merge($this->warnings, $flow->getWarnings()),
                array_merge($this->confirmations, $flow->getConfirmations()),
                ['logId' => $this->module->log->getScheduler()]
            );
            $this->module->log->extractFromAjaxResponse($response);
            exit($response);
        } catch (Exception $exception) {
            $this->module->log->error(sprintf('An unexpected error has occurred: %s', $exception->getMessage()));
            exit(AjaxResponseOnce::onlyAnError($exception->getMessage()));
        }
    }

    /**
     * @param $timestampOrDate
     * @return string|bool
     */
    private function convertTimeStamp($timestampOrDate)
    {
        if (empty($this->since)) {
            return false;
        }
        if (is_numeric($timestampOrDate)) {
            $timestamp = (int) $timestampOrDate;
        } else {
            $timestamp = strtotime($timestampOrDate);
        }
        return date('Y-m-d H:i:s', $timestamp);
    }

    private function resolveLang($mkpId): int
    {
        $langByMkp = Region::langByMkp();
        if (isset($langByMkp[$mkpId])) {
            $lang = $langByMkp[$mkpId];
            if ($langId = Language::getIdByIso($lang)) {
                return $langId;
            }
        }
        return (int) Configuration::get('PS_LANG_DEFAULT');
    }
}
