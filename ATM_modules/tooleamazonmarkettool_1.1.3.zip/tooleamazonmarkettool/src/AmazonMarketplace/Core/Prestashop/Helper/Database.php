<?php
/**
 * TooleAmazonMarketPlaceTools
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Helper;

use Db;
use PrestaShopDatabaseException;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Database
{
    const TABLE_AMAZON_ORDERS = 'toole_amt_amazon_orders';
    const TABLE_FILTER_PRODUCTS = 'toole_amt_filter_products';
    const TABLE_FILTER_MANUFACTURERS = 'toole_amt_filter_manufacturers';
    const TABLE_FILTER_SUPPLIERS = 'toole_amt_filter_suppliers';
    const TABLE_FILTER_CATEGORIES = 'toole_amt_filter_categories';
    const TABLE_AMAZON_PRODUCTS = 'toole_amt_amazon_products';
    const TABLE_FEEDS = 'toole_amt_feeds';
    const TABLE_LOGS = 'toole_amt_logs';
    const TABLE_MESSAGES = 'toole_amt_messages';
    const TABLE_LOG_DETAILS = 'toole_amt_log_details';
    const TABLE_AMAZON_ENTITIES = 'toole_amt_entities';
    const TABLE_FBA_ORDERS = 'toole_amt_fba_orders';
    const TABLE_ORDER_ITEMS = 'toole_amt_amazon_order_items';
    const TABLE_IN_CART_ORDERS = 'toole_amt_in_cart_orders';
    const TABLE_IN_CART_ORDER_ITEMS = 'toole_amt_in_cart_order_items';

    protected static $tableList = [];

    /**
     * @throws PrestaShopDatabaseException
     */
    public static function tableExists($table, bool $use_cache = true): bool
    {
        if (isset(self::$tableList[$table]) && $use_cache) {
            return self::$tableList[$table];
        }

        $query_result = Db::getInstance()->executeS('SHOW TABLES FROM `' . pSQL(_DB_NAME_) . '`', true, false);
        if (!is_array($query_result) || !count($query_result)) {
            return false;
        }

        $tables = [];
        foreach ($query_result as $row) {
            foreach ($row as $columnAsTableName) {
                $tables[$columnAsTableName] = true;
            }
        }
        self::$tableList = $tables;

        return isset(self::$tableList[$table]) && self::$tableList[$table];
    }

    public static function getModuleTables(): array
    {
        return [
            _DB_PREFIX_ . self::TABLE_AMAZON_ORDERS,
            _DB_PREFIX_ . self::TABLE_FILTER_PRODUCTS,
            _DB_PREFIX_ . self::TABLE_FILTER_MANUFACTURERS,
            _DB_PREFIX_ . self::TABLE_FILTER_SUPPLIERS,
            _DB_PREFIX_ . self::TABLE_FILTER_CATEGORIES,
            _DB_PREFIX_ . self::TABLE_AMAZON_PRODUCTS,
            _DB_PREFIX_ . self::TABLE_FEEDS,
            _DB_PREFIX_ . self::TABLE_LOGS,
            _DB_PREFIX_ . self::TABLE_MESSAGES,
            _DB_PREFIX_ . self::TABLE_LOG_DETAILS,
            _DB_PREFIX_ . self::TABLE_AMAZON_ENTITIES,
            _DB_PREFIX_ . self::TABLE_FBA_ORDERS,
            _DB_PREFIX_ . self::TABLE_ORDER_ITEMS,
            _DB_PREFIX_ . self::TABLE_IN_CART_ORDERS,
            _DB_PREFIX_ . self::TABLE_IN_CART_ORDER_ITEMS,
        ];
    }
}
