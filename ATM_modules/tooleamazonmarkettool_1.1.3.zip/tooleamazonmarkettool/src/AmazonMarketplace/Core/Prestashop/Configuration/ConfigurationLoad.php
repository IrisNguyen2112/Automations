<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

use AttributeGroup;
use Carrier;
use CarrierCore;
use Category;
use Configuration;
use Context;
use OrderState;
use PrestaShopBundle\Translation\TranslatorComponent;
use Toole\Module\Amazon\Client\Model\Order;
use Toole\Module\Amazon\Client\Model\ProductTypeList;
use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\Amazon\Client\V4\Constant\CronConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\Rule;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\RuleByPrice;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\RuleByWeight;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\FulfillmentCarrierDefault;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\FulfillmentCarrierWithShippingMethod;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\OrderImportCarrierExpress;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\OrderImportCarrierStandard;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Url;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v2\ServiceAPIHelper;
use TooleAmazonMarketTool;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfigurationLoad
{
    /**
     * @var TooleAmazonMarketTool
     */
    protected $module;

    /** @var Context */
    protected $context;

    /** @var TranslatorComponent|null */
    protected $translator;

    public function __construct(TooleAmazonMarketTool $module)
    {
        $this->module = $module;
        $this->context = $module->getContext();
        $this->translator = $this->module->getTranslator();
    }

    public function getTplVars(): array
    {
        // Handle show inactive carrier
        $psCarriers = Carrier::getCarriers($this->context->language->id, false, false, false, null, CarrierCore::ALL_CARRIERS);
        $psCarriers = array_map(function ($carrier) {
            if ((int) $carrier['active'] === 0) {
                $carrier['name'] = $carrier['name'] . ' (' . $this->module->l('inactive') . ')';
            }

            return $carrier;
        }, $psCarriers);

        return [
            'url' => $this->module->getContextLink()->getAdminLink('AdminModules', true, [], [
                'configure' => $this->module->name,
                'tab_module' => $this->module->tab,
                'module_name' => $this->module->name,
            ]),
            'images_url' => Url::getModuleUrl($this->module->name) . 'views/img/',
            'help_center_url' => $this->module->help_center_url,
            'welcome_image_url' => $this->getModuleWelcomeImage(),
            'languages' => $this->context->controller->getLanguages(),
            'fields_constant' => $this->getModuleConfigFieldsConstant(),
            'defined_fields' => $this->getModuleConfigDefinedFields(),
            'fields_value' => $this->getModuleConfigFieldsValues(),
            'product_types' => $this->searchProductTypeDefinitions(),
            'amazon_attributes_list' => [],
            'product_attribute_mappings' => [],
            'product_type_definition_schema' => '',
            'categories' => Category::getAllCategoriesName(2, $this->context->language->id, false),
            'attribute_groups' => AttributeGroup::getAttributesGroups($this->context->language->id),
            'account' => [
                'regionsWMkps' => Region::getAllRegionsWithMkps(),
                'authorizedRegions' => AmazonMarketConfiguration::getAmazonAccountAuthorization(),
                // ToolEAmazonMarketAdminConfigController
                'controller' => $this->context->link->getAdminLink('ToolEAmazonMarketAdminConfig'),
            ],
            'orders' => [
                'carriers' => [
                    'ps_carriers' => $psCarriers,
                    'incoming_amazon_carriers' => array_merge(
                        OrderImportCarrierStandard::CARRIER_CODES,
                        OrderImportCarrierExpress::CARRIER_CODES
                    ),
                    'outgoing_amazon_carriers' => FulfillmentCarrierDefault::CARRIER_CODES,
                    'carrier_need_shipping_method' => $this->resolveCarrierNeedShippingMethod(),
                ],
            ],
        ];
    }

    protected function getModuleConfigDefinedFields(): array
    {
        return [
            'order_state_list' => OrderState::getOrderStates($this->context->language->id),
            'catalog_amazon_sync_time_options' => CronConstant::AMT_CRON_FREQUENCIES[CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ],
            'catalog_fba_sync_time_options' => CronConstant::AMT_CRON_FREQUENCIES[CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA],
            'catalog_prestashop_sync_time_options' => CronConstant::AMT_CRON_FREQUENCIES[CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS],
            'order_import_sync_time_options' => CronConstant::AMT_CRON_FREQUENCIES[CronConstant::CRON_AMT_TYPE_ORDERS_IMPORT],
            'order_fulfillment_sync_time_options' => CronConstant::AMT_CRON_FREQUENCIES[CronConstant::CRON_AMT_TYPE_ORDERS_FULFILL],
            'order_create_fba_sync_time_options' => CronConstant::AMT_CRON_FREQUENCIES[CronConstant::CRON_AMT_TYPE_CREATE_FBA_ORDERS],
            'order_cancellation_sync_time_options' => CronConstant::AMT_CRON_FREQUENCIES[CronConstant::CRON_AMT_TYPE_AMAZON_CANCELLATION_ORDERS],
            'in_cart_order_sync_time_options' => CronConstant::AMT_CRON_FREQUENCIES[CronConstant::CRON_AMT_TYPE_SUPERVISE_IN_CART_ORDERS],
            'amz_order_statuses' => [
                'All' => 'All',
                'Shipped' => Order::ORDER_STATUS_SHIPPED,
                'Unshipped' => Order::ORDER_STATUS_UNSHIPPED,
                'PartiallyShipped' => Order::ORDER_STATUS_PARTIALLY_SHIPPED,
            ],
        ];
    }

    protected function getModuleConfigFieldsValues(): array
    {
        $moduleConfigs = [
            ConfigurationConstant::AMT_ORDER_STATUS_IMPORT => AmazonMarketConfiguration::get(ConfigurationConstant::AMT_ORDER_STATUS_IMPORT),
            ConfigurationConstant::AMT_ORDER_STATUS_FULFILL => AmazonMarketConfiguration::get(ConfigurationConstant::AMT_ORDER_STATUS_FULFILL),
            ConfigurationConstant::AMT_ORDER_STATUS_CANCEL => AmazonMarketConfiguration::get(ConfigurationConstant::AMT_ORDER_STATUS_CANCEL),
            ConfigurationConstant::AMT_SHIPPING_TEMPLATES => $this->getShippingTemplates(),
            ConfigurationConstant::AMT_CONFIG_AMZ_MARKETPLACES_AMZ_AUTH_COMBO => AmazonMarketConfiguration::get(ConfigurationConstant::AMT_CONFIG_AMZ_MARKETPLACES_AMZ_AUTH_COMBO, null, null, []),
            ConfigurationConstant::AMT_CONFIG_CRON => $this->getCronConfig(AmazonMarketConfiguration::get(ConfigurationConstant::AMT_CONFIG_CRON, null, null, [])),
            Key::SERVICE_API_URL => Configuration::getGlobalValue(Key::SERVICE_API_URL),
            Key::SERVICE_API_KEY => Configuration::getGlobalValue(Key::SERVICE_API_KEY),
            Key::SERVICE_AMAZON_AUTH_URL => Configuration::getGlobalValue(Key::SERVICE_AMAZON_AUTH_URL),
            ConfigurationConstant::CONFIG_AMAZON_PRODUCT_CATEGORY => AmazonMarketConfiguration::get(ConfigurationConstant::CONFIG_AMAZON_PRODUCT_CATEGORY, null, null, 2),
            ConfigurationConstant::CONFIG_AMAZON_CREATE_AMAZON_PRODUCTS_ON_SYNC => AmazonMarketConfiguration::get(ConfigurationConstant::CONFIG_AMAZON_CREATE_AMAZON_PRODUCTS_ON_SYNC, null, null, 0),
            ConfigurationConstant::AMT_CONFIG_FBA_SETTINGS => AmazonMarketConfiguration::get(ConfigurationConstant::AMT_CONFIG_FBA_SETTINGS, null, null, []),
            ConfigurationConstant::AMT_OUTGOING_ORDER_STATUS_CANCEL => AmazonMarketConfiguration::get(ConfigurationConstant::AMT_OUTGOING_ORDER_STATUS_CANCEL),
        ];

        return array_merge($moduleConfigs,
            ['hasAScheduledTask' => $this->hasOneScheduledTaskAtLeast($moduleConfigs)],
            $this->getConfigurationCarriers(ConfigurationConstant::AMT_OUTGOING_CARRIERS),
            $this->getConfigurationCarriers(ConfigurationConstant::AMT_INCOMING_CARRIERS)
        );
    }

    private function getModuleConfigFieldsConstant(): array
    {
        return [
            'incoming_carriers' => ConfigurationConstant::AMT_INCOMING_CARRIERS,
            'outgoing_carriers' => ConfigurationConstant::AMT_OUTGOING_CARRIERS,
            'import_order_status' => ConfigurationConstant::AMT_ORDER_STATUS_IMPORT,
            'fulfill_order_status' => ConfigurationConstant::AMT_ORDER_STATUS_FULFILL,
            'prestashop_cancellation_status' => ConfigurationConstant::AMT_ORDER_STATUS_CANCEL,
            'shipping_templates' => ConfigurationConstant::AMT_SHIPPING_TEMPLATES,
            'auth_combo' => ConfigurationConstant::AMT_CONFIG_AMZ_MARKETPLACES_AMZ_AUTH_COMBO,
            'cron' => [
                'master' => ConfigurationConstant::AMT_CONFIG_CRON,
                'amz_sync' => CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ,
                'fba_sync' => CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA,
                'ps_sync' => CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS,
                'orders_import' => CronConstant::CRON_AMT_TYPE_ORDERS_IMPORT,
                'orders_fulfill' => CronConstant::CRON_AMT_TYPE_ORDERS_FULFILL,
                'orders_acknowledge' => CronConstant::CRON_AMT_TYPE_ORDERS_ACKNOWLEDGE,
                'feeds_result' => CronConstant::CRON_AMT_TYPE_FETCH_FEED_RESULT,
                'fba_orders' => CronConstant::CRON_AMT_TYPE_CREATE_FBA_ORDERS,
                'enable_cancellation_amazon_orders' => CronConstant::CRON_AMT_TYPE_AMAZON_CANCELLATION_ORDERS,
                'in_cart_orders' => CronConstant::CRON_AMT_TYPE_SUPERVISE_IN_CART_ORDERS,
            ],
            'advanced_service_api_url' => Key::SERVICE_API_URL,
            'advanced_service_api_key' => Key::SERVICE_API_KEY,
            'advanced_service_api_auth' => Key::SERVICE_AMAZON_AUTH_URL,
            'fba_order_status' => [
                'key' => ConfigurationConstant::AMT_CONFIG_FBA_SETTINGS,
                'fulfill' => ConfigurationConstant::AMT_FBA_FULFILL_ORDER_STATUS,
                'shipped' => ConfigurationConstant::AMT_FBA_SHIPPED_ORDER_STATUS,
                'delivered' => ConfigurationConstant::AMT_FBA_DELIVERED_ORDER_STATUS,
                'cancelled' => ConfigurationConstant::AMT_FBA_CANCELLED_ORDER_STATUS,
            ],
            'outgoing_cancel_order_status' => ConfigurationConstant::AMT_OUTGOING_ORDER_STATUS_CANCEL,
        ];
    }

    private function getModuleWelcomeImage(): string
    {
        $iso_code = $this->context->language->iso_code;
        $base_url = Url::getModuleUrl($this->module->name) . 'views/img/';
        if (file_exists(_PS_ROOT_DIR_ . $base_url . 'module-features-' . $iso_code . '.jpg')) {
            return $base_url . 'module-features-' . $iso_code . '.jpg';
        }

        return $base_url . 'module-features.jpg';
    }

    private function getConfigurationCarriers($key): array
    {
        $carriers = AmazonMarketConfiguration::get($key);

        if ($carriers) {
            $carrierList = $carriers;
        }

        return [$key => $carrierList ?? []];
    }

    private function resolveCarrierNeedShippingMethod(): array
    {
        $result = [];
        foreach (FulfillmentCarrierWithShippingMethod::CARRIERS as $carriers) {
            foreach ($carriers as $carrier) {
                if (!isset($result[$carrier['carrier']])) {
                    $result[$carrier['carrier']] = $carrier['method'];
                } else {
                    $result[$carrier['carrier']] = array_unique(array_merge($result[$carrier['carrier']], $carrier['method']));
                }
            }
        }

        return $result;
    }

    public function getShippingTemplates(): array
    {
        $rulePrice = [];
        $ruleWeight = [];
        $stConfig = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_SHIPPING_TEMPLATES, null, null, []);
        $stConfig = is_array($stConfig) ? $stConfig : [];
        $rules = $stConfig['rules'] ?? [];

        foreach ($rules as $ruleType => $rulesByType) {
            foreach ($rulesByType as $ruleId => $rule) {
                if ($ruleType == Rule::TYPE_WEIGHT) {
                    $ruleWeight[$ruleId] = new RuleByWeight($rule['min'] ?? 0, $rule['max'] ?? 0, $rule['unit'] ?? '', $rule['name'] ?? '');
                } else {
                    $rulePrice[$ruleId] = new RuleByPrice($rule['min'] ?? 0, $rule['max'] ?? 0, $rule['name'] ?? '');
                }
            }
        }

        return [
            'enable' => $stConfig['enable'] ?? false,
            'types' => [
                Rule::TYPE_PRICE => [
                    'displayType' => $this->module->l('Price'),
                    'requireUnit' => false,
                ],
                Rule::TYPE_WEIGHT => [
                    'displayType' => $this->module->l('Weight'),
                    'requireUnit' => true,
                ],
            ],
            'use_type' => $stConfig['use_type'] ?? Rule::TYPE_PRICE,
            'use_unit' => $stConfig['use_unit'] ?? Configuration::get('PS_WEIGHT_UNIT'),
            'rules' => [
                Rule::TYPE_PRICE => $rulePrice,
                Rule::TYPE_WEIGHT => $ruleWeight,
            ],
        ];
    }

    protected function getCronConfig($savedData): array
    {
        $skeleton = [
            CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ => [
                'enable' => 0,
                'frequency' => 30,
            ],
            CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA => [
                'enable' => 0,
                'frequency' => 30,
            ],
            CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS => [
                'enable' => 0,
                'frequency' => 30,
            ],
            CronConstant::CRON_AMT_TYPE_ORDERS_IMPORT => [
                'enable' => 0,
                'frequency' => 30,
                'params' => [
                    'statuses' => Order::ORDER_STATUS_UNSHIPPED,
                ],
            ],
            CronConstant::CRON_AMT_TYPE_ORDERS_FULFILL => [
                'enable' => 0,
                'frequency' => 30,
            ],
            CronConstant::CRON_AMT_TYPE_CREATE_FBA_ORDERS => [
                'enable' => 0,
                'frequency' => 30,
            ],
            CronConstant::CRON_AMT_TYPE_AMAZON_CANCELLATION_ORDERS => [
                'enable' => 0,
                'frequency' => 60,
            ],
            CronConstant::CRON_AMT_TYPE_SUPERVISE_IN_CART_ORDERS => [
                'enable' => 0,
                'frequency' => 60,
            ],
        ];

        return array_replace_recursive($skeleton, $savedData ?: []);
    }

    protected function hasOneScheduledTaskAtLeast(array $moduleConfigs): bool
    {
        if ($moduleConfigs[ConfigurationConstant::AMT_CONFIG_CRON][CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ]['enable']) {
            return true;
        }
        if ($moduleConfigs[ConfigurationConstant::AMT_CONFIG_CRON][CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA]['enable']) {
            return true;
        }
        if ($moduleConfigs[ConfigurationConstant::AMT_CONFIG_CRON][CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS]['enable']) {
            return true;
        }
        if ($moduleConfigs[ConfigurationConstant::AMT_CONFIG_CRON][CronConstant::CRON_AMT_TYPE_ORDERS_IMPORT]['enable']) {
            return true;
        }
        if ($moduleConfigs[ConfigurationConstant::AMT_CONFIG_CRON][CronConstant::CRON_AMT_TYPE_ORDERS_FULFILL]['enable']) {
            return true;
        }
        if ($moduleConfigs[ConfigurationConstant::AMT_CONFIG_CRON][CronConstant::CRON_AMT_TYPE_CREATE_FBA_ORDERS]['enable']) {
            return true;
        }
        if ($moduleConfigs[ConfigurationConstant::AMT_CONFIG_CRON][CronConstant::CRON_AMT_TYPE_AMAZON_CANCELLATION_ORDERS]['enable']) {
            return true;
        }
        if ($moduleConfigs[ConfigurationConstant::AMT_CONFIG_CRON][CronConstant::CRON_AMT_TYPE_SUPERVISE_IN_CART_ORDERS]['enable']) {
            return true;
        }

        return false;
    }

    private function searchProductTypeDefinitions($keywords = null): array
    {
        $context = Context::getContext();
        $active_marketplace = Configuration::get(
            KEY::CONFIG_PRESTASHOP_KEY_ACTIVE_MARKEPLACE,
            null,
            $context->shop->id_shop_group,
            $context->shop->id
        ) ?: AmazonConstant::MKP_FR;

        $region = Region::searchRegionByMkp($active_marketplace);
        /** @var ServiceAPIHelper $saasHelper */
        $saasHelper = SaaSConnector::initHelperWithConnector($region, [$active_marketplace]);
        try {
            $amzResponse = $saasHelper->searchDefinitionsProductTypes([], $keywords);

            /** @var ProductTypeList $productTypeData */
            $productTypeData = $amzResponse->getAmazonData();
            $productTypes = [];
            foreach ($productTypeData->getProductTypes() as $productType) {
                $productTypes[] = [
                    'id' => $productType->getName(),
                    'name' => $productType->getName(),
                ];
            }

            return $productTypes;
        } catch (\Exception $exception) {
            return [];
        }
    }
}
