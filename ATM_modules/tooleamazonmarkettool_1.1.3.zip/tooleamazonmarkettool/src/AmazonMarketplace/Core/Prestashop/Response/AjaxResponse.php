<?php
/**
 * AjaxResponse
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  AmazonMarketplaceGeneralDataConfiguration
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Response;

if (!defined('_PS_VERSION_')) {
    exit;
}

class AjaxResponse
{
    protected $hasError = false;
    protected $errors = [];

    protected $hasWarnings = false;
    protected $warnings = [];

    protected $hasMessage = false;
    protected $messages = [];

    protected $isContinuous = false;
    protected $continue = false;

    protected $data = [];

    public function __construct($errors, $warnings, $messages, $isContinuous, $continue, $data)
    {
        $this->errors = is_array($errors) ? $errors : [];
        $this->hasError = count($this->errors) > 0;
        $this->warnings = is_array($warnings) ? $warnings : [];
        $this->hasWarnings = count($this->warnings) > 0;
        $this->messages = is_array($messages) ? $messages : [];
        $this->hasMessage = count($this->messages) > 0;
        $this->isContinuous = (bool) $isContinuous;
        $this->continue = (bool) $continue;
        $this->data = $data;
    }

    public function addErrors($errors): AjaxResponse
    {
        if (is_array($errors)) {
            foreach ($errors as $error) {
                $this->addError($error);
            }
        } elseif (is_string($errors)) {
            $this->addError($errors);
        }

        return $this;
    }

    public function addWarnings($warnings): AjaxResponse
    {
        if (is_array($warnings)) {
            foreach ($warnings as $warning) {
                $this->addWarning($warning);
            }
        } elseif (is_string($warnings)) {
            $this->addWarning($warnings);
        }

        return $this;
    }

    public function addMessages($messages): AjaxResponse
    {
        if (is_array($messages)) {
            foreach ($messages as $message) {
                $this->addMessage($message);
            }
        } elseif (is_string($messages)) {
            $this->addMessage($messages);
        }

        return $this;
    }

    public function addError($error)
    {
        $this->errors[] = $error;
    }

    public function addWarning($warning)
    {
        $this->warnings[] = $warning;
    }

    public function addMessage($msg)
    {
        $this->messages[] = $msg;
    }

    public function __toString()
    {
        return json_encode([
            'hasError' => count($this->getErrors()) > 0,
            'errors' => $this->getErrors(),
            'hasWarning' => count($this->getWarnings()) > 0,
            'warnings' => $this->getWarnings(),
            'hasMessage' => count($this->getMessages()) > 0,
            'messages' => $this->getMessages(),
            'isContinuous' => $this->isContinuous,
            'continue' => $this->continue,
            'data' => $this->data,
        ]);
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public function getWarnings(): array
    {
        return $this->warnings;
    }

    public function getMessages(): array
    {
        return $this->messages;
    }
}
