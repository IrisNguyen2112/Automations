<?php
/**
 *  OrderProduct
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes;

use Tax;

if (!defined('_PS_VERSION_')) {
    exit;
}

class OrderProduct
{
    public $psId;
    public $quantity;
    public $price;
    public $hasTax;
    public $taxAmount;
    public $giftWrap;
    public $giftWrapTax;

    public function getUnitPriceTaxIncl()
    {
        // Price from Amazon is tax included
        return $this->price;
    }

    public function getUnitPriceTaxExcl($psIdAddress, $priceDisplayMethod)
    {
        if ($this->hasTax) {
            return $this->price - ($this->taxAmount / $this->quantity);
        }

        $psTaxRate = $this->getPsTaxRate($psIdAddress, $priceDisplayMethod);
        return $psTaxRate ? $this->price / ((100 + $psTaxRate) / 100) : $this->price;
    }

    public function getTotalPriceTaxIncl()
    {
        return $this->getUnitPriceTaxIncl() * $this->quantity;
    }

    public function getTotalPriceTaxExcl($psIdAddress, $priceDisplayMethod)
    {
        return $this->getUnitPriceTaxExcl($psIdAddress, $priceDisplayMethod) * $this->quantity;
    }

    public function getGiftWrapTaxIncl()
    {
        if ($this->giftWrap) {
            return $this->giftWrap;
        }

        return 0;
    }

    public function getGiftWrapTaxExcl()
    {
        if ($this->giftWrap) {
            if ($this->hasTax) {
                // Wrap is considered for all items in same type
                return $this->giftWrap - $this->giftWrapTax;
            }
        }

        return 0;
    }

    private function getPsTaxRate($psIdAddress, $priceDisplayMethod)
    {
        if ($this->hasTax && $priceDisplayMethod) {
            return Tax::getProductTaxRate($this->psId, $psIdAddress);
        }

        return 0;
    }
}
