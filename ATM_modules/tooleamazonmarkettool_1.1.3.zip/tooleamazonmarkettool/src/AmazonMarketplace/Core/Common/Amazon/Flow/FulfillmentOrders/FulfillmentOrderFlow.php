<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\FulfillmentOrders;

class FulfillmentOrderFlow
{
    protected $errors = [];
    protected $warnings = [];
    protected $confirmations = [];
    protected $isSandbox = false;

    /**
     * @return array
     */
    public function getConfirmations(): array
    {
        return $this->confirmations;
    }

    /**
     * @return array
     */
    public function getWarnings(): array
    {
        return $this->warnings;
    }

    /**
     * @return array
     */
    public function getErrors(): array
    {
        return $this->errors;
    }
}
