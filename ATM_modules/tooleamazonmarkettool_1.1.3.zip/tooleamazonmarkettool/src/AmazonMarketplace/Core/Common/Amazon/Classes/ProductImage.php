<?php
/**
 *  ProductImage
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes;

use Toole\Module\Amazon\Client\V2\Model\CatalogSync\Image;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ProductImage extends Image
{
    const TYPE_MAIN = 'Main';
    const TYPE_SWATCH = 'Swatch';
    const TYPE_PT_PREFIX = 'PT';
}
