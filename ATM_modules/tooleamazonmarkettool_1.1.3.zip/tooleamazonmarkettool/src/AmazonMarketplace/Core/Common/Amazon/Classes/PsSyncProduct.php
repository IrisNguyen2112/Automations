<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes;

use Toole\Module\Amazon\Client\V2\Model\CatalogSync\CatalogSyncItem;

if (!defined('_PS_VERSION_')) {
    exit;
}

class PsSyncProduct extends CatalogSyncItem
{
    public function setSku($sku): CatalogSyncItem
    {
        $sku = trim($sku);
        parent::setSku($sku);
        if ($this->getProductIdType() == self::PRODUCT_ID_TYPE_SKU) {
            $this->setProductIdCode($sku);
        }

        return $this;
    }

    public function setAsin($asin): CatalogSyncItem
    {
        $asin = trim($asin);
        parent::setAsin($asin);
        if ($this->getProductIdType() == self::PRODUCT_ID_TYPE_ASIN) {
            $this->setProductIdCode($asin);
        }

        return $this;
    }

    public function setEan($ean): CatalogSyncItem
    {
        $ean = trim($ean);
        parent::setEan($ean);
        if ($this->getProductIdType() == self::PRODUCT_ID_TYPE_EAN) {
            $this->setProductIdCode($ean);
        }

        return $this;
    }

    public function setRawImages(array $images): CatalogSyncItem
    {
        $totalImg = count($images);
        $imgSet = [];
        if ($totalImg) {
            if ($totalImg > 8) {
                $images = array_slice($images, 0, 8);
            }
            $main = array_shift($images);
            if ($main) {
                $imgSet[] = new ProductImage(['type' => ProductImage::TYPE_MAIN, 'url' => $main]);
            }
            $swatch = array_shift($images);
            if ($swatch) {
                $imgSet[] = new ProductImage(['type' => ProductImage::TYPE_SWATCH, 'url' => $swatch]);
            }

            $ptIndex = 1;
            foreach ($images as $image) {
                $ptType = ProductImage::TYPE_PT_PREFIX . $ptIndex;
                $imgSet[] = new ProductImage(['type' => $ptType, 'url' => $image]);
                ++$ptIndex;
            }
        }
        $this->setImages($imgSet);

        return $this;
    }

    public function setChildren(array $children): CatalogSyncItem
    {
        return $this->setRelation(PsSyncRelationship::createParentInstance($children));
    }

    public function setParent($parent): CatalogSyncItem
    {
        return $this->setRelation(PsSyncRelationship::createChildInstance($parent));
    }

    public function toArray(): array
    {
        return json_decode(json_encode($this), true);
    }
}
