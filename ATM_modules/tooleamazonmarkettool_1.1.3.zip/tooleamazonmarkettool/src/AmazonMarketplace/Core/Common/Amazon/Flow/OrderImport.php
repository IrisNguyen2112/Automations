<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Carrier;
use Cart;
use Configuration;
use Context;
use Currency;
use Customer;
use Db;
use DbQuery;
use Exception;
use Generator;
use Module;
use OrderDetail;
use OrderState;
use PrestaShopDatabaseException;
use PrestaShopException;
use Product;
use StockAvailable;
use Symfony\Contracts\Translation\TranslatorInterface;
use Toole\Module\Amazon\Client\Model\Address;
use Toole\Module\Amazon\Client\Model\BuyerInfo;
use Toole\Module\Amazon\Client\Model\Order;
use Toole\Module\Amazon\Client\Model\OrderItem;
use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Cart as TeCart;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\OrderProduct as TeProduct;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Payment;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Address as AddressHelper;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Name;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Order as OrderHelper;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Carrier as CarrierHelper;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;
use Toole\Module\Utils\Utils;
use TooleAmazonMarketAmazonOrder;
use TooleAmazonMarketAmazonOrderItem;
use Tools;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class OrderImport
{
    private $amazonOrderIds;

    protected $errors = [];
    protected $warnings = [];
    protected $confirmations = [];
    protected $debugs = [];
    private $orders = [];

    private $cronMode;

    private $availableMarketplaces;

    const AFN = 'AFN';
    const MFN = 'MFN';
    const BUYER_MAIL_DOMAIN = 'amazon.toolecommerce.com';

    protected $idLang;
    protected $originCurrencyCode;
    protected $originCurrencyId;
    /** @var Module */
    protected $module;
    private $isPaid = false;

    /** @var TranslatorInterface */
    protected $translator;

    /** @var ServiceAPIV3Helper */
    protected $saasHelper;
    protected $id_shop;

    public function __construct($amazonOrderIds, ServiceAPIV3Helper $saasHelper, Module $module, Currency $currency, $id_shop, $cronMode = false)
    {
        $this->amazonOrderIds = $amazonOrderIds;
        $this->cronMode = $cronMode;
        $this->saasHelper = $saasHelper;
        $this->idLang = Configuration::get('PS_LANG_DEFAULT');
        $this->originCurrencyCode = $currency->iso_code;
        $this->originCurrencyId = $currency->id;
        $this->module = $module;
        $this->id_shop = $id_shop;
        $amzConnector = $this->saasHelper->getAmazonConnector();
        $this->availableMarketplaces = $amzConnector ? $amzConnector->getAvailableMarketplaces() : [];
        $this->translator = $module->getTranslator();

        $this->validate();
    }

    /**
     * @throws Exception
     */
    private function validate()
    {
        if (!$this->amazonOrderIds) {
            throw new Exception($this->module->l('No Orders have been selected'));
        }

        if (!$this->cronMode && count($this->amazonOrderIds) > 50) {
            throw new Exception(sprintf($this->module->l('Too many orders have been selected. The maximum number is %s'), 50));
        }
    }

    public function importOrders()
    {
        foreach ($this->amazonOrderIds as $k => $orderId) {
            if (TooleAmazonMarketAmazonOrder::isExistingImportedOrderByThisModule($orderId)) {
                $message = sprintf($this->module->l('Order (%s) already exists'), $orderId);
                $this->warnings[] = $message;
                unset($this->amazonOrderIds[$k]);
            }
        }

        $orderGenerator = $this->saasHelper->getOrdersAll([], null, null, null, null, null, null, $this->amazonOrderIds);
        $this->importList($orderGenerator, $this->amazonOrderIds);
    }

    private function importList($amazonOrders, $ordersIds)
    {
        foreach ($amazonOrders as $order) {
            if (!($order instanceof Order)) {
                continue;
            }

            $orderId = $order->getAmazonOrderId();

            if (!$this->validateAvailableMarketplace($order->getMarketplaceId())) {
                if ($this->cronMode) {
                    $message = sprintf('Order ID (%s) is not enabled in the marketplace', $orderId);
                } else {
                    $message = sprintf($this->module->l('Order ID (%s) is not enabled in the marketplace'), $orderId);
                }

                $this->warnings[] = $message;

                continue;
            }
            if ($order->getIsReplacementOrder()) {
                $message = sprintf(
                    $this->module->l('Order ID (%s) has been replaced by ID (%s)'),
                    $orderId,
                    $order->getReplacedOrderId()
                );
                $this->warnings[] = $message;

                continue;
            }
            if (!$this->cronMode && !in_array($orderId, $ordersIds)) {
                continue;
            }

            $this->importOneOrder($order);
        }
    }

    private function importOneOrder(Order $order)
    {
        $order_id = $order->getAmazonOrderId();

        try {
            $orderResult = $this->importOneOrderMainLogic($order);
            $orderResult['status'] = true;
            $this->confirmations[] = sprintf('Order (%s) imported successfully', $order_id);
        } catch (Exception|PrestaShopException $exception) {
            $failedReason = $exception->getMessage();
            $this->errors[] = $failedReason;
            $this->debugs[] = $exception->getTraceAsString();

            $orderResult = ['status' => false, 'reason' => $failedReason];
        }
        $orderResult['purchase_date'] = $order->getPurchaseDate();
        $orderResult['marketplace'] = $order->getMarketplaceId();

        // prevent overriding when tryPreviousFailedOrders imported the order successfully, to acknowledge later
        if (!isset($this->orders[$order_id]) || !$this->orders[$order_id]['status']) {
            $this->orders[$order_id] = $orderResult;
        }
    }

    /**
     * @throws PrestaShopException
     * @throws Exception
     */
    private function importOneOrderMainLogic(Order $order): array
    {
        $order_id = $order->getAmazonOrderId();

        // 1. Validate order
        if ($order->getOrderStatus() == Order::ORDER_STATUS_CANCELED) {
            throw new Exception($this->module->l('Skipping canceled order'), self::ERR_STATUS_CANCELLED);
        }
        if ($order->getOrderStatus() == Order::ORDER_STATUS_PENDING) {
            throw new Exception($this->module->l('Skipping pending order'), self::ERR_STATUS_PENDING);
        }
        $orderCurrency = $this->getOrderCurrency($order);

        $orderItems = $this->getAllOrderItems($this->getOrderItemsApi($order), $order_id);
        if ($order->getFulfillmentChannel() == self::AFN
            && 'Non-Amazon' == (string) $order->getSalesChannel()
            && !$order->getOrderTotal()->getCurrencyCode()) {
            throw new Exception(sprintf($this->module->l('AFN order without price: (%s)'), $order_id));
        }

        // 2. Fill missing info by default data
        if ($shippingAddress = $this->fillDefaultDataShippingAddress($order)) {
            $order->setShippingAddress($shippingAddress);
        }
        if ($buyerInfo = $this->fillDefaultDataBuyerInfo($order)) {
            $order->setBuyerInfo($buyerInfo);
        }

        // 3. Prepare context. Switch context to order's currency
        Context::getContext()->currency = $orderCurrency;
        $id_currency_from = $orderCurrency->id;

        // 4. Do importing, resolve PS objects
        // Customer
        $customer = $this->resolveCustomer($order);
        // Addresses
        $shipping_address_id = $this->resolveShippingAddress($customer->id, $order);
        $billing_address_id = $shipping_address_id;
        // Carrier
        $carrier = $this->resolveCarrier($order);

        Context::getContext()->customer = $customer;
        // 5. Build cart
        $cart = $this->resolveCart($shipping_address_id, $billing_address_id, $carrier->id, $customer->id);
        $cartItems = $this->resolveItems($order, $cart, $orderItems, $id_currency_from);
        $orderDataResult = $cartItems['orderDataResult'];
        $itemDetails = $cartItems['itemDetails'];
        $totalShipping = $cartItems['totalShipping'];
        $totalShippingTax = $cartItems['totalShippingTax'];
        if (!count($itemDetails)) {
            $this->deleteCart($cart);

            throw new Exception($this->module->l('Skipping Order: No products for this order') . ' (' . $order->getAmazonOrderId() . ')');
        }
        if (!$cart->getProducts()) {
            $this->deleteCart($cart);

            throw new Exception(sprintf($this->module->l('Unable to get product from cart for order: %s'), $order->getAmazonOrderId()));
        }
        $teOrder = $this->resolveToolEOrder($order);
        $teCart = new TeCart($itemDetails, $customer, $carrier, $shipping_address_id, $totalShipping, $totalShippingTax);

        // Get Order State
        if (!$idOrderState = $this->getIdStateForOrder()) {
            $this->deleteCart($cart);

            throw new Exception($this->module->l('Selected order status is no longer available. Please check your settings: Configuration/Orders/Incoming Orders Status'));
        }

        $date_add = date('Y-m-d H:i:s', strtotime($order->getPurchaseDate()));
        // check duplicate order - importing by non native PS module
        $amount = OrderHelper::sanityPrice($teCart->calPriceTotal(true));
        if (TooleAmazonMarketAmazonOrder::isExistingImportedOrderByOtherModule($date_add, $amount, $this->module->name)) {
            throw new Exception(sprintf($this->module->l('Order (%s) already exists'), $order_id));
        }

        // 6. Create order + payment
        $payment = new Payment(
            $cart, $teCart, $teOrder, $idOrderState, $this->module->name, $this->module->displayName,
            $date_add, Context::getContext()->shop->id, Context::getContext()->shop->id_shop_group, true, $this->isPaid
        );
        $newOrderId = $payment->payOrder();
        if (!$newOrderId) {
            $this->deleteCart($cart);

            throw new Exception($this->module->l('Error while importing this order') . ': ' . $order->getAmazonOrderId());
        }

        // store order items
        $amzOrder = TooleAmazonMarketAmazonOrder::getOrderByPsOrderId($newOrderId);
        $psOrderDetails = $this->getPsOrderDetailIdsByOrderId($newOrderId);
        $this->importOrderItems($orderItems, $amzOrder['id_order'], $psOrderDetails);

        // 7. Restore original currency
        Context::getContext()->currency = new Currency($this->originCurrencyId);
        $orderDataResult['merchant_order_id'] = $newOrderId;
        $orderDataResult['marketplace'] = $order->getMarketplaceId();
        $orderDataResult['ps_url'] = Context::getContext()->link->getAdminLink('AdminOrders', true, [], ['id_order' => $newOrderId, 'vieworder' => 1]);

        return $orderDataResult;
    }

    /**
     * @throws Exception
     */
    protected function getAllOrderItems($apiResult, $mpOrderId): array
    {
        $result = [];

        foreach ($apiResult as $item) {
            if (!$item instanceof OrderItem) {
                throw new Exception($this->module->l('Unable to retrieve items for Amazon order') . ': ' . $mpOrderId . '. ' . print_r($item, true));
            }

            $sku = trim($item->getSellerSku());
            if ($item->getQuantityOrdered() <= 0) {
                $this->warnings[] = sprintf(
                    $this->module->l('Skipping zero quantity item for order #%s product SKU: %s'),
                    $mpOrderId,
                    $sku
                );
            } else {
                $combination = \Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Product::findProductBySku($sku, false, $this->idLang, 'reference', $this->id_shop);
                if (!$this->getIdByReference($sku) && !$combination) {
                    throw new Exception(sprintf($this->module->l('SKU/Reference not found. Please check the existence of this product: %s'), $sku));
                }
                $result[] = $item;
            }
        }

        if (!count($result)) {
            throw new Exception($this->module->l('Item list is empty for order') . ': ' . $mpOrderId);
        }

        return $result;
    }

    private function getIdByReference($reference)
    {
        if (empty($reference)) {
            return 0;
        }

        if (!Validate::isReference($reference)) {
            return 0;
        }

        $query = new DbQuery();
        $query->select('p.id_product');
        $query->from('product', 'p');
        $query->where('p.reference = \'' . pSQL($reference) . '\'');

        return Db::getInstance()->getValue($query);
    }

    protected function getOrderItemsApi(Order $order): Generator
    {
        return $this->saasHelper->getOrderItems($order->getAmazonOrderId());
    }

    private function checkCurrency($id_currency)
    {
        if ($id_currency) {
            $currency = new Currency($id_currency);
            if (Validate::isLoadedObject($currency)) {
                return $currency;
            }
        }

        return false;
    }

    /**
     * @throws PrestaShopException
     * @throws PrestaShopDatabaseException
     * @throws Exception
     */
    private function resolveCustomer(Order $order): Customer
    {
        $orderId = $order->getAmazonOrderId();
        $email_address = (string) $order->getBuyerInfo()->getBuyerEmail();
        $customer = new Customer();
        $customer->getByEmail($email_address);
        if ($customer->id) {
            return $customer;
        }

        $nameSegment = Name::parseAmazonName($order->getShippingAddress()->getName());
        $customer->firstname = $nameSegment['firstname'];
        $customer->lastname = $nameSegment['lastname'];
        $customer->company = $nameSegment['company'];
        $customer->newsletter = false;
        $customer->optin = false;
        $customer->email = $email_address;
        $customer->passwd = md5(rand());
        $customer->id_default_group = 3;
        $customer->id_lang = $this->idLang;

        if (!Validate::isName($customer->firstname) || !Validate::isName($customer->lastname) || !Validate::isEmail($customer->email)) {
            throw new Exception($this->module->l('Cannot add customer with name or address.') . ' Order: ' . $orderId);
        }

        $validateResult = $customer->validateFields(false, true);
        if ($validateResult !== true) {
            throw new Exception($validateResult . " Order: $orderId");
        }

        if (!$customer->add()) {
            throw new Exception($this->module->l('Cannot save customer'));
        }

        return $customer;
    }

    /**
     * @throws \PrestaShop\PrestaShop\Core\Foundation\IoC\Exception
     */
    private function resolveShippingAddress($id_customer, Order $order): int
    {
        $shipping_address = AddressHelper::lookupOrCreateAmazonAddress($this->idLang, $order->getShippingAddress(), $order->getBuyerTaxInformation(), $id_customer);

        return $shipping_address->id;
    }

    /**
     * @throws Exception
     */
    private function resolveCarrier($order): Carrier
    {
        $carrierName = $order->getShipServiceLevel();
        $isAccessPointOrder = $order->getIsAccessPointOrder();
        $incomingCarriers = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_INCOMING_CARRIERS);

        if ($incomingCarriers && is_array($incomingCarriers)) {
            foreach ($incomingCarriers as $incomingCarrier) {
                if ($incomingCarrier['amazon_carrier'] === trim($carrierName)) {
                    $mappingCarrierId = $isAccessPointOrder === true ? $incomingCarrier['access_point'] : $incomingCarrier['non-access_point'];
                    $carrierId = CarrierHelper::getIdCurrentlyUsing($mappingCarrierId);
                    if ($carrierId) {
                        $carrier = new Carrier($carrierId);
                        if (Validate::isLoadedObject($carrier)) {
                            return $carrier;
                        }
                        if (!$carrier->active) {
                            throw new Exception(sprintf($this->module->l('Carrier %s is not active. Please check and map in Module Configuration -> Orders -> Carriers for incoming orders'), $carrier->name));
                        }
                    }
                }
            }
        }

        throw new Exception(sprintf($this->module->l('Carrier %s is not available. Please check and map in Module Configuration -> Orders -> Carriers for incoming orders'), $carrierName));
    }

    /**
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     * @throws Exception
     */
    private function resolveCart($shipping_address_id, $billing_address_id, $id_carrier, $id_customer): Cart
    {
        $cart = new Cart();
        $cart->id_address_delivery = $shipping_address_id;
        $cart->id_address_invoice = $billing_address_id;
        $cart->id_carrier = $id_carrier;
        $cart->id_currency = Context::getContext()->currency->id;
        $cart->id_customer = $id_customer;
        $cart->id_lang = $this->idLang;

        if (($validation_message = $cart->validateFields(false, true)) !== true) {
            $this->deleteCart($cart);
            throw new Exception($this->module->l('Cannot save customer') . $validation_message);
        }
        $cart->add();

        return $cart;
    }

    private function resolveToolEOrder(Order $order): TooleAmazonMarketAmazonOrder
    {
        $teOrder = new TooleAmazonMarketAmazonOrder();
        $teOrder->id_shop = Context::getContext()->shop->id;
        $teOrder->id_shop_group = Context::getContext()->shop->id_shop_group;
        $teOrder->mp_order_id = $order->getAmazonOrderId();
        $teOrder->mp_status = $order->getOrderStatus();
        $teOrder->channel = $order->getFulfillmentChannel();
        $teOrder->marketplace_id = Tools::substr($order->getMarketplaceId(), 0, 16);
        $teOrder->buyer_name = Tools::substr($order->getBuyerInfo()->getBuyerName(), 0, 32);
        $teOrder->sales_channel = Tools::substr($order->getSalesChannel(), 0, 32);
        $teOrder->order_channel = Tools::substr($order->getOrderChannel(), 0, 32);
        $teOrder->ship_service_level = Tools::substr(trim($order->getShipServiceLevel()), 0, 32);
        $teOrder->is_prime = (bool) $order->getIsPrime();
        $teOrder->is_premium = (bool) $order->getIsPremiumOrder();
        $teOrder->is_business = (bool) $order->getIsBusinessOrder();
        $teOrder->is_acknowledged = false;
        $teOrder->earliest_ship_date = $order->getEarliestShipDate();
        $teOrder->latest_ship_date = $order->getLatestShipDate();
        $teOrder->earliest_delivery_date = $order->getEarliestDeliveryDate();
        $teOrder->latest_delivery_date = $order->getLatestDeliveryDate();
        $teOrder->is_access_point = (bool) $order->getIsAccessPointOrder();

        return $teOrder;
    }

    /**
     * @throws Exception
     */
    private function resolveItems(Order $order, Cart $cart, $items, $id_currency_from): array
    {
        $priceInclTax = false; // Except EU & Japan, prices do not include tax
        if ($this->saasHelper->getAmazonConnector()->getRegion() == AmazonConstant::MKP_REGION_EU || $order->getMarketplaceId() == AmazonConstant::MKP_JP) {
            $priceInclTax = true;
        }

        $orderDataResult = [];
        $itemDetails = [];
        $totalShipping = 0;
        $totalShippingTax = 0;
        $i = 0;
        $order_id = $order->getAmazonOrderId();

        /** @var OrderItem $item */
        foreach ($items as $item) {
            $SKU = trim((string) $item->getSellerSKU());
            /*$idBySku = Product::getIdByReference($SKU);
            if (!$idBySku) {
                throw new Exception("Cannot find the product $SKU");
            }*/
            $product = \Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Product::findProductBySku($SKU, false, $this->idLang, 'reference', $this->id_shop);
            if (!Validate::isLoadedObject($product)) {
                throw new Exception('Cannot load the product' . $SKU);
            }
            $id_product = (int) $product->id;
            if (!$product->active) {
                throw new Exception('Unable to import inactive product' . $SKU);
            }
            if (isset($product->available_for_order) && !$product->available_for_order) {
                throw new Exception(sprintf($this->module->l('Unable to import unavailable product %s'), $SKU));
            }
            // id_product_attribute is set dynamically
            if (empty($product->id_product_attribute) && isset($product->minimal_quantity) && $product->minimal_quantity > 1) {
                throw new Exception(sprintf($this->module->l('Product %s has a minimum order quantity'), $SKU));
            }

            $quantity = $item->getQuantityOrdered();
            $shipping_discount = 0;
            if ($item->getShippingDiscount() && $item->getShippingDiscount()->getAmount()) {
                $shipping_discount = (float) $item->getShippingDiscount()->getAmount();
            }
            $buyerInfo = $item->getBuyerInfo();
            $discount = (float) $item->getPromotionDiscount()->getAmount();
            $price = ((float) $item->getItemPrice()->getAmount() - ($discount ?: 0)) / $quantity;
            $giftwrap = $buyerInfo && $buyerInfo->getGiftWrapPrice() ? (float) $buyerInfo->getGiftWrapPrice()->getAmount() : null;
            $shipping_price = $item->getShippingPrice() ? $item->getShippingPrice()->getAmount() - $shipping_discount : 0;
            $item_tax = (float) $item->getItemTax()->getAmount();
            $shipping_tax = $item->getShippingTax() ? $item->getShippingTax()->getAmount() : 0;
            $giftwrap_tax = $buyerInfo && $buyerInfo->getGiftWrapTax() ? (float) $buyerInfo->getGiftWrapTax()->getAmount() : null;
            $itemCurrency = $item->getItemPrice()->getCurrencyCode();

            /*if ($id_currency_from != $this->originCurrencyId) {
                $from_currency = new Currency($id_currency_from);
                $price = Tools::ps_round(Tools::convertPrice($price, $from_currency, false), 2);
                $giftwrap = $giftwrap ? Tools::ps_round(Tools::convertPrice($giftwrap, $from_currency, false), 2) : null;
                $shipping_price = $shipping_price ? Tools::ps_round(Tools::convertPrice($shipping_price, $from_currency, false), 2) : null;
                $item_tax = $item_tax ? Tools::ps_round(Tools::convertPrice($item_tax, $from_currency, false), 2) : null;
                $shipping_tax = $shipping_tax ? Tools::ps_round(Tools::convertPrice($shipping_tax, $from_currency, false), 2) : null;
                $giftwrap_tax = $giftwrap_tax ? Tools::ps_round(Tools::convertPrice($giftwrap_tax, $from_currency, false), 2) : null;
            }*/

            $amazon_has_tax = $item_tax || $shipping_tax || $giftwrap_tax;

            $totalShipping += $shipping_price;
            $totalShippingTax += $shipping_tax;
            $product_name = (string) $item->getTitle();
            $order_item_id = $item->getOrderItemId();

            $itemCurrency = new Currency(Currency::getIdByIsoCode($itemCurrency));
            $orderDataResult['products'][$i] = [
                'SKU' => $SKU,
                'ASIN' => $item->getASIN(),
                'OrderItemId' => $order_item_id,
                'product' => $product_name,
                'quantity' => $quantity,
                'price' => Utils::formatPrice($price * $quantity, $itemCurrency),
                'id_product' => $product->id,
                'id_product_attribute' => $product->id_product_attribute ?? null,
            ];

            if (!$priceInclTax) {
                $price += ($item_tax / $quantity);
                $giftwrap += $giftwrap_tax;
            }

            $itemDetails[$SKU] = $this->resolveItemTeProduct(
                $product->id,
                $quantity, $price, $amazon_has_tax, $item_tax, $giftwrap, $giftwrap_tax
            );

            // Product Combinations
            $combinations = $product->getAttributeCombinations($this->idLang);
            $id_product_attribute = 0;
            $minimal_quantity = $product->minimal_quantity;
            if ($combinations) {
                foreach ($combinations as $combination) {
                    if (trim($combination['reference']) == $SKU) {
                        $id_product_attribute = (int) $combination['id_product_attribute'];
                        $minimal_quantity = $combination['minimal_quantity'];

                        break;
                    }
                }
            }
            if ($minimal_quantity > 1) {
                throw new Exception($this->module->l('Unable to import order with a product with a minimal quantity greater than 1') . "$order_id ($id_product-$id_product_attribute)");
            }

            $productQuantity = Product::getQuantity($id_product, $id_product_attribute, null, $cart);
            $availableOutOfStock = Product::isAvailableWhenOutOfStock(StockAvailable::outOfStock($product->id));
            if ($quantity > $productQuantity && !$availableOutOfStock) {
                throw new Exception(sprintf($this->module->l('Insufficient enough stock (ASIN: %s : SKU: %s : Order: #%s)'), $item->getASIN(), $SKU, $order_id));
            }

            // amzStockZero change Behavior when out of stock to Use default behavior (Deny orders) --Product/Tab Quantities setting
            $res = $cart->updateQty($quantity, $id_product, $id_product_attribute);
            if ($res === false) {
                throw new Exception(sprintf($this->module->l('Unable to add item to cart (ASIN: %s : SKU: %s : Order: #%s)'), $item->getASIN(), $SKU, $order_id));
            }
            if ($res < 0) {
                throw new Exception(sprintf($this->module->l('Not enough stock (ASIN: %s : SKU: %s : Order: #%s)'), $item->getASIN(), $SKU, $order_id));
            }

            ++$i;
        }

        return [
            'orderDataResult' => $orderDataResult,
            'itemDetails' => $itemDetails,
            'totalShipping' => $totalShipping,
            'totalShippingTax' => $totalShippingTax,
        ];
    }

    private function resolveItemAdditionalInfo(OrderItem $item): array
    {
        $additionalInfo = [];
        if ($item->getDeemedResellerCategory()) {
            $additionalInfo['DeemedResellerCategory'] = [
                'display_name' => 'Deemed Reseller Category',
                'value' => $item->getDeemedResellerCategory(),
            ];
        }
        if ($item->getIossNumber()) {
            $additionalInfo['IossNumber'] = ['display_name' => 'Ioss Number', 'value' => $item->getIossNumber()];
        }

        return $additionalInfo;
    }

    private function resolveItemTeProduct($psId, $totalQty, $price, $hasTax, $item_tax, $giftwrap, $giftwrap_tax): TeProduct
    {
        $teProduct = new TeProduct();
        $teProduct->psId = $psId;
        $teProduct->quantity = $totalQty;
        $teProduct->price = $price;
        $teProduct->hasTax = $hasTax;
        $teProduct->taxAmount = $item_tax;
        $teProduct->giftWrap = $giftwrap;
        $teProduct->giftWrapTax = $giftwrap_tax;

        return $teProduct;
    }

    private function deleteCart($cart)
    {
        if (Validate::isLoadedObject($cart)) {
            $cart->delete();
        }
    }

    protected function getOrderCurrency(Order $order): Currency
    {
        $orderCurCode = $order->getOrderTotal()->getCurrencyCode();
        $id_currency = Currency::getIdByIsoCode($orderCurCode, Context::getContext()->shop->id);

        if (!$id_currency) {
            throw new Exception($this->module->l('Unable to load currency') . ': ' . $orderCurCode, self::ERR_CURRENCY_NOT_FOUND);
        }

        return new Currency($id_currency);
    }

    private function fillDefaultDataShippingAddress(Order $order): ?Address
    {
        if (empty($order->getShippingAddress())) {
            $address = new Address();
        } elseif (empty($order->getShippingAddress()->getName())) {
            $address = $order->getShippingAddress();
        } else {
            // Return nothing to keep the address as is
            return null;
        }

        // Fill required address data
        if (empty($address->getName())) {
            $address->setName($order->getBuyerInfo()->getBuyerName());
        }
        if (empty($address->getAddressLine1())) {
            $address = $this->fillDefaultDataShippingAddressLine1($address);
        }
        if (empty($address->getCity())) {
            $address = $this->fillDefaultDataShippingAddressCity($address);
        }
        if (empty($address->getPostalCode())) {
            $address = $this->fillDefaultDataShippingAddressPostalCode($address);
        }

        return $address;
    }

    private function fillDefaultDataShippingAddressLine1(Address $address): Address
    {
        return $address->setAddressLine1(
            $this->module->l('Unknown Address')
        );
    }

    private function fillDefaultDataShippingAddressCity(Address $address): Address
    {
        return $address->setCity(
            $this->module->l('Unknown')
        );
    }

    private function fillDefaultDataShippingAddressPostalCode(Address $address): Address
    {
        return $address->setPostalCode('1000');
    }

    private function fillDefaultDataBuyerInfo(Order $order): ?BuyerInfo
    {
        if (empty($order->getBuyerInfo()->getBuyerEmail())) {
            return $order->getBuyerInfo()
                ->setBuyerEmail(sprintf('amz-%s@%s', $order->getAmazonOrderId(), self::BUYER_MAIL_DOMAIN));
        }

        return null;
    }

    private function validateAvailableMarketplace($orderMkpId): bool
    {
        return in_array($orderMkpId, $this->availableMarketplaces, true);
    }

    const ERR_CURRENCY_NOT_FOUND = '1001';
    const ERR_STATUS_CANCELLED = '2001';
    const ERR_STATUS_PENDING = '2002';

    private function getIdStateForOrder(): string
    {
        $state = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_ORDER_STATUS_IMPORT);
        if ($state) {
            $psState = new OrderState($state);
            if (Validate::isLoadedObject($psState) && !$psState->deleted) {
                $this->isPaid = (bool) $psState->paid;

                return $psState->id;
            }
        }

        return false;
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public function getWarnings(): array
    {
        return $this->warnings;
    }

    public function getConfirmations(): array
    {
        return $this->confirmations;
    }

    public function getDebugs(): array
    {
        return $this->debugs;
    }

    public function getResultOrders(): array
    {
        return $this->orders;
    }

    /**
     * @throws PrestaShopException
     * @throws Exception
     */
    private function importOrderItems(array $orderItems, int $psOrderId, array $psOrderDetails): void
    {
        /** @var OrderItem $item */
        foreach ($orderItems as $item) {
            $teOrderItem = new TooleAmazonMarketAmazonOrderItem();
            $teOrderItem->id_order = (int) $psOrderId;
            $teOrderItem->ps_order_detail_id = $psOrderDetails[$item->getSellerSku()] ?? 0;
            $teOrderItem->asin = $item->getAsin();
            $teOrderItem->seller_sku = $item->getSellerSku();
            $teOrderItem->order_item_id = $item->getOrderItemId();
            $teOrderItem->quantity = $item->getQuantityOrdered();
            $teOrderItem->item_price = $item->getItemPrice();
            $teOrderItem->shipping_price = $item->getShippingPrice();
            $teOrderItem->item_tax = $item->getItemTax();
            $teOrderItem->shipping_tax = $item->getShippingTax();
            if (!$teOrderItem->save(null, true)) {
                throw new Exception('Save Order Item Failed');
            }
        }
    }

    private function getPsOrderDetailIdsByOrderId(int $newOrderId): array
    {
        $orderDetails = OrderDetail::getList($newOrderId);
        $orderDetailIds = [];
        if ($orderDetails) {
            foreach ($orderDetails as $orderDetail) {
                $orderDetailIds[$orderDetail['product_reference']] = $orderDetail['id_order_detail'];
            }
        }

        return $orderDetailIds;
    }
}
