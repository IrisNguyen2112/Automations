<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper;

use Toole\Module\Amazon\Client\ContentType;
use Tools;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Report
{
    public static function fetchReport($resourceUrl, $compressAlgorithm, $contentType)
    {
        $rawContents = Tools::file_get_contents($resourceUrl);
        $contents = Tools::strtoupper($compressAlgorithm) === 'GZIP' ? gzdecode($rawContents) : $rawContents;

        switch ($contentType) {
            // All current reports are TAB, add other cases if use
            case ContentType::TAB:
                return preg_replace('/(\t|^)\"([^\"]+?)(\t|\n)/', '$1\"\"$2$3', $contents);
            default:
                return $contents;
        }
    }
}
