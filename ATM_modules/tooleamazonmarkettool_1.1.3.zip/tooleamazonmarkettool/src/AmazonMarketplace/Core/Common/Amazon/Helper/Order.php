<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper;

use Db;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Tools;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Order
{
    public static function sanityPrice($price): float
    {
        return Tools::ps_round(max(0, $price), 2);
    }

    /**
     * @param $orderState
     * @param $id_shop
     * @param bool $since
     *
     * @return array|bool|\mysqli_result|\PDOStatement|resource|null
     * @throws \PrestaShopDatabaseException
     */
    public static function getPsOrderIdsForCreatingFbaOrders($orderState, $id_shop, $since = false)
    {
        if ($since) {
            $dateRange = ' AND o.`date_add` >= "' . pSQL($since) . '" ';
        } else {
            $dateRange = '';
        }
        $sql = 'SELECT o.`id_order` FROM `' . _DB_PREFIX_ . 'orders` o
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FBA_ORDERS . '` fba_o ON fba_o.`ps_order_id` = o.`id_order`
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` amz_o ON amz_o.`ps_order_id` = o.`id_order`
                WHERE o.`current_state` = ' . (int) $orderState . $dateRange . '
                    AND o.`id_shop` = ' . (int) $id_shop . '
                    AND fba_o.`id_fba_order` is null
                    AND amz_o.`id_order` is null
                GROUP by o.`id_order` ORDER BY o.`date_add` desc ';

        return Db::getInstance()->executeS($sql);
    }
}
