<?php
/**
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate;

class Rule
{
    const TYPE_PRICE = 'price';
    const TYPE_WEIGHT = 'weight';

    public $min;
    public $max;
    public $name;
    public $type;

    public function __construct($min, $max, $name, $type)
    {
        $this->min = $min;
        $this->max = $max;
        $this->name = $name;
        $this->type = $type;
    }

    protected function validateMinMax($inputValue): bool
    {
        if ($this->min <= $inputValue && $inputValue <= $this->max) {
            return true;
        }

        return false;
    }
}
