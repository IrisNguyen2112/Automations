<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\FulfillmentOrders;

use Configuration;
use Context;
use Exception;
use Module;
use Order;
use OrderCarrier;
use PrestaShopDatabaseException;
use PrestaShopException;
use Symfony\Component\Translation\TranslatorInterface;
use Toole\Module\Amazon\Client\V3\Model\FulfillmentOrder\FulfillmentOrderStatus;
use Toole\Module\Amazon\Client\V3\Model\FulfillmentOrder\GetFulfillmentOrderResponse;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;
use ToolEAmazonMarketFbaOrder;

class UpdateFulfillmentOrder extends FulfillmentOrderFlow
{
    /* @var ServiceAPIV3Helper */
    protected $saasHelper;
    protected $fbaOrderIds;
    protected $marketplaceId;
    protected $context;
    protected $module;
    protected $cronMode = false;
    /** @var TranslatorInterface */
    protected $translator;

    /**
     * @throws Exception
     */
    public function __construct(ServiceAPIV3Helper $saasHelper, array $fbaOrderIds, string $marketplaceId, Context $context, Module $module, $cronMode = false)
    {
        $this->saasHelper = $saasHelper;
        $this->fbaOrderIds = $fbaOrderIds;
        $this->marketplaceId = $marketplaceId;
        $this->context = $context;
        $this->module = $module;
        $this->cronMode = $cronMode;
        $this->translator = $this->module->getTranslator();
        $this->isSandbox = (bool) Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SANDBOX');

        if (!Region::searchRegionByMkp($marketplaceId)) {
            throw new Exception(sprintf($this->module->l('Unknown marketplace %s'), $marketplaceId));
        }
    }

    /**
     * @throws PrestaShopException
     * @throws PrestaShopDatabaseException
     */
    public function doUpdate()
    {
        $this->module->log->message(sprintf('FBA - update fulfillment order by %s', $this->cronMode ? 'Cron' : 'Manual'));

        $fulfillStatus = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_CONFIG_FBA_SETTINGS);
        $fbaShippedOrderStatus = $fulfillStatus[ConfigurationConstant::AMT_FBA_SHIPPED_ORDER_STATUS] ?? null;
        $fbaDeliveredOrderStatus = $fulfillStatus[ConfigurationConstant::AMT_FBA_DELIVERED_ORDER_STATUS] ?? null;

        foreach ($this->fbaOrderIds as $fbaOrderId) {
            $fbaOrder = new ToolEAmazonMarketFbaOrder($fbaOrderId);
            $sellerFulfillmentOrderId = $fbaOrder->seller_fulfillment_order_id;
            $apiResult = $this->saasHelper->getFulfillmentOrder($sellerFulfillmentOrderId, $this->isSandbox);

            /** @var GetFulfillmentOrderResponse $response */
            $response = $apiResult->getAmazonData();
            $ffmOrderPayload = $response->getPayload();

            if ($ffmOrderPayload) {
                $orderFulfillment = $ffmOrderPayload->getFulfillmentOrder();
                $fulfillmentShipment = $ffmOrderPayload->getFulfillmentShipments()[0] ?? [];
                $orderStatus = $orderFulfillment->getFulfillmentOrderStatus();
                $statusUpdatedDate = $orderFulfillment->getStatusUpdatedDate()->format('Y-m-d H:i:s');

                $fbaOrder->fulfillment_order_status = $orderStatus;
                $fbaOrder->status_updated_date = $statusUpdatedDate;
                $fbaOrder->update();

                // update ps order
                if (!empty($fulfillmentShipment)) {
                    $shipmentPackage = $fulfillmentShipment->getFulfillmentShipmentPackage();

                    if (!empty($shipmentPackage->getTrackingNumber())) {
                        $orderCarrier = new OrderCarrier((int) $fbaOrder->ps_order_id);
                        $orderCarrier->tracking_number = $shipmentPackage->getTrackingNumber();
                        $orderCarrier->update();

                        $currentStatus = $fbaShippedOrderStatus;

                        if (FulfillmentOrderStatus::COMPLETE == $orderStatus && $fulfillmentShipment->getEstimatedArrivalDate() !== null) {
                            $now = date('Y-m-d H:i:s');
                            $estimatedArrival = $fulfillmentShipment->getEstimatedArrivalDate()->format('Y-m-d H:i:s');

                            if ($estimatedArrival <= $now) {
                                $currentStatus = $fbaDeliveredOrderStatus;
                            }
                        }

                        $psOrder = new Order((int) $fbaOrder->ps_order_id);
                        $psOrder->setCurrentState($currentStatus);
                        $psOrder->update();
                    }
                }
            }

            if ($response->getErrors()) {
                $this->errors[] = $this->module->l('Failed to get fulfillment Order');

                foreach ($response->getErrors() as $error) {
                    $this->errors[] = $error->getMessage();
                }

                return;
            }

            $this->warning[] = $this->module->l('Update Fulfillment Order Successfully');

            $this->module->log->message(sprintf('FBA - Cancel fulfillment order #%s successful', $fbaOrderId));
        }
    }
}
