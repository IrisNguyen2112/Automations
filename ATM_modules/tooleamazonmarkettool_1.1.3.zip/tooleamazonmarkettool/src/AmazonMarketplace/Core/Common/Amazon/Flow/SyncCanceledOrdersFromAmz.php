<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Module;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;
use TooleAmazonMarketAmazonOrder;

class SyncCanceledOrdersFromAmz extends CatalogSyncFromAmazon
{
    protected $psCancelState;

    public function __construct(Module $module, ServiceAPIV3Helper $saasHelper, $domain, $uuid, $reportType, $dataStartTime = null, $idEntity = null, $isFBA = false, $additionalParams = null, $cronMode = false)
    {
        $this->psCancelState = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_ORDER_STATUS_CANCEL);
        parent::__construct($module, $saasHelper, $domain, $uuid, $reportType, $dataStartTime, $idEntity, $isFBA, $additionalParams, $cronMode);
    }

    public function doTheSync($mrkId)
    {
        $isContinuous = false;
        $this->requestReport();
        $report = $this->getReportResult();
        $reportData = $this->getParseReportResult();

        if (!empty($report->getDocumentUrl())) {
            $this->processingAmazonOffers($reportData->getData(), $mrkId);

            if ($reportData->getHasMore()) {
                $isContinuous = true;
            }
        } elseif ($report->isProcessFailed()) {
            $this->uuid = $report->getUuid();
        } else {
            $isContinuous = true;
            $this->uuid = $report->getUuid();
        }

        if (!$isContinuous) {
            /* storage last statistic report data */
            $this->storageLastStatisticReportData($mrkId, $reportData->getStatistic());
        }

        return $isContinuous;
    }

    public function processingAmazonOffers($offers, $mrkId): void
    {
        $importedOffers = 0;

        foreach ($offers as $item) {
            $this->log->message(sprintf('Start bulk synchronizing all amazon products - Marketplace ID #%s', $mrkId));
            $amzOrderId = $item['amazon-order-id'];
            $orderStatus = $item['order-status'];
            $psOrder = TooleAmazonMarketAmazonOrder::isExistingImportedOrderByThisModule($amzOrderId);
            $psOrderId = $psOrder ? $psOrder->id : 0;

            // ignore if this order already has been cancelled
            if (TooleAmazonMarketAmazonOrder::isCancelled($amzOrderId)) {
                $msg = sprintf($this->translator->trans(
                    'Order (%s) has been cancelled',
                    [],
                    'Modules.Amazonmarkettool.Admin'
                ), $amzOrderId);
                $this->log->success($msg);
                $this->confirmations[] = $msg;
                continue;
            }

            if ($psOrderId) {
                // update amazon order
                TooleAmazonMarketAmazonOrder::updateMarketplaceStatus($amzOrderId, $orderStatus);

                // update ps order
                $psOrder->setCurrentState($this->psCancelState);
                $msg = sprintf($this->translator->trans(
                    'Cancel Order (%s) Successfully',
                    [],
                    'Modules.Amazonmarkettool.Admin'
                ), $amzOrderId);
                $this->log->success($msg);
                $this->confirmations[] = $msg;
                ++$importedOffers;
            }
        }

        // add warning / confirmation for imported offers
        if ($importedOffers < 1) {
            $this->warnings[] = $this->module->l('No offers have been imported');
        } elseif ($importedOffers == 1) {
            $this->confirmations[] = $this->module->l('1 Amazon offer has been imported');
        } else {
            $this->confirmations[] = sprintf(
                $this->module->l('%d Amazon offers have been imported'),
                $importedOffers
            );
        }

        $this->offersImportedFromReport = $importedOffers;
    }
}
