<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Validate
{
    public static function validSku($sku): bool
    {
        return $sku && preg_match('/[\x00-\xFF]{1,40}/', $sku) && preg_match('/[^ ]$/', $sku);
    }
}
