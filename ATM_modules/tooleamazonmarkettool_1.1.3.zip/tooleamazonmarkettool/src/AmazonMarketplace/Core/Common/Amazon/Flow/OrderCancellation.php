<?php
/**
 * OrderCancellation
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Exception;
use Module;
use Order as PsOrder;
use OrderState;
use PrestaShop\PrestaShop\Adapter\Entity\Db;
use Toole\Module\Amazon\Client\Model\Order;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\Amazon\Client\V4\Model\OrdersCancellation\OrderItemCancellation;
use Toole\Module\Amazon\Client\V4\Model\OrdersCancellation\OrdersCancellationByMkp;
use Toole\Module\Amazon\Client\V4\Model\OrdersCancellation\OrdersCancellationResponse;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v4\ServiceAPIV4Helper;
use TooleAmazonMarketAmazonFeed;
use TooleAmazonMarketAmazonOrder;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class OrderCancellation extends OrderFulfillment
{
    protected $cancel_reason;

    public function __construct(ServiceAPIV4Helper $saasHelper, $teOrderIds, Module $module, $cronMode = false, $cancel_reason = '')
    {
        $this->psSentState = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_OUTGOING_ORDER_STATUS_CANCEL);
        $validCancelReason = OrderItemCancellation::definedCancelReasonAllowableValues();
        $this->cancel_reason = $validCancelReason[$cancel_reason] ?? '';

        parent::__construct($saasHelper, $teOrderIds, $module, $cronMode);
    }

    public function doCancel()
    {
        $region = Region::getRegionNameByCode($this->saasHelper->getAmazonConnector()->getRegion());
        $this->module->log->message(sprintf('Amazon %s', $region));

        $this->module->log->message(sprintf(
            'Cancel order by %s. Order State: %s. Delay: %s',
            $this->cronMode ? 'Cron' : 'Manual',
            $this->psSentState,
            $this->delay
        ));

        if (!$this->psSentState) {
            if ($this->cronMode) {
                $this->errors[] = 'Order status is empty';
            } else {
                $this->errors[] = $this->translator->trans(
                    'Order status is empty',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
            }

            return;
        }

        $orderState = new OrderState($this->psSentState);
        if (!Validate::isLoadedObject($orderState)) {
            if ($this->cronMode) {
                $this->errors[] = 'Order status is invalid';
            } else {
                $this->errors[] = $this->translator->trans(
                    'Order status is invalid',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
            }

            return;
        }

        $mrkIds = $this->saasHelper->getAmazonConnector()->getAvailableMarketplaces();
        $orders = $this->getOrdersToCancel($mrkIds);
        if (empty($orders)) {
            if ($this->cronMode) {
                $this->warnings[] = 'No orders yet. Please check Order Status has been entered or not.';
            } else {
                $this->warnings[] = $this->translator->trans(
                    'No orders yet. Please check Order Status has been entered or not.',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
            }

            return;
        }

        $ordersGroupedByMkp = [];
        foreach ($orders as $order) {
            $marketplaceId = $order['marketplace_id'];
            $importedOrder = new TooleAmazonMarketAmazonOrder($order['id_order']);
            $orderDetails = $this->getOrderDetails($order['id_order']);

            $items = [];
            foreach ($orderDetails as $orderDetail) {
                $orderDetail['cancel_reason'] = $this->cancel_reason;
                $items[] = new OrderItemCancellation($orderDetail);
            }
            $ordersGroupedByMkp[$marketplaceId][] = new \Toole\Module\Amazon\Client\V4\Model\OrdersCancellation\OrderCancellation([
                'amazon_order_id' => $importedOrder->mp_order_id,
                'items' => $items,
            ]);
        }

        $tobeSent = [];
        foreach ($ordersGroupedByMkp as $mkpId => $ordersCancellation) {
            $tobeSent[] = new OrdersCancellationByMkp([
                'marketplace' => $mkpId,
                'orders' => $ordersCancellation,
            ]);
        }

        try {
            $apiResult = $this->saasHelper->ordersAcknowledgeCancel($tobeSent);
        } catch (Exception $exception) {
            $this->errors[] = $this->translator->trans('Unable to cancel order', [], 'Modules.Amazonmarkettool.Admin');
            $this->errors[] = $exception->getMessage();

            return;
        }

        /** @var OrdersCancellationResponse $response */
        $response = $apiResult->getAmazonData();
        $totalItemExported = $response->getTotalItems();
        $totalFeeds = $response->getTotalFeeds();
        $feeds = $response->getFeeds();
        if ($totalItemExported < 1 || $totalFeeds < 1 || !count($feeds)) {
            if ($this->cronMode) {
                $this->warnings[] = 'Export done but no item was processed.';
            } else {
                $this->warnings[] = $this->translator->trans('Export done but no item was processed.', [], 'Modules.Amazonmarkettool.Admin');
            }

            return;
        }

        foreach ($feeds as $feed) {
            $idFeed = TooleAmazonMarketAmazonFeed::saveRecord([
                'marketplace_id' => $feed->getMarketplaces()[0],
                'feed_type' => $feed->getFeedType(),
                'feed_id' => $feed->getFeedId(),
                'status' => TooleAmazonMarketAmazonFeed::SENT_STATUS,
                'content_location' => $feed->getContentLocation(),
            ]);
            $this->module->log->message(
                $this->translator->trans('Sent Feed (%feed_id%) - (%feed_type%) successfully.', ['%feed_id%' => $feed->getFeedId(), '%feed_type%' => $feed->getFeedType()], 'Modules.Amazonmarkettool.Admin'),
                $idFeed
            );
        }

        $this->confirmations[] = sprintf(
            $this->translator->trans('Orders Cancelled successfully. Sent %d item(s), received %d feeds(s)', [], 'Modules.Amazonmarkettool.Admin'),
            $totalItemExported, $totalFeeds
        );

        foreach ($orders as $order) {
            if (!in_array($order['mp_order_id'], $this->orderErrorIds)) {
                TooleAmazonMarketAmazonOrder::updateMarketplaceStatus($order['mp_order_id'], Order::ORDER_STATUS_CANCELED);

                if ($order['ps_order_id']) {
                    $psOrder = new PsOrder($order['ps_order_id']);
                    $psOrder->setCurrentState(\Configuration::get('PS_OS_CANCELED'));
                }
            }
        }
        $this->module->log->message(
            'Cancelled the order(s).'
        )
            ->success($this->translator->trans(
                'Cancelled the order(s).',
                [],
                'Modules.Tooleamazonmarkettool.Admin'
            ));
    }

    private function getOrdersToCancel(array $mrkIds)
    {
        $psOrderStatus = '';
        if ($this->psSentState) {
            $psOrderStatus = ' AND o.`current_state` = ' . (int) $this->psSentState;
        }
        if (!$this->cronMode) {
            $cdtLimitOrders = 'mp.`id_order` IN (' . implode(',', $this->teOrderIds) . ')';
        } else {
            $cdtLimitOrders = 'o.`date_add` > DATE_ADD(NOW(), INTERVAL -' . (int) $this->delay . ' DAY)';
        }
        $conditionMrkIds = '';
        if ($mrkIds) { // query by marketplaces
            $conditionMrkIds = ' AND mp.`marketplace_id` IN ("' . implode('","', $mrkIds) . '")';
        }

        $sql = '
            SELECT
                mp.`id_order`, o.`id_lang`, mp.`mp_order_id`, mp.`marketplace_id`,
                o.`date_add` AS `date_place`, mp.`ps_order_id`
            FROM `' . _DB_PREFIX_ . 'orders` o
            JOIN `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` mp ON (o.`id_order` = mp.`ps_order_id`)
            WHERE o.`module` = "' . $this->module->name . '"
            AND ' . $cdtLimitOrders . $conditionMrkIds . $psOrderStatus . '
            AND mp.`mp_status` != "' . Order::ORDER_STATUS_CANCELED . '"
            AND mp.`channel` != "' . Order::FULFILLMENT_CHANNEL_AFN . '"
            ORDER BY mp.`marketplace_id`';

        $this->debugs[] = $sql;

        return Db::getInstance()->executeS($sql);
    }

    private function getOrderDetails(int $psOrderId)
    {
        return Db::getInstance()
            ->executeS('SELECT o.`order_item_id` as amazon_order_item_id
                FROM `' . _DB_PREFIX_ . Database::TABLE_ORDER_ITEMS . '` o
                WHERE o.`id_order` = ' . (int) $psOrderId);
    }
}
