<?php
/**
 * FbaOrder
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\FulfillmentOrders;

use Address;
use Context;
use Country;
use Db;
use Exception;
use Module;
use Order;
use OrderState;
use PrestaShopDatabaseException;
use PrestaShopException;
use State;
use Symfony\Component\Translation\TranslatorInterface;
use Toole\Module\Amazon\Client\V3\Model\FbaInventory\GetInventorySummariesResponse;
use Toole\Module\Amazon\Client\V3\Model\FbaInventory\GetInventorySummariesResult;
use Toole\Module\Amazon\Client\V3\Model\FulfillmentOrder\CreateFulfillmentOrderResponse;
use Toole\Module\Amazon\Client\V3\Model\FulfillmentOrder\ShippingSpeedCategory;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;
use TooleAmazonMarketAmazonEntity;
use ToolEAmazonMarketFbaOrder;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class CreateFulfillmentOrder extends FulfillmentOrderFlow
{
    const MAX_BACK_OFF_DAYS = 7;

    /* @var ServiceAPIV3Helper */
    protected $saasHelper;
    protected $psOrderIds;
    protected $marketplaceId;
    protected $langId;
    protected $entityId;
    protected $context;
    protected $module;
    protected $cronMode = false;
    /** @var TranslatorInterface */
    protected $translator;
    protected $psOrders;
    protected $psSentState;

    public function __construct(array $psOrderIds, Context $context, Module $module, $fulfillStatus, bool $cronMode = false)
    {
        $this->psOrderIds = $psOrderIds;
        $this->context = $context;
        $this->module = $module;
        $this->cronMode = $cronMode;
        $this->langId = $context->language->id;
        $this->psSentState = $fulfillStatus;
        $this->translator = $this->module->getTranslator();
        $this->isSandbox = (bool) \Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SANDBOX');
        if (!$this->psOrderIds || count($this->psOrderIds) == 0) {
            $this->warnings[] = $this->module->l('No orders yet. Please check Order Status.');
            $this->module->log->message('No orders yet. Please check Order Status.');

            return;
        }

        $this->psOrders = $this->getPsOrderIdsWithEntity();
    }

    /**
     * @throws PrestaShopException
     * @throws PrestaShopDatabaseException
     * @throws Exception
     */
    public function doCreate(): void
    {
        $this->module->log->message(sprintf(
            'FBA - Create FBA order by %s',
            $this->cronMode ? 'Cron' : 'Manual',
        ));

        if (!$this->psSentState) {
            if ($this->cronMode) {
                $this->errors[] = 'Order status is empty';
            } else {
                $this->errors[] = $this->module->l('Order status is empty');
            }

            return;
        }

        $orderState = new OrderState($this->psSentState);
        if (!Validate::isLoadedObject($orderState)) {
            if ($this->cronMode) {
                $this->errors[] = 'Order status is invalid';
            } else {
                $this->errors[] = $this->module->l('Order status is invalid');
            }

            return;
        }

        if (!$this->psOrders || count($this->psOrders) == 0) {
            $this->warnings[] = $this->module->l('No orders yet. Please check Order Status.');
            $this->module->log->message('No orders yet. Please check Order Status.');

            return;
        }

        $currentEntity = '';
        foreach ($this->psOrders as $psOrder) {
            $psOrderId = $psOrder['id_order'] ?? null;
            $this->marketplaceId = $psOrder['entity'] ?? null;

            if (!$psOrderId && !$this->marketplaceId) {
                $this->module->log->message('FBA - invalid request');

                continue;
            }

            if (!Region::searchRegionByMkp($this->marketplaceId)) {
                throw new Exception(sprintf($this->module->l('Unknown marketplace %s'), $this->marketplaceId));
            }

            if (!$currentEntity || $currentEntity != $this->marketplaceId) {
                $currentEntity = $this->marketplaceId;
                $region = Region::searchRegionByMkp($currentEntity);

                $this->saasHelper = SaaSConnector::initHelperWithConnector($region, [$currentEntity], true);
            }

            $psOrder = new Order($psOrderId);
            $psOrderItems = $this->getOrderDetails($psOrderId);
            $items = [];

            if (!$psOrderItems) {
                $this->module->log->message('FBA - Empty Order Details');

                continue;
            }

            $sellerSKUs = [];
            foreach ($psOrderItems as $orderItem) {
                $sellerSKUs[$orderItem['product_reference']] = $orderItem['product_quantity'];
                $items[] = [
                    'seller_sku' => $orderItem['product_reference'],
                    'seller_fulfillment_order_item_id' => $orderItem['id_order_detail'],
                    'quantity' => $orderItem['product_quantity'],
                ];
            }

            // Validate Product SKUs in FBA order
            if (!$this->isSandbox && $sellerSKUs && !$this->doValidateProductSKUsInFbaOrder($sellerSKUs)) {
                $this->errors[] = sprintf($this->module->l('Failed to validate Product SKUs (%s)'), implode(',', array_keys($sellerSKUs)));

                continue;
            }

            $destinationAddress = new Address($psOrder->id_address_delivery);
            $state = new State($destinationAddress->id_state);
            $country = new Country($destinationAddress->id_country);
            $address = [
                'name' => $destinationAddress->firstname . ' ' . $destinationAddress->lastname,
                'address_line1' => $destinationAddress->address1 ?? '',
                'state_or_region' => $state->iso_code ?? $country->iso_code ?? '',
                'city' => $destinationAddress->city,
                'postal_code' => $destinationAddress->postcode,
                'country_code' => $country->iso_code ?? '',
            ];
            $date_add = gmdate('Y-m-d\TH:i:s\Z', strtotime($psOrder->date_add));

            $seller_fulfillment_order_id = $psOrder->reference;
            $displayable_order_comment = 'Order #' . $seller_fulfillment_order_id . ' from ' . $this->module->displayName . ' (Prestashop)';

            try {
                $apiResult = $this->saasHelper->createFulfillmentOrder($this->marketplaceId, $seller_fulfillment_order_id, $seller_fulfillment_order_id, $date_add, $displayable_order_comment, ShippingSpeedCategory::STANDARD, null, $address, null, null, null, null, null, null, $items, null, $this->isSandbox);
            } catch (Exception $exception) {
                $this->errors[] = sprintf($this->module->l('Unable to create FBA order') . ' #%s', $psOrderId);
                $this->errors[] = $exception->getMessage();

                continue;
            }

            /** @var CreateFulfillmentOrderResponse $response */
            $response = $apiResult->getAmazonData();
            if ($response->getErrors()) {
                $this->errors[] = sprintf($this->module->l('Failed to create FBA Order') . ' #%s', $psOrderId);

                foreach ($response->getErrors() as $error) {
                    $this->errors[] = $error->getMessage();
                }

                continue;
            }

            // storage FBA order
            $fbaOrder = new ToolEAmazonMarketFbaOrder();
            $fbaOrder->id_shop = $psOrder->id_shop;
            $fbaOrder->id_shop_group = $psOrder->id_shop_group;
            $fbaOrder->id_entity = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->marketplaceId);
            $fbaOrder->ps_order_id = $psOrderId;
            $fbaOrder->seller_fulfillment_order_id = $seller_fulfillment_order_id;
            $fbaOrder->displayable_order_id = $seller_fulfillment_order_id;
            $fbaOrder->displayable_order_date = $psOrder->date_add;
            $fbaOrder->displayable_order_comment = $displayable_order_comment;
            $fbaOrder->received_date = date('Y-m-d H:i:s');
            $fbaOrder->status_updated_date = date('Y-m-d H:i:s');
            $fbaOrder->shipping_speed_category = ShippingSpeedCategory::STANDARD;
            $fbaOrder->date_add = date('Y-m-d H:i:s');
            $fbaOrder->date_upd = date('Y-m-d H:i:s');
            $fbaOrder->save();

            $this->module->log->message(sprintf('FBA - Create FBA order #%s successful', $psOrderId));
        }
    }

    /**
     * @throws PrestaShopDatabaseException
     */
    private function getPsOrderIdsWithEntity()
    {
        $sql = 'SELECT DISTINCT en.entity, o.id_order FROM `' . _DB_PREFIX_ . 'orders` o
                JOIN `' . _DB_PREFIX_ . 'address` a on a.`id_address` = o.`id_address_delivery`
                JOIN `' . _DB_PREFIX_ . 'country` c on c.`id_country` = a.`id_country`
                JOIN `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` en on en.`iso_code` = c.`iso_code`
                WHERE o.`id_order` IN (' . implode(',', $this->psOrderIds) . ')
                    AND o.`id_lang` = ' . (int) $this->langId . '
                    AND o.`current_state` = ' . (int) $this->psSentState . '
                ORDER BY en.`id_entity`';

        return Db::getInstance()->executeS($sql);
    }

    /**
     * Validate Product SKU in FBA order
     */
    private function doValidateProductSKUsInFbaOrder(array $data): bool
    {
        $sellerSKUs = array_keys($data);

        try {
            $apiResult = $this->saasHelper->getInventorySummaries($this->marketplaceId, null, $sellerSKUs, $this->isSandbox);
        } catch (Exception $exception) {
            $this->errors[] = sprintf($this->module->l('Failed to get inventory summaries') . ' (%s)', implode(',', $sellerSKUs));
            $this->errors[] = $exception->getMessage();

            return false;
        }

        /** @var GetInventorySummariesResponse $response */
        $response = $apiResult->getAmazonData();
        if ($response->getErrors()) {
            $this->errors[] = sprintf($this->module->l('Failed to get inventory summaries') . ' (%s)', implode(',', $sellerSKUs));

            foreach ($response->getErrors() as $error) {
                $this->errors[] = $error->getMessage();
            }

            return false;
        }

        /* @var GetInventorySummariesResult $result */
        if ($result = $response->getPayload()) {
            $inventorySummaries = $result->getInventorySummaries();
            if (count($inventorySummaries) == 0) {
                $this->errors[] = sprintf($this->module->l('Inventory Summaries are empty - (%s)'), implode(',', $sellerSKUs));

                return false;
            } else {
                $skusAvailable = true;
                foreach ($inventorySummaries as $inventorySummary) {
                    if ($data[$inventorySummary->getSellerSku()] && $data[$inventorySummary->getSellerSku()] > $inventorySummary->getInventoryDetails()->getFulfillableQuantity()) {
                        $this->errors[] = sprintf($this->module->l('The number of SKU #%s unavailable'), $inventorySummary->getSellerSku());
                        $skusAvailable &= false;
                    }
                }

                if (!$skusAvailable) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * @throws PrestaShopDatabaseException
     */
    private function getOrderDetails(int $psOrderId)
    {
        return Db::getInstance()->executeS('SELECT o.`id_order_detail`, if (attr.`reference` is null, o.`product_reference`, attr.`reference`) as product_reference, o.`product_quantity` 
                FROM `ps_order_detail` o
                LEFT JOIN `ps_product_attribute` attr ON attr.id_product = o.product_id AND attr.id_product_attribute = o.product_attribute_id
                WHERE `id_order` = ' . (int) $psOrderId);
    }
}
