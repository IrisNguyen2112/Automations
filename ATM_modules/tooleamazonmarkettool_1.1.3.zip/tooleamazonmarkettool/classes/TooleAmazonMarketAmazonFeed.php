<?php
/**
 * TooleAmazonMarketAmazonFeed
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketAmazonFeed extends ObjectModel
{
    const SENT_STATUS = 1;
    const DONE_STATUS = 2;

    const DAYS_RESET_FEED = 90;

    public $id;
    public $id_shop;
    public $id_shop_group;
    public $marketplace_id;
    public $feed_type;
    public $feed_id;
    public $status;
    public $messages_status_code;
    public $messages_processed;
    public $messages_successful;
    public $messages_with_error;
    public $messages_with_warning;
    public $content_location;
    public $result_location;
    public $date_add;

    public static $definition = [
        'table' => Database::TABLE_FEEDS,
        'primary' => 'id',
        'multilang' => false,
        'fields' => [
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_shop_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'marketplace_id' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'feed_type' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'feed_id' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'status' => ['type' => self::TYPE_INT],
            'messages_status_code' => ['type' => self::TYPE_STRING],
            'messages_processed' => ['type' => self::TYPE_INT],
            'messages_successful' => ['type' => self::TYPE_INT],
            'messages_with_error' => ['type' => self::TYPE_INT],
            'messages_with_warning' => ['type' => self::TYPE_INT],
            'content_location' => ['type' => self::TYPE_STRING, 'size' => 255, 'validate' => 'isUrl'],
            'result_location' => ['type' => self::TYPE_INT, 'size' => 255, 'validate' => 'isUrl'],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDateFormat'],
        ],
    ];

    /**
     * @throws PrestaShopException
     */
    public static function saveRecord($data): ?int
    {
        // reset feed
        self::resetFeed();

        $feed = new self();
        $feed->id_shop = Context::getContext()->shop->id;
        $feed->id_shop_group = Context::getContext()->shop->id_shop_group;
        $feed->marketplace_id = $data['marketplace_id'] ?: '';
        $feed->feed_type = $data['feed_type'] ?: '';
        $feed->feed_id = $data['feed_id'] ?: '';
        $feed->status = $data['status'] ?: '';
        $feed->content_location = $data['content_location'] ?? '';
        $feed->result_location = $data['result_location'] ?? '';
        if (!$feed->id) {
            $feed->date_add = date('Y-m-d H:i:s');
        }
        if ($feed->save()) {
            return $feed->id;
        }
        return null;
    }

    /**
     * @param $feedSubmissionId
     * @param $data
     * @return void
     */
    public static function updateResult($data)
    {
        $sql = 'UPDATE  `' . _DB_PREFIX_ . Database::TABLE_FEEDS . '` fs
                  SET fs.`status` = "' . pSQL(self::DONE_STATUS) . '",
                      fs.`messages_status_code` = "' . pSQL($data->messages_status_code) . '",
                      fs.`messages_processed` = "' . pSQL($data->messages_processed) . '",
                      fs.`messages_successful` = "' . pSQL($data->messages_successful) . '",
                      fs.`messages_with_error` = "' . pSQL($data->messages_with_error) . '",
                      fs.`messages_with_warning` = "' . pSQL($data->messages_with_warning) . '",
                      fs.`result_location` = "' . pSQL($data->result_location) . '"
                  WHERE fs.`feed_id` = "' . pSQL($data->feed_id) . '" ;';

        Db::getInstance()->execute($sql);
    }

    public static function resetFeed(): void
    {
        $sql = 'DELETE FROM `' . _DB_PREFIX_ . Database::TABLE_FEEDS . '`
                    WHERE `status` = "' . pSQL(self::DONE_STATUS) . '"
                    AND `date_add` < DATE_SUB(NOW(), INTERVAL ' . self::DAYS_RESET_FEED . ' DAY)';
        Db::getInstance()->execute($sql);
    }
}
