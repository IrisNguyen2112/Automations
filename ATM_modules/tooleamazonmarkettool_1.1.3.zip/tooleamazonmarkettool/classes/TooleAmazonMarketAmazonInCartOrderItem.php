<?php
/**
 * TooleAmazonMarketAmazonInCartOrderItem
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketAmazonInCartOrderItem extends ObjectModel
{
    public $id;
    public $id_in_cart_order;
    public $id_product;
    public $id_product_attribute;
    public $quantity;
    public $date_add;
    public $date_upd;

    public static $definition = [
        'table' => Database::TABLE_IN_CART_ORDER_ITEMS,
        'primary' => 'id',
        'multilang' => false,
        'multishop' => false,
        'fields' => [
            'id_in_cart_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'id_product' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'id_product_attribute' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'quantity' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
        ],
    ];
}
