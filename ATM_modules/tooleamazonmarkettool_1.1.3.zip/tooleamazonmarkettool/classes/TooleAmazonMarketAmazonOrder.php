<?php
/**
 * TooleAmazonOrder
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\Model\Order as AmazonOrderModel;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderImport;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketAmazonOrder extends ObjectModel
{
    public $id_order;
    public $id_shop;
    public $id_shop_group;
    public $ps_order_id;
    public $mp_order_id;
    public $mp_status;
    public $channel;
    public $channel_status;
    public $marketplace_id;
    public $buyer_name;
    public $sales_channel;
    public $order_channel;
    public $ship_service_level;
    public $ship_category;
    public $is_prime;
    public $is_premium;
    public $is_business;
    public $is_acknowledged;
    public $earliest_ship_date;
    public $latest_ship_date;
    public $earliest_delivery_date;
    public $latest_delivery_date;
    public $shipping_services;
    public $is_access_point;

    public static $definition = [
        'table' => Database::TABLE_AMAZON_ORDERS,
        'primary' => 'id_order',
        'multilang' => false,
        'multishop' => false,
        'fields' => [
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_shop_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'ps_order_id' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'mp_order_id' => ['type' => self::TYPE_STRING, 'size' => 32, 'required' => true],
            'mp_status' => ['type' => self::TYPE_STRING, 'size' => 32, 'required' => false],
            'channel' => ['type' => self::TYPE_STRING, 'size' => 16, 'validate' => 'isName', 'required' => false],
            'channel_status' => ['type' => self::TYPE_STRING, 'size' => 24, 'validate' => 'isName', 'required' => false],
            'marketplace_id' => ['type' => self::TYPE_STRING, 'size' => 16, 'required' => false],
            'buyer_name' => ['type' => self::TYPE_STRING, 'size' => 32, 'required' => false],
            'sales_channel' => ['type' => self::TYPE_STRING, 'size' => 32, 'validate' => 'isName', 'required' => false],
            'order_channel' => ['type' => self::TYPE_STRING, 'size' => 32, 'validate' => 'isName', 'required' => false],
            'ship_service_level' => ['type' => self::TYPE_STRING, 'size' => 32, 'required' => false],
            'ship_category' => ['type' => self::TYPE_STRING, 'size' => 16, 'required' => false],
            'is_prime' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'is_premium' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'is_business' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'is_acknowledged' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => true],
            'earliest_ship_date' => ['type' => self::TYPE_DATE, 'required' => false],
            'latest_ship_date' => ['type' => self::TYPE_DATE, 'required' => false],
            'earliest_delivery_date' => ['type' => self::TYPE_DATE, 'required' => false],
            'latest_delivery_date' => ['type' => self::TYPE_DATE, 'required' => false],
            'shipping_services' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => false],
            'is_access_point' => ['type' => self::TYPE_BOOL, 'validate' => 'isBool', 'required' => false],
        ],
    ];

    public static function isCancelled($amzOrderId)
    {
        if (Database::tableExists(_DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS)) {
            $currentStatus = Db::getInstance()->getValue('SELECT a.`mp_status` FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` a WHERE a.`mp_order_id` = "' . $amzOrderId . '"');

            return $currentStatus == AmazonOrderModel::ORDER_STATUS_CANCELED;
        }

        return false;
    }

    public function isFulfillable(): bool
    {
        return in_array($this->mp_status, [AmazonOrderModel::ORDER_STATUS_UNSHIPPED, AmazonOrderModel::ORDER_STATUS_PARTIALLY_SHIPPED]);
    }

    public static function isExistingImportedOrderByThisModule($amazonOrderId): ?Order
    {
        if (Database::tableExists(_DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS)) {
            $sql = 'SELECT ao.`id_order`, ao.`ps_order_id` FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` ao
          		WHERE ao.`mp_order_id` = "' . pSQL($amazonOrderId) . '"
          		    AND ao.`id_shop` = ' . (int) Context::getContext()->shop->id . '
                    AND ao.`id_shop_group` = ' . (int) Context::getContext()->shop->id_shop_group . '
          		ORDER BY ao.`id_order` DESC';

            $result = Db::getInstance()->getRow($sql, false);
            if (!$result || !is_array($result)) {
                return null;
            }

            $psOrder = new Order($result['ps_order_id']);

            return Validate::isLoadedObject($psOrder) ? $psOrder : null;
        }

        return null;
    }

    public static function isExistingOrderItemByOrderId($id_order)
    {
        $sql = 'SELECT `id_order_item` FROM `' . _DB_PREFIX_ . Database::TABLE_ORDER_ITEMS . '`
                WHERE `id_order`=' . (int) $id_order;

        return Db::getInstance()->getValue($sql);
    }

    public static function isExistingImportedOrderByOtherModule($date_add, $amount, $module)
    {
        $sql = 'SELECT o.`id_order` FROM `' . _DB_PREFIX_ . 'orders` o
                WHERE (o.`module` != "' . pSQL($module) . '" AND o.`module` NOT LIKE "%ps_%")
                    AND o.`date_add` = "' . pSQL($date_add) . '"
                    AND o.`total_paid` = ' . (float) $amount;

        return Db::getInstance()->getValue($sql);
    }

    public static function updateMarketplaceStatus($amzOrderId, $status)
    {
        $sql = 'UPDATE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` o
				  SET  o.`mp_status` = "' . pSQL($status) . '"
				  WHERE o.`mp_order_id` = "' . $amzOrderId . '"';

        Db::getInstance()->execute($sql);
    }

    public static function getOrderByPsOrderId($id)
    {
        $sql = 'SELECT ao.*, o.current_state FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` ao
                LEFT JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.`id_order` = ao.`ps_order_id`)
                WHERE ao.`ps_order_id` = ' . (int) $id;

        return Db::getInstance()->getRow($sql);
    }

    public static function isValidStateToDo($mpStatus, $psState, $key, $action = 'fulfill'): bool
    {
        $validStatus = AmazonMarketConfiguration::get($key);

        if ($validStatus != $psState) {
            return false;
        }

        switch ($action) {
            case 'fulfill':
                return in_array($mpStatus, [AmazonOrderModel::ORDER_STATUS_UNSHIPPED, AmazonOrderModel::ORDER_STATUS_PARTIALLY_SHIPPED]);
            case 'cancel':
                return $mpStatus != AmazonOrderModel::ORDER_STATUS_CANCELED;
            default:
                return true;
        }
    }

    public function isAFNChannel(): bool
    {
        return $this->channel === OrderImport::AFN;
    }
}
