<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tooleamazonmarkettool}prestashop>filter_c52feaf85bffc4fa7e3ea596baec725e'] = 'Informazioni sul prodotto';
