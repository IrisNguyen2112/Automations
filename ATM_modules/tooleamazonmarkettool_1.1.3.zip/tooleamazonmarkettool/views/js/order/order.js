/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

$(document).ready(function () {

    // Date Picker
    if ($.datepicker.initialized !== 'undefined') {
        $("#date-to").datepicker({
            prevText: "",
            nextText: "",
            dateFormat: "yy-mm-dd",
            setDate: new Date()
        });
        $('#date-to').datepicker('setDate', new Date());

        $("#date-from").datepicker({
            prevText: "",
            nextText: "",
            dateFormat: "yy-mm-dd"
        });
        let today = new Date();
        let yesterday = new Date(today);
        yesterday.setDate(today.getDate() - 1);
        $('#date-from').datepicker('setDate', yesterday);
    }

    // Import order
    $(document).on('click', '#fetch-order', function (e) {
        var from = $('#date-from').val(),
            to = $('#date-to').val(),
            status = $('#statuses').val(),
            url = $('#subtab-ToolEAmazonMarketOrderListing').attr('href') + '&action=fetchOrder&ajax=1';

        const messageZone = $('#toole-import-message');
        const warningZone = $('#toole-import-warning');
        const errorZone = $('#toole-import-error');

        $.ajax({
            url: url,
            type: 'POST',
            dataType: 'json',
            data: {
                from: from,
                to: to,
                status: status,
            },
            beforeSend: function () {
                warningZone.empty().hide();
                messageZone.empty().hide();
                errorZone.empty().hide();
                $('#toole-modal-dialog').fadeIn();
            },
            success: function (data) {
                // Remove old Data
                var body = $('#table-tooleamazonmarketplace tbody');
                $(body).find('tr:not(:first-child)').remove();

                if (data.orders && data.count) {
                    $('#count-order-listing').text(data.count.toString()).show();

                    displayOrders(data.orders);
                    if (data.next_token) {
                        $('#next_token').val(data.next_token);
                        $('#more-order').show();
                    }
                } else if (data.error) {
                    $.each(data.errors, function (e, message) {
                        errorZone.append(message + '<br />');
                    });
                    if (data.messages) {
                        $.each(data.messages, function (e, message) {
                            errorZone.append(message + '<br />');
                        });
                    }

                    errorZone.show();
                } else {
                    $('#toole-import-warning').html($('#no_orders').val()).show();
                }
            },
            error: function (data) {
                console.log('error', data);
                errorZone.append(toole_unexpected_error + '<br />');
                errorZone.show();
            },
            complete: function (data) {
                $('#toole-modal-dialog').fadeOut();
                $('#check-all').prop('checked', false);
                $('#table-tooleamazonmarketplace tbody .order-check').prop('checked', false);
            }
        });
    });

    $(document).on('click', '#more-order', function () {
        var url = $('#subtab-ToolEAmazonMarketOrderListing').attr('href') + '&action=fetchOrder&ajax=1';
        $.ajax({
            url: url,
            type: 'POST',
            dataType: 'json',
            data: {
                next_token: $('#next_token').val(),
            },
            beforeSend: function () {
                $('#toole-import-warning').hide();
                $('#toole-modal-dialog').fadeIn();
            },
            success: function (data) {
                $('#next_token').val('');
                $('#more-order').hide();
                if (data.orders && data.count) {
                    displayOrders(data.orders);
                    if (data.next_token) {
                        $('#next_token').val(data.next_token);
                        $('#more-order').show();
                    }
                }
            },
            error: function (data) {
                console.log('error', data);
                errorZone.append(toole_unexpected_error + '<br />');
                errorZone.show();
            },
            complete: function (data) {
                $('#toole-modal-dialog').fadeOut();
            }
        });
    });

    $(document).on('click', '#import-order', function (e) {
        const orderList = $('#table-tooleamazonmarketplace tbody .order-check:checked:not(:disabled)'),
            url = tooleImportController + '&action=importOrders&ajax=1',
            warningZone = $('#toole-import-warning'),
            errorZone = $('#toole-import-error'),
            messageZone = $('#toole-import-message'),
            modalDialog = $('#toole-modal-dialog');

        const productListHeader = {
            information: $(this).data('productListHeaderInformation'),
            quantity: $(this).data('productListHeaderQuantity'),
            price: $(this).data('productListHeaderPrice'),
        }

        if (orderList.length <= 0) {
            alert($('#msg_select').val());
            return false;
        } else if (orderList.length > 50) {
            alert($('#msg_select_50').val());
            return false;
        }

        $.ajax({
            url: url,
            type: 'POST',
            dataType: 'json',
            data: [
                $('form[name="amazon-order-form"]').serialize()
            ].join('&'),
            beforeSend: function () {
                warningZone.empty().hide();
                errorZone.empty().hide();
                messageZone.empty().hide();
                modalDialog.fadeIn();
            },
            success: function (response) {
                if (response.hasError && (response.errors).length > 0) {
                    $.each(response.errors, function (e, message) {
                        errorZone.append(message + '<br />');
                    });
                    errorZone.show();
                }

                if (response.hasWarning && (response.warnings).length > 0) {
                    $.each(response.warnings, function (e, message) {
                        warningZone.append(message + '<br />');
                    });
                    warningZone.show();
                }

                if (response.hasMessage && (response.messages).length > 0) {
                    $.each(response.messages, function (e, message) {
                        messageZone.append(message + '<br />');
                    });
                    messageZone.show();
                }

                if (typeof (response.data) != 'undefined' && response.data) {
                    displayImported(response.data, productListHeader);
                } else {
                    errorZone.append('A server-side error has occurred. Please contact you server administrator<br />');
                    errorZone.show();
                }
            },
            error: function (data) {
                console.log('error', data);
                errorZone.append(toole_unexpected_error + '<br />');
                errorZone.show();
            },
            complete: function (data) {
                modalDialog.fadeOut();
            }
        });
    });

    if ($.isFunction($(document).on)) {
        $(document).on('click', '#table-tooleamazonmarketplace tbody .order-row', function (e) {
            if (e.target.type !== 'checkbox') {
                $(':checkbox', this).trigger('click');
            }
        });

        $('#check-all').on('click', function (e) {
            const checkbox = $('#table-tooleamazonmarketplace tbody .order-check:not(:disabled)');
            if ($(checkbox).length <= 1) {
                return;
            }
            $(checkbox).prop('checked', $(this).is(':checked'));
        });
    }

    function displayOrders(orders) {
        var irow = 0;
        $.each(orders, function (o, order) {
            var order_line = $('#row-model').clone().appendTo('#table-tooleamazonmarketplace tbody');
            order_line.attr('id', 'O' + o).attr('class', 'order-row');

            // Fill Lines
            //
            order_line.children('[rel=flag]').html('<img width="32px" src="' + order.flag_src + '" alt="" />');
            order_line.children('[rel=date]').html(order.date);
            order_line.children('[rel=id]').html(
                (!order.imported || !order.ps_id) ? order.id :
                    '<a href="' + order.ps_url + '" title="Go to order" target="_blank">' + order.id + '(' + order.ps_id + ')' + '</a>'
            );
            order_line.children('[rel=status]').html(order.status);
            if (order.invoice)
                order_line.children('[rel=invoice]').html(order.invoice); // KAM_CHG
            order_line.children('[rel=customer]').html(order.customer);
            order_line.children('[rel=shipping]').html(order.shipping);
            order_line.children('[rel=fulfillment]').html(
                !order.is_prime ? order.fulfillment : order.fulfillment + ' <b>(Prime)</b>'
            );
            order_line.children('[rel=quantity]').html(order.quantity);
            order_line.children('[rel=total]').html(order.total);
            order_line.children('[rel=currency]').html(order.currency);
            order_line.children('[rel=is_prime]').html(Boolean(order.is_prime) === true ? 'Yes' : 'No');
            order_line.addClass(irow++ % 2 ? '' : 'odd');
            var checkbox = order_line.children('td[rel=checkbox]').children('input');
            checkbox.attr('name', 'order_id[' + o + ']').val(o);

            checkbox.attr('checked', false);
            checkbox.attr('disabled', false);

            if (order.te_order_id || order.imported || order.canceled || order.pending) {
                checkbox.attr('disabled', true);
                order_line.addClass('imported_row2');
            } else {
                checkbox.attr('disabled', false);
            }

            order_line.show();
        });
    }

    function displayImported(orders, productListHeader = {}) {
        let parent;
        $('#table-tooleamazonmarketplace tbody tr').removeClass('error_row').removeClass('imported_row');
        $.each(orders, function (o, order) {
            parent = $('#O' + o);
            parent.find('.order-check').prop('disabled', order.status);
            if (order.status !== true) {
                parent.removeClass('odd').addClass('error_row');
                return;
            } else {
                parent.removeClass('odd').addClass('imported_row');
            }

            $('#O' + o + ' td[rel=id]').html(order.link);
            parent.find('.order-link').html(
                '<a href="' + order.ps_url + '" title="Go to order" target="_blank">' + o + '(' + order.merchant_order_id + ')' + '</a>'
            );

            // Product header of imported order
            parent.after(`
                <tr class="order-line">
                    <td colspan="3"></td>
                    <td style="padding: 0; font-weight: bold">SKU</td>
                    <td colspan="2" style="padding: 0; font-weight: bold">ASIN</td>
                    <td colspan="2" style="padding: 0; font-weight: bold">${productListHeader?.information || ''}</td>
                    <td colspan="2" style="padding: 0; font-weight: bold">${productListHeader?.quantity || ''}</td>
                    <td colspan="2" style="padding: 0; font-weight: bold">${productListHeader?.price || ''}</td>
                </tr>
            `);
            let insertedElement = parent.next();
            $.each(order.products, function (p, product) {
                insertedElement.after(`
                    <tr class="order-line">
                        <td colspan="3"></td>
                        <td style="padding: 0;">${product.SKU}</td>
                        <td colspan="2" style="padding: 0;">${product.ASIN}</td>
                        <td colspan="2" style="padding: 0;">${product.product}</td>
                        <td colspan="2" style="padding: 0;">${product.quantity}</td>
                        <td colspan="2" style="padding: 0;">${product.price}</td>
                    </tr>
                `);
                insertedElement = insertedElement.next();
            });
        });
    }
});
