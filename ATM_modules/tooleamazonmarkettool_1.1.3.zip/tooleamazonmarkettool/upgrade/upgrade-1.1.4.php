<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param TooleAmazonMarketTool $module
 *
 * @return bool
 */
function upgrade_module_1_1_4($module)
{
    $result = true;

    $tableCollation = Db::getInstance()->getValue('SELECT TABLE_COLLATION FROM information_schema.TABLES WHERE TABLE_SCHEMA = "' . pSQL(_DB_NAME_) . '" AND TABLE_NAME = "' . pSQL(_DB_PREFIX_ . 'product') . '"');
    $tables = Database::getModuleTables();
    foreach ($tables as $table) {
        $query = "ALTER TABLE $table CONVERT TO CHARACTER SET utf8mb4 COLLATE $tableCollation";
        $result &= Db::getInstance()->execute($query);
    }

    return $result;
}
