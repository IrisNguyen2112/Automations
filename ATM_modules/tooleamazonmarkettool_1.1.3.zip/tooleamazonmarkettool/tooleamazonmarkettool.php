<?php
/**
 *  * TooleAmazonMarkettool
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use PrestaShop\ModuleLibServiceContainer\DependencyInjection\ServiceContainer;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
use PrestaShop\PsAccountsInstaller\Installer\Exception\ModuleNotInstalledException;
use Symfony\Component\HttpFoundation\Response;
use Toole\Module\Amazon\Client\Model\ProductTypeDefinition;
use Toole\Module\Amazon\Client\Model\PropertyGroup;
use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\Amazon\Client\V4\Model\OrdersCancellation\OrderItemCancellation;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\AmazonAuth\AmazonAuth;
use Toole\Module\AmazonMarketplace\Core\Common\AmazonAuth\AmazonAuthCredentials;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\ConfigurationLoad;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\ConfigurationSave;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Install;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Uninstall;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Log\Log;
use Toole\Module\SubscriptionManager\Service\Api\ServiceApiHelper;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\CreateStoreVersionsResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\GetSubscriptionResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\InstallModuleResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\ValidateSubscriptionResponse;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v3\Response\CreateSubscriptionResponse;
use Toole\Module\SubscriptionManager\Service\Api\v3\Response\UninstallModuleResponse;
use Toole\Module\Utils\Utils;

if (!defined('_PS_VERSION_')) {
    exit;
}

$autoloadPath = __DIR__ . '/vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
}

class TooleAmazonMarketTool extends Module implements WidgetInterface
{
    const HOOKS = [
        'actionAdminControllerSetMedia',
        'actionFrontControllerSetMedia',
        'displayAdminOrder',
        'displayDashboardToolbarTopMenu',
        'displayAdminListBefore',
    ];
    const CONFIGURATION_UPDATE_STATUS = [
        'SUCCESS' => 1,
        'FAILED' => 2,
    ];

    public static $ymlConfigPath;

    /**
     * @var ServiceContainer
     */
    private $container;

    /** @var string */
    private $html = '';

    /** @var Log */
    public $log;

    public $author_address;
    public $support_email;
    public $help_center_url;
    public $external_assets_base_url;
    public $order_import_optional_columns;
    private $regionForbiddenToGetMarketplaces = [];

    public function __construct()
    {
        $this->name = 'tooleamazonmarkettool';
        $this->tab = 'market_place';
        $this->version = '1.1.4';
        $this->author = 'Inter-Soft';
        $this->is_eu_compatible = 1;
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->tabClassName = 'AdminAmazonMarketplace';
        $this->external_assets_base_url = Configuration::getGlobalValue(Key::SERVICE_API_URL) . '/getAssetLink/' . $this->name . '/' . $this->version;

        parent::__construct();

        $this->controllers = [
            'TooleAmazonMarketplaceFront',
        ];

        $this->displayName = $this->l('ToolE - Amazon Market Tool');
        $this->description = $this->l('AMT is the most reliable tool to succeed on Amazon designed exclusively for Prestashop by experienced Amazon sellers.');
        $this->ps_versions_compliancy = ['min' => '1.7.4', 'max' => _PS_VERSION_];
        $this->confirmUninstall = $this->l('Are you sure to uninstall this module?');
        $this->secure_key = Tools::encrypt($this->name);
        $this->module_key = 'feb8213d46ffcc6165647bc46728424c';
        $this->author_address = Utils::config(dirname(__FILE__), 'module:author_address');
        $this->support_email = Utils::config(dirname(__FILE__), 'module:support_email');
        $this->help_center_url = Utils::config(dirname(__FILE__), 'module:help_center_url');
        $this->order_import_optional_columns = [
            'latest_ship_date' => [
                'title' => $this->l('Latest Shipping Date'),
                'width' => 100,
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'date',
                'align' => 'center',
            ],
            'latest_delivery_date' => [
                'title' => $this->l('Latest Delivery Date'),
                'width' => 100,
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'date',
                'align' => 'center',
            ],
            'is_premium' => [
                'title' => $this->l('Premium Order'),
                'width' => 'auto',
                'type' => 'bool',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'is_business' => [
                'title' => $this->l('Business Order'),
                'width' => 'auto',
                'type' => 'bool',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'is_access_point' => [
                'title' => $this->l('Access Point'),
                'width' => 100,
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'bool',
                'align' => 'center',
            ],
        ];

        if ($this->container === null) {
            $this->container = new \PrestaShop\ModuleLibServiceContainer\DependencyInjection\ServiceContainer(
                $this->name,
                $this->getLocalPath()
            );
        }

        self::$ymlConfigPath = _PS_MODULE_DIR_ . $this->name;

        $this->log = new Log();
        $translations = new TooleAmazonMarketTranslations($this);
    }

    public function getContext()
    {
        return $this->context;
    }

    public function getContextLink()
    {
        return $this->context->link;
    }

    public function install(): bool
    {
        if (false === (new Install($this))->run()) {
            return false;
        }

        $return = parent::install()
            && $this->getService('tooleamazonmarkettool.ps_accounts.installer')->install()
            && $this->registerHook(static::HOOKS);

        if ($return
            && !Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SANDBOX')
            && $api_helper = SaaSConnector::initHelperWithoutConnector()) {
            /* @var InstallModuleResponse $install_response */
            $api_helper->installModuleEventV3(
                $this->displayName,
                $this->version,
                $_SERVER['HTTP_HOST'],
                Configuration::get('PS_SHOP_EMAIL')
            );
        }
        return $return;
    }

    public function uninstall(): bool
    {
        $return = (new Uninstall($this))->run()
            && parent::uninstall();

        if ($return
            && !Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SANDBOX')
            && $api_helper = SaaSConnector::initHelperWithoutConnector()) {
            /* @var UninstallModuleResponse $install_response */
            $api_helper->uninstallModuleEventV3(
                $this->displayName,
                $this->version,
                $_SERVER['HTTP_HOST'],
                Configuration::get('PS_SHOP_EMAIL')
            );
        }

        return $return;
    }

    public function renderWidget($hookName = null, array $configuration = []): string
    {
        if ($hookName === 'displayAdminListBefore' && $this->context->controller->controller_name !== 'ToolEAmazonMarketOrderImported') {
            return '';
        }

        if ($hookName == null && isset($configuration['hook'])) {
            $hookName = $configuration['hook'];
        }
        $template = 'views/templates/hook/' . $hookName . '.tpl';

        isset($configuration['cache_id']) ? $cache_id = $configuration['cache_id'] : $cache_id = null;
        $variables = $this->getWidgetVariables($hookName, $configuration);
        if (isset($variables['cache_id'])) {
            $cache_id = $variables['cache_id'];
        }

        if (!$this->isCached($template, $this->getCacheId($hookName))) {
            $this->smarty->assign($variables);
        }

        return $this->fetch($this->getLocalPath() . $template, $cache_id);
    }

    public function getWidgetVariables($hookName = null, array $configuration = []): array
    {
        if ('displayDashboardToolbarTopMenu' == $hookName) {
            if (strpos($this->context->controller->controller_name, 'ToolEAmazonMarket') !== false) {
                $configuration['help_center_url'] = $this->getHelperLink();
            }

            if (in_array($this->context->controller->controller_name, ['ToolEAmazonMarketLogsSummary', 'ToolEAmazonMarketFeed', 'ToolEAmazonMarketFbaOrderListing'])) {
                unset($configuration['enable_marketplaces'], $configuration['enable_regions']);
            }
        }

        if ('displayAdminOrder' == $hookName) {
            $amzOrder = TooleAmazonMarketAmazonOrder::getOrderByPsOrderId($configuration['id_order']);
            $configuration['shop_logo'] = $this->getTooleLogo();
            $configuration['amz_order'] = $amzOrder;
            $configuration['is_fulfillable'] = !empty($amzOrder) && TooleAmazonMarketAmazonOrder::isValidStateToDo($amzOrder['mp_status'], $amzOrder['current_state'], ConfigurationConstant::AMT_FBA_FULFILL_ORDER_STATUS);
            $configuration['is_cancellable'] = !empty($amzOrder) && TooleAmazonMarketAmazonOrder::isValidStateToDo($amzOrder['mp_status'], $amzOrder['current_state'], ConfigurationConstant::AMT_OUTGOING_ORDER_STATUS_CANCEL, 'cancel');
            $configuration['fulfill_link'] = $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported', true) . '&action=fulfillment';
            $configuration['cancel_link'] = $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported', true) . '&action=cancelOrder';
            // select cancel reason
            $configuration['cancel_reason_name'] = 'cancel_reason_name';
            $configuration['cancel_reason_list'] = OrderItemCancellation::definedCancelReasonAllowableValues();
        }

        if ('displayAdminListBefore' == $hookName) {
            $currentOptionalColumns = json_decode(Configuration::get(OrderKey::CONFIG_IMPORTED_ORDERS_OPTIONAL_COLUMNS, null, null, null, '')) ?? [];
            $configuration['optionalColumns'] = $currentOptionalColumns;
            $configuration['optionalColumnsOptions'] = $this->order_import_optional_columns;
            $configuration['saveOptionalColumnsLink'] = $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported') . '&action=saveOptionalColumns';
            // select cancel reason
            $configuration['cancel_reason_name'] = 'cancel_reason_name';
            $configuration['cancel_reason_list'] = OrderItemCancellation::definedCancelReasonAllowableValues();
        }

        return $configuration;
    }

    /**
     * @throws Toole\Module\SubscriptionManager\APIHelper\InvalidArgumentException
     * @throws Exception
     */
    public function getContent(): string
    {
        $active_tab = $this->getActiveTab();
        $configurationSave = new ConfigurationSave($this, $this->context);

        if (Tools::isSubmit('submitAdvanced')) {
            $configurationSave->processSubmitAdvancedConfiguration();
            $this->html .= $this->displayConfirmation(
                $this->l('Settings updated')
            );
        }

        $accountsInstaller = $this->getService('tooleamazonmarkettool.ps_accounts.installer');
        $accountsInstaller->install();

        $billingService = false;
        try {
            $billingService = $this->getService('tooleamazonmarkettool.ps_billings.service');
        } catch (ModuleNotInstalledException $e) {
            $this->html .= $this->displayError(
                $this->l('You need to install the PS Accounts module.')
            );
            return $this->html;
        }
        $billingServiceContext = $this->getService('tooleamazonmarkettool.ps_billings.context_wrapper');
        $status = 'inactive';
        $subscription = [];

        if (!Configuration::getGlobalValue(Key::CONFIG_PRESTASHOP_SANDBOX)) {
            $subscription = $billingService->getCurrentSubscription();
            $customer = $billingService->getCurrentCustomer();
            $subscription_id = isset($subscription['body']['id']) ? $subscription['body']['id'] : '';
            $shop_id = isset($customer['body']['cf_shop_id']) ? $customer['body']['cf_shop_id'] : '';
        } else {
            $subscription['body'] = [];

            $subscription_id = Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID) ?
                Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID) :
                Utils::config(dirname(__FILE__), 'module:sandbox_subscription_id');
            $subscription['body']['plan_id'] = Configuration::get(Key::CONFIG_PRESTASHOP_PLANID) ?
                Configuration::get(Key::CONFIG_PRESTASHOP_PLANID) :
                Utils::config(dirname(__FILE__), 'module:sandbox_plan_id');
            $shop_id = Configuration::get(Key::CONFIG_PRESTASHOP_STOREID) ?
                Configuration::get(Key::CONFIG_PRESTASHOP_STOREID) :
                $this->generateStoreId();
            $subscription['success'] = 1;
        }

        /* @var ServiceApiHelper $api_helper */
        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new Exception('Problem');
        }

        if ($subscription['success']) {
            /* @var GetSubscriptionResponse $get_subscription_response */
            try {
                $get_subscription_response = $api_helper->getSubscription($subscription_id);
                if ($get_subscription_response && $get_subscription_response->getIsValid()) {
                    Configuration::updateValue(
                        Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID,
                        $get_subscription_response->getSubscriptionId()
                    );
                    Configuration::updateValue(
                        Key::CONFIG_PRESTASHOP_PLANID,
                        $get_subscription_response->getPlanId()
                    );
                    Configuration::updateValue(
                        Key::CONFIG_PRESTASHOP_STOREID,
                        $get_subscription_response->getStoreId()
                    );
                    $status = $get_subscription_response->getStatus();
                } else {
                    throw new Exception('No subscription found.');
                }
            } catch (Exception $e) {
                // create a temporary subscription entry
                if ($e->getCode() == 301) {
                    throw new Exception($e->getMessage(), $e->getCode());
                }
                /* @var CreateSubscriptionResponse $create_response */
                $create_response = $api_helper->createSubscription(
                    $subscription_id,
                    $shop_id,
                    isset($subscription['body']['plan_id']) ? $subscription['body']['plan_id'] : '',
                    isset($subscription['body']['customer_id']) ? $subscription['body']['customer_id'] : '',
                    isset($subscription['body']['created_at']) ? $subscription['body']['created_at'] : '',
                    isset($subscription['body']['activated_at']) ? $subscription['body']['activated_at'] : '',
                    isset($subscription['body']['started_at']) ? $subscription['body']['started_at'] : '',
                    isset($subscription['body']['next_billing_at']) ? $subscription['body']['next_billing_at'] : '',
                    isset($subscription['body']['trial_end']) ? $subscription['body']['trial_end'] : '',
                    isset($subscription['body']['updated_at']) ? $subscription['body']['updated_at'] : '',
                    $this->name,
                    'unconfirmed'
                );
                if ($create_response && $create_response->getIsValid()) {
                    Configuration::updateValue(
                        Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID,
                        $create_response->getSubscriptionId()
                    );
                    Configuration::updateValue(
                        Key::CONFIG_PRESTASHOP_PLANID,
                        $create_response->getPlanId()
                    );
                    Configuration::updateValue(
                        Key::CONFIG_PRESTASHOP_STOREID,
                        $create_response->getStoreId()
                    );
                    $status = $create_response->getSubscriptionStatus();
                } else {
                    $this->html .= $this->displayError(
                        $this->l('Fatal error creating subscription details.')
                    );
                }
            }

            if (!Configuration::get(
                Key::CONFIG_PRESTASHOP_STOREID
            )) {
                $this->html .= $this->displayError(
                    $this->l('Subscription pending confirmation')
                );
            }
        }

        $errorMessages = '';
        $successMessages = '';
        $amazonRefreshToken = Tools::getValue('refresh_token');

        if ((Tools::isSubmit('submitConfiguration') || Tools::isSubmit('toole_amazon_authorization') || $amazonRefreshToken) && !Tools::isSubmit('submitAdvanced')) {
            try {
                /* @var ValidateSubscriptionResponse $validate_response */
                $validate_response = $api_helper->validateSubscription(
                    Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID),
                    Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                    Configuration::get(Key::CONFIG_PRESTASHOP_PLANID)
                );
            } catch (Exception $e) {
                $this->html .= $this->displayError(
                    $this->l('Unable to connect to subscription validation server, please contact support')
                );
                return $this->html;
            }
            if ($validate_response && $validate_response->getIsValid()) {
                $returned = true;
                if (Tools::isSubmit('submitConfiguration')) {
                    $returned = $configurationSave->processSubmitConfiguration();
                }
                $amzAuth = $this->amazonAuthorization();
                if ($amzAuth && $amzAuth->region) {
                    $active_tab = $amzAuth->region;
                }

                if ($returned === ConfigurationSave::ERROR_CREATE) {
                    $errorMessages .= $this->displayError($this->l('Unable to create store configuration'));
                } elseif ($returned === ConfigurationSave::ERROR_UPDATE) {
                    $errorMessages .= $this->displayError($this->l('Unable to update store configuration'));
                } elseif ($returned === ConfigurationSave::SUCCESS || $returned === true) {
                    /* @var CreateStoreVersionsResponse $create_store_configuration_response */
                    $create_store_configuration_response = $api_helper->createStoreVersions(
                        Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID),
                        Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                        _PS_VERSION_,
                        $this->name,
                        $this->version,
                        phpversion(),
                        Db::getInstance()->getLink()->getAttribute(PDO::ATTR_DRIVER_NAME),
                        Db::getInstance()->getVersion()
                    );
                    if (!$create_store_configuration_response) {
                        throw new Exception($this->l('Unable to save store configuration'));
                    }
                    $successMessages .= $this->displayConfirmation($this->l('Settings updated'));
                    $this->context->cookie->__set('custom_conf', !($this->error ?? false) ? self::CONFIGURATION_UPDATE_STATUS['SUCCESS'] : self::CONFIGURATION_UPDATE_STATUS['FAILED']);
                } else {
                    $errorMessages .= $this->displayError($this->l('Unable to save configuration'));
                    $this->context->cookie->__set('custom_conf', self::CONFIGURATION_UPDATE_STATUS['FAILED']);
                }
            } else {
                if ($validate_response && !$validate_response->getIsValid()) {
                    $errorMessages .= $this->displayError($validate_response->getMessage());
                }
                $errorMessages .= $this->displayError($this->l('Unable to save configuration'));
                $this->context->cookie->__set('custom_conf', self::CONFIGURATION_UPDATE_STATUS['FAILED']);
            }

            $this->context->cookie->__set('active_tab', $active_tab);
            $this->context->cookie->__set('success_messages', $successMessages);
            $this->context->cookie->__set('error_messages', $errorMessages);
            $this->context->cookie->write();

            Tools::redirect($this->context->link->getAdminLink('AdminModules', true, [], ['configure' => $this->name, 'tab_module' => $this->tab, 'module_name' => $this->name]));
        }

        try {
            $accountsFacade = $this->getService('tooleamazonmarkettool.ps_accounts.facade');
            $accountsService = $accountsFacade->getPsAccountsService();
            Media::addJsDef([
                'contextPsAccounts' => $accountsFacade->getPsAccountsPresenter()
                    ->present($this->name),
            ]);

            // Retrieve Account CDN
            $this->context->smarty->assign('urlAccountsVueCdn', $accountsService->getAccountsVueCdn());

            $billingFacade = $this->getService('tooleamazonmarkettool.ps_billings.facade');

            // Billing
            Media::addJsDef($billingFacade->present([
                'logo' => $this->getLocalPath() . 'views/img/partnerLogo.png',
                'tosLink' => $this->getTosLink($this->context->language->iso_code),
                'tosUrl' => $this->getTosLink($this->context->language->iso_code),
                'privacyLink' => $this->getPrivacyLink($this->context->language->iso_code),
                'privacyUrl' => $this->getPrivacyLink($this->context->language->iso_code),
                'emailSupport' => $this->support_email,
            ]));
            Media::addJsDef([
                'configModule' => json_encode(Utils::config(dirname(__FILE__), 'module')),
                'moduleVersion' => $this->version,
                'toole_moduleconfiguration_url' => $this->context->link->getAdminLink(
                    'AdminModules',
                    true
                ) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name,
                'isPsSandbox' => Configuration::get(Key::CONFIG_PRESTASHOP_SANDBOX),
                'subscription_status' => $status,
            ]);

            $cssLink = $this->getMediaLink('/public/css/configuration.css');
            $this->context->controller->addCSS($cssLink);

            if ((int) $this->context->cookie->__get('custom_conf') === self::CONFIGURATION_UPDATE_STATUS['SUCCESS']) {
                $this->html .= $this->context->cookie->__get('success_messages') ?? '';
            }

            if ((int) $this->context->cookie->__get('custom_conf') === self::CONFIGURATION_UPDATE_STATUS['FAILED']) {
                $this->html .= $this->context->cookie->__get('error_messages') ?? '';
            }

            $this->html .= $this->context->smarty->assign([
                'configModule' => json_encode(Utils::config(dirname(__FILE__), 'module')),
                'loadingText' => $this->l('Please wait, loading account details'),
                'pathVendor' => sprintf('%sviews/app/js/vendor.%s.js', $this->getPathUri(), $this->version),
                'pathApp' => sprintf('%sviews/app/js/index.%s.js', $this->getPathUri(), $this->version),
                'status' => $status,
                'subscriptionId' => Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                ),
                'isPsSandbox' => (int) Configuration::get(Key::CONFIG_PRESTASHOP_SANDBOX),
                'storeId' => Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                'subscriptionStatus' => isset($status) ? strtoupper($status) : '',
                'isLinked' => $accountsService->isAccountLinked(),
                'isSubscribed' => (in_array($status, ['inactive', 'cancelled'])) ? 0 : 1,
                'isCancelled' => ($status == 'cancelled') ? 1 : 0,
                'urlAccountsCdn' => $accountsService->getAccountsCdn(),
                'urlBilling' => 'https://unpkg.com/@prestashopcorp/billing-cdc/dist/bundle.js',
                'prestashopVersion' => _PS_VERSION_,
                'moduleName' => htmlspecialchars_decode($this->displayName),
                'moduleVersion' => $this->version,
                'phpVersion' => phpversion(),
                'databaseType' => Db::getInstance()->getLink()->getAttribute(PDO::ATTR_DRIVER_NAME),
                'databaseVersion' => Db::getInstance()->getVersion(),
                'active_tab' => $active_tab,
                'regionForbiddenToGetMarketplaces' => $this->regionForbiddenToGetMarketplaces,
            ])
                ->assign($this->getConfigurationFormVars())
                ->fetch($this->getLocalPath() . 'views/templates/admin/configuration.tpl');

            // clear cookies
            $this->context->cookie->__unset('custom_conf');
            $this->context->cookie->__unset('active_tab');
            $this->context->cookie->__unset('success_messages');
            $this->context->cookie->__unset('error_messages');

            return $this->html;
        } catch (Exception $e) {
            $this->context->controller->errors[] = $e->getMessage();
            return '';
        }
    }

    public function hookActionAdminControllerSetMedia($params)
    {
        if (Module::isEnabled($this->name)) {
            if ($this->context->controller->controller_name == 'AdminModules' && Tools::getValue('configure') == $this->name) {
                $jsLink = $this->getMediaLink('/public/js/configuration.js?v=' . $this->version);
                $this->context->controller->addJS($jsLink);
            } elseif ($this->context->controller->controller_name == 'ToolEAmazonMarketOrderImported') {
                $jsLink = $this->getMediaLink('/views/js/order/imported_order.js?v=' . $this->version);
                $this->context->controller->addJS($jsLink);
            } elseif ($this->context->controller->controller_name == 'AdminOrders') {
                $jsLink = $this->getMediaLink('/views/js/order/order_detail.js?v=' . $this->version);
                $this->context->controller->addJS($jsLink);
            }
        }
    }

    /**
     * @throws SmartyException
     */
    public function ajaxProcessgetDefinitionsProductType()
    {
        $productType = Tools::getValue('productType');
        [$defs, $link] = $this->getProductTypeDefinitions(
            $productType,
            null
        );
        $tpl = $this->context->smarty->createTemplate(
            _PS_MODULE_DIR_ . $this->name . '/views/templates/admin/configuration/products/products-amz-attrs.tpl'
        );
        $tpl->assign(
            [
                'product_type_definition_schema' => $link,
                'product_type_definitions' => $defs,
                'attribute_groups' => \AttributeGroup::getAttributesGroups($this->context->language->id),
            ]
        );
        $view = $tpl->fetch();

        die(json_encode(['result' => 1, 'view' => $view]));
    }

    /**
     * @throws PrestaShopException
     */
    public function ajaxProcessImportAttribute()
    {
        $schema = Tools::getValue('schema');
        $attribute = Tools::getValue('attribute');

        if ($attribute_schema = $this->getSchema($schema)) {
            $schema = null;
            $attribute_schema = json_decode($attribute_schema['data']);

            $propertySchema = null;
            foreach ($attribute_schema->properties as $key => $property) {
                if (strtolower($attribute) == strtolower($key)) {
                    $propertySchema = $property;
                    break;
                }
            }

            if ($propertySchema) {
                $sql = new DbQuery();
                $sql->select('id_attribute_group')
                    ->from('attribute_group_lang', 'agl')
                    ->where('agl.name="' . 'amz_' . pSQL(strtolower($key)) . '"')
                    ->where('agl.id_lang=' . (int) $this->context->language->id);
                if (!$id_attribute_group = Db::getInstance()->getValue($sql)) {
                    $attr_group = new AttributeGroup();
                    // TODO - Check if it already exists.
                    foreach (Language::getLanguages(true) as $lang) {
                        $attr_group->name[$lang['id_lang']] = 'amz_' . strtolower($key);
                    }
                    $attr_group->public_name[$this->context->language->id] = $propertySchema->title;
                    $attr_group->group_type = 'select';
                    $attr_group->save();
                    $id_attribute_group = $attr_group->id;
                    /*
                    }*/
                }
                if ($id_attribute_group && isset($propertySchema->items->properties->value->enum)) {
                    foreach ($propertySchema->items->properties->value->enum as $key => $attrVal) {
                        $sql = new DbQuery();
                        $sql->select('id_attribute')
                            ->from('attribute_lang', 'al')
                            ->where('al.name="' . pSQL($propertySchema->items->properties->value->enumNames[$key]) . '"')
                            ->where('al.id_lang=' . (int) $this->context->language->id);
                        if (!Db::getInstance()->getValue($sql)) {
                            if (version_compare(_PS_VERSION_, '8', '<') === true) {
                                $attr = new Attribute();
                            } else {
                                $attr = new ProductAttribute();
                            }
                            $attr->id_attribute_group = $id_attribute_group;
                            $attr->name[$this->context->language->id] = $propertySchema->items->properties->value->enumNames[$key];
                            $attr->save();
                        }
                    }
                }
            }
        }

        die(json_encode(array(
            'result' => 1,
            'message' => $this->l('Attribute Added')
        )));
    }

    /**
     * Indicate that module is using new translation system
     */
    public function isUsingNewTranslationSystem()
    {
        if (version_compare(_PS_VERSION_, '1.7.7', '>=')) {
            return true;
        }
    }

    /**
     * Get the Tos URL from the context language, if null, send default link value
     *
     * @return string
     */
    public function getTosLink($iso_lang): string
    {
        switch ($iso_lang) {
            case 'fr':
                return 'https://toolecommerce.com/fr/terms-and-conditions/';
            default:
                return 'https://toolecommerce.com/terms-and-conditions/';
        }
    }

    /**
     * Get the Tos URL from the context language, if null, send default link value
     *
     * @param $iso_lang
     * @return string
     */
    public function getPrivacyLink($iso_lang): string
    {
        switch ($iso_lang) {
            case 'fr':
                return 'https://toolecommerce.com/fr/politique-de-confidentialit%C3%A9/';
            default:
                return 'https://toolecommerce.com/privacy-policy/';
        }
    }

    public function getHelperLink()
    {
        switch ($this->context->controller->controller_name) {
            case 'ToolEAmazonMarketCatalogFiltersCategories':
            case 'ToolEAmazonMarketCatalogFiltersManufacturers':
            case 'ToolEAmazonMarketCatalogFiltersSuppliers':
            case 'ToolEAmazonMarketCatalogFiltersProducts':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12935421768594-AMT-Filters-Tab-Streamlining-Your-Catalog';
                break;
            case 'ToolEAmazonMarketProductsImportedFromAmazon':
            case 'ToolEAmazonMarketProductSyncFromAmazon':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12935751954322-AMT-Amazon-Sync-Amazon-Prestashop-Seamlessly-Integrate-Your-Products';
                break;
            case 'ToolEAmazonMarketProductSyncFromPrestashop':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12935951276434-AMT-Prestashop-Sync-Prestashop-Amazon-Effortless-Integration-of-Your-Prestashop-Offers';
                break;
            case 'ToolEAmazonMarketLogsSummary':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12936004169746-AMT-Activity-Summaries-Comprehensive-Insights-at-Your-Fingertips';
                break;
            case 'ToolEAmazonMarketOrderImported':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12935188470034-Managing-your-Order-Importing-with-the-Amazon-Market-Tool-';
                break;
            case 'ToolEAmazonMarketOrderListing':
                $url = 'https://www.youtube.com/watch?v=9mQJBi7dZoI';
                break;
            case 'ToolEAmazonMarketFeed':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12936148275346-AMT-Feed-Tab-Comprehensive-Insights-into-Your-Feeds';
                break;
            default:
                $url = $this->help_center_url;
                break;
        }

        return $url;
    }

    public function getTooleLogo()
    {
        return 'https://toolecommerce.com/wp-content/uploads/2023/06/White-Logo.png';
    }

    public static function clearAllCached()
    {
        $module = Module::getInstanceByName('tooleamazonmarkettool');
        /*$module->clearCache('tab', 'homefeatured-tab', false);
        $module->clearCache('homefeatured', '', false);
        $module->clearCache('*', 'ps_featuredproducts', false);*/
    }

    protected function amazonAuthorization(): ?AmazonAuthCredentials
    {
        $amazonAuthCre = (new AmazonAuth($this, Context::getContext()))->amazonAuthorization();
        if ($amazonAuthCre) {
            $this->log->setLog(sprintf('Amazon authorization: %s', $amazonAuthCre->region));
            try {
                $amazonAuthCre->saveAmazonAuthCredentials();
                $connector = SaaSConnector::initHelperWithConnector($amazonAuthCre->region);
                $apiResult = $connector->getMarketplaceParticipations();
                $enableList = $connector->getAmazonConnector()->getAvailableMarketplaces();
                $enableList[] = $amazonAuthCre->marketplaceId;
                AmazonMarketConfiguration::saveAmzMarketplaces($apiResult->getAmazonData(), $enableList, $amazonAuthCre->region);
                Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_REGION, $amazonAuthCre->region);
                Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_MARKEPLACE, $amazonAuthCre->marketplaceId);
                $this->log->success(sprintf('Success: %s with region list enabled: %s', 'Authorize successfully', implode(', ', $enableList)));
            } catch (Exception $e) {
                if ($e->getCode() === Response::HTTP_FORBIDDEN) {
                    $this->regionForbiddenToGetMarketplaces[$amazonAuthCre->region] = true;
                }
                $this->html .= $this->displayError(
                    $this->l('Error saving selected marketplace') . ' [' . $e->getMessage() . ']'
                );
                $this->log->error(sprintf('Error: %s, details: %s', 'Error saving selected marketplace', $e->getMessage()));
            }
        }

        return $amazonAuthCre;
    }

    /**
     * Retrieve the service
     *
     * @param string $serviceName
     *
     * @return mixed
     */
    private function getService($serviceName)
    {
        return $this->container->getService($serviceName);
    }

    private function getConfigurationFormVars(): array
    {
        return (new ConfigurationLoad($this))->getTplVars();
    }

    private function getActiveTab(): string
    {
        if ($this->context->cookie->__get('active_tab')) {
            return $this->context->cookie->__get('active_tab');
        }

        if (Tools::getValue('active_tab')) {
            return Tools::getValue('active_tab');
        }

        return 'welcome';
    }

    public function getMediaLink(string $path): string
    {
        $link = _PS_MODULE_DIR_ . $this->name . $path;
        if (AmazonMarketConfiguration::get(ConfigurationConstant::AMT_USE_EXTERNAL_ASSETS)) {
            $link = $this->external_assets_base_url . $path;
        }
        return $link;
    }

    private function getProductTypeDefinitions(
        $productType,
        $sellerId
    ) {
        $context = Context::getContext();
        $active_marketplace = Configuration::get(
            KEY::CONFIG_PRESTASHOP_KEY_ACTIVE_MARKEPLACE,
            null,
            $context->shop->id_shop_group,
            $context->shop->id
        ) ?: AmazonConstant::MKP_FR;

        $region = Region::searchRegionByMkp($active_marketplace);
        $saasHelper = SaaSConnector::initHelperWithConnector($region, [$active_marketplace]);
        try {
            $amzResponse = $saasHelper->getDefinitionsProductTypes(
                [],
                $productType,
                $sellerId,
                null, // productTypeVersion
                null, // $requirements
                null, // $requirementsEnforced
                $context->language->iso_code // $locale
            );

            $properties = [];
            $propertyTypeSchemaLinkResource = false;
            /** @var ProductTypeDefinition $productTypeData */
            if ($productTypeData = $amzResponse->getAmazonData()) {
                $propertyGroups = $productTypeData->getPropertyGroups();
                $propertyTypeSchema = $productTypeData->getSchema();
                $propertyTypeSchemaLink = $propertyTypeSchema->getLink();
                $propertyTypeSchemaLinkResource = $propertyTypeSchemaLink->getResource();

                if ($schema = $this->getSchema($propertyTypeSchemaLinkResource)) {
                    $schema = json_decode($schema['data']);
                    /** @var PropertyGroup $productDetails */
                    $productDetails = $propertyGroups['product_details'];
                    $propertyNames = $productDetails->getPropertyNames();
                    foreach ($propertyNames as $propertyName) {
                        $propertySchema = null;
                        foreach ($schema->properties as $key => $property) {
                            if (strtolower($propertyName) == strtolower($key)) {
                                $propertySchema = $property;
                                break;
                            }
                        }
                        $properties[] = [
                            'id' => $propertyName,
                            'name' => $propertySchema->title,
                        ];
                    }
                }
            }

            return [
                $properties,
                $propertyTypeSchemaLinkResource,
            ];
        } catch (\Exception $exception) {
            return [];
        }
    }

    private function getSchema(
        $url
    ) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($ch);
        $info = curl_getinfo($ch);
        curl_close($ch);
        if ($info['http_code'] == 200) {
            return [
                'data' => $data,
            ];
        }

        return false;
    }

    public function l($string, $specific = false, $locale = null)
    {
        if (version_compare(_PS_VERSION_, '1.7.7', '>=')) {
            return parent::trans($string, [], 'Modules.Tooleamazonmarkettool.Admin', $locale);
        } else {
            return parent::l($string, false, $locale);
        }
    }

    private function generateStoreId($data = null)
    {
        // Generate 16 bytes (128 bits) of random data or use the data passed into the function.
        $data = $data ?? random_bytes(16);
        assert(strlen($data) == 16);

        // Set version to 0100
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        // Set bits 6-7 to 10
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

        // Output the 36 character UUID.
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
