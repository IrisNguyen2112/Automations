# Amazon Market Tool

## About
AMT is the most reliable tool to succeed on Amazon designed exclusively for Prestashop by experienced Amazon sellers.

## Multistore compatibility
This module is not compatible with multistore

## Reporting issues


## License

## Changelog

#### 1.1.1
* FBA: Sync stock from Amazon to PS
* MCF: Manage Multi-channel-fulfillment orders
* Customer notifications
  * Order import fails
  * Plan limits reached
* Incoming carrier mapping for the order delivered to access point
* See prime (and other criteria) orders
* Summaries: Easier examine logs by pagination, cache

#### 1.1.0
* Worldwide Marketplaces - Sell in 3 zones
* Sync From Amazon - Update sync logic
* Multi-store installations supported, licences required.

#### 1.0.4
* Add sandbox server details
* PS 1.7.4 support (NB. Translations are not available with this version of Prestashop)
* PS 8.1 support.

#### 1.0.3
* Feature requests
    * Set the order status for cron Order Import / Cron parameters
    * Avoid already imported orders by other modules
* Bug fixes and improvement
    * Configuration: Prevent submit by enter, because we have many sections
    * Catalog Filters: Consistent titles
    * Catalog Filters: View links go to nowhere
    * Prestashop Sync: The sort order is not consistent
    * Activity logs: The ID sometimes is parsed to float
    * Activity logs: Purse after 90 days
    * Feeds: Not trigger the loading modal while dowload document

#### 1.0.2
* Fix order invoice products
* Enhance Order importing
    * Add new order with complete data
    * Set order history
    * Set invoice (if order state is paid)

#### 1.0.1
* Add menu translations
