<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\FulfillmentOrders\CreateFulfillmentOrder;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

class ToolEAmazonMarketFbaOrderListingController extends TooleBaseAdminController
{
    const CREATED_DATE_AFTER = '2023-08-01 00:00:00';

    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'order/fba/';
        $this->tpl_folder = 'order/fba/';
        $this->bootstrap = true;
        $this->table = 'orders';
        $this->identifier = 'id_order';
        $this->submit_action = 'submitAdd' . $this->table;
        $this->class_name = 'ToolEAmazonMarketFbaOrder';
        $this->lang = false;
        $this->deleted = false;
        $this->colorOnBackground = false;

        $this->explicitSelect = true;

        if (!Tools::getValue('id_product')) {
            $this->multishop_context_group = false;
        }
        $this->imageType = 'gif';
        $this->fieldImageSettings = [
            'name' => 'icon',
            'dir' => 'os',
        ];
        $this->_defaultOrderBy = 'a.date_add';
        $this->deleted = false;
        $this->_orderBy = 'a.date_add';
        $this->_orderWay = 'DESC';
        $this->list_no_link = true;

        $this->_select .= ' a.`id_order`, a.`current_state`, osl.`name` as current_state_name, os.`color` as state_color, country_l.`name` as country_name';

        $this->_join = ' JOIN `' . _DB_PREFIX_ . 'order_state` os ON os.`id_order_state` = a.`current_state` 
            JOIN `' . _DB_PREFIX_ . 'order_state_lang` osl ON (osl.`id_order_state` = a.`current_state` AND osl.`id_lang` = ' . $this->context->language->id . ')
            JOIN `' . _DB_PREFIX_ . 'address` address ON address.`id_address` = a.`id_address_delivery`
            JOIN `' . _DB_PREFIX_ . 'country` country ON country.`id_country` = address.`id_country`
            JOIN `' . _DB_PREFIX_ . 'country_lang` country_l ON (country_l.`id_country` = country.`id_country` AND country_l.`id_lang` = ' . $this->context->language->id . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FBA_ORDERS . '` fba_o ON fba_o.`ps_order_id` = a.`id_order`
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` amz_o ON amz_o.`ps_order_id` = a.`id_order`';

        $this->_where = ' AND fba_o.`id_fba_order` IS NULL AND amz_o.`id_order` IS NULL AND a.`module` != "' . $this->module->name . '"';
        $this->_where .= ' AND a.`id_shop` = ' . $this->shop_id;

        $this->bulk_actions = [
            'CreateFbaOrder' => [
                'text' => $this->trans(
                    'Create FBA Orders selected',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'confirm' => $this->trans(
                    'Create FBA Orders selected items?',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'icon' => 'icon-check',
            ],
        ];

        $this->fields_list = [
            'id_order' => [
                'title' => $this->trans('Id', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'align' => 'text-center',
                'class' => 'fixed-width-sm',
                'search' => true,
            ],
            'reference' => [
                'title' => $this->trans('Reference', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 'auto',
                'type' => 'string',
                'search' => true,
                'filter_key' => 'a!reference',
            ],
            'current_state_name' => [
                'title' => $this->trans('Status', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 'auto',
                'type' => 'string',
                'search' => true,
                'filter_key' => 'ols!name',
                'color' => 'state_color',
            ],
            'country_name' => [
                'title' => $this->trans('Shipping Country', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 'auto',
                'search' => true,
                'filter_key' => 'country_l!name',
            ],
            'total_paid_tax_incl' => [
                'title' => $this->trans('Reference', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 'auto',
                'search' => false,
                'align' => 'text-right',
            ],
            'date_add' => [
                'title' => $this->trans('Date', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 100,
                'filter_key' => 'a!date_add',
                'class' => 'fixed-width-100',
                'search' => true,
                'type' => 'date',
                'align' => 'center',
            ],
        ];
        $this->addRowAction('viewOrder');
        $this->addRowAction('fulfillmentOrder');
    }

    public function getList(
        $id_lang,
        $orderBy = null,
        $orderWay = null,
        $start = 0,
        $limit = null,
        $id_lang_shop = null
    ) {
        $id_lang_shop = Shop::isFeatureActive() && Shop::getContext() == Shop::CONTEXT_SHOP ?
            (int) $this->context->shop->id : 'a.id_shop_default';
        parent::getList($id_lang, $orderBy, $orderWay, $start, $limit, $id_lang_shop);
    }

    public function displayViewOrderLink($token, $id)
    {
        return $this->context->smarty->createTemplate($this->getTemplatePath() . 'order/view_order_link.tpl')
            ->assign([
                'action' => $this->trans('View', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'href' => $this->context->link->getAdminLink('AdminOrders', true, [], ['id_order' => $id, 'vieworder' => 1]),
            ])->fetch();
    }

    public function processFulfillmentOrder()
    {
        $id = Tools::getValue('id');
        $this->handleCreateFulfillmentOrder([$id]);
        $this->redirectAdminToole();
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitBulkCreateFbaOrder' . $this->table)) {
            if ($selectedIds = Tools::getValue($this->table . 'Box')) {
                $this->handleCreateFulfillmentOrder($selectedIds);
            }
        }

        return parent::postProcess(); // TODO: Change the autogenerated stub
    }

    public function displayFulfillmentOrderLink($token, $id)
    {
        $disabled_text = '';
        $disabled = false;
        $psOrder = new Order($id);
        $fulfillStatus = AmazonMarketConfiguration::get(Key::CONFIG_FBA_SETTINGS)[OrderKey::FBA_FULFILL_ORDER_STATUS] ?? null;
        if (!$fulfillStatus || $psOrder->current_state != $fulfillStatus) {
            $disabled_text = $this->trans(
                'Create a FBA Order Unavailable - Incorrect Prestashop Status',
                [],
                'Modules.Tooleamazonmarkettool.Admin'
            );
            $disabled = true;
        }

        return $this->context->smarty->createTemplate($this->getTemplatePath() . 'order/fba/fulfillment_order_link.tpl')
            ->assign([
                'action' => $this->trans(
                    'Create a FBA Order',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'disabled' => $disabled,
                'action_disabled_text' => $disabled_text,
                'action_text' => $this->trans(
                    'Create a FBA Order',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'href' => $this->context->link->getAdminLink('ToolEAmazonMarketFbaOrderListing') .
                    $this->submit_action . '&id=' . $id . '&action=fulfillmentOrder&token=' .
                    $this->token,
            ])->fetch();
    }

    public function handleCreateFulfillmentOrder(array $ids)
    {
        if (is_array($ids) && count($ids) > 0) {
            $this->module->log->setLog(sprintf('Create FBA Order(s) ID(s) (%s)', implode(',', $ids)));
            $fulfillStatus = AmazonMarketConfiguration::get(Key::CONFIG_FBA_SETTINGS)[OrderKey::FBA_FULFILL_ORDER_STATUS] ?? null;
            $fulfillOrder = new CreateFulfillmentOrder($ids, $this->context, $this->module, $fulfillStatus);
            try {
                $fulfillOrder->doCreate();
                $this->module->log->error($fulfillOrder->getErrors())->warning($fulfillOrder->getWarnings());
                $this->errors = array_merge($this->errors, $fulfillOrder->getErrors());
                $this->warnings = array_merge($this->warnings, $fulfillOrder->getWarnings());
                if (!$this->errors && !$this->warnings) {
                    $this->confirmations[] = $this->trans(
                        'FBA order creation is complete. Details of the process are in the Activity Logs > Summaries',
                        [],
                        'Modules.Tooleamazonmarkettool.Admin'
                    );
                }
            } catch (Exception $e) {
                $this->module->log->error(sprintf('Error: %s', $e->getMessage()));
                $this->errors[] = sprintf('An unexpected error has occurred: %s', $e->getMessage());
            }
        } else {
            $this->errors[] = $this->trans('Unable to create FBA order', [], 'Modules.Tooleamazonmarkettool.Admin');
        }
    }
}
