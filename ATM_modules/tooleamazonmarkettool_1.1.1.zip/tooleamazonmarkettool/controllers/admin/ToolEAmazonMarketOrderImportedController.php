<?php
/**
 * ToolEAmazonMarketOrderImported
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\Model\Order as ISOrderModel;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderFulfillment;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponse;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketOrderImportedController extends TooleBaseAdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->context = Context::getContext();
        $this->multishop = true;
        $this->tpl_folder = 'order/';
        $this->bootstrap = true;
        $this->list_no_link = true;
        $this->class_name = 'ToolEAmazonMarketOrderImported';

        $this->table = Database::TABLE_AMAZON_ORDERS;
        $this->identifier = 'id_order';
        $this->_defaultOrderBy = 'id_order';

        $ffCon = 'a.mp_status = "' . ISOrderModel::ORDER_STATUS_UNSHIPPED . '" OR a.mp_status = "' . ISOrderModel::ORDER_STATUS_PARTIALLY_SHIPPED . '"';
        $this->_select = ' o.date_add, IF(' . $ffCon . ', "#ffc107", "#4ad550") as fulfillable_color';
        $this->_join = ' INNER JOIN `' . _DB_PREFIX_ . 'orders` o ON o.id_order = a.ps_order_id';
        $this->_orderBy = 'a.id_order';
        $this->_orderWay = 'DESC';

        if ($this->availableMarketplaces) {
            $this->_where .= ' AND a.marketplace_id IN ("' . implode('","', $this->availableMarketplaces) . '")';
        }

        $this->fields_list = [
            'ps_order_id' => [
                'title' => $this->trans(
                    'ID',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'center',
                'class' => 'fixed-width-sm',
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
            ],
            'mp_order_id' => [
                'title' => $this->trans(
                    'Order ID',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'mp_status' => [
                'title' => $this->trans(
                    'Amazon Order Status',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
                'order_key' => 'a!mp_status',
                'color' => 'fulfillable_color',
                'align' => 'center',
            ],
            'channel' => [
                'title' => $this->trans(
                    'Channel',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'marketplace_id' => [
                'title' => $this->trans(
                    'Marketplace ID',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'buyer_name' => [
                'title' => $this->trans(
                    'Customer',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'sales_channel' => [
                'title' => $this->trans(
                    'Sales Channel',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => false,
                'search' => false,
                'align' => 'center',
            ],
            'date_add' => [
                'title' => $this->trans(
                    'Imported date',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 100,
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'date',
                'align' => 'center',
            ],
            'is_prime' => [
                'title' => $this->trans(
                    'Prime Order',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'type' => 'bool',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
        ];

        // Handle the optional columns
        $currentOptionalColumns = json_decode(Configuration::get(OrderKey::CONFIG_IMPORTED_ORDERS_OPTIONAL_COLUMNS, null, null, null, '')) ?? [];
        $optional_fields_list = array_filter($this->module->order_import_optional_columns, function ($column) use ($currentOptionalColumns) {
            return in_array($column, $currentOptionalColumns);
        }, ARRAY_FILTER_USE_KEY);
        $this->fields_list = array_merge($this->fields_list, $optional_fields_list);

        $this->bulk_actions = [
            'fulfillAll' => [
                'text' => $this->trans(
                    'Fulfill selected',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'confirm' => $this->trans(
                    'Fulfill selected items?',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'icon' => 'icon-check',
            ],
        ];

        $lastImport = AmazonMarketConfiguration::get(OrderKey::CONFIG_LAST_ORDER_IMPORT_TIME);
        if (!empty($lastImport)) {
            $this->informations[] = sprintf('%s: %s', $this->trans('Last Imported By Cron', [], 'Modules.Tooleamazonmarkettool.Admin'), $lastImport[$this->active_region] ?? null);
        }

        $this->addRowAction('viewOrder');
        $this->addRowAction('fulfillment');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitBulkfulfillAll' . $this->table)) {
            if (Tools::getValue($this->table . 'Box')) {
                $this->handleFulfill((array) Tools::getValue($this->table . 'Box'));
                $this->redirectAdminToole();
            }
        }

        return parent::postProcess();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $cssLink = $this->module->getMediaLink('/views/css/order/imported_order.css');
        $this->context->controller->addCSS($cssLink);
    }

    public function displayViewOrderLink($token, $id)
    {
        $teOrder = new TooleAmazonMarketAmazonOrder($id);

        return $this->context->smarty->createTemplate($this->getTemplatePath() . 'order/view_order_link.tpl')
            ->assign([
                'action' => $this->trans('View', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'href' => $this->context->link->getAdminLink('AdminOrders', true, [], ['id_order' => $teOrder->ps_order_id, 'vieworder' => 1]),
            ])->fetch();
    }

    public function displayFulfillmentLink($token, $id)
    {
        $teOrder = new TooleAmazonMarketAmazonOrder($id);
        $psOrder = new Order($teOrder->ps_order_id);
        if (Validate::isLoadedObject($psOrder)) {
            $disabled = false;
            $disabled_text = '';
            if ($teOrder->isAFNChannel()) {
                $disabled_text = $this->trans(
                    'Fulfillment Unavailable - Fulfilled by Amazon',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
                $disabled = true;
            } elseif (!$teOrder->isFulfillable()) {
                $disabled_text = $this->trans(
                    'Fulfillment Unavailable - Amazon Order Status Not Supported',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
                $disabled = true;
            } else {
                $fulfillStatus = AmazonMarketConfiguration::get(OrderKey::FULFILL_ORDER_STATUS);
                if ($fulfillStatus != $psOrder->getCurrentState()) {
                    $disabled_text = $this->trans(
                        'Fulfillment Unavailable - Incorrect Prestashop Status',
                        [],
                        'Modules.Tooleamazonmarkettool.Admin'
                    );
                    $disabled = true;
                }
            }

            return $this->context->smarty->createTemplate(
                $this->getTemplatePath() . 'order/fulfill_link.tpl'
            )->assign([
                'action' => $this->trans(
                    'Fulfillment',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'disabled' => $disabled,
                'action_text' => $this->trans(
                    'Fulfill',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'action_disabled_text' => $disabled_text,
                'href' => $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported') .
                    $this->submit_action . '&id=' . $id . '&action=fulfillment',
            ])->fetch();
        }

        return '';
    }

    public function ajaxProcessFulfillment(): void
    {
        try {
            $id = Tools::getValue('id');
            $this->handleFulfill([$id], true);
            exit(new AjaxResponse([], $this->warnings, $this->confirmations, true, false,
                [
                    'mp_status' => ISOrderModel::ORDER_STATUS_SHIPPED,
                    'logId' => $this->module->log->getScheduler(),
                ]
            ));
        } catch (Exception $e) {
            $this->module->log->error(sprintf('Error: %s', $e->getMessage()));
            exit(new AjaxResponse($this->errors, [], [], true, false,
                [
                    'logId' => $this->module->log->getScheduler(),
                ]
            ));
        }
    }

    public function processFulfillment(): void
    {
        $id = Tools::getValue('id');
        $this->handleFulfill([$id]);
        $this->redirectAdminToole();
    }

    /**
     * @throws Exception
     */
    public function handleFulfill($ids, $isAjax = false)
    {
        if (is_array($ids) && count($ids) > 0) {
            $isSingle = 1 === count($ids);
            $this->module->log->setLog(sprintf('Fulfillment Order ID(s) (%s)', implode(',', $ids)));
            $fulfillOrder = new OrderFulfillment($this->saasHelper, $ids, $this->module);
            try {
                $fulfillOrder->doFulfill();
                $this->module->log->error($fulfillOrder->getErrors())->warning($fulfillOrder->getWarnings());
                $this->errors = array_merge($this->errors, $fulfillOrder->getErrors());
                $this->warnings = array_merge($this->warnings, $fulfillOrder->getWarnings());
                if (!$this->errors && !$this->warnings) {
                    if ($isSingle) {
                        $this->confirmations[] = $this->trans(
                            'The order fulfillment process has completed. Details of the process are in the Activity Logs > Summaries',
                            [],
                            'Modules.Tooleamazonmarkettool.Admin'
                        );
                    } else {
                        $this->confirmations[] = $this->trans(
                            'The orders fulfillment process have completed. Details of the process are in the Activity Logs > Summaries',
                            [],
                            'Modules.Tooleamazonmarkettool.Admin'
                        );
                    }
                }
            } catch (Exception $e) {
                $this->module->log->error(sprintf('Error: %s', $e->getMessage()));
                $this->errors[] = sprintf('An unexpected error has occurred: %s', $e->getMessage());
            }
        } else {
            $this->errors[] = $this->trans('Unable to fulfill order', [], 'Modules.Tooleamazonmarkettool.Admin');
        }
        if (!$isAjax) {
            $this->redirectAdminToole();
        }
    }

    public function processSaveOptionalColumns(): void
    {
        $optionalColumns = Tools::getValue('optionalColumns', []);
        Configuration::updateValue(OrderKey::CONFIG_IMPORTED_ORDERS_OPTIONAL_COLUMNS, json_encode(array_values($optionalColumns)));
        $this->redirectAdminToole();
    }
}
