<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\CatalogKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketProductsImportedFromAmazonController extends TooleBaseAdminController
{
    protected $entityId;
    protected $isFBA = false;
    protected $productType = TooleAmazonMarketAmazonProduct::AMAZON_PRODUCT;
    protected $lastFetchReport = CatalogKey::LAST_FETCH_CATALOG_REPORT;

    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'catalog/amazon_sync/';
        $this->tpl_folder = 'catalog/amazon_sync/';
        $this->bootstrap = true;
        $this->class_name = 'TooleAmazonMarketAmazonProduct';

        $this->table = Database::TABLE_AMAZON_PRODUCTS;
        $this->identifier = 'id';
        $this->colorOnBackground = false;
        $this->multishop = true;
        $this->toolbar_title = $this->trans(
            'Amazon Products',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );
        $this->_defaultOrderBy = 'id';
        $this->list_id = 'id';
        $this->use_distinct = true;
        $this->_use_found_rows = false;
        $this->list_no_link = true;
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);

        $this->bulk_actions = [
            'syncAll' => [
                'text' => $this->trans(
                    'Sync Selected',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'confirm' => $this->trans(
                    'Are you sure you want to synchronize all selected products?',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
            ],
        ];
        $this->_orderBy = 'id';
        $this->_orderWay = 'ASC';
        $this->_select = ' IF(is_synced = 0, "#ff2614", "#54ff81") as color, CASE
            WHEN is_mapped = ' . TooleAmazonMarketAmazonProduct::MAPPING_NOT_EXIST_ON_PS . ' THEN "#e0e045"
            WHEN is_mapped = ' . TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED . ' THEN "#25b9d7"
            WHEN is_mapped = ' . TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_AND_ENABLED . ' THEN "#54ff81"
            ELSE ""#ff2614"
        END AS mapping_color';

        $this->_where .= (' AND `id_entity` = ' . (int) $this->entityId);
        $this->_where .= (' AND `type` = ' . (int) $this->productType);

        // Don't filter by time, just show all the listing

        $this->fields_list = [
            'id' => [
                'title' => $this->trans(
                    'Id',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'left',
                'width' => 'auto',
                'orderby' => true,
                'search' => false,
            ],
            'sku' => [
                'title' => $this->trans(
                    'Amazon SKU',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
            ],
            'amz_product_name' => [
                'title' => $this->trans(
                    'Name',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'left',
                'width' => 'auto',
            ],
            'amz_product_desc' => [
                'title' => $this->trans(
                    'Description',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'left',
                'width' => 'auto',
                'orderby' => false,
                'search' => false,
            ],
            'qty' => [
                'title' => $this->trans(
                    'Quantity',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'text-center',
                'search' => false,
                'width' => 'auto',
            ],
            'price' => [
                'title' => $this->trans(
                    'Price',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'text-center',
                'search' => false,
                'width' => 'auto',
            ],
            'is_mapped' => [
                'title' => $this->trans(
                    'Mapping',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'color' => 'mapping_color',
                'align' => 'text-center',
                'type' => 'string',
                'orderby' => false,
                'filter_type' => 'string',
                'filter_key' => 'a!is_mapped',
            ],
            'is_synced' => [
                'title' => $this->trans(
                    'Sync',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'color' => 'color',
                'align' => 'text-center',
                'type' => 'bool',
                'orderby' => false,
                'filter_type' => 'bool',
                'filter_key' => 'a!is_synced',
            ],
            'date_upd' => [
                'title' => $this->trans(
                    'Adjustment Date',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'text-center',
                'width' => 'auto',
                'search' => false,
            ],
        ];
        $this->addRowAction('sync');
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitBulksyncAll' . $this->table)) {
            $ids = Tools::getValue('idBox');
            if (!empty($ids)) {
                $this->module->log->setLog(sprintf('Start bulk synchronizing all amazon products'));
                foreach ($ids as $id) {
                    TooleAmazonMarketAmazonProduct::syncProduct($id, $this->entityId, $this->productType, $this->module->log);
                }
            }
            $this->redirectAdminToole();
        }
        parent::postProcess();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $cssLink = $this->module->getMediaLink('/views/css/catalog/amazon_sync.css');
        $jsLink = $this->module->getMediaLink('/views/js/catalog/amazon_sync.js?v=' . $this->module->version);
        $this->context->controller->addCSS($cssLink);
        $this->context->controller->addJS($jsLink);
    }

    // Custom callback function to render tooltips
    public function renderMappingStatusTooltip($value, $item)
    {
        $title = TooleAmazonMarketAmazonProduct::getMappingStatusMessages($value, $this->module->getTranslator());
        $tpl = $this->context->smarty->createTemplate($this->getTemplatePath() . '/common/tooltip.tpl')->assign([
            'title' => $this->trans($title, [], 'Modules.Tooleamazonmarkettool.Admin'),
            'value' => $value,
        ]);

        return $tpl->fetch();
    }

    public function renderList()
    {
        $lastFetch = AmazonMarketConfiguration::get($this->lastFetchReport);
        if ($lastFetch) {
            $lastFetch = date('Y-m-d H:i:s', $lastFetch);
            $this->informations[] = $this->trans('The list was refreshed at %refreshDate%', ['%refreshDate%' => $lastFetch], 'Modules.Tooleamazonmarkettool.Admin');
        }
        $this->informations[] = $this->trans('There is a scheduled task available that will update this list automatically.  You can enable it in Module Configuration > Scheduled Tasks', [], 'Modules.Tooleamazonmarkettool.Admin');

        // Add the custom rendering for mapping tooltips
        $this->fields_list['is_mapped']['callback'] = 'renderMappingStatusTooltip';

        return parent::renderList();
    }

    public function displaySyncLink($token, $id)
    {
        $sql = new DbQuery();
        $sql->select('p.`is_synced`, p.`is_mapped`');
        $sql->from(Database::TABLE_AMAZON_PRODUCTS, 'p');
        $sql->where('p.`id` = ' . pSQL($id));
        $sql->where('p.`id_entity` = ' . (int) $this->entityId);
        $sql->where('p.`type` = ' . (int) $this->productType);
        $result = Db::getInstance()->getRow($sql);

        $isSync = true;

        if (!empty($result)) {
            if (is_null($result['is_mapped']) || (int) $result['is_mapped'] === TooleAmazonMarketAmazonProduct::MAPPING_EXIST_ON_PS_AND_ENABLED) {
                $isSync = false;
            }
        }

        return $this->context->smarty->createTemplate(
            $this->getTemplatePath() . 'catalog/amazon_sync/list_action_sync_amazon_product.tpl'
        )->assign([
            'id' => $id,
            'action' => $this->trans(
                'Sync Product',
                [],
                'Modules.Tooleamazonmarkettool.Admin'
            ),
            'is_sync' => $isSync,
            'href' => $this->context->link->getAdminLink($this->controller_name) .
                $this->submit_action . '&id=' . $id . '&action=sync',
        ])->fetch();
    }

    public function processSync()
    {
        $id = Tools::getValue('id');
        $this->module->log->setLog(sprintf('Synchronizing a product'));
        TooleAmazonMarketAmazonProduct::syncProduct($id, $this->entityId, $this->productType, $this->module->log);
        $this->redirectAdminToole();
    }

    public function initPageHeaderToolbar(): void
    {
        $this->page_header_toolbar_btn['toole_feed_request'] = [
            'href' => $this->context->link->getAdminLink($this->controller_name) .
                      $this->submit_action . '&action=updateMappingStatusForProducts&token=' .
                      $this->token,
            'desc' => $this->trans(
                'Update Mapping State',
                [],
                'Modules.Tooleamazonmarkettool.Admin'
            ),
            'icon' => 'process-icon-download',
        ];
        parent::initPageHeaderToolbar();
    }

    public function processUpdateMappingStatusForProducts(): void
    {
        $products = TooleAmazonMarketAmazonProduct::getTooleProductsWithMappingStatus($this->entityId, $this->productType);

        if (!empty($products)) {
            foreach ($products as $product) {
                TooleAmazonMarketAmazonProduct::updateMappingStatusTooleProduct($product['id'], $product['mapping_status']);
            }
        }
    }
}
