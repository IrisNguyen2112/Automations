<?php
/**
 * AmazonMarketplaceImportOrderController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Avoid name conflict with \Toole\Module\AmazonMarketplace\Core\Prestashop\Controller\AmazonMarketplaceConfigurationAdminController
 */
class ToolEAmazonMarketAdminConfigController extends TooleBaseAdminController
{
    public function ajaxProcessAccountTestConnection()
    {
        $this->active_region = Tools::getValue('region', AmazonConstant::MKP_REGION_EU);
        Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_REGION, $this->active_region, false, $this->shop_id_group, $this->shop_id);
        $this->saasHelper = SaaSConnector::initHelperWithConnector($this->active_region, [], true);
        $this->module->log->setLog(sprintf('Test connection: %s', $this->active_region));

        try {
            $amzResponse = $this->saasHelper->getMarketplaceParticipations();
            $enableList = $this->saasHelper->getAmazonConnector()->getAvailableMarketplaces();
            $listMkpParticipation = $amzResponse->getAmazonData() ?: [];
            if (!count($listMkpParticipation)) {
                $response = [
                    'success' => false,
                    'msg' => $this->trans(
                        "You don't have any active marketplaces",
                        [],
                        'Modules.Tooleamazonmarkettool.Admin'
                    ),
                ];
                $this->module->log->error(sprintf('Error: %s', $response['msg']));
            } else {
                // Reset data marketplaces to enable
                AmazonMarketConfiguration::saveAmzMarketplaces($listMkpParticipation, $enableList, $this->active_region);

                $response = [
                    'success' => true,
                    'msg' => $this->trans(
                        'Your seller account has been connected to Amazon successfully',
                        [],
                        'Modules.Tooleamazonmarkettool.Admin'
                    ),
                    'data' => $listMkpParticipation,
                ];
                $this->module->log->success(sprintf('Success: %s', $response['msg']));
            }
        } catch (Exception $exception) {
            $this->module->log->error(sprintf('Error: %s', $exception->getMessage()));
            $response = [
                'success' => false,
                'msg' => $exception->getMessage(),
                'status' => $exception->getCode(),
            ];
        }

        exit(json_encode($response));
    }
}
