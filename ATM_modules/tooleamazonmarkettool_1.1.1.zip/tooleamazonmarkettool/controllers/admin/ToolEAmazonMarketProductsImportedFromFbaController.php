<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\CatalogKey;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketProductsImportedFromFbaController extends ToolEAmazonMarketProductsImportedFromAmazonController
{
    public function __construct()
    {
        $this->isFBA = true;
        $this->productType = TooleAmazonMarketAmazonProduct::FBA_PRODUCT;
        $this->lastFetchReport = CatalogKey::LAST_FETCH_FBA_REPORT;
        parent::__construct();
        $this->toolbar_title = $this->trans(
            'FBA Products',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );
        $this->fields_list['sku']['title'] = $this->trans(
            'FBA SKU',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );
    }
}
