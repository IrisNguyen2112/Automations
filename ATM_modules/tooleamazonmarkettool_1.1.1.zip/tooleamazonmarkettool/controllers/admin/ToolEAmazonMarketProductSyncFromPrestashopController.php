<?php
/**
 * ToolEAmazonMarketProductSyncFromPrestashopController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\CatalogSyncFromPs;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketProductSyncFromPrestashopController extends TooleBaseAdminController
{
    private $entityId;

    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();
        $this->bootstrap = true;
        $this->list_no_link = true;
        $this->class_name = 'ToolEAmazonMarketProductSyncFromPrestashop';
        $this->override_folder = 'catalog/prestashop_sync/';
        $this->tpl_folder = 'catalog/prestashop_sync/';
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);

        // Table information
        $this->_use_found_rows = false;
        $this->list_id = 'identifier_key';
        $this->use_distinct = true;
        $this->identifier = 'identifier_key';
        $this->force_identifier = 'CONCAT(a.id_product, "_", IF(pa.id_product_attribute IS NOT NULL, pa.id_product_attribute, 0))';
        $this->table = 'product';
        $this->_select = '
            CONCAT(a.id_product, "_", IF(pa.id_product_attribute IS NOT NULL, pa.id_product_attribute, 0)) as identifier_key,
            a.id_product,
            IF(pa.id_product_attribute IS NOT NULL, pa.id_product_attribute, 0) AS id_product_attribute,
            IF(pa.reference IS NOT NULL, pa.reference, a.reference) AS reference,
            pl.name AS name_to_show,
            sa.quantity,
            IF(pas.price IS NOT NULL AND pas.price > 0, pas.price, ps.price) AS price
            ';
        $this->_join =
            ' INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON a.id_product = pl.id_product
            INNER JOIN `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` ae
            LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute` pa ON a.id_product = pa.id_product
            LEFT JOIN `' . _DB_PREFIX_ . 'stock_available` sa ON (IF(pa.reference IS NOT NULL, sa.id_product_attribute = pa.id_product_attribute, sa.id_product = a.id_product AND sa.id_product_attribute = 0))
            LEFT JOIN `' . _DB_PREFIX_ . 'product_shop` ps ON (ps.id_product = a.id_product AND ps.id_shop = sa.id_shop)
            LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_shop` pas ON (pas.id_product_attribute = pa.id_product_attribute AND pas.id_shop = ' . $this->shop_id . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` tmsp ON (tmsp.id_product = a.id_product AND tmsp.id_entity = ae.id_entity AND tmsp.id_shop = sa.id_shop AND tmsp.id_shop_group = ' . $this->shop_id_group . ')
            LEFT JOIN `' . _DB_PREFIX_ . 'category_product` cp ON (cp.id_product = a.id_product)
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` tmsc ON (tmsc.id_category = cp.id_category AND tmsc.id_entity = ae.id_entity AND tmsc.id_shop = sa.id_shop AND tmsc.id_shop_group = ' . $this->shop_id_group . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` tmsm ON (tmsm.id_manufacturer = a.id_manufacturer AND tmsm.id_entity = ae.id_entity AND tmsm.id_shop = sa.id_shop AND tmsm.id_shop_group = ' . $this->shop_id_group . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` tmss ON (tmss.id_supplier = a.id_supplier AND tmss.id_entity = ae.id_entity AND tmss.id_shop = sa.id_shop AND tmss.id_shop_group = ' . $this->shop_id_group . ')
            ';

        $this->_where .= ' AND sa.id_shop = ' . $this->shop_id;
        $this->_where .= ' AND pl.id_shop = ' . $this->shop_id;
        $this->_where .= ' AND pl.id_lang = ' . $this->context->language->id;
        $this->_where .= ' AND ae.id_entity = ' . $this->entityId;
        $this->_where .= ' AND (tmsp.`enabled_ps_amz` = 1 OR tmsc.`enabled_ps_amz` = 1 OR tmsm.`enabled_ps_amz` = 1 OR tmss.`enabled_ps_amz` = 1)';

        $this->_orderBy = 'a.id_product';
        $this->_orderWay = 'DESC';

        $this->fields_list = [
            'id_product' => [
                'title' => $this->trans(
                    'Product Id',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'center',
                'class' => 'fixed-width-sm',
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
                'filter_key' => 'a!id_product',
            ],
            'id_product_attribute' => [
                'title' => $this->trans(
                    'Product Attribute Id',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'center',
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
                'filter_key' => 'pa!id_product_attribute',
            ],
            'reference' => [
                'title' => $this->trans(
                    'SKU',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'a!reference',
            ],
            'name_to_show' => [
                'title' => $this->trans(
                    'Product Name',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => false,
                'search' => true,
                'filter_key' => 'pl!name',
            ],
            'quantity' => [
                'title' => $this->trans(
                    'Quantity',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => true,
                'search' => false,
                'filter_key' => 'sa!quantity',
            ],
            'price' => [
                'title' => $this->trans(
                    'Price',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => true,
                'search' => false,
                'filter_key' => 'ps!price',
            ],
        ];

        $this->bulk_actions = $this->buildBulkActions();

        $this->addRowAction('export');
    }

    public function postProcess()
    {
        foreach ($this->saasHelper->getAmazonConnector()->getAvailableMarketplaces() as $marketplace) {
            if (Tools::isSubmit('submitBulkexport' . $marketplace . $this->table)) {
                $ids = Tools::getValue('identifier_keyBox');
                $mkpId = $marketplace;
                $this->module->log->setLog(sprintf(
                    'Bulk export products - Marketplace (%s)',
                    $mkpId
                ));
                if (is_array($ids)) {
                    $this->doExport($ids, $mkpId);
                } else {
                    $this->errors[] = $this->trans('Nothing to export', [], 'Modules.Amazonmarkettool.Admin');
                }
                $this->redirectAdminToole();
            }
        }
        return parent::postProcess();
    }

    /**
     * @param $token
     * @param $id
     * @return false|string
     * @throws SmartyException
     */
    public function displayExportLink($token, $id)
    {
        $tpl = $this->createTemplate('export_link.tpl');
        $tpl->assign([
            'action' => $this->trans(
                'Export',
                [],
                'Modules.Tooleamazonmarkettool.Admin'
            ),
            'href' => $this->context->link->getAdminLink('ToolEAmazonMarketProductSyncFromPrestashop') .
                $this->submit_action . '&id=' . $id . '&action=exportProduct&token=' .
                ($token != null ? $token : $this->token),
            'marketplaces' => $this->saasHelper->getAmazonConnector()->getAvailableMarketplaces(),
            'flag_url' => $this->images . 'geo_flags/',
        ]);
        return $tpl->fetch();
    }

    public function renderList()
    {
        $tpl = $this->createTemplate('modal.tpl');
        return $tpl->fetch() . parent::renderList();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $jsLink = $this->module->getMediaLink('/views/js/catalog/prestashop_sync.js?v=' . $this->module->version);
        $this->context->controller->addJS($jsLink);
    }

    public function processExportProduct(): void
    {
        $id = Tools::getValue('id');
        $mkpId = Tools::getValue('mkpId');
        $this->module->log->setLog(sprintf(
            'Export product (%s - Marketplace (%s)',
            $id,
            $mkpId
        ));
        $this->doExport([$id], $mkpId);
        $this->redirectAdminToole();
    }

    private function doExport(array $ids, $mkpId): void
    {
        $identifiers = [];
        $this->module->log->message(sprintf(
            'Total %s products',
            count($ids)
        ));
        foreach ($ids as $id) {
            $parseId = explode('_', $id);
            if (is_array($parseId) && count($parseId) == 2) {
                $identifiers[] = [
                    'id_product' => $parseId[0],
                    'id_product_attribute' => $parseId[1],
                ];
            }
        }

        try {
            $flow = new CatalogSyncFromPs($this->saasHelper, $identifiers, $mkpId, $this->context, $this->module, false);
            $flow->doExport();
            $this->module->log->error($flow->getErrors())->warning($flow->getWarnings())->success($flow->getConfirmations());
            $this->errors = array_merge($this->errors, $flow->getErrors());
            $this->warnings = array_merge($this->warnings, $flow->getWarnings());
            $this->confirmations = array_merge($this->confirmations, $flow->getConfirmations());
        } catch (Exception $exception) {
            $this->module->log->error(sprintf(
                'An error has occurred importing a product: %s',
                $exception->getMessage()
            ));
            $this->errors[] = $exception->getMessage();
        }
    }

    /**
     * @throws SmartyException
     */
    private function buildBulkActions(): array
    {
        $bulkActions = [];
        $tpl = $this->createTemplate('flag.tpl');
        foreach ($this->saasHelper->getAmazonConnector()->getAvailableMarketplaces() as $marketplace) {
            $tpl->assign([
                'flag_url' => $this->images . "geo_flags/$marketplace.png",
            ]);
            $bulkActions['export' . $marketplace] = [
                'text' => $tpl->fetch(),
                'confirm' => $this->trans(
                    'Are you sure you want to export all selected products to %mkp%?',
                    ['%mkp%' => Region::getMkpName($marketplace)],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
            ];
        }

        return $bulkActions;
    }
}
