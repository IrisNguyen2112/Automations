<?php
/**
 * TooleBaseAdminController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Product as ProductHelper;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Url;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @property TooleAmazonMarketTool $module
 */
class TooleBaseAdminController extends ModuleAdminController
{
    public $images;
    public $url;
    public $use_distinct = false;
    public $multishop = false;
    public $force_identifier = '';
    public $class_name;
    public $shop_id;
    public $shop_id_group;

    const TOOLE_DISPLAY_ERRORS = 'tooleDisplayErrors';
    const TOOLE_DISPLAY_WARNINGS = 'tooleDisplayWarnings';
    const TOOLE_DISPLAY_SUCCESSES = 'tooleDisplaySuccesses';
    const TOOLE_DISPLAY_INFO = 'tooleDisplayInformation';

    protected $active_marketplace = AmazonConstant::MKP_FR;
    protected $use_region = true;
    protected $active_region = AmazonConstant::MKP_REGION_EU;
    /** @var ServiceAPIV3Helper */
    protected $saasHelper;

    public function __construct()
    {
        parent::__construct();
        $this->url = Url::getModuleUrl($this->module->name);
        $this->images = $this->url . 'views/img/';
        $this->shop_id = $this->context->shop->id;
        $this->shop_id_group = $this->context->shop->id_shop_group;
        $this->active_region = Configuration::get(KEY::CONFIG_PRESTASHOP_KEY_ACTIVE_REGION, null, $this->shop_id_group, $this->shop_id) ?: AmazonConstant::MKP_REGION_EU;
        $this->active_marketplace = Configuration::get(KEY::CONFIG_PRESTASHOP_KEY_ACTIVE_MARKEPLACE, null, $this->shop_id_group, $this->shop_id) ?: AmazonConstant::MKP_FR;
        $this->saasHelper = $this->buildSaasHelper();
        $amzConnector = $this->saasHelper->getAmazonConnector();
        $this->availableMarketplaces = $amzConnector ? $amzConnector->getAvailableMarketplaces() : [];

        foreach ($this->carryMsgArray() as $key => $value) {
            if ($this->context->cookie->__get($value)) {
                $this->{$key} = json_decode($this->context->cookie->__get($value), true);
                $this->context->cookie->__unset($value);
            }
        }

        Hook::coreRenderWidget($this->module, 'displayDashboardToolbarTopMenu',
            [
                'controller' => 'TooleBaseAdmin',
                'href' => $this->context->link->getAdminLink($this->controller_name) . '&action=change' . ($this->use_region ? 'Region' : 'Marketplace'),
                'allRegions' => Region::getAllRegionsWithMkps(),
                'use_region' => $this->use_region,
                'active_region' => $this->active_region,
                'enable_regions' => $this->renderEnableRegions(),
                'active_marketplace' => $this->active_marketplace,
                'enable_marketplaces' => AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO) ?: [],
            ]);
    }

    protected function buildSaasHelper()
    {
        if ($this->use_region) {
            return SaaSConnector::initHelperWithConnector($this->active_region);
        }

        $activeMarketplace = $this->active_marketplace;
        $region = Region::searchRegionByMkp($activeMarketplace);

        return SaaSConnector::initHelperWithConnector($region, [$activeMarketplace]);
    }

    public function init()
    {
        parent::init();

        /* Support versions lower than 1.7.8 */
        if (version_compare(_PS_VERSION_, '1.7.8', '<')) {
            $id_tab = Tab::getIdFromClassName($this->class_name);
        } else {
            /** @var $tabRepository \PrestaShopBundle\Entity\Repository\TabRepository */
            $tabRepository = $this->get('prestashop.core.admin.tab.repository');
            $id_tab = $tabRepository->findOneIdByClassName($this->class_name);
        }

        $this->tabAccess = Profile::getProfileAccess(
            $this->context->employee->id_profile,
            $id_tab
        );
    }

    /**
     * Override Parent function classes/controller/AdminController.php
     *
     * @param $id_lang
     * @param $order_by
     * @param $order_way
     * @param $start
     * @param $limit
     * @param $id_lang_shop
     * @return void
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function getList(
        $id_lang,
        $order_by = null,
        $order_way = null,
        $start = 0,
        $limit = null,
        $id_lang_shop = false
    ) {
        Hook::exec('action' . $this->controller_name . 'ListingFieldsModifier', [
            'select' => &$this->_select,
            'join' => &$this->_join,
            'where' => &$this->_where,
            'group_by' => &$this->_group,
            'order_by' => &$this->_orderBy,
            'order_way' => &$this->_orderWay,
            'fields' => &$this->fields_list,
        ]);

        if (!isset($this->list_id)) {
            $this->list_id = $this->table;
        }

        if (!Validate::isTableOrIdentifier($this->table)) {
            throw new PrestaShopException(sprintf('Table name %s is invalid:', $this->table));
        }

        /* Check params validity */
        if (!is_numeric($start) || !Validate::isUnsignedId($id_lang)) {
            throw new PrestaShopException('get list params is not valid');
        }

        $limit = $this->checkSqlLimit($limit);

        /* Determine offset from current page */
        $start = 0;
        if ((int) Tools::getValue('submitFilter' . $this->list_id)) {
            $start = ((int) Tools::getValue('submitFilter' . $this->list_id) - 1) * $limit;
        } elseif (
            empty($start)
            && isset($this->context->cookie->{$this->list_id . '_start'})
            && Tools::isSubmit('export' . $this->table)
        ) {
            $start = $this->context->cookie->{$this->list_id . '_start'};
        }

        // Either save or reset the offset in the cookie
        if ($start) {
            $this->context->cookie->{$this->list_id . '_start'} = $start;
        } elseif (isset($this->context->cookie->{$this->list_id . '_start'})) {
            unset($this->context->cookie->{$this->list_id . '_start'});
        }

        /* Cache */
        $this->_lang = (int) $id_lang;

        // Add SQL shop restriction
        $select_shop = '';
        if ($this->shopLinkType) {
            $select_shop = ', shop.name as shop_name ';
        }

        if ($this->multishop_context && Shop::isTableAssociated($this->table) && !empty($this->className)) {
            if (Shop::getContext() != Shop::CONTEXT_ALL || !$this->context->employee->isSuperAdmin()) {
                $test_join = !preg_match('#`?' . preg_quote(_DB_PREFIX_ . $this->table . '_shop') . '`? *sa#',
                    $this->_join);
                if (Shop::isFeatureActive() && $test_join && Shop::isTableAssociated($this->table)) {
                    $this->_where .= ' AND EXISTS (
                        SELECT 1
                        FROM `' . _DB_PREFIX_ . $this->table . '_shop` sa
                        WHERE a.`' . bqSQL($this->identifier) . '` = sa.`' . bqSQL($this->identifier) . '`
                         AND sa.id_shop IN (' . implode(', ', Shop::getContextListShopID()) . ')
                    )';
                }
            }
        }

        if ($this->multishop) {
            $this->_where .= (' AND `a`.`id_shop` = ' . (int) $this->shop_id);
            $this->_where .= (' AND `a`.`id_shop_group` = ' . (int) $this->shop_id_group);
        }

        $fromClause = $this->getFromClause();
        $joinClause = $this->getJoinClause($id_lang, $id_lang_shop);
        $whereClause = $this->getWhereClause();
        $orderByClause = $this->getOrderByClause($order_by, $order_way);

        $shouldLimitSqlResults = $this->shouldLimitSqlResults($limit);

        do {
            $this->_listsql = '';

            if ($this->explicitSelect) {
                foreach ($this->fields_list as $key => $array_value) {
                    // Add it only if it is not already in $this->_select
                    if (isset($this->_select) && preg_match('/[\s]`?' . preg_quote($key, '/') . '`?\s*,/', $this->_select)) {
                        continue;
                    }

                    if (isset($array_value['filter_key'])) {
                        $this->_listsql .= str_replace('!', '.`', $array_value['filter_key']) . '` AS `' . $key . '`, ';
                    } elseif ($key == 'id_' . $this->table) {
                        $this->_listsql .= 'a.`' . bqSQL($key) . '`, ';
                    } elseif ($key != 'image' && !preg_match('/' . preg_quote($key, '/') . '/i', $this->_select)) {
                        $this->_listsql .= '`' . bqSQL($key) . '`, ';
                    }
                }
                $this->_listsql = rtrim(trim($this->_listsql), ',');
            } else {
                $this->_listsql .= ($this->lang ? 'b.*,' : '') . ' a.*';
            }

            $this->_listsql .= "\n" . (isset($this->_select) ? ', ' . rtrim($this->_select, ', ') : '') . $select_shop;

            $limitClause = ' ' . (($shouldLimitSqlResults) ? ' LIMIT ' . (int) $start . ', ' . (int) $limit : '');

            if ($this->_use_found_rows || isset($this->_filterHaving) || isset($this->_having)) {
                $this->_listsql = 'SELECT ' . ($this->use_distinct ? 'DISTINCT' : '') . ' SQL_CALC_FOUND_ROWS ' . ($this->_tmpTableFilter ? ' * FROM (SELECT ' : '') .
                    $this->_listsql .
                    $fromClause .
                    $joinClause .
                    $whereClause .
                    $orderByClause .
                    $limitClause;

                $list_count = 'SELECT ' . ($this->use_distinct ? 'DISTINCT' : '') . ' FOUND_ROWS() AS `' . _DB_PREFIX_ . $this->table . '`';
            } else {
                $this->_listsql = 'SELECT ' . ($this->use_distinct ? 'DISTINCT' : '') . ($this->_tmpTableFilter ? ' * FROM (SELECT ' : '') .
                    $this->_listsql .
                    $fromClause .
                    $joinClause .
                    $whereClause .
                    $orderByClause .
                    $limitClause;

                $list_count = 'SELECT ' . ($this->use_distinct ? 'COUNT(DISTINCT(' . ($this->force_identifier ?: $this->identifier) . '))' : 'COUNT(*)') . ' AS `' . _DB_PREFIX_ . $this->table . '` ' .
                    $fromClause .
                    $joinClause .
                    $whereClause;
            }

            $this->_list = Db::getInstance()->executeS($this->_listsql, true, false);

            if ($this->_list === false) {
                $this->_list_error = Db::getInstance()->getMsgError();

                break;
            }

            $this->_listTotal = Db::getInstance()->getValue($list_count, false);

            if ($shouldLimitSqlResults) {
                $start = (int) $start - (int) $limit;
                if ($start < 0) {
                    break;
                }
            } else {
                break;
            }
        } while (empty($this->_list));

        Hook::exec('action' . $this->controller_name . 'ListingResultsModifier', [
            'list' => &$this->_list,
            'list_total' => &$this->_listTotal,
        ]);
    }

    public function renderList()
    {
        $tpl = $this->context->smarty->createTemplate(_PS_MODULE_DIR_ . $this->module->name . '/views/templates/admin/common/modal.tpl');
        return $tpl->fetch() . parent::renderList();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $cssLink = $this->module->getMediaLink('/views/css/common.css');
        $jsLink = $this->module->getMediaLink('/views/js/common.js?v=' . $this->module->version);
        $this->context->controller->addCSS($cssLink);
        $this->context->controller->addJS($jsLink);
    }

    public function redirectAdminToole(): void
    {
        foreach ($this->carryMsgArray() as $key => $value) {
            if ($this->{$key}) {
                $this->context->cookie->__set($value, json_encode($this->{$key}));
            }
        }
        Tools::redirectAdmin(
            $this->context->link->getAdminLink(Tools::getValue('controller'))
        );
    }

    /**
     * Catalog Filters: Catalog cycle sync warning
     */
    protected function warningCatalogFilter()
    {
        $infiniteProducts = ProductHelper::marketplaceGetCycleSyncProducts($this->context->language->id, $this->active_marketplace);
        if (!empty($infiniteProducts)) {
            $strProducts = Tools::truncateString(implode(', ', array_column($infiniteProducts, 'name')), 200);
            $this->warnings[] = sprintf('%s (%s)',
                $this->trans('Please do not enable 2-way sync for any product as it will lead to an infinite loop.',
                    [], 'Modules.Amazonmarkettool.Admin'), $strProducts);
        }
    }

    private function carryMsgArray(): array
    {
        return [
            'errors' => self::TOOLE_DISPLAY_ERRORS,
            'warnings' => self::TOOLE_DISPLAY_WARNINGS,
            'confirmations' => self::TOOLE_DISPLAY_SUCCESSES,
            'informations' => self::TOOLE_DISPLAY_INFO,
        ];
    }

    private function renderEnableRegions(): array
    {
        $authorizedRegions = AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO) ?: [];

        if (!$authorizedRegions) {
            return [AmazonConstant::MKP_REGION_EU => Region::getRegionNameByCode(AmazonConstant::MKP_REGION_EU)];
        }

        $options = [];
        foreach ($authorizedRegions as $key => $authorizedRegion) {
            if (isset($authorizedRegion['enable']) && $authorizedRegion['enable'] == '1' && $authorizedRegion['sellerId']) {
                $options[$key] = $authorizedRegion['name'];
            }
        }

        return $options;
    }

    public function ajaxProcessChangeRegion()
    {
        $this->active_region = Tools::getValue('zone');
        Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_REGION, $this->active_region, false, $this->shop_id_group, $this->shop_id);
        exit(json_encode([
            'url' => $this->context->link->getAdminLink($this->controller_name),
        ]));
    }

    public function ajaxProcessChangeMarketplace()
    {
        $this->active_marketplace = Tools::getValue('zone');
        Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_MARKEPLACE, $this->active_marketplace, false, $this->shop_id_group, $this->shop_id);
        exit(json_encode([
            'url' => $this->context->link->getAdminLink($this->controller_name),
        ]));
    }
}
