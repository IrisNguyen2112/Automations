<?php
/**
 * ToolEAmazonMarketProductSyncFromFbaController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\ReportType;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\CatalogKey;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketProductSyncFromFbaController extends ToolEAmazonMarketProductSyncFromAmazonController
{
    public function __construct()
    {
        $this->isFBA = true;
        $this->reportTypeName = 'FBA';
        $this->importedCtl = 'ToolEAmazonMarketProductsImportedFromFba';
        $this->reportTypeAmazonApi = ReportType::GET_FBA_MYI_ALL_INVENTORY_DATA;
        $this->lastFetchReport = CatalogKey::LAST_FETCH_FBA_REPORT;
        parent::__construct();
    }
}
