<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\FulfillmentOrders\CancelFulfillmentOrder;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\FulfillmentOrders\UpdateFulfillmentOrder;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

class ToolEAmazonMarketFbaOrderSyncedController extends TooleBaseAdminController
{
    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'order/fba/';
        $this->tpl_folder = 'order/fba/';
        $this->bootstrap = true;
        $this->table = Database::TABLE_FBA_ORDERS;
        $this->identifier = 'id_fba_order';
        $this->submit_action = 'submitAdd' . $this->table;
        $this->class_name = 'ToolEAmazonMarketFbaOrder';
        $this->lang = false;
        $this->deleted = false;
        $this->colorOnBackground = false;
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);

        $this->explicitSelect = true;
        $this->addRowAction('viewOrder');
        $this->addRowAction('updateOrder');
        $this->addRowAction('cancelOrder');

        if (!Tools::getValue('id_product')) {
            $this->multishop_context_group = false;
        }
        $this->imageType = 'gif';
        $this->fieldImageSettings = [
            'name' => 'icon',
            'dir' => 'os',
        ];
        $this->_defaultOrderBy = 'a.date_add';
        $this->deleted = false;
        $this->_orderBy = 'a.date_add';
        $this->_orderWay = 'DESC';
        $this->list_no_link = true;

        $this->_select .= ' a.`id_fba_order`, a.`ps_order_id`, a.`displayable_order_id`, a.`displayable_order_date`, a.`displayable_order_comment`, a.`date_add`, a.`fulfillment_order_status`, a.`status_updated_date`';

        $this->_join = '
            JOIN `' . _DB_PREFIX_ . 'orders` o ON (o.`id_order` = a.`ps_order_id` AND o.`id_shop` = a.`id_shop`)
            JOIN `' . _DB_PREFIX_ . 'order_state` os ON os.`id_order_state` = o.`current_state`
            JOIN `' . _DB_PREFIX_ . 'order_state_lang` osl ON (osl.`id_order_state` = o.`current_state` AND osl.`id_lang` = ' . $this->context->language->id . ')';
        $this->_where .= ' AND a.`id_shop` = ' . $this->shop_id;
        $this->_where .= ' AND a.`id_entity` = ' . $this->entityId;

        $this->bulk_actions = [];

        $this->fields_list = [
            'ps_order_id' => [
                'title' => $this->trans('Id', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'align' => 'text-center',
                'class' => 'fixed-width-sm',
                'search' => true,
                'filter_key' => 'a!ps_order_id',
            ],
            'displayable_order_id' => [
                'title' => $this->trans('Reference', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 'auto',
                'type' => 'string',
                'search' => true,
                'filter_key' => 'a!displayable_order_id',
            ],
            'shipping_speed_category' => [
                'title' => $this->trans('Shipping method', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 'auto',
                'type' => 'string',
                'search' => true,
                'filter_key' => 'a!shipping_speed_category',
            ],
            'fulfillment_order_status' => [
                'title' => $this->trans('Order Status', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 'auto',
                'type' => 'string',
                'search' => true,
                'filter_key' => 'a!fulfillment_order_status',
            ],
            'status_updated_date' => [
                'title' => $this->trans('Updated Date', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 100,
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'date',
                'align' => 'center',
                'filter_key' => 'a!status_updated_date',
            ],
            'date_add' => [
                'title' => $this->trans('Date', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'width' => 100,
                'filter_key' => 'a!date_add',
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'date',
                'align' => 'center',
            ],
        ];
    }

    public function getList(
        $id_lang,
        $orderBy = null,
        $orderWay = null,
        $start = 0,
        $limit = null,
        $id_lang_shop = null
    ) {
        $id_lang_shop = Shop::isFeatureActive() && Shop::getContext() == Shop::CONTEXT_SHOP ?
            (int) $this->context->shop->id : 'a.id_shop_default';
        parent::getList($id_lang, $orderBy, $orderWay, $start, $limit, $id_lang_shop);
    }

    public function displayViewOrderLink($token, $id)
    {
        $fbaOrder = new ToolEAmazonMarketFbaOrder($id);

        return $this->context->smarty->createTemplate($this->getTemplatePath() . 'order/view_order_link.tpl')
            ->assign([
                'action' => $this->trans('View', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'href' => $this->context->link->getAdminLink('AdminOrders', true, [], ['id_order' => $fbaOrder->ps_order_id, 'vieworder' => 1]),
            ])->fetch();
    }

    public function displayUpdateOrderLink($token, $id)
    {
        return $this->context->smarty->createTemplate($this->getTemplatePath() . 'order/fba/update_order_link.tpl')
            ->assign([
                'action' => $this->trans('Update Status', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'href' => $this->context->link->getAdminLink('ToolEAmazonMarketFbaOrderSynced') .
                    $this->submit_action . '&id=' . $id . '&action=updateOrderStatus&token=' .
                    $this->token,
            ])->fetch();
    }

    public function displayCancelOrderLink($token, $id)
    {
        $fbaOrder = new ToolEAmazonMarketFbaOrder($id);
        $disabled = !$fbaOrder->isPossibleCancel();
        $disabled_text = $this->trans(
            'Cancel Unavailable',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );

        return $this->context->smarty->createTemplate($this->getTemplatePath() . 'order/fba/cancel_order_link.tpl')
            ->assign([
                'action' => $this->trans(
                    'CancelOrder',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'action_text' => $this->trans(
                    'Cancel',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'disabled' => $disabled,
                'action_disabled_text' => $disabled_text,
                'href' => $this->context->link->getAdminLink('ToolEAmazonMarketFbaOrderSynced') .
                    $this->submit_action . '&id=' . $id . '&action=cancelOrder&token=' .
                    $this->token,
            ])->fetch();
    }

    public function processCancelOrder()
    {
        $id = Tools::getValue('id');
        $this->handleCancelFulfillmentOrder([$id]);
        $this->redirectAdminToole();
    }

    public function processUpdateOrderStatus()
    {
        $id = Tools::getValue('id');
        $this->handleUpdateFulfillmentOrderStatus([$id]);
        $this->redirectAdminToole();
    }

    private function handleCancelFulfillmentOrder(array $ids)
    {
        if (is_array($ids) && count($ids) > 0) {
            $isSingle = 1 === count($ids);
            $this->module->log->setLog(sprintf('Cancel Fulfillment Order ID(s) (%s)', implode(',', $ids)));
            $fulfillOrder = new CancelFulfillmentOrder($this->saasHelper, $ids, $this->active_marketplace, $this->context, $this->module);
            try {
                $fulfillOrder->doCancel();
                $this->module->log->error($fulfillOrder->getErrors())->warning($fulfillOrder->getWarnings());
                $this->errors = array_merge($this->errors, $fulfillOrder->getErrors());
                $this->warnings = array_merge($this->warnings, $fulfillOrder->getWarnings());
                if (!$this->errors && !$this->warnings) {
                    if ($isSingle) {
                        $this->confirmations[] = $this->trans(
                            'The order fulfillment process has completed. Details of the process are in the Activity Logs > Summaries',
                            [],
                            'Modules.Tooleamazonmarkettool.Admin'
                        );
                    } else {
                        $this->confirmations[] = $this->trans(
                            'The orders fulfillment process have completed. Details of the process are in the Activity Logs > Summaries',
                            [],
                            'Modules.Tooleamazonmarkettool.Admin'
                        );
                    }
                }
            } catch (Exception $e) {
                $this->module->log->error(sprintf('Error: %s', $e->getMessage()));
                $this->errors[] = sprintf('An unexpected error has occurred: %s', $e->getMessage());
            }
        } else {
            $this->errors[] = $this->trans('Unable to cancel fulfill order', [], 'Modules.Tooleamazonmarkettool.Admin');
        }
    }

    private function handleUpdateFulfillmentOrderStatus(array $ids)
    {
        if (count($ids) > 0) {
            $isSingle = 1 === count($ids);
            $this->module->log->setLog(sprintf('Update Status Fulfillment Order ID(s) (%s)', implode(',', $ids)));
            $fulfillOrder = new UpdateFulfillmentOrder($this->saasHelper, $ids, $this->active_marketplace,
                $this->context, $this->module);
            try {
                $fulfillOrder->doUpdate();
                $this->module->log->error($fulfillOrder->getErrors())->warning($fulfillOrder->getWarnings());
                $this->errors = array_merge($this->errors, $fulfillOrder->getErrors());
                $this->warnings = array_merge($this->warnings, $fulfillOrder->getWarnings());
                if (!$this->errors && !$this->warnings) {
                    if ($isSingle) {
                        $this->confirmations[] = $this->trans(
                            'The order fulfillment process has completed. Details of the process are in the Activity Logs > Summaries',
                            [],
                            'Modules.Tooleamazonmarkettool.Admin'
                        );
                    } else {
                        $this->confirmations[] = $this->trans(
                            'The orders fulfillment process have completed. Details of the process are in the Activity Logs > Summaries',
                            [],
                            'Modules.Tooleamazonmarkettool.Admin'
                        );
                    }
                }
            } catch (Exception $e) {
                $this->module->log->error(sprintf('Error: %s', $e->getMessage()));
                $this->errors[] = sprintf('An unexpected error has occurred: %s', $e->getMessage());
            }
        } else {
            $this->errors[] = $this->trans('Unable to update fulfill order', [], 'Modules.Tooleamazonmarkettool.Admin');
        }
    }
}
