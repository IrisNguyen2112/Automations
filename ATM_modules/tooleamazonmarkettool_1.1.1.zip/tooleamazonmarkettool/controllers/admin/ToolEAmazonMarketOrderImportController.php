<?php
/**
 * ToolEAmazonMarketOrderImportController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderImport;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketOrderImportController extends TooleBaseAdminController
{
    public function ajaxProcessImportOrders()
    {
        $this->module->log->setLog('Importing Amazon Orders');
        $amazonOrderIds = Tools::getValue('order_id');

        if ($amazonOrderIds) {
            $this->module->log->message(sprintf('Number of orders to import %s', count($amazonOrderIds)));
        }

        try {
            $amazonImport = new OrderImport($amazonOrderIds, $this->saasHelper, $this->module, $this->context->currency, $this->shop_id);
            $amazonImport->importOrders();
            $response = new AjaxResponseOnce($amazonImport->getErrors(), $amazonImport->getWarnings(), $amazonImport->getConfirmations(), $amazonImport->getResultOrders());
            $this->module->log->extractFromAjaxResponse($response)->message($amazonImport->getDebugs());
        } catch (Exception $exception) {
            $response = AjaxResponseOnce::onlyAnError($exception->getMessage(), ['logId' => $this->module->log->getScheduler()]);
            $this->module->log->extractFromAjaxResponse($response);
        }

        exit($response);
    }
}
