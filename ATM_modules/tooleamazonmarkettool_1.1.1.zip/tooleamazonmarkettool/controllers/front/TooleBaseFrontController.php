<?php
/**
 * TooleBaseFrontController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Url;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @property TooleAmazonMarketTool $module
 */
class TooleBaseFrontController extends ModuleFrontController
{
    public $images;
    public $url;

    protected $active_marketplace = AmazonConstant::MKP_ES;
    protected $use_region = true;
    protected $active_region = AmazonConstant::MKP_REGION_EU;
    /** @var ServiceAPIV3Helper */
    protected $saasHelper;

    public function __construct()
    {
        parent::__construct();
        $this->auth();
        $this->url = Url::getModuleUrl($this->module->name);
        $this->images = $this->url . 'views/img/';
        $this->context = Context::getContext();
        $this->saasHelper = $this->buildSaaSHelper();
    }

    protected function buildSaasHelper()
    {
        if ($this->use_region) {
            return SaaSConnector::initHelperWithConnector($this->active_region);
        }

        $activeMarketplace = $this->active_marketplace;
        $region = Region::searchRegionByMkp($activeMarketplace);

        return SaaSConnector::initHelperWithConnector($region, [$activeMarketplace]);
    }

    /**
     * Check base on subscription
     * @return void
     * @throws Exception
     */
    protected function auth()
    {
        $id_subscription = Tools::getValue('id_subscription');
        $id_config_subscription = Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID);

        if (!$id_subscription || !$id_config_subscription || ($id_subscription !== Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID))) {
            throw new Exception('Not subscribed');
        }
    }
}
