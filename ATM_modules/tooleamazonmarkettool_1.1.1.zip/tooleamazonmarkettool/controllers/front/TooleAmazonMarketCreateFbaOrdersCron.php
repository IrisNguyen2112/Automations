<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\FulfillmentOrders\CreateFulfillmentOrder;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Order as OrderHelper;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;

class TooleamazonmarkettoolTooleAmazonMarketCreateFbaOrdersCronModuleFrontController extends TooleBaseFrontController
{
    const MAX_BACK_OFF_DAYS = 7;

    protected $entityId;
    protected $since;
    protected $psSentState;
    protected $warnings = [];
    protected $confirmations = [];

    public function __construct()
    {
        $this->use_region = false;
        parent::__construct();

        $cronConfig = AmazonMarketConfiguration::get(Key::CONFIG_CRON);
        $enableSync = $cronConfig[OrderKey::CRON_AMT_TYPE_CREATE_FBA_ORDERS]['enable'];

        if (!$enableSync) {
            exit(new AjaxResponseOnce(['This feature is not enabled'], [], [], null));
        }

        $this->psSentState = AmazonMarketConfiguration::get(Key::CONFIG_FBA_SETTINGS)[OrderKey::FBA_FULFILL_ORDER_STATUS] ?? null;

        $this->ajax = true;
        $this->since = Tools::getValue('since', date('Y-m-d H:i:s', strtotime('-' . self::MAX_BACK_OFF_DAYS . ' days')));
    }

    public function displayAjaxCreateFulfillmentOrder(): void
    {
        $this->module->log->setLog('MCF Order: Process Create FBA Order', true);
        $orderIds = OrderHelper::getPsOrderIdsForCreatingFbaOrders($this->psSentState, $this->context->shop->id, $this->since);

        $this->module->log->message([
            sprintf('Get orders since %s', $this->since),
            sprintf('Total %s orders', count($orderIds)),
        ]);

        $orderIds = array_map(function ($val) {
            return $val['id_order'];
        }, $orderIds);

        try {
            $flow = new CreateFulfillmentOrder($orderIds, $this->context, $this->module, $this->psSentState, true);
            $flow->doCreate();
            $response = new AjaxResponseOnce(
                array_merge($this->errors, $flow->getErrors()),
                array_merge($this->warnings, $flow->getWarnings()),
                array_merge($this->confirmations, $flow->getConfirmations()),
                ['logId' => $this->module->log->getScheduler()]
            );
            $this->module->log->extractFromAjaxResponse($response);
            exit($response);
        } catch (Exception $exception) {
            $this->module->log->error(sprintf('An unexpected error has occurred: %s', $exception->getMessage()));
            exit(AjaxResponseOnce::onlyAnError($exception->getMessage()));
        }
    }
}
