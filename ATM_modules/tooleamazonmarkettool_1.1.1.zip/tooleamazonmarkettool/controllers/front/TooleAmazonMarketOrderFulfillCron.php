<?php
/**
 * TooleAmazonMarketOrderFulfillCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderFulfillment;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketOrderFulfillCronModuleFrontController extends TooleBaseFrontController
{
    public function __construct()
    {
        $this->active_region = Tools::getValue('region', AmazonConstant::MKP_REGION_EU);
        parent::__construct();

        $cronConfig = AmazonMarketConfiguration::get(Key::CONFIG_CRON);
        $enableFulfill = $cronConfig[OrderKey::CRON_AMT_TYPE_ORDERS_FULFILL]['enable'];
        if (!$enableFulfill) {
            exit(new AjaxResponseOnce(
                ['This feature is not enabled'],
                [],
                [],
                null
            ));
        }

        $this->ajax = true;
    }

    /**
     * URL: http://hostname/index.php?action=orderFulfill&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketOrderFulfillCron&id_subscription=
     *
     * @return void
     */
    public function displayAjaxOrderFulfill()
    {
        $this->module->log->setLog('Running order fulfilment', true);
        $fulfillOrder = new OrderFulfillment($this->saasHelper, [], $this->module, true);
        try {
            $fulfillOrder->doFulfill();
            $this->module->log->error($fulfillOrder->getErrors())->warning($fulfillOrder->getWarnings());
            exit(new AjaxResponseOnce($fulfillOrder->getErrors(), $fulfillOrder->getWarnings(), [], $fulfillOrder->getShipmentData()));
        } catch (Exception $e) {
            $this->module->log->error(sprintf('Error: %s', $e->getMessage()));
            exit(new AjaxResponseOnce([$e->getMessage()], [], [], ['logId' => $this->module->log->getScheduler()]));
        }
    }
}
