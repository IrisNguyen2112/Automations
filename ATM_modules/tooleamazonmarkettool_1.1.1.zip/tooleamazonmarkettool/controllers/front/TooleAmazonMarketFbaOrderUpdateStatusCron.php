<?php
/**
 * TooleAmazonMarketFbaOrderUpdateStatusCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketFbaOrderUpdateStatusCronModuleFrontController extends TooleBaseFrontController
{
    const STEP_GET_ORDERS = 'getOrders';
    const STEP_SAVE_ORDERS = 'updateOrders';

    private $fbaShippedOrderStatus;
    private $fbaDeliveredOrderStatus;

    public function __construct()
    {
        parent::__construct();
        $cronConfig = AmazonMarketConfiguration::get(Key::CONFIG_CRON);
        $fulfillStatus = AmazonMarketConfiguration::get(Key::CONFIG_FBA_SETTINGS);
        $enableFulfill = $cronConfig[OrderKey::CRON_AMT_TYPE_CREATE_FBA_ORDERS]['enable'];

        $this->fbaShippedOrderStatus = $fulfillStatus[OrderKey::FBA_SHIPPED_ORDER_STATUS] ?? null;
        $this->fbaDeliveredOrderStatus = $fulfillStatus[OrderKey::FBA_DELIVERED_ORDER_STATUS] ?? null;

        if (!$enableFulfill) {
            exit(new AjaxResponseOnce(['This feature is not enabled'], [], [], null));
        }

        $this->ajax = true;
    }

    /**
     * URL: http://hostname/index.php?action=updateStatus&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketFbaOrderUpdateStatusCron&id_subscription=&step=
     *
     * @return void
     */
    public function displayAjaxUpdateStatus()
    {
        $step = Tools::getValue('step');
        if (self::STEP_GET_ORDERS === $step) {
            $this->getOrders();
        } elseif (self::STEP_SAVE_ORDERS === $step) {
            $this->updateOrders();
        } else {
            exit(new AjaxResponseOnce(['Something went wrong'], [], [], []));
        }
    }

    private function getOrders()
    {
        $this->module->log->setLog('Running update FBA orders', true);
        $orders = ToolEAmazonMarketFbaOrder::getOrdersNeedToUpdateStatus();
        exit(new AjaxResponseOnce([], [], [], ['orders' => $orders]));
    }

    private function updateOrders()
    {
        $orders = Tools::getValue('orders', []);
        $counter = 0;

        foreach ($orders as $order) {
            try {
                $this->processUpdateOrder($order);
                ++$counter;
            } catch (Exception $e) {
                $json = json_encode([
                    'result' => null,
                    'errors' => $e->getMessage(),
                    'exception' => $e,
                ]);
                exit(new AjaxResponseOnce([], [], [], ['errors' => $json]));
            }
        }
        exit(new AjaxResponseOnce([], [], [], ['counter' => $counter]));
    }

    public function processUpdateOrder($order)
    {
        $ffmOrder = $order['fulfillmentOrder'];
        $sellerFulfillmentOrderId = $ffmOrder['sellerFulfillmentOrderId'];
        $orderId = ToolEAmazonMarketFbaOrder::getPsOrderIdBySellerFulfillmentOrderId($sellerFulfillmentOrderId);

        if ($orderId) {
            $fulfillmentOrderStatus = $ffmOrder['fulfillmentOrderStatus'];
            $statusUpdatedDate = date('Y-m-d H:i:s', strtotime($ffmOrder['statusUpdatedDate']));
            $fulfillmentShipment = $order['fulfillmentShipments'][0] ?? [];
            $updated = ToolEAmazonMarketFbaOrder::updateOrderStatus($orderId, $fulfillmentOrderStatus, $statusUpdatedDate);

            if ($updated && !empty($fulfillmentShipment['trackingNumber'])) {
                $orderCarrier = new OrderCarrier((int) $orderId);
                $orderCarrier->tracking_number = $fulfillmentShipment['trackingNumber'];
                $orderCarrier->update();

                $currentStatus = $this->fbaShippedOrderStatus;

                if (ToolEAmazonMarketFbaOrder::MCF_STATUS_COMPLETE == $fulfillmentOrderStatus && !empty($fulfillmentShipment['estimatedArrivalDate'])) {
                    $now = date('Y-m-d H:i:s');
                    $estimatedArrival = date('Y-m-d H:i:s', strtotime($fulfillmentShipment['estimatedArrivalDate']));

                    if ($estimatedArrival <= $now) {
                        $currentStatus = $this->fbaDeliveredOrderStatus;
                    }
                }

                $psOrder = new Order((int) $orderId);
                $psOrder->setCurrentState($currentStatus);
                $psOrder->update();
            }
        }
    }
}
