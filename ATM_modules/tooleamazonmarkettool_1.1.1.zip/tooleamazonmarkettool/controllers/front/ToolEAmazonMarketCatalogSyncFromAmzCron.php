<?php
/**
 * TooleAmazonMarketCatalogSyncFromAmzCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\ReportType;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\CatalogSyncFromAmazon;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\CatalogKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Log\Log;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponse;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;
use Toole\Module\Utils\Utils;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketCatalogSyncFromAmzCronModuleFrontController extends TooleBaseFrontController
{
    protected $isFBA = false;
    protected $syncType = 'Amazon';
    protected $cronConfigKey = CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ;
    protected $reportTypeAmazonApi = ReportType::GET_MERCHANT_LISTINGS_ALL_DATA;

    public function __construct()
    {
        $this->use_region = false;
        $this->active_marketplace = Tools::getValue('mkp_id', '');

        parent::__construct();

        $cronConfig = AmazonMarketConfiguration::get(Key::CONFIG_CRON);
        $enableSync = $cronConfig[$this->cronConfigKey]['enable'];
        if (!$enableSync) {
            exit(new AjaxResponseOnce(['This feature is not enabled'], [], [], null));
        }

        $this->module->log = new Log(Tools::getValue('logId', null));
        $this->ajax = true;
    }

    /**
     * URL: http://hostname/index.php?action=stockSync&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketCatalogSyncFromAmzCron&id_subscription=
     *
     * @return void
     * @throws PrestaShopDatabaseException|PrestaShopException
     */
    public function displayAjaxStockSync()
    {
        $this->module->log->setLog(sprintf('Refreshing the offer list from %s.', $this->syncType), true);

        $uuid = Tools::getValue('uuid', '');
        $startTime = Tools::getValue('startTime', null);
        $additional_params = Tools::getValue('additional_params', null);

        if (!empty($startTime)) {
            $startTime = Utils::convertDateTimeToIso8601($startTime);
        }

        $entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);

        if (empty($entityId)) {
            exit(AjaxResponseOnce::onlyAnError(
                $this->trans('No marketplace available.', [], 'Modules.Tooleamazonmarkettool.Admin')
            ));
        }

        if ($uuid) {
            // All subsequence calls must wait for the report to complete
            sleep(15);
        }

        $flow = new CatalogSyncFromAmazon(
            $this->module,
            $this->saasHelper,
            Tools::getShopDomain(),
            $uuid,
            $this->reportTypeAmazonApi,
            $startTime,
            $entityId,
            $this->isFBA,
            $additional_params
        );
        try {
            $isContinuous = $flow->doTheSync($this->active_marketplace);

            $statistic = $flow->getStatistic();
            if ($flow->getParseReportResult()->getData()) {
                $statistic = $flow->updateStatistics($flow->getStatistic(), (array) $flow->getParseReportResult()->getStatistic());
            }
            $response = new AjaxResponse(
                $flow->getErrors(),
                $flow->getWarnings(),
                null,
                $isContinuous,
                $isContinuous,
                [
                    'logId' => $this->module->log->getScheduler(),
                    'uuid' => $flow->getReportResult()->getUuid() ?? '',
                    'additional_params' => [
                        'statistic' => $statistic,
                        'page' => $flow->getParseReportResult()->getNextPage() ?? 1,
                    ],
                ]
            );
        } catch (Exception $e) {
            $response = new AjaxResponse(
                $flow->getErrors(),
                $flow->getWarnings(),
                $e->getMessage(),
                false,
                false,
                array_merge($flow->getStatistic(), ['logId' => $this->module->log->getScheduler()])
            );
        }

        if ($flow->getReportResult()->isProcessFailed()) {
            $this->module->log->extractFromAjaxResponse($response)
                ->error('Error: Report ends unexpectedly!')
                ->error(sprintf('Processing status %s: ', $flow->getReportResult()->getProcessingStatus()));
        }

        $this->module->log->extractFromAjaxResponse($response)
            ->message('statistic: ' . json_encode($flow->getStatistic()))
            ->success(sprintf('Marketplace (%s) - %s', $this->active_marketplace, $this->trans('The process is complete.', [], 'Modules.Tooleamazonmarkettool.Admin')));

        exit($response);
    }
}
