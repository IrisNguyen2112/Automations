<?php
/**
 * AmazonMarketplaceGeneralDataProvider
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  AmazonMarketplaceGeneralDataProvider
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

/**
 *  * AmazonMarketplaceGeneralDataProvider
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */
namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Form;

use PrestaShop\PrestaShop\Core\Configuration\DataConfigurationInterface;
use PrestaShop\PrestaShop\Core\Form\FormDataProviderInterface;

if (!defined('_PS_VERSION_')) {
    exit;
}

class AmazonMarketplaceGeneralDataProvider implements FormDataProviderInterface
{
    private $demoFirstTextDataConfiguration;
    public function __construct(DataConfigurationInterface $demoFirstTextDataConfiguration)
    {
        $this->demoFirstTextDataConfiguration = $demoFirstTextDataConfiguration;
    }
    public function getData(): array
    {
        return $this->demoFirstTextDataConfiguration->getConfiguration();
    }
    public function setData(array $data): array
    {
        return $this->demoFirstTextDataConfiguration->updateConfiguration($data);
    }
}
