<?php
/**
 * Log
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Log;

use Context;
use Db;
use Exception;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponse;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Log
{
    private $scheduler;
    private $log;

    const MESSAGE = 0;
    const SUCCESS = 1;
    const ERROR = 2;
    const WARNING = 3;

    const DAYS_RESET_LOG = 90;

    public function __construct($scheduler = null)
    {
        $this->scheduler = $scheduler ?: (string) ((microtime(true) * 10000) + rand(10000, 99999));
    }

    public function getScheduler(): string
    {
        return (string) $this->scheduler;
    }

    public function setLog($title, $isCron = false): void
    {
        // reset log
        $this->resetLog();

        // Create log record
        $sql = 'INSERT INTO `' . _DB_PREFIX_ . Database::TABLE_LOGS . '` (id, id_shop, id_shop_group, title, is_cron_mode, date_add) VALUES '
               . sprintf('("%s", %d, %d, "%s", %d, "%s")', $this->scheduler, Context::getContext()->shop->id, Context::getContext()->shop->id_shop_group, $title, $isCron ? 1 : 0, date('Y-m-d H:i:s'))
               . 'ON DUPLICATE KEY UPDATE `id` = "' . $this->scheduler . '"';

        try {
            Db::getInstance()->execute($sql);
            $this->log = true;
        } catch (Exception $e) {
            $this->log = false;
        }
    }

    public function message($message, $idFeed = null): Log
    {
        if (is_array($message)) {
            foreach ($message as $mess) {
                $this->log($mess, self::MESSAGE, $idFeed);
            }
        } else {
            $this->log($message, self::MESSAGE, $idFeed);
        }
        return $this;
    }

    public function success($message, $idFeed = null): Log
    {
        if (is_array($message)) {
            foreach ($message as $mess) {
                $this->log($mess, self::SUCCESS, $idFeed);
            }
        } else {
            $this->log($message, self::SUCCESS, $idFeed);
        }
        return $this;
    }

    public function error($message, $idFeed = null): Log
    {
        if (is_array($message)) {
            foreach ($message as $mess) {
                $this->log($mess, self::ERROR, $idFeed);
            }
        } else {
            $this->log($message, self::ERROR, $idFeed);
        }
        return $this;
    }

    public function warning($message, $idFeed = null): Log
    {
        if (is_array($message)) {
            foreach ($message as $mess) {
                $this->log($mess, self::WARNING, $idFeed);
            }
        } else {
            $this->log($message, self::WARNING, $idFeed);
        }
        return $this;
    }

    private function log($message, $type = self::MESSAGE, $idFeed = null): void
    {
        if ($this->log && !empty($message)) {
            $dateStart = date('Y-m-d H:i:s', $_SERVER['REQUEST_TIME']);
            $dateStop = date('Y-m-d H:i:s');

            $sql = 'INSERT INTO `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '` (id_shop, id_shop_group, id_log, id_feed, message, type, date_start, date_stop) VALUES ' .
                sprintf('(%d, %d, "%s", %s, "%s", %d, "%s", "%s") ;', Context::getContext()->shop->id, Context::getContext()->shop->id_shop_group, $this->scheduler, $idFeed ?: 0, pSQL($message), $type,
                    $dateStart, $dateStop);

            Db::getInstance()->execute($sql);
        }
    }

    public function extractFromAjaxResponse(AjaxResponse $response): self
    {
        return $this->error($response->getErrors())->warning($response->getWarnings())->success($response->getMessages());
    }

    public function resetLog(): void
    {
        $sql = 'DELETE `' . _DB_PREFIX_ . Database::TABLE_LOGS . '`, `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '`
            FROM `' . _DB_PREFIX_ . Database::TABLE_LOGS . '`
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '` ON `' . _DB_PREFIX_ . Database::TABLE_LOGS . '`.id = `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '`.id_log
            WHERE `date_add` < DATE_SUB(NOW(), INTERVAL ' . self::DAYS_RESET_LOG . ' DAY)';
        try {
            Db::getInstance()->execute($sql);
        } catch (Exception $e) {
            // ignore
        }
    }
}
