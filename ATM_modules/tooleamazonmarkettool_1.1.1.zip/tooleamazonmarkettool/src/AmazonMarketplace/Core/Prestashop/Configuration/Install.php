<?php
/**
 *  * Install
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

use Configuration;
use Db;
use Language;
use PrestaShopBundle\Entity\Repository\TabRepository;
use Symfony\Contracts\Translation\TranslatorInterface;
use Tab;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\Utils\Utils;
use TooleAmazonMarketAmazonEntity;
use TooleAmazonMarketTool;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Install
{
    protected static $moduleAdminControllers;

    /**
     * @var TranslatorInterface
     */
    protected $translator;
    /**
     * @var TooleAmazonMarketTool
     */
    protected $module;

    public function __construct(TooleAmazonMarketTool $module)
    {
        $this->translator = $module->getTranslator();
        $this->module = $module;

        self::$moduleAdminControllers = array_merge(
            [
                [
                    'class_name' => 'ToolEAmazonMarketConfigurationAdminParent',
                    'parent_class_name' => 'AdminParentModulesSf',
                    'icon' => '',
                    'active' => 0,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketAdminParentTab',
                    'parent_class_name' => '',
                    'icon' => '',
                    'position' => 3,
                    'active' => 1,
                ],
                // Admin configuration
                [
                    'class_name' => 'ToolEAmazonMarketAdminConfig',
                    'parent_class_name' => 'ToolEAmazonMarketAdminParentTab',
                    'icon' => '',
                    'active' => 0,
                ],
            ],

            [
                // Menu root Orders
                [
                    'class_name' => 'ToolEAmazonMarketOrderTab',
                    'parent_class_name' => 'ToolEAmazonMarketAdminParentTab',
                    'icon' => 'shopping_basket',
                    'active' => 1,
                ],
                // Menu root Order
                [
                    'class_name' => 'ToolEAmazonMarketOrderAmazonTab',
                    'parent_class_name' => 'ToolEAmazonMarketOrderTab',
                    'icon' => 'shopping_basket',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketOrderImported',
                    'parent_class_name' => 'ToolEAmazonMarketOrderAmazonTab',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketOrderListing',
                    'parent_class_name' => 'ToolEAmazonMarketOrderAmazonTab',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketOrderImport',
                    'parent_class_name' => 'ToolEAmazonMarketOrderAmazonTab',
                    'icon' => '',
                    'active' => 0,
                ],
                // Menu root FBA Orders
                [
                    'class_name' => 'ToolEAmazonMarketFbaOrderTab',
                    'parent_class_name' => 'ToolEAmazonMarketOrderTab',
                    'icon' => 'shopping_basket',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketFbaOrderListing',
                    'parent_class_name' => 'ToolEAmazonMarketFbaOrderTab',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketFbaOrderSynced',
                    'parent_class_name' => 'ToolEAmazonMarketFbaOrderTab',
                    'icon' => '',
                    'active' => 1,
                ],
            ],

            [
                // Menu root Catalog
                [
                    'class_name' => 'ToolEAmazonMarketCatalogTab',
                    'parent_class_name' => 'ToolEAmazonMarketAdminParentTab',
                    'icon' => 'store',
                    'active' => 1,
                ],
                // Catalog filters
                [
                    'class_name' => 'ToolEAmazonMarketCatalogFilters',
                    'parent_class_name' => 'ToolEAmazonMarketCatalogTab',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketCatalogFiltersProducts',
                    'parent_class_name' => 'ToolEAmazonMarketCatalogFilters',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketCatalogFiltersManufacturers',
                    'parent_class_name' => 'ToolEAmazonMarketCatalogFilters',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketCatalogFiltersSuppliers',
                    'parent_class_name' => 'ToolEAmazonMarketCatalogFilters',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketCatalogFiltersCategories',
                    'parent_class_name' => 'ToolEAmazonMarketCatalogFilters',
                    'icon' => '',
                    'active' => 1,
                ],
            ],
            [
                [
                    'class_name' => 'ToolEAmazonMarketProduct',
                    'parent_class_name' => 'ToolEAmazonMarketCatalogTab',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketProductsImportedFromAmazon',
                    'parent_class_name' => 'ToolEAmazonMarketProduct',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketProductSyncFromAmazon',
                    'parent_class_name' => 'ToolEAmazonMarketProduct',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketProductSyncFromPrestashop',
                    'parent_class_name' => 'ToolEAmazonMarketCatalogTab',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketProductFba',
                    'parent_class_name' => 'ToolEAmazonMarketCatalogTab',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketProductsImportedFromFba',
                    'parent_class_name' => 'ToolEAmazonMarketProductFba',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketProductSyncFromFba',
                    'parent_class_name' => 'ToolEAmazonMarketProductFba',
                    'icon' => '',
                    'active' => 1,
                ],
            ],
            [
                [
                    'class_name' => 'ToolEAmazonMarketActivityLogsTab',
                    'parent_class_name' => 'ToolEAmazonMarketAdminParentTab',
                    'icon' => 'chat',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketLogsSummary',
                    'parent_class_name' => 'ToolEAmazonMarketActivityLogsTab',
                    'icon' => '',
                    'active' => 1,
                ],
                [
                    'class_name' => 'ToolEAmazonMarketFeed',
                    'parent_class_name' => 'ToolEAmazonMarketActivityLogsTab',
                    'icon' => '',
                    'active' => 1,
                ],
            ]
        );
    }

    public function run(): bool
    {
        return $this->installTables()
               && $this->seedInitializationData()
               && $this->installConfiguration()
               && $this->installTabs();
    }

    public function installTables(): bool
    {
        $sql = [
            // toole_marketplace_orders
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` (
                `id_order` INT unsigned NOT NULL auto_increment,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `ps_order_id` INT UNSIGNED NOT NULL,
                `mp_order_id` VARCHAR( 32 ) NOT NULL,
                `mp_status` VARCHAR(32) NULL,
                `channel` VARCHAR( 16 ) NULL,
                `channel_status` VARCHAR( 24 ) NULL DEFAULT NULL,
                `marketplace_id` VARCHAR( 16 ) NULL DEFAULT NULL,
                `buyer_name` VARCHAR( 32 ) NULL DEFAULT NULL,
                `sales_channel` VARCHAR( 32 ) NULL DEFAULT NULL,
                `order_channel` VARCHAR( 32 ) NULL DEFAULT NULL,
                `ship_service_level` VARCHAR( 32 ) NULL DEFAULT NULL,
                `ship_category` VARCHAR( 16 ) NULL DEFAULT NULL,
                `is_prime` BOOL NOT NULL DEFAULT 0,
                `is_premium` BOOL NOT NULL DEFAULT 0,
                `is_business` BOOL NOT NULL DEFAULT 0,
                `is_acknowledged` BOOL NOT NULL DEFAULT 0,
                `earliest_ship_date` datetime DEFAULT NULL,
                `latest_ship_date` datetime DEFAULT NULL,
                `earliest_delivery_date` datetime DEFAULT NULL,
                `latest_delivery_date` datetime DEFAULT NULL,
                `shipping_services` VARCHAR(255) NULL,
                `is_access_point` tinyint(1) NULL DEFAULT \'0\',
                PRIMARY KEY (`id_order`) ,
                KEY `mp_order_id`(`mp_order_id`)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` (
                `id_entity` INT unsigned NOT NULL auto_increment,
                `entity` VARCHAR(50) NOT NULL,
                `name` TEXT NOT NULL,
                `iso_code` VARCHAR(3) NULL DEFAULT NULL,
                PRIMARY KEY (`id_entity`),
                CONSTRAINT unique_entity UNIQUE (entity)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` (
                `id_sync_product` INT unsigned NOT NULL auto_increment,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `id_product` INT NOT NULL,
                `id_entity` INT unsigned NOT NULL,
                `enabled_ps_amz` tinyint(1) NOT NULL DEFAULT \'0\',
                `enabled_amz_ps` tinyint(1) NOT NULL DEFAULT \'0\',
                `enabled_fba_ps` tinyint(1) NOT NULL DEFAULT \'0\',
                PRIMARY KEY (`id_sync_product`),
                FOREIGN KEY (id_entity) REFERENCES ' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '(id_entity),
                INDEX id_product (id_product)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` (
                `id_sync_manufacturer` INT unsigned NOT NULL auto_increment,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `id_manufacturer` INT NOT NULL,
                `id_entity` INT unsigned NOT NULL,
                `enabled_ps_amz` tinyint(1) NOT NULL DEFAULT \'0\',
                `enabled_amz_ps` tinyint(1) NOT NULL DEFAULT \'0\',
                `enabled_fba_ps` tinyint(1) NOT NULL DEFAULT \'0\',
                PRIMARY KEY (`id_sync_manufacturer`),
                FOREIGN KEY (id_entity) REFERENCES ' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '(id_entity),
                INDEX id_manufacturer (id_manufacturer)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` (
                `id_sync_supplier` INT unsigned NOT NULL auto_increment,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `id_supplier` INT NOT NULL,
                `id_entity` INT unsigned NOT NULL,
                `enabled_ps_amz` tinyint(1) NOT NULL DEFAULT \'0\',
                `enabled_amz_ps` tinyint(1) NOT NULL DEFAULT \'0\',
                `enabled_fba_ps` tinyint(1) NOT NULL DEFAULT \'0\',
                PRIMARY KEY (`id_sync_supplier`),
                FOREIGN KEY (id_entity) REFERENCES ' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '(id_entity),
                INDEX id_supplier (id_supplier)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` (
                `id_sync_category` INT unsigned NOT NULL auto_increment,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `id_category` INT NOT NULL,
                `id_entity` INT unsigned NOT NULL,
                `enabled_ps_amz` tinyint(1) NOT NULL DEFAULT \'0\',
                `enabled_amz_ps` tinyint(1) NOT NULL DEFAULT \'0\',
                `enabled_fba_ps` tinyint(1) NOT NULL DEFAULT \'0\',
                PRIMARY KEY (`id_sync_category`),
                FOREIGN KEY (id_entity) REFERENCES ' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '(id_entity),
                INDEX id_category (id_category)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` (
                `id` INT unsigned NOT NULL auto_increment,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `id_entity` INT unsigned NOT NULL,
                `sku` VARCHAR( 32 ) NOT NULL,
                `qty` INT NOT NULL,
                `price` DECIMAL(20,2) NOT NULL,
                `amz_product_name` VARCHAR( 32 ) NOT NULL,
                `amz_product_desc` VARCHAR( 255 ) DEFAULT NULL,
                `is_synced` tinyint(1) NOT NULL DEFAULT \'0\',
                `is_mapped` tinyint(1) DEFAULT NULL,
                `type` tinyint(1) NOT NULL DEFAULT \'0\',
                `date_add` DATETIME NOT NULL,
	            `date_upd` TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_FEEDS . '` (
                `id` INT unsigned NOT NULL auto_increment,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `marketplace_id` VARCHAR( 255 ) NOT NULL,
                `feed_type` VARCHAR( 32 ) NOT NULL,
                `feed_id` VARCHAR( 32 ) NOT NULL,
                `status` VARCHAR( 32 ) NOT NULL,
                `messages_status_code` VARCHAR( 32 ) DEFAULT NULL,
                `messages_processed` INT DEFAULT 0,
                `messages_successful` INT DEFAULT 0,
                `messages_with_error` INT DEFAULT 0,
                `messages_with_warning` INT DEFAULT 0,
                `content_location` VARCHAR(255) DEFAULT NULL,
                `result_location` VARCHAR(255) DEFAULT NULL,
                `date_add` DATETIME NOT NULL,
	            `date_upd` TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_LOGS . '` (
                `id` bigint(20) NOT NULL,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `title` VARCHAR(255) NOT NULL,
                `is_cron_mode` TINYINT(1) NOT NULL DEFAULT 0,
                `date_add` DATETIME NOT NULL,
	            `date_upd` TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '` (
                `id` INT unsigned NOT NULL auto_increment,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `id_log` bigint(20) NOT NULL,
                `id_feed` INT unsigned DEFAULT NULL,
                `message` mediumtext NOT NULL,
                `type` int(11) NULL DEFAULT 0,
                `date_start` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
                `date_stop` datetime(0) NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_MESSAGES . '` (
                `id_message` bigint(20) NOT NULL,
                `id_shop` int(11) unsigned DEFAULT NULL,
                `id_shop_group` int(11) unsigned DEFAULT NULL,
                `message` TEXT NOT NULL,
                `priority` TINYINT(1) NOT NULL DEFAULT 0,
                `is_read` TINYINT(1) NOT NULL DEFAULT 0,
                `date_add` DATETIME NOT NULL,
	            `date_upd` TIMESTAMP,
                PRIMARY KEY (`id_message`)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',

            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_FBA_ORDERS . '` (
                `id_fba_order` int unsigned NOT NULL AUTO_INCREMENT,
                `id_entity` int unsigned DEFAULT NULL,
                `id_shop` int unsigned DEFAULT NULL,
                `id_shop_group` int unsigned DEFAULT NULL,
                `ps_order_id` int unsigned NOT NULL,
                `seller_fulfillment_order_id` varchar(40) DEFAULT NULL,
                `displayable_order_id` varchar(40) DEFAULT NULL,
                `displayable_order_date` datetime NOT NULL,
                `displayable_order_comment` text NOT NULL,
                `shipping_speed_category` varchar(32) NOT NULL,
                `fulfillment_action` varchar(32) NOT NULL,
                `received_date` datetime NOT NULL,
                `fulfillment_order_status` varchar(32) NOT NULL,
                `status_updated_date` datetime NOT NULL,
                `notification_emails` text NOT NULL,
                `feature_constraints` text NOT NULL,
                `date_add` DATETIME NOT NULL,
	            `date_upd` TIMESTAMP,
                PRIMARY KEY (`id_fba_order`)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;',
        ];

        $result = true;
        foreach ($sql as $query) {
            $result = $result && Db::getInstance()->execute($query);
        }

        return $result;
    }

    public function seedInitializationData(): bool
    {
        $regions = Region::getAllRegionsWithMkps();
        foreach ($regions as $regionId => $region) {
            TooleAmazonMarketAmazonEntity::saveEntity($regionId, $region['name']);
            foreach ($region['marketplaces'] as $mkpId => $mkpName) {
                TooleAmazonMarketAmazonEntity::saveEntity($mkpId, $mkpName);
            }
        }

        TooleAmazonMarketAmazonEntity::seedIsoCode();

        return true;
    }

    public function installConfiguration(): bool
    {
        Configuration::updateGlobalValue(
            'TOOLE_AMAZONMARKETTOOL_SERVICE_API_URL',
            Utils::config(
                _PS_MODULE_DIR_ . DIRECTORY_SEPARATOR . $this->module->name,
                'module:service_url'
            )
        );
        Configuration::updateGlobalValue(
            'TOOLE_AMAZONMARKETTOOL_SERVICE_API_KEY',
            Utils::config(
                _PS_MODULE_DIR_ . DIRECTORY_SEPARATOR . $this->module->name,
                'module:service_key'
            )
        );
        Configuration::updateGlobalValue(
            'TOOLE_AMAZONMARKETTOOL_AMAZON_AUTH_API_URL',
            Utils::config(
                _PS_MODULE_DIR_ . DIRECTORY_SEPARATOR . $this->module->name,
                'module:service_auth'
            )
        );
        Configuration::updateGlobalValue(
            'TOOLE_AMAZONMARKETTOOL_SANDBOX',
            Utils::config(
                _PS_MODULE_DIR_ . DIRECTORY_SEPARATOR . $this->module->name,
                'module:sandbox'
            )
        );

        return true;
    }

    public function installTabs(): bool
    {
        /* Support versions lower than 1.7.8 */
        if (version_compare(_PS_VERSION_, '1.7.8', '<')) {
            return $this->installTabsLegacy();
        }

        /** @var TabRepository $tabRepository */
        $tabRepository = $this->module->getContainer()->get('prestashop.core.admin.tab.repository');

        foreach (self::$moduleAdminControllers as $adminController) {
            if (!$tabRepository->findOneIdByClassName($adminController['class_name'])) {
                $tab = new Tab();
                $tab->active = $adminController['active'];
                $tab->class_name = $adminController['class_name'];
                if (isset($adminController['is_root']) && $adminController['is_root']) {
                    $tab->id_parent = 0;
                } else {
                    $tab->id_parent = $tabRepository->findOneIdByClassName($adminController['parent_class_name']);
                }
                $tab->module = $this->module->name;
                $tab->icon = $adminController['icon'];
                $tab->name = [];
                foreach (Language::getLanguages(true) as $lang) {
                    if (!$menu = Utils::config(_PS_MODULE_DIR_ . $this->module->name, 'menu:' . $lang['iso_code'])) {
                        $menu = Utils::config(_PS_MODULE_DIR_ . $this->module->name, 'menu:en');
                    }
                    $tab->name[$lang['id_lang']] = $menu[$tab->class_name];
                }

                if ($tab->add() && !empty($adminController['position'])) {
                    $tab->updatePosition(0, $adminController['position']);
                }
            }
        }

        return true;
    }

    protected function installTabsLegacy(): bool
    {
        $installTabCompleted = true;

        foreach (self::$moduleAdminControllers as $adminController) {
            if (!Tab::getIdFromClassName($adminController['class_name'])) {
                $tab = new Tab();
                $tab->active = $adminController['active'];
                $tab->class_name = $adminController['class_name'];
                if (isset($adminController['is_root']) && $adminController['is_root']) {
                    $tab->id_parent = 0;
                } else {
                    $tab->id_parent = Tab::getIdFromClassName($adminController['parent_class_name']);
                }
                $tab->module = $this->module->name;
                $tab->icon = $adminController['icon'];
                $tab->name = [];
                foreach (Language::getLanguages(true) as $lang) {
                    if (!$menu = Utils::config(_PS_MODULE_DIR_ . $this->module->name, 'menu:' . $lang['iso_code'])) {
                        $menu = Utils::config(_PS_MODULE_DIR_ . $this->module->name, 'menu:en');
                    }
                    $tab->name[$lang['id_lang']] = $menu[$tab->class_name];
                }

                if ($installTabCompleted &= $tab->add() && !empty($adminController['position'])) {
                    $tab->updatePosition(0, $adminController['position']);
                }
            }
        }

        return $installTabCompleted;
    }
}
