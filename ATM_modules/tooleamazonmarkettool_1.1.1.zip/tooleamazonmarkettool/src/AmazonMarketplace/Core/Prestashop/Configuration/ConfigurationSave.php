<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

use Configuration;
use Context;
use Exception;
use Module;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\SubscriptionManager\Service\Api\v2\Response\CreateStoreConfigurationResponse;
use Toole\Module\SubscriptionManager\Service\Api\v2\Response\UpdateStoreConfigurationResponse;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIHelper;
use Tools;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfigurationSave
{
    const ERROR_CREATE = 2;
    const ERROR_UPDATE = 3;
    const SUCCESS = 1;

    /** @var Context */
    protected $context;

    /** @var Module */
    protected $module;

    public function __construct(Module $module, $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function processSubmitAdvancedConfiguration()
    {
        if (Tools::getValue(Key::SERVICE_API_URL)) {
            Configuration::updateGlobalValue(
                Key::SERVICE_API_URL,
                rtrim(Tools::getValue(Key::SERVICE_API_URL), '/')
            );
        }
        if (Tools::getValue(Key::SERVICE_API_KEY)) {
            Configuration::updateGlobalValue(
                Key::SERVICE_API_KEY,
                Tools::getValue(Key::SERVICE_API_KEY)
            );
        }
        if (Tools::getValue(Key::SERVICE_AMAZON_AUTH_URL)) {
            Configuration::updateGlobalValue(
                Key::SERVICE_AMAZON_AUTH_URL,
                rtrim(Tools::getValue(Key::SERVICE_AMAZON_AUTH_URL), '/')
            );
        }
    }

    public function processSubmitConfiguration(): int
    {
        /** @var ServiceAPIHelper $api_helper */
        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new Exception('Problem');
        }
        $custom_data = [
            OrderKey::IMPORT_ORDER_STATUS => Tools::getValue(OrderKey::IMPORT_ORDER_STATUS, null),
            OrderKey::FULFILL_ORDER_STATUS => Tools::getValue(OrderKey::FULFILL_ORDER_STATUS, null),
            OrderKey::INCOMING_CARRIERS => $this->buildMappingCarrier(OrderKey::INCOMING_CARRIERS),
            OrderKey::OUTGOING_CARRIERS => $this->buildMappingCarrier(OrderKey::OUTGOING_CARRIERS),
            Key::AMZ_AUTH_COMBO => $this->buildAmzMarketplaceCombo(),
            Key::CONFIG_CRON => $this->buildCronParamConfigurations(Tools::getValue(Key::CONFIG_CRON, [])),
            ShippingKey::SHIPPING_TEMPLATES => $this->buildShippingRules(Tools::getValue(ShippingKey::SHIPPING_TEMPLATES, [])),
            Key::PRESTASHOP_SHOP_DETAILS => $this->getShopDetails(),
            Key::CONFIG_FBA_SETTINGS => Tools::getValue(Key::CONFIG_FBA_SETTINGS, null)
        ];

        if (!Configuration::get(Key::CONFIG_PRESTASHOP_STORECONFIGURATIONID)) {
            /* @var CreateStoreConfigurationResponse $create_store_configuration_response */
            $create_store_configuration_response = $api_helper->createStoreConfiguration(
                Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID),
                Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                $custom_data
            );
            if (!$create_store_configuration_response) {
                return self::ERROR_CREATE;
            }

            Configuration::updateValue(
                Key::CONFIG_PRESTASHOP_STORECONFIGURATIONID,
                $create_store_configuration_response->getStoreConfigurationId()
            );
        } else {
            /* @var UpdateStoreConfigurationResponse $update_store_configuration_response */
            $update_store_configuration_response = AmazonMarketConfiguration::updateStoreConfiguration($custom_data);
            if (!$update_store_configuration_response) {
                return self::ERROR_UPDATE;
            }
        }

        return self::SUCCESS;
    }

    protected function buildMappingCarrier($key): array
    {
        $filteredCarriers = array_filter(Tools::getValue($key, []), function ($carrier) use ($key) {
            return ($key === OrderKey::INCOMING_CARRIERS && !empty($carrier['amazon_carrier']) && !empty($carrier['non-access_point']))
                || ($key === OrderKey::OUTGOING_CARRIERS && !empty($carrier['ps']) && !empty($carrier['amazon']));
        }, ARRAY_FILTER_USE_BOTH);
        return array_map(function ($carrier) {
            $carrier['access_point'] = $carrier['access_point'] ?? null;
            return $carrier;
        }, $filteredCarriers);
    }

    protected function buildAmzMarketplaceCombo()
    {
        $regionsWMkps = AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO);
        $enableRegions = Tools::getValue(Key::AMZ_AUTH_COMBO);

        if (!empty($regionsWMkps)) {
            foreach ($regionsWMkps as $region => &$regionData) {
                $regionData['enable'] = $enableRegions[$region]['enable'] ?? null;

                // processing update active region & marketplace
                if (!$regionData['enable'] && Configuration::get(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_REGION, null, $this->context->shop->id_shop_group, $this->context->shop->id) == $region) {
                    $availableRegions = array_keys(array_filter($enableRegions, function ($value) {
                        return $value['enable'];
                    }));

                    // update active region
                    $activeRegion = $availableRegions[0] ?? null;
                    Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_REGION, $activeRegion, false, $this->context->shop->id_shop_group, $this->context->shop->id);

                    // update active marketplace
                    $marketplaces = $regionsWMkps[$activeRegion]['marketplaces'];
                    $availableMkps = array_keys(array_filter($marketplaces, function ($value) {
                        return $value['isParticipating'] && $value['isEnable'];
                    }));

                    $activeMkp = $availableMkps[0] ?? null;
                    Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_MARKEPLACE, $activeMkp, false, $this->context->shop->id_shop_group, $this->context->shop->id);
                }

                if (!empty($regionData['marketplaces'])) {
                    array_walk($regionData['marketplaces'], function (&$mkpData, $idMkp) {
                        $mkpData['isEnable'] = Tools::getValue($idMkp) && $mkpData['isParticipating'];
                    });
                }
            }
        }

        return $regionsWMkps ?: [];
    }

    protected function buildCronParamConfigurations($cronSettings): array
    {
        $cronControllers = [
            CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ => [
                'controller' => 'TooleAmazonMarketCatalogSyncFromAmzCron',
                'action' => 'stockSync',
            ],
            CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA => [
                'controller' => 'TooleAmazonMarketCatalogSyncFromFbaCron',
                'action' => 'stockSync',
            ],
            CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS => [
                'controller' => 'TooleAmazonMarketCatalogSyncFromPsCron',
                'action' => 'export',
            ],
            OrderKey::CRON_AMT_TYPE_ORDERS_IMPORT => [
                'controller' => 'TooleAmazonMarketOrderImportCron',
                'action' => 'orderImport',
            ],
            OrderKey::CRON_AMT_TYPE_ORDERS_FULFILL => [
                'controller' => 'TooleAmazonMarketOrderFulfillCron',
                'action' => 'orderFulfill',
            ],
            OrderKey::CRON_AMT_TYPE_ORDERS_ACKNOWLEDGE => [
                'controller' => 'TooleAmazonMarketOrderAcknowledgeCron',
                'action' => 'acknowledge',
            ],
            OrderKey::CRON_AMT_TYPE_UPDATE_STATUS_FBA_ORDERS => [
                'controller' => 'TooleAmazonMarketFbaOrderUpdateStatusCron',
                'action' => 'updateStatus',
            ],
            Key::CRON_AMT_TYPE_FETCH_FEED_RESULT => [
                'controller' => 'TooleAmazonMarketGetFeedSubmissionResultCron',
                'action' => 'getFeedSubmissionResult',
            ],
            OrderKey::CRON_AMT_TYPE_CREATE_FBA_ORDERS => [
                'controller' => 'TooleAmazonMarketCreateFbaOrdersCron',
                'action' => 'createFulfillmentOrder',
            ],
        ];

        foreach ($cronControllers as $key => $cronController) {
            $inputForThisCron = $cronSettings[$key] ?? [];
            $additionalParams = $inputForThisCron['params'] ?? [];
            $params = array_merge(['action' => $cronController['action']], $additionalParams);
            $cronSettings[$key]['url'] = $this->context->link->getModuleLink($this->module->name, $cronController['controller'], $params);
        }

        return $cronSettings;
    }

    protected function buildShippingRules(array $data): ?array
    {
        if (!$data) {
            return null;
        }

        if (!isset($data['enable']) || $data['enable'] == '0') {
            return $data; // Configuration is turned off
        }

        if (!isset($data['rules']) || !is_array($data['rules'])) {
            return $data; // Shipping rules not found
        }

        $rules = $data['rules'];

        $newData = [];
        foreach (['price', 'weight'] as $ruleName) {
            $this->validateShippingRules($rules, $ruleName, $newData);
        }

        $data['rules'] = $newData;

        return $data;
    }

    protected function validateShippingRules($rules, $ruleName, &$newData)
    {
        if (!isset($rules[$ruleName]) || !is_array($rules[$ruleName])) {
            return;
        }

        $validRules = [];
        foreach ($rules[$ruleName] as $rule) {
            $min = isset($rule['min']) ? trim($rule['min']) : null;
            $max = isset($rule['max']) ? trim($rule['max']) : null;
            $name = isset($rule['name']) ? trim($rule['name']) : null;
            if ($min == '' || $max == '' || empty($name)) {
                continue;
            }

            // add valid rule
            $validRules[] = $rule;
        }
        $newData[$ruleName] = $validRules;
    }

    protected function getShopDetails(): array
    {
        $shopDetails = ['email' => 'PS_SHOP_EMAIL', 'name' => 'PS_SHOP_NAME'];
        foreach ($shopDetails as $key => $psKey) {
            $shopDetails[$key] = Configuration::get($psKey, null, $this->context->shop->id_shop_group, $this->context->shop->id);
        }

        return $shopDetails;
    }
}
