<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

if (!defined('_PS_VERSION_')) {
    exit;
}

class CatalogKey extends Key
{
    const LAST_FETCH_CATALOG_REPORT = 'TOOLE_AMAZON_MARKET_LAST_FETCH_CATALOG_REPORT';
    const LAST_FETCH_FBA_REPORT = 'TOOLE_AMAZON_MARKET_LAST_FETCH_FBA_REPORT';

    // Shared config name
    const CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS = 'TOOLE_AMT_CRON_CATALOG_SYNC_FROM_PS_TIME';
    const CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ = 'TOOLE_AMT_CRON_CATALOG_SYNC_FROM_AMZ_TIME';
    const CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA = 'TOOLE_AMT_CRON_CATALOG_SYNC_FROM_FBA_TIME';

    const START_TIME_REPORT_LISTINGS_ALL_DATA = 'TOOLE_AMAZON_MARKETPLACE_START_TIME_REPORT_LISTINGS_ALL_DATA';

    const CONFIG_LAST_PRODUCT_EXPORT_TIME = 'TOOLE_LAST_PRODUCT_EXPORT_TIME';
}
