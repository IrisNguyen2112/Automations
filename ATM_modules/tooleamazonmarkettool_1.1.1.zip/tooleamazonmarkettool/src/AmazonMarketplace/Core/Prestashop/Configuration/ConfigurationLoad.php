<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

use Carrier;
use CarrierCore;
use Configuration;
use Context;
use OrderState;
use PrestaShopBundle\Translation\TranslatorComponent;
use Toole\Module\Amazon\Client\Model\Order;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\Rule;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\RuleByPrice;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\RuleByWeight;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\FulfillmentCarrierDefault;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\FulfillmentCarrierWithShippingMethod;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\OrderImportCarrierExpress;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\OrderImportCarrierStandard;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Url;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use TooleAmazonMarketTool;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfigurationLoad
{
    /**
     * @var TooleAmazonMarketTool
     */
    protected $module;

    /** @var Context */
    protected $context;

    /** @var TranslatorComponent|null */
    protected $translator;

    public function __construct(TooleAmazonMarketTool $module)
    {
        $this->module = $module;
        $this->context = $module->getContext();
        $this->translator = $this->module->getTranslator();
    }

    public function getTplVars(): array
    {
        // Handle show inactive carrier
        $psCarriers = Carrier::getCarriers($this->context->language->id, false, false, false, null, CarrierCore::ALL_CARRIERS);
        $psCarriers = array_map(function ($carrier) {
            if ((int) $carrier['active'] === 0) {
                $carrier['name'] = $carrier['name'] . ' (' . $this->translator->trans('inactive', [], 'Modules.Tooleamazonmarkettool.Admin') . ')';
            }
            return $carrier;
        }, $psCarriers);

        return [
            'url' => $this->module->getContextLink()->getAdminLink('AdminModules', true, [], [
                'configure' => $this->module->name,
                'tab_module' => $this->module->tab,
                'module_name' => $this->module->name,
            ]),
            'images_url' => Url::getModuleUrl($this->module->name) . 'views/img/',
            'help_center_url' => $this->module->help_center_url,
            'welcome_image_url' => $this->getModuleWelcomeImage(),
            'languages' => $this->context->controller->getLanguages(),
            'fields_constant' => $this->getModuleConfigFieldsConstant(),
            'defined_fields' => $this->getModuleConfigDefinedFields(),
            'fields_value' => $this->getModuleConfigFieldsValues(),
            'account' => [
                'regionsWMkps' => Region::getAllRegionsWithMkps(),
                'authorizedRegions' => AmazonMarketConfiguration::getAmazonAccountAuthorization(),
                // ToolEAmazonMarketAdminConfigController
                'controller' => $this->context->link->getAdminLink('ToolEAmazonMarketAdminConfig'),
            ],
            'orders' => [
                'carriers' => [
                    'ps_carriers' => $psCarriers,
                    'incoming_amazon_carriers' => array_merge(
                        OrderImportCarrierStandard::CARRIER_CODES,
                        OrderImportCarrierExpress::CARRIER_CODES
                    ),
                    'outgoing_amazon_carriers' => FulfillmentCarrierDefault::CARRIER_CODES,
                    'carrier_need_shipping_method' => $this->resolveCarrierNeedShippingMethod(),
                ],
            ],
        ];
    }

    protected function getModuleConfigDefinedFields(): array
    {
        return [
            'order_state_list' => OrderState::getOrderStates($this->context->language->id),
            'catalog_sync_time_options' => AmazonMarketConfiguration::$catalog_sync_time_options,
            'order_sync_time_options' => AmazonMarketConfiguration::$order_sync_time_options,
            'amz_order_statuses' => [
                'All' => 'All',
                'Shipped' => Order::ORDER_STATUS_SHIPPED,
                'Unshipped' => Order::ORDER_STATUS_UNSHIPPED,
                'PartiallyShipped' => Order::ORDER_STATUS_PARTIALLY_SHIPPED,
            ],
        ];
    }

    protected function getModuleConfigFieldsValues(): array
    {
        $moduleConfigs = [
            OrderKey::IMPORT_ORDER_STATUS => AmazonMarketConfiguration::get(OrderKey::IMPORT_ORDER_STATUS),
            OrderKey::FULFILL_ORDER_STATUS => AmazonMarketConfiguration::get(OrderKey::FULFILL_ORDER_STATUS),
            ShippingKey::SHIPPING_TEMPLATES => $this->getShippingTemplates(),
            Key::AMZ_AUTH_COMBO => AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO, null, null, []),
            Key::CONFIG_CRON => $this->getCronConfig(AmazonMarketConfiguration::get(Key::CONFIG_CRON, null, null, [])),
            Key::SERVICE_API_URL => Configuration::getGlobalValue(Key::SERVICE_API_URL),
            Key::SERVICE_API_KEY => Configuration::getGlobalValue(Key::SERVICE_API_KEY),
            Key::SERVICE_AMAZON_AUTH_URL => Configuration::getGlobalValue(Key::SERVICE_AMAZON_AUTH_URL),
            Key::CONFIG_FBA_SETTINGS => AmazonMarketConfiguration::get(Key::CONFIG_FBA_SETTINGS, null, null, []),
        ];

        return array_merge($moduleConfigs,
            ['hasAScheduledTask' => $this->hasOneScheduledTaskAtLeast($moduleConfigs)],
            $this->getConfigurationCarriers(OrderKey::OUTGOING_CARRIERS),
            $this->getConfigurationCarriers(OrderKey::INCOMING_CARRIERS)
        );
    }

    private function getModuleConfigFieldsConstant(): array
    {
        return [
            'incoming_carriers' => OrderKey::INCOMING_CARRIERS,
            'outgoing_carriers' => OrderKey::OUTGOING_CARRIERS,
            'import_order_status' => OrderKey::IMPORT_ORDER_STATUS,
            'fulfill_order_status' => OrderKey::FULFILL_ORDER_STATUS,
            'shipping_templates' => ShippingKey::SHIPPING_TEMPLATES,
            'auth_combo' => Key::AMZ_AUTH_COMBO,
            'cron' => [
                'master' => Key::CONFIG_CRON,
                'amz_sync' => CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ,
                'fba_sync' => CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA,
                'ps_sync' => CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS,
                'orders_import' => OrderKey::CRON_AMT_TYPE_ORDERS_IMPORT,
                'orders_fulfill' => OrderKey::CRON_AMT_TYPE_ORDERS_FULFILL,
                'orders_acknowledge' => OrderKey::CRON_AMT_TYPE_ORDERS_ACKNOWLEDGE,
                'feeds_result' => Key::CRON_AMT_TYPE_FETCH_FEED_RESULT,
                'fba_orders' => OrderKey::CRON_AMT_TYPE_CREATE_FBA_ORDERS,
            ],
            'advanced_service_api_url' => Key::SERVICE_API_URL,
            'advanced_service_api_key' => Key::SERVICE_API_KEY,
            'advanced_service_api_auth' => Key::SERVICE_AMAZON_AUTH_URL,
            'fba_order_status' => [
                'key' => Key::CONFIG_FBA_SETTINGS,
                'fulfill' => OrderKey::FBA_FULFILL_ORDER_STATUS,
                'shipped' => OrderKey::FBA_SHIPPED_ORDER_STATUS,
                'delivered' => OrderKey::FBA_DELIVERED_ORDER_STATUS,
            ],
        ];
    }

    private function getModuleWelcomeImage(): string
    {
        $iso_code = $this->context->language->iso_code;
        $base_url = Url::getModuleUrl($this->module->name) . 'views/img/';
        if (file_exists(_PS_ROOT_DIR_ . $base_url . 'module-features-' . $iso_code . '.jpg')) {
            return $base_url . 'module-features-' . $iso_code . '.jpg';
        }
        return $base_url . 'module-features.jpg';
    }

    private function getConfigurationCarriers($key): array
    {
        $carriers = AmazonMarketConfiguration::get($key);

        if ($carriers) {
            $carrierList = $carriers;
        }
        return [$key => $carrierList ?? []];
    }

    private function resolveCarrierNeedShippingMethod(): array
    {
        $result = [];
        foreach (FulfillmentCarrierWithShippingMethod::CARRIERS as $carriers) {
            foreach ($carriers as $carrier) {
                if (!isset($result[$carrier['carrier']])) {
                    $result[$carrier['carrier']] = $carrier['method'];
                } else {
                    $result[$carrier['carrier']] = array_unique(array_merge($result[$carrier['carrier']], $carrier['method']));
                }
            }
        }
        return $result;
    }

    public function getShippingTemplates(): array
    {
        $rulePrice = [];
        $ruleWeight = [];
        $stConfig = AmazonMarketConfiguration::get(ShippingKey::SHIPPING_TEMPLATES, null, null, []);
        $stConfig = is_array($stConfig) ? $stConfig : [];
        $rules = $stConfig['rules'] ?? [];

        foreach ($rules as $ruleType => $rulesByType) {
            foreach ($rulesByType as $ruleId => $rule) {
                if ($ruleType == Rule::TYPE_WEIGHT) {
                    $ruleWeight[$ruleId] = new RuleByWeight($rule['min'] ?? 0, $rule['max'] ?? 0, $rule['unit'] ?? '', $rule['name'] ?? '');
                } else {
                    $rulePrice[$ruleId] = new RuleByPrice($rule['min'] ?? 0, $rule['max'] ?? 0, $rule['name'] ?? '');
                }
            }
        }

        return [
            'enable' => $stConfig['enable'] ?? false,
            'types' => [
                Rule::TYPE_PRICE => [
                    'displayType' => $this->translator->trans('Price', [], 'Modules.Tooleamazonmarkettool.Admin'),
                    'requireUnit' => false,
                ],
                Rule::TYPE_WEIGHT => [
                    'displayType' => $this->translator->trans('Weight', [], 'Modules.Tooleamazonmarkettool.Admin'),
                    'requireUnit' => true,
                ],
            ],
            'use_type' => $stConfig['use_type'] ?? Rule::TYPE_PRICE,
            'use_unit' => $stConfig['use_unit'] ?? Configuration::get('PS_WEIGHT_UNIT'),
            'rules' => [
                Rule::TYPE_PRICE => $rulePrice,
                Rule::TYPE_WEIGHT => $ruleWeight,
            ],
        ];
    }

    protected function getCronConfig($savedData): array
    {
        $skeleton = [
            CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ => [
                'enable' => 0,
                'frequency' => 30,
            ],
            CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA => [
                'enable' => 0,
                'frequency' => 30,
            ],
            CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS => [
                'enable' => 0,
                'frequency' => 30,
            ],
            OrderKey::CRON_AMT_TYPE_ORDERS_IMPORT => [
                'enable' => 0,
                'frequency' => 30,
                'params' => [
                    'statuses' => Order::ORDER_STATUS_UNSHIPPED,
                ],
            ],
            OrderKey::CRON_AMT_TYPE_ORDERS_FULFILL => [
                'enable' => 0,
                'frequency' => 30,
            ],
            OrderKey::CRON_AMT_TYPE_CREATE_FBA_ORDERS => [
                'enable' => 0,
                'frequency' => 30,
            ],
        ];

        return array_replace_recursive($skeleton, $savedData ?: []);
    }

    protected function hasOneScheduledTaskAtLeast(array $moduleConfigs): bool
    {
        if ($moduleConfigs[Key::CONFIG_CRON][CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_AMZ]['enable']) {
            return true;
        }
        if ($moduleConfigs[Key::CONFIG_CRON][CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA]['enable']) {
            return true;
        }
        if ($moduleConfigs[Key::CONFIG_CRON][CatalogKey::CRON_AMT_TYPE_CATALOG_SYNC_FROM_PS]['enable']) {
            return true;
        }
        if ($moduleConfigs[Key::CONFIG_CRON][OrderKey::CRON_AMT_TYPE_ORDERS_IMPORT]['enable']) {
            return true;
        }
        if ($moduleConfigs[Key::CONFIG_CRON][OrderKey::CRON_AMT_TYPE_ORDERS_FULFILL]['enable']) {
            return true;
        }

        return false;
    }
}
