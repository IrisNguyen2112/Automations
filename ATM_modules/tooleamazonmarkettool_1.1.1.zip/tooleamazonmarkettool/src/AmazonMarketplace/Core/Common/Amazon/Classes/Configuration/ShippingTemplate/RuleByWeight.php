<?php
/**
 * RuleByWeight
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate;

class RuleByWeight extends Rule
{
    const UNIT_GRAM = 'g';
    const UNIT_KG = 'kg';

    public $unit;

    public function __construct($min, $max, $unit, $name)
    {
        parent::__construct($min, $max, $name, self::TYPE_WEIGHT);
        if (!in_array($unit, [self::UNIT_GRAM, self::UNIT_KG])) {
            $unit = self::UNIT_GRAM;
        }
        $this->unit = $unit;
    }

    public function validateInput($inputValue, $inputUnit): bool
    {
        if ($inputUnit == $this->unit) {
            return $this->validateMinMax($inputValue);
        }

        // todo: Do the convert
        return false;
    }
}
