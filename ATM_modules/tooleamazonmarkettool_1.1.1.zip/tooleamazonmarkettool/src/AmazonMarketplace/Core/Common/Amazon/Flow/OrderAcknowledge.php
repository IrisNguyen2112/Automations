<?php
/**
 * OrderAcknowledge
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Module;
use PrestaShop\PrestaShop\Adapter\Entity\Db;
use PrestaShopDatabaseException;
use PrestaShopException;
use Symfony\Contracts\Translation\TranslatorInterface;
use Toole\Module\Amazon\Client\V2\Model\OrdersAcknowledge\OrdersAcknowledgeResponse;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;
use TooleAmazonMarketAmazonFeed;
use TooleAmazonMarketAmazonOrder;

if (!defined('_PS_VERSION_')) {
    exit;
}

class OrderAcknowledge
{
    private $errors = [];
    private $warnings = [];
    private $confirmations = [];
    private $orders = [];

    /** @var ServiceAPIV3Helper */
    protected $saasHelper;

    /** @var Module */
    protected $module;

    /** @var TranslatorInterface */
    protected $translator;

    public function __construct(ServiceAPIV3Helper $saasHelper, $module)
    {
        $this->saasHelper = $saasHelper;
        $this->module = $module;
        $this->translator = $module->getTranslator();
    }

    /**
     * @throws PrestaShopException
     * @throws PrestaShopDatabaseException
     */
    public function doAcknowledge()
    {
        $region = Region::getRegionNameByCode($this->saasHelper->getAmazonConnector()->getRegion());
        $this->module->log->message(sprintf('Amazon %s', $region));
        $mrkIds = $this->saasHelper->getAmazonConnector()->getAvailableMarketplaces();
        $orders = $this->getOrders($mrkIds);
        if (empty($orders)) {
            $this->warnings[] = $this->translator->trans(
                'No orders yet.',
                [],
                'Modules.Tooleamazonmarkettool.Admin'
            );
            return;
        }

        $ordersGroupedByMkp = [];
        $teOrders = [];
        foreach ($orders as $order) {
            $importedOrder = new TooleAmazonMarketAmazonOrder($order['id_order']);
            $ordersGroupedByMkp[$importedOrder->marketplace_id][$importedOrder->mp_order_id] = $importedOrder->ps_order_id;
            $teOrders[] = $importedOrder;
        }

        $apiResult = $this->saasHelper->ordersAcknowledge($ordersGroupedByMkp);
        /** @var OrdersAcknowledgeResponse $response */
        $response = $apiResult->getAmazonData();
        $totalItemExported = $response->getTotalItems();
        $totalFeeds = $response->getTotalFeeds();
        $feeds = $response->getFeeds();
        if ($totalItemExported < 1 || $totalFeeds < 1 || !count($feeds)) {
            $this->warnings[] = $this->translator->trans('Export done but no item is processed!', [], 'Modules.Amazonmarkettool.Admin');
            return;
        }

        foreach ($feeds as $feed) {
            $idFeed = TooleAmazonMarketAmazonFeed::saveRecord([
                'marketplace_id' => $feed->getMarketplaces()[0],
                'feed_type' => $feed->getFeedType(),
                'feed_id' => $feed->getFeedId(),
                'status' => TooleAmazonMarketAmazonFeed::SENT_STATUS,
                'content_location' => $feed->getContentLocation(),
            ]);
            $this->module->log->message(
                $this->translator->trans('Sent Feed (%feed_id%) - (%feed_type%) successfully.', ['%feed_id%' => $feed->getFeedId(), '%feed_type%' => $feed->getFeedType()], 'Modules.Amazonmarkettool.Admin'),
                $idFeed
            );
        }

        $this->confirmations[] = sprintf(
            $this->translator->trans('Acknowledge orders successfully. Sent %d item(s), received %d feeds(s)', [], 'Modules.Amazonmarkettool.Admin'),
            $totalItemExported, $totalFeeds
        );

        $this->markOrdersAsAcked($teOrders);

        $this->orders = $ordersGroupedByMkp;
    }

    /**
     * Get orders are not acknowledged
     */
    private function getOrders($mrkIds = [])
    {
        if ($mrkIds) {
            $conditionMrkIds = ' AND `marketplace_id` IN ("' . implode('","', $mrkIds) . '")';
        }

        $sql = 'SELECT `id_order`, `marketplace_id` FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '`
                WHERE `is_acknowledged` = 0' . $conditionMrkIds;

        return Db::getInstance()->executeS($sql);
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public function getWarnings(): array
    {
        return $this->warnings;
    }

    public function getConfirmations(): array
    {
        return $this->confirmations;
    }

    public function getAckOrders(): array
    {
        return $this->orders;
    }

    /**
     * @param TooleAmazonMarketAmazonOrder[] $teOrders
     * @return void
     * @throws PrestaShopException
     */
    protected function markOrdersAsAcked(array $teOrders)
    {
        foreach ($teOrders as $teOrder) {
            $teOrder->is_acknowledged = true;
            $teOrder->save();
        }
    }
}
