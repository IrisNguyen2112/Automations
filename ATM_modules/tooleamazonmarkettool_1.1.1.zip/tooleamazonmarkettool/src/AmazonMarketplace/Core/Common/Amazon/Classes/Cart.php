<?php
/**
 * Cart
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes;

use Address;
use Carrier;
use Customer;
use Group;
use Tax;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Cart
{
    /** @var OrderProduct[] */
    public $products;
    /** @var Customer */
    public $customer;
    /** @var Carrier */
    public $carrier;
    public $psIdAddress;

    public $shipping;
    public $shippingTaxAmount;

    /**
     * @param OrderProduct[] $products
     * @return void
     */
    public function __construct(array $products, Customer $customer, Carrier $carrier, $psIdAddress, $shipping, $shippingTaxAmount)
    {
        $this->products = $products;
        $this->customer = $customer;
        $this->carrier = $carrier;
        $this->psIdAddress = $psIdAddress;
        $this->shipping = $shipping;
        $this->shippingTaxAmount = $shippingTaxAmount;
    }

    public function calPriceTotalProducts($withTax): float
    {
        $totalProducts = 0;

        foreach ($this->products as $product) {
            if ($withTax) {
                $totalProducts += $product->getUnitPriceTaxIncl() * $product->quantity;
            } else {
                $totalProducts += $product->getUnitPriceTaxExcl($this->psIdAddress, $this->getPriceDisplayMethod()) * $product->quantity;
            }
        }

        return $totalProducts;
    }

    public function calPriceTotalShipping($withTax)
    {
        if ($withTax) {
            return $this->shipping;
        }

        if ($this->shipping == 0) {
            return 0;
        }
        if ($this->shippingTaxAmount) {
            // If products carry shipping tax, just use them
            return $this->shipping - $this->shippingTaxAmount;
        } else {
            // If not, get shipping prices from Amz cart, and calculate tax based on PS tax
            $psCarrierTaxRate = $this->getShippingTaxRate();
            return $this->shipping / ((100 + $psCarrierTaxRate) / 100);
        }
    }

    public function calPriceGiftWrap($withTax)
    {
        // Gift wrap is the same for each item
        foreach ($this->products as $product) {
            $price = $withTax ? $product->getGiftWrapTaxIncl() : $product->getGiftWrapTaxExcl();
            if ($price) {
                return $price;
            }
        }

        return 0;
    }

    public function calPriceTotal($withTax)
    {
        return $this->calPriceTotalProducts($withTax)
            + $this->calPriceTotalShipping($withTax)
            + $this->calPriceGiftWrap($withTax);
    }

    public function getShippingTaxRate()
    {
        $address = new Address($this->psIdAddress);
        if (!Validate::isLoadedObject($address)) {
            return 0;
        }
        if (!$this->getPriceDisplayMethod()) {
            return 0;
        }

        if (method_exists('Carrier', 'getTaxesRate')) {
            return $this->carrier->getTaxesRate($address);
        } elseif (method_exists('Tax', 'getCarrierTaxRate')) {
            return Tax::getCarrierTaxRate($this->carrier->id, $address->id);
        }

        return 0;
    }

    public function getPriceDisplayMethod(): int
    {
        return !Group::getPriceDisplayMethod($this->customer->id_default_group);
    }
}
