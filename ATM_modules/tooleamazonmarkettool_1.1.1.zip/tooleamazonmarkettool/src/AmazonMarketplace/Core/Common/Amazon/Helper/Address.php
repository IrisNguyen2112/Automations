<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper;

use Address as PsAddress;
use Country;
use Db;
use PrestaShop\PrestaShop\Core\Foundation\IoC\Exception;
use Toole\Module\Amazon\Client\Model\Address as TooleAddress;
use Toole\Module\Amazon\Client\Model\BuyerTaxInformation;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Address
{
    const INVALID_FILTER = '/[!<>?=+@{}_$%]+/';

    public static function lookupOrCreateAmazonAddress($id_lang, TooleAddress $amazonAddress, ?BuyerTaxInformation $buyerTaxInfo, $idCustomer): PsAddress
    {
        $alias = self::hash($amazonAddress);
        $id_address = self::getPsAddressByAlias($alias);
        if ($id_address) {
            return new PsAddress($id_address);
        }

        $countryCode = $amazonAddress->getCountryCode();
        if (!Validate::isLanguageIsoCode($countryCode)) {
            throw new Exception("Country code is not valid: $countryCode");
        }
        $psAddress = new PsAddress();
        $idCountry = Country::getByIso($countryCode);
        if (!$idCountry) {
            throw new Exception("Country does not exist: $countryCode");
        }
        $countryName = Country::getNameById($id_lang, $idCountry);
        if (!$countryName) {
            throw new Exception("Country name is malformed for this ID? $idCountry");
        }

        $psAddress->id_country = $idCountry;
        $psAddress->country = Country::getNameById($id_lang, $idCountry);
        $psAddress->alias = $alias;

        $name = Name::parseAmazonName($amazonAddress->getName());
        $psAddress->firstname = $name['firstname'];
        $psAddress->lastname = $name['lastname'];
        $psAddress->company = $name['company'];
        $psAddress->id_customer = $idCustomer;

        $addressLine = self::resolveAddressLines($amazonAddress->getAddressLine1(), $amazonAddress->getAddressLine2());
        $psAddress->address1 = $addressLine['line1'];
        $psAddress->address2 = $addressLine['line2'];

        $psAddress->postcode = preg_replace(
            '/[^a-zA-Z 0-9-]/', '',
            preg_replace('/[,\/]/', '-', $amazonAddress->getPostalCode())
        );
        $psAddress->city = trim($amazonAddress->getCity()) ? preg_replace(self::INVALID_FILTER, ' ', trim($amazonAddress->getCity())) : 'NA';

        $psAddress->phone = preg_replace(
            '/[^+0-9. ()-]/', '',
            preg_replace('/,/', '-', $amazonAddress->getPhone())
        );
        $psAddress->postcode = $amazonAddress->getPostalCode();

        $psAddress->date_add = date('Y-m-d H:i:s');
        $psAddress->date_upd = date('Y-m-d H:i:s');

        if (self::countryRequiresIdentificationNumber($idCountry)) {
            $psAddress->dni = rand(10, 99) . date('YmdHis');
        }

        if (property_exists($psAddress, 'vat_number') && $buyerTaxInfo && $buyerTaxInfo->getBuyerTaxRegistrationId()) {
            $psAddress->vat_number = $buyerTaxInfo->getBuyerTaxRegistrationId();
        }

        if ($psAddress->validateFields() === true && $psAddress->add()) {
            return $psAddress;
        }

        throw new Exception('Address validation failed');
    }

    protected static function hash(TooleAddress $obj): string
    {
        return md5($obj->getName() . $obj->getAddressLine1() . $obj->getAddressLine2()
            . $obj->getCity() . $obj->getPostalCode() . $obj->getCountryCode());
    }

    protected static function getPsAddressByAlias($alias, $id_customer = null)
    {
        $customer_filter = $id_customer ? ' AND a.`id_customer`=' . (int) $id_customer : '';

        return Db::getInstance()->getValue('
             SELECT `id_address`
             FROM `' . _DB_PREFIX_ . 'address` a
             WHERE a.`deleted` = 0 AND a.`date_add` >= "2021-08-20" AND a.`alias` = "' . pSQL($alias) . '"' . $customer_filter);
    }

    protected static function resolveAddressLines($line1, $line2): array
    {
        $line1 = trim($line1);
        $line2 = trim($line2);

        if (!$line1 && $line2) {
            $line1 = $line2;
            $line2 = '';
        }
        if (!$line1) {
            $line1 = 'Unknown';
        }

        $line1 = preg_replace(self::INVALID_FILTER, '', $line1);
        $line2 = preg_replace(self::INVALID_FILTER, '', $line2);
        $line1 = preg_replace('/"/', "'", $line1);
        $line2 = preg_replace('/"/', "'", $line2);
        $line1 = trim($line1, ',');
        $line2 = trim($line2, ',');

        return ['line1' => $line1, 'line2' => $line2];
    }

    protected static function countryRequiresIdentificationNumber($idCountry): bool
    {
        return (bool) Db::getInstance()->getValue('
			SELECT c.`need_identification_number`
			FROM `' . _DB_PREFIX_ . 'country` c
			WHERE c.`id_country` = ' . (int) $idCountry);
    }
}
