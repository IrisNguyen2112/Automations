<?php
/**
 *  PsSyncRelationship
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes;

use Toole\Module\Amazon\Client\V2\Model\CatalogSync\Relation;

if (!defined('_PS_VERSION_')) {
    exit;
}

class PsSyncRelationship extends Relation
{
    public $isParent = false;
    public $parent;
    public $children = [];

    public static function createParentInstance(array $children): Relation
    {
        $instance = new static();
        $instance->setIsParent(true);
        $instance->setChildren(array_unique($children));

        return $instance;
    }

    public static function createChildInstance($parent): Relation
    {
        $instance = new static();
        $instance->setIsParent(false);
        $instance->setParent($parent);

        return $instance;
    }
}
