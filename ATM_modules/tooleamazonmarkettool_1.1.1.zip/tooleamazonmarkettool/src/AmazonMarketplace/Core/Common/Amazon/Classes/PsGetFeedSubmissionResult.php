<?php
/**
 * PsGetFeedSubmissionResult
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes;

use Configuration;
use Db;
use DbQuery;
use Exception;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\SubscriptionManager\Service\Api\v2\ServiceAPIHelper;
use TooleAmazonMarketAmazonFeed;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * todo: Should we move to a proper place?
 */
class PsGetFeedSubmissionResult
{
    public static function getFeedSubmissionResult(): array
    {
        // Get Feeds
        $sql = new DbQuery();
        $sql->from(Database::TABLE_FEEDS, 'f');
        $sql->select('f.`feed_id`');
        $sql->where('f.`status`=' . TooleAmazonMarketAmazonFeed::SENT_STATUS);
        $feeds = Db::getInstance()->executeS($sql);
        $feedSubmissionResult = [];
        if (!empty($feeds)) {
            $feedsIds = array_column($feeds, 'feed_id');
            /* @var ServiceAPIHelper $api_helper */
            if (!$apiHelper = SaaSConnector::initHelperWithoutConnector()) {
                return ['status' => false, 'message' => 'Problem'];
            }

            try {
                $feedResult = $apiHelper->getFeedSubmissionResult(Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID),
                    Configuration::get(Key::CONFIG_PRESTASHOP_STOREID), $feedsIds);
                if ($feedSubmissionResult = $feedResult->getFeedResult()) {
                    foreach ($feedSubmissionResult as $feedItem) {
                        TooleAmazonMarketAmazonFeed::updateResult($feedItem);
                    }
                }
            } catch (Exception $e) {
                return ['status' => false, 'message' => $e->getMessage()];
            }
        }
        return ['status' => true, 'message' => sprintf('Total %d feeds updated.', count($feedSubmissionResult))];
    }
}
