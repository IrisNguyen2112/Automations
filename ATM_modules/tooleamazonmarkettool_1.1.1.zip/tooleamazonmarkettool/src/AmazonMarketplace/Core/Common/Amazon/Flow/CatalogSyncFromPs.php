<?php
/**
 * CatalogSyncFromPs
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Configuration;
use Context;
use Currency;
use Exception;
use PrestaShopException;
use Toole\Module\Amazon\Client\V2\Model\CatalogSync\CatalogSyncResponse;
use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Product;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\ConfigurationLoad;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;
use TooleAmazonMarketAmazonFeed;
use TooleAmazonMarketTool;
use Tools;

if (!defined('_PS_VERSION_')) {
    exit;
}

class CatalogSyncFromPs
{
    /** @var ServiceAPIV3Helper */
    protected $saasHelper;
    protected $identifiers = [];
    protected $marketplaceId;
    /** @var Context */
    protected $context;
    /** @var TooleAmazonMarketTool */
    protected $module;
    private $cronMode;
    private $errors = [];
    private $warnings = [];
    private $confirmations = [];
    private $currencyCode;

    public function __construct(ServiceAPIV3Helper $saasHelper, $identifiers, $marketplaceId, $context, $module, $cronMode = false)
    {
        $this->saasHelper = $saasHelper;
        $this->identifiers = $identifiers;
        $this->marketplaceId = $marketplaceId;
        $this->context = $context;
        $this->module = $module;
        $this->cronMode = $cronMode;
        $this->currencyCode = $this->getCurrencyCode();
        if (!Region::searchRegionByMkp($marketplaceId)) {
            throw new Exception(sprintf($this->context->getTranslator()->trans('Unknown marketplace %s', [], 'Modules.Amazonmarkettool.Admin'), $marketplaceId));
        }
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public function getWarnings(): array
    {
        return $this->warnings;
    }

    public function getConfirmations(): array
    {
        return $this->confirmations;
    }

    /**
     * @throws PrestaShopException
     */
    public function doExport(): void
    {
        // Validate currency
        $hasCurrency = Currency::getIdByIsoCode($this->currencyCode, $this->context->shop->id);
        if (!$hasCurrency) {
            if ($this->cronMode) {
                $msg = 'Not found currency (%s).';
            } else {
                $msg = $this->context->getTranslator()->trans('Not found currency (%s).', [], 'Modules.Tooleamazonmarkettool.Admin');
            }
            $this->errors[] = sprintf($msg, $this->currencyCode);
            return;
        }

        $productData = [];
        $shippingTemplates = (new ConfigurationLoad($this->module))->getShippingTemplates();
        foreach ($this->identifiers as $identifier) {
            try {
                $syncProduct = Product::getProductDataForFeeds(
                    $identifier['id_product'], $identifier['id_product_attribute'],
                    $shippingTemplates, Tools::strtolower(Configuration::get('PS_WEIGHT_UNIT')),
                    $this->context, true, $this->currencyCode
                );
                if ($syncProduct) {
                    $productData[] = $syncProduct;
                }
            } catch (Exception $e) {
                if ($this->cronMode) {
                    $msg = 'Unable to export product %s [%s] with reason [%s]';
                } else {
                    $msg = $this->context->getTranslator()->trans('Unable to export product %s [%s] with reason [%s]', [], 'Modules.Amazonmarkettool.Admin');
                }
                $this->errors[] = sprintf(
                    $msg,
                    $identifier['id_product'],
                    $identifier['id_product_attribute'],
                    $e->getMessage()
                );
            }
        }

        if (!$productData) {
            if ($this->cronMode) {
                $this->warnings[] = 'Nothing to export';
            } else {
                $this->warnings[] = $this->context->getTranslator()->trans('Nothing to export', [], 'Modules.Amazonmarkettool.Admin');
            }
            return;
        }

        try {
            $apiResult = $this->saasHelper->catalogSync($this->marketplaceId, $productData);
        } catch (Exception $exception) {
            $this->errors[] = $this->cronMode ? 'Errors while exporting selected products'
                : $this->context->getTranslator()->trans('Errors while exporting selected products', [], 'Modules.Amazonmarkettool.Admin');
            $this->errors[] = $exception->getMessage();
            return;
        }

        /** @var CatalogSyncResponse $response */
        $response = $apiResult->getAmazonData();
        $totalItemExported = $response->getTotalItems() ?? 0;
        $totalFeeds = $response->getTotalFeeds() ?? 0;
        $feeds = $response->getFeeds() ?? [];
        if ($totalItemExported < 1 || $totalFeeds < 1 || !count($feeds)) {
            if ($this->cronMode) {
                $this->warnings[] = 'Export done but no items have been processed';
            } else {
                $this->warnings[] = $this->context->getTranslator()->trans('Export done but no items have been processed', [], 'Modules.Amazonmarkettool.Admin');
            }
            return;
        }

        foreach ($feeds as $feed) {
            $idFeed = TooleAmazonMarketAmazonFeed::saveRecord([
                'marketplace_id' => $this->marketplaceId,
                'feed_type' => $feed->getFeedType(),
                'feed_id' => $feed->getFeedId(),
                'status' => TooleAmazonMarketAmazonFeed::SENT_STATUS,
                'content_location' => $feed->getContentLocation(),
            ]);
            $this->module->log->message(sprintf(
                'Sent Feed (%s) - (%s) successfully.',
                $feed->getFeedId(),
                $feed->getFeedType()
            ), $idFeed);
        }

        $this->confirmations[] = sprintf(
            $this->context->getTranslator()->trans('Products synced finished. Sent %d item(s), received %d feed(s)', [], 'Modules.Amazonmarkettool.Admin'),
            $totalItemExported, $totalFeeds
        );
    }

    private function getCurrencyCode()
    {
        $amzAuthCombo = AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO);
        $defaultCurrency = AmazonMarketConfiguration::availableAmazonCurrencies()[AmazonConstant::MKP_FR];
        if ($amzAuthCombo) {
            foreach ($amzAuthCombo as $regionData) {
                if (!empty($regionData['marketplaces'])) {
                    foreach ($regionData['marketplaces'] as $mkpId => $marketplace) {
                        if ($mkpId == $this->marketplaceId && !empty($marketplace['currency'])) {
                            $currencyCode = $marketplace['currency'];
                        }
                    }
                }
            }
        }

        return $currencyCode ?? $defaultCurrency;
    }
}
