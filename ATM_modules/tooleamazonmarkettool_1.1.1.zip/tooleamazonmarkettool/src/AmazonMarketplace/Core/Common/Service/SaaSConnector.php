<?php
/**
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Service;

use Configuration;
use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Connector;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceApiFactory;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIHelper;

if (!defined('_PS_VERSION_')) {
    exit;
}

class SaaSConnector
{
    const VERSION = ServiceApiFactory::V3;

    public static function initHelperWithoutConnector($renew = false): ServiceAPIHelper
    {
        return ServiceApiFactory::getApiHelperWithoutConnector(
            self::VERSION,
            Configuration::getGlobalValue(Key::SERVICE_API_URL),
            Configuration::getGlobalValue(Key::SERVICE_API_KEY),
            false,
            $renew
        );
    }

    public static function initHelperWithConnector($connectorInRegion = AmazonConstant::MKP_REGION_EU, $connectorInMarketplaces = [], $renew = false): ServiceAPIHelper
    {
        return ServiceApiFactory::getApiHelperWithConnector(
            self::VERSION,
            Configuration::getGlobalValue(Key::SERVICE_API_URL),
            Configuration::getGlobalValue(Key::SERVICE_API_KEY),
            false,
            self::initAmazonConnector($connectorInRegion, $connectorInMarketplaces),
            $renew
        );
    }

    protected static function initAmazonConnector($connectorInRegion = AmazonConstant::MKP_REGION_EU, $connectorInMarketplaces = []): Connector
    {
        $amzAuthCombo = AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO);

        $marketplaces = [];
        if (!empty($connectorInMarketplaces) && !empty($amzAuthCombo)) {
            foreach ($connectorInMarketplaces as $connectorInMarketplace) {
                if (isset($amzAuthCombo[$connectorInRegion]['marketplaces'][$connectorInMarketplace])) {
                    $marketplaces[$connectorInMarketplace] = $amzAuthCombo[$connectorInRegion]['marketplaces'][$connectorInMarketplace];
                }
            }
        } else {
            $marketplaces = $amzAuthCombo[$connectorInRegion]['marketplaces'] ?? [];
        }

        $availableMarketplaces = [];
        foreach ($marketplaces as $key => $marketplace) {
            if ($marketplace['isParticipating'] && $marketplace['isEnable']) {
                $availableMarketplaces[] = $key;
            }
        }

        $connector = new Connector(
            AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO) ?: [],
            $availableMarketplaces,
            $connectorInRegion
        );

        $connector->setBillingInfo(
            Configuration::getGlobalValue(Key::SERVICE_API_KEY),
            Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
            Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID)
        );

        return $connector;
    }
}
