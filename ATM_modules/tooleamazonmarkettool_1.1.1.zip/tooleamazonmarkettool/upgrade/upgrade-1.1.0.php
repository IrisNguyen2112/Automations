<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param TooleAmazonMarketTool $module
 *
 * @return bool
 */
function upgrade_module_1_1_0($module)
{
    $result = true;
    $shop_id = Context::getContext()->shop->id;
    $shop_id_group = Context::getContext()->shop->id_shop_group;

    $orders = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '`');
    if (!in_array('id_shop_group', array_column($orders, 'Field')) && !in_array('id_shop', array_column($orders, 'Field'))) {
        $ordersSql = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '`
                ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id_order`,
                ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id_order`';
        $result &= (bool) Db::getInstance()->execute($ordersSql);
        if ($result) {
            Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
        }
    }

    $products = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '`');
    if (!in_array('id_shop_group', array_column($products, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id`');
    }
    if (in_array('id_shop', array_column($products, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` DROP COLUMN `id_shop`');
    }
    $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id`');
    if ($result) {
        Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
    }

    $feeds = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FEEDS . '`');
    if (!in_array('id_shop_group', array_column($feeds, 'Field')) && !in_array('id_shop', array_column($feeds, 'Field'))) {
        $feedsSql = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FEEDS . '`
                ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id`,
                ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id`';
        $result &= (bool) Db::getInstance()->execute($feedsSql);
        if ($result) {
            Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_FEEDS . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
        }
    }

    $filterCategories = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '`');
    if (!in_array('id_shop_group', array_column($filterCategories, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id_sync_category`');
    }
    if (in_array('id_shop', array_column($filterCategories, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` DROP COLUMN `id_shop`');
    }
    $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id_sync_category`');
    if ($result) {
        Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
    }

    $filterManufacturers = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '`');
    if (!in_array('id_shop_group', array_column($filterManufacturers, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id_sync_manufacturer`');
    }
    if (in_array('id_shop', array_column($filterManufacturers, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` DROP COLUMN `id_shop`');
    }
    $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id_sync_manufacturer`');
    if ($result) {
        Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
    }

    $filterProducts = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '`');
    if (!in_array('id_shop_group', array_column($filterProducts, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id_sync_product`');
    }
    if (in_array('id_shop', array_column($filterProducts, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` DROP COLUMN `id_shop`');
    }
    $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id_sync_product`');
    if ($result) {
        Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
    }

    $filterSuppliers = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '`');
    if (!in_array('id_shop_group', array_column($filterSuppliers, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id_sync_supplier`');
    }
    if (in_array('id_shop', array_column($filterSuppliers, 'Field'))) {
        $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` DROP COLUMN `id_shop`');
    }
    $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id_sync_supplier`');
    if ($result) {
        Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
    }

    $logs = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_LOGS . '`');
    if (!in_array('id_shop_group', array_column($logs, 'Field')) && !in_array('id_shop', array_column($logs, 'Field'))) {
        $logsSql = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_LOGS . '`
                ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id`,
                ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id`';
        $result &= (bool) Db::getInstance()->execute($logsSql);
        if ($result) {
            Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_LOGS . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
        }
    }

    $logDetails = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '`');
    if (!in_array('id_shop_group', array_column($logDetails, 'Field')) && !in_array('id_shop', array_column($logDetails, 'Field'))) {
        $logDetailsSql = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '`
                ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id`,
                ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id`';
        $result &= (bool) Db::getInstance()->execute($logDetailsSql);
        if ($result) {
            Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
        }
    }

    $messages = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_MESSAGES . '`');
    if (!in_array('id_shop_group', array_column($messages, 'Field')) && !in_array('id_shop', array_column($messages, 'Field'))) {
        $messagesSql = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_MESSAGES . '`
                ADD COLUMN `id_shop_group` int(11) unsigned DEFAULT NULL AFTER `id_message`,
                ADD COLUMN `id_shop` int(11) unsigned DEFAULT NULL AFTER `id_message`';
        $result &= (bool) Db::getInstance()->execute($messagesSql);
        if ($result) {
            Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_MESSAGES . '` SET `id_shop` = ' . $shop_id . ', `id_shop_group` = ' . $shop_id_group);
        }
    }

    // register hook: displayAdminOrder
    $isHookable = Db::getInstance()->executeS('SELECT `a`.* FROM `' . _DB_PREFIX_ . 'hook_module` a LEFT JOIN `' . _DB_PREFIX_ . 'hook` h ON `h`.`id_hook` = `a`.`id_hook` WHERE `h`.`name` = "displayAdminOrder" AND `a`.`id_module` = ' . $module->id);
    if (!$isHookable) {
        $result &= $module->registerHook('displayAdminOrder');
    }

    return $result;
}
