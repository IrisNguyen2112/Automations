<?php
/**
 *  * TooleAmazonMarkettool
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use PrestaShop\ModuleLibServiceContainer\DependencyInjection\ServiceContainer;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
use Symfony\Component\HttpFoundation\Response;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\AmazonAuth\AmazonAuth;
use Toole\Module\AmazonMarketplace\Core\Common\AmazonAuth\AmazonAuthCredentials;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\ConfigurationLoad;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\ConfigurationSave;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Install;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Uninstall;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Log\Log;
use Toole\Module\SubscriptionManager\Service\Api\ServiceApiHelper;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\CreateStoreVersionsResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\CreateSubscriptionResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\GetSubscriptionResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\InstallModuleResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\ValidateSubscriptionResponse;
use Toole\Module\SubscriptionManager\Service\Api\v3\Response\UninstallModuleResponse;
use Toole\Module\Utils\Utils;

if (!defined('_PS_VERSION_')) {
    exit;
}

$autoloadPath = __DIR__ . '/vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
}

class TooleAmazonMarketTool extends Module implements WidgetInterface
{
    const HOOKS = [
        'actionAdminControllerSetMedia',
        'actionFrontControllerSetMedia',
        'displayAdminOrder',
        'displayDashboardToolbarTopMenu',
        'displayAdminListBefore',
    ];

    public static $ymlConfigPath;

    /**
     * @var ServiceContainer
     */
    private $container;

    /** @var string */
    private $html = '';

    /** @var Log */
    public $log;

    public $author_address;
    public $support_email;
    public $help_center_url;
    public $external_assets_base_url;
    public $order_import_optional_columns;
    private $regionForbiddenToGetMarketplaces = [];

    public function __construct()
    {
        $this->name = 'tooleamazonmarkettool';
        $this->tab = 'market_place';
        $this->version = '1.1.1';
        $this->author = 'Inter-Soft';
        $this->is_eu_compatible = 1;
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->tabClassName = 'AdminAmazonMarketplace';
        $this->external_assets_base_url = Configuration::getGlobalValue(Key::SERVICE_API_URL) . '/getAssetLink/' . $this->name . '/' . $this->version;

        parent::__construct();

        $this->controllers = [
            'TooleAmazonMarketplaceFront',
        ];

        $this->displayName = $this->trans(
            'ToolE - Amazon Market Tool',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );
        $this->description = $this->trans(
            'AMT is the most reliable tool to succeed on Amazon designed exclusively for Prestashop by experienced Amazon sellers.',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );
        $this->ps_versions_compliancy = ['min' => '1.7.4', 'max' => _PS_VERSION_];
        $this->confirmUninstall = $this->trans(
            'Are you sure to uninstall this module?',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );
        $this->secure_key = Tools::encrypt($this->name);
        $this->module_key = 'feb8213d46ffcc6165647bc46728424c';
        $this->author_address = Utils::config(dirname(__FILE__), 'module:author_address');
        $this->support_email = Utils::config(dirname(__FILE__), 'module:support_email');
        $this->help_center_url = Utils::config(dirname(__FILE__), 'module:help_center_url');
        $this->order_import_optional_columns = [
            'latest_ship_date' => [
                'title' => $this->trans(
                    'Latest Shipping Date',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 100,
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'date',
                'align' => 'center',
            ],
            'latest_delivery_date' => [
                'title' => $this->trans(
                    'Latest Delivery Date',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 100,
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'date',
                'align' => 'center',
            ],
            'is_premium' => [
                'title' => $this->trans(
                    'Premium Order',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'type' => 'bool',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'is_business' => [
                'title' => $this->trans(
                    'Business Order',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'type' => 'bool',
                'orderby' => false,
                'search' => true,
                'align' => 'center',
            ],
            'is_access_point' => [
                'title' => $this->trans(
                    'Access Point',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 100,
                'class' => 'fixed-width-100',
                'orderby' => false,
                'search' => true,
                'type' => 'bool',
                'align' => 'center',
            ],
        ];

        if ($this->container === null) {
            $this->container = new \PrestaShop\ModuleLibServiceContainer\DependencyInjection\ServiceContainer(
                $this->name,
                $this->getLocalPath()
            );
        }

        self::$ymlConfigPath = _PS_MODULE_DIR_ . $this->name;

        $this->log = new Log();
    }

    public function getContext()
    {
        return $this->context;
    }

    public function customConf()
    {
        return [
            1 => $this->trans('Settings updated', [], 'Modules.Tooleamazonmarkettool.Admin'),
        ];
    }

    public function getContextLink()
    {
        return $this->context->link;
    }

    public function install(): bool
    {
        if (false === (new Install($this))->run()) {
            return false;
        }

        $return = parent::install()
            && $this->getService('tooleamazonmarkettool.ps_accounts.installer')->install()
            && $this->registerHook(static::HOOKS);

        if ($return
            && !Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SANDBOX')
            && $api_helper = SaaSConnector::initHelperWithoutConnector()) {
            /* @var InstallModuleResponse $install_response */
            $api_helper->installModuleEventV3(
                $this->displayName,
                $this->version,
                $_SERVER['HTTP_HOST'],
                Configuration::get('PS_SHOP_EMAIL')
            );
        }
        return $return;
    }

    public function uninstall(): bool
    {
        $return = (new Uninstall($this))->run()
            && parent::uninstall();

        if ($return
            && !Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SANDBOX')
            && $api_helper = SaaSConnector::initHelperWithoutConnector()) {
            /* @var UninstallModuleResponse $install_response */
            $api_helper->uninstallModuleEventV3(
                $this->displayName,
                $this->version,
                $_SERVER['HTTP_HOST'],
                Configuration::get('PS_SHOP_EMAIL')
            );
        }

        return $return;
    }

    public function renderWidget($hookName = null, array $configuration = []): string
    {
        if ($hookName === 'displayAdminListBefore' && $this->context->controller->controller_name !== 'ToolEAmazonMarketOrderImported') {
            return '';
        }

        if ($hookName == null && isset($configuration['hook'])) {
            $hookName = $configuration['hook'];
        }
        $template = 'views/templates/hook/' . $hookName . '.tpl';

        isset($configuration['cache_id']) ? $cache_id = $configuration['cache_id'] : $cache_id = null;
        $variables = $this->getWidgetVariables($hookName, $configuration);
        if (isset($variables['cache_id'])) {
            $cache_id = $variables['cache_id'];
        }

        if (!$this->isCached($template, $this->getCacheId($hookName))) {
            $this->smarty->assign($variables);
        }

        return $this->fetch($this->getLocalPath() . $template, $cache_id);
    }

    public function getWidgetVariables($hookName = null, array $configuration = [])
    {
        if (in_array($hookName, ['displayDashboardToolbarTopMenu'])) {
            if (strpos($this->context->controller->controller_name, 'ToolEAmazonMarket') !== false) {
                $configuration['help_center_url'] = $this->getHelperLink();
            }

            if (in_array($this->context->controller->controller_name, ['ToolEAmazonMarketLogsSummary', 'ToolEAmazonMarketFeed', 'ToolEAmazonMarketFbaOrderListing'])) {
                unset($configuration['enable_marketplaces'], $configuration['enable_regions']);
            }
        }

        if ('displayAdminOrder' == $hookName) {
            $amzOrder = TooleAmazonMarketAmazonOrder::getOrderByPsOrderId($configuration['id_order']);
            $configuration['shop_logo'] = $this->getTooleLogo();
            $configuration['amz_order'] = $amzOrder;
            $configuration['is_fulfillable'] = !empty($amzOrder) && TooleAmazonMarketAmazonOrder::isFulfillableGlobal($amzOrder['mp_status'], $amzOrder['current_state']);
            $configuration['fulfill_link'] = $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported', true) . '&action=fulfillment';
        }

        if ('displayAdminListBefore' == $hookName) {
            $currentOptionalColumns = json_decode(Configuration::get(OrderKey::CONFIG_IMPORTED_ORDERS_OPTIONAL_COLUMNS, null, null, null, '')) ?? [];
            $configuration['optionalColumns'] = $currentOptionalColumns;
            $configuration['optionalColumnsOptions'] = $this->order_import_optional_columns;
            $configuration['saveOptionalColumnsLink'] = $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported') . '&action=saveOptionalColumns';
        }

        return $configuration;
    }

    public function getContent()
    {
        $active_tab = $this->getActiveTab();
        $configurationSave = new ConfigurationSave($this, $this->context);

        if (Tools::isSubmit('submitAdvanced')) {
            $configurationSave->processSubmitAdvancedConfiguration();
            $this->html .= $this->displayConfirmation(
                $this->trans('Settings updated', [], 'Modules.Tooleamazonmarkettool.Admin')
            );
        }

        $billingService = $this->getService('tooleamazonmarkettool.ps_billings.service');
        $billingServiceContext = $this->getService('tooleamazonmarkettool.ps_billings.context_wrapper');

        $plan_id = false;
        // Retrieve the subscritpion for this module
        $subscription = $billingService->getCurrentSubscription();
        if ($subscription['success'] == false) {
            $status = 'inactive';
        } else {
            $status = $subscription['body']['status'];
        }
        /* @var ServiceApiHelper $api_helper */
        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new Exception('Problem');
        }

        if ($subscription['success']) {
            $plan_id = $subscription['body']['plan_id'];

            if ($status != 'inactive') {
                if (!Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID)) {
                    /* @var GetSubscriptionResponse $get_subscription_response */
                    try {
                        $get_subscription_response = $api_helper->getSubscription($subscription['body']['id']);
                        if ($get_subscription_response->getIsValid()) {
                            Configuration::updateValue(
                                Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID,
                                $get_subscription_response->getSubscriptionId()
                            );
                            Configuration::updateValue(
                                Key::CONFIG_PRESTASHOP_PLANID,
                                $get_subscription_response->getPlanId()
                            );
                            Configuration::updateValue(
                                Key::CONFIG_PRESTASHOP_STOREID,
                                $get_subscription_response->getStoreId()
                            );
                        } else {
                            throw new Exception('No subscription found.');
                        }
                    } catch (Exception $e) {
                        // need to wait until the subscription is updated on the server
                        $this->html .= $this->displayError(
                            $this->trans('No subscription information available', [], 'Modules.Tooleamazonmarkettool.Admin')
                        );
                        $customer = $billingService->getCurrentCustomer();
                        /* @var CreateSubscriptionResponse $create_response */
                        $create_response = $api_helper->createSubscription(
                            $subscription['body']['id'],
                            $customer['body']['cf_shop_id'],
                            isset($subscription['body']['plan_id']) ? $subscription['body']['plan_id'] : '',
                            isset($subscription['body']['customer_id']) ? $subscription['body']['customer_id'] : '',
                            isset($subscription['body']['created_at']) ? $subscription['body']['created_at'] : '',
                            isset($subscription['body']['activated_at']) ? $subscription['body']['activated_at'] : '',
                            isset($subscription['body']['started_at']) ? $subscription['body']['started_at'] : '',
                            isset($subscription['body']['next_billing_at']) ? $subscription['body']['next_billing_at'] : '',
                            isset($subscription['body']['trial_end']) ? $subscription['body']['trial_end'] : '',
                            isset($subscription['body']['updated_at']) ? $subscription['body']['updated_at'] : '',
                            $this->name,
                            'unconfirmed'
                        );
                        if ($create_response && !$create_response->getIsValid()) {
                            $this->html .= $this->displayError(
                                $this->trans('Fatal error creating subscription details.', [], 'Modules.Tooleamazonmarkettool.Admin')
                            );
                        }
                    }
                }

                if (!Configuration::get(
                    Key::CONFIG_PRESTASHOP_STOREID
                )) {
                    $this->html .= $this->displayError(
                        $this->trans('Processing subscription', [], 'Modules.Tooleamazonmarkettool.Admin')
                    );
                }
            }
        }

        $amazonRefreshToken = Tools::getValue('refresh_token');
        if ((Tools::isSubmit('submitConfiguration') || Tools::isSubmit('toole_amazon_authorization') || $amazonRefreshToken) && !Tools::isSubmit('submitAdvanced')) {
            try {
                /* @var ValidateSubscriptionResponse $validate_response */
                $validate_response = $api_helper->validateSubscription(
                    Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID),
                    Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                    Configuration::get(Key::CONFIG_PRESTASHOP_PLANID)
                );
            } catch (Exception $e) {
                $this->html .= $this->displayError(
                    $this->trans('Unable to connect to subscription validation server, please contact support', [], 'Modules.Tooleamazonmarkettool.Admin')
                );
                return $this->html;
            }
            if ($validate_response && $validate_response->getIsValid()) {
                $returned = true;
                if (Tools::isSubmit('submitConfiguration')) {
                    $returned = $configurationSave->processSubmitConfiguration();
                }
                $amzAuth = $this->amazonAuthorization();
                if ($amzAuth && $amzAuth->region) {
                    $active_tab = $amzAuth->region;
                }

                if ($returned === ConfigurationSave::ERROR_CREATE) {
                    $this->html .= $this->displayError(
                        $this->trans('Unable to create store configuration', [], 'Modules.Tooleamazonmarkettool.Admin')
                    );
                } elseif ($returned === ConfigurationSave::ERROR_UPDATE) {
                    $this->html .= $this->displayError(
                        $this->trans('Unable to update store configuration', [], 'Modules.Tooleamazonmarkettool.Admin')
                    );
                } elseif ($returned === ConfigurationSave::SUCCESS || $returned === true) {
                    /* @var CreateStoreVersionsResponse $create_store_configuration_response */
                    $create_store_configuration_response = $api_helper->createStoreVersions(
                        Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID),
                        Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                        _PS_VERSION_,
                        $this->name,
                        $this->version,
                        phpversion(),
                        Db::getInstance()->getLink()->getAttribute(PDO::ATTR_DRIVER_NAME),
                        Db::getInstance()->getVersion()
                    );
                    if (!$create_store_configuration_response) {
                        throw new Exception($this->trans('Unable to save store configuration', [], 'Modules.Tooleamazonmarkettool.Admin'));
                    }
                    $this->html .= $this->displayConfirmation(
                        $this->trans('Settings updated', [], 'Modules.Tooleamazonmarkettool.Admin')
                    );

                    // Only redirect if no error
                    if (!($this->error ?? false)) {
                        $this->context->cookie->__set('custom_conf', 1);
                        $this->context->cookie->__set('active_tab', $active_tab);
                        $this->context->cookie->write();
                        Tools::redirect($this->context->link->getAdminLink(
                            'AdminModules',
                            true,
                            [],
                            ['configure' => $this->name, 'tab_module' => $this->tab, 'module_name' => $this->name]
                        ));
                    }
                } else {
                    $this->html .= $this->displayError(
                        $this->trans('Unable to save configuration', [], 'Modules.Tooleamazonmarkettool.Admin')
                    );
                }
            } else {
                if ($validate_response && !$validate_response->getIsValid()) {
                    $this->html .= $this->displayError(
                        $validate_response->getMessage()
                    );
                }
                $this->html .= $this->displayError(
                    $this->trans('Unable to save configuration', [], 'Modules.Tooleamazonmarkettool.Admin')
                );
            }
        }

        $accountsInstaller = $this->getService('tooleamazonmarkettool.ps_accounts.installer');
        $accountsInstaller->install();

        try {
            $accountsFacade = $this->getService('tooleamazonmarkettool.ps_accounts.facade');
            $accountsService = $accountsFacade->getPsAccountsService();
            Media::addJsDef([
                'contextPsAccounts' => $accountsFacade->getPsAccountsPresenter()
                    ->present($this->name),
            ]);

            // Retrieve Account CDN
            $this->context->smarty->assign('urlAccountsVueCdn', $accountsService->getAccountsVueCdn());

            $billingFacade = $this->getService('tooleamazonmarkettool.ps_billings.facade');

            // Billing
            Media::addJsDef($billingFacade->present([
                'logo' => $this->getLocalPath() . 'views/img/partnerLogo.png',
                'tosLink' => $this->getTosLink($this->context->language->iso_code),
                'privacyLink' => $this->getPrivacyLink($this->context->language->iso_code),
                'emailSupport' => $this->support_email,
            ]));
            Media::addJsDef([
                'configModule' => json_encode(Utils::config(dirname(__FILE__), 'module')),
                'moduleVersion' => $this->version,
                'toole_moduleconfiguration_url' => $this->context->link->getAdminLink('AdminModules', true)
                    . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name,
                'subscription_status' => $status,
            ]);

            $cssLink = $this->getMediaLink('/public/css/configuration.css');
            $this->context->controller->addCSS($cssLink);

            if (isset($this->customConf()[$this->context->cookie->__get('custom_conf')])) {
                $this->html .= $this->displayConfirmation(
                    $this->customConf()[$this->context->cookie->__get('custom_conf')]
                );
            }

            $this->html .= $this->context->smarty->assign([
                'configModule' => json_encode(Utils::config(dirname(__FILE__), 'module')),
                'loadingText' => $this->trans('Please wait, loading account details', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'pathVendor' => sprintf('%sviews/app/js/vendor.%s.js', $this->getPathUri(), $this->version),
                'pathApp' => sprintf('%sviews/app/js/index.%s.js', $this->getPathUri(), $this->version),
                'status' => $status,
                'subscriptionId' => Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                ),
                'isPsSandbox' => $billingServiceContext->isSandbox(),
                'storeId' => Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                'subscriptionStatus' => strtoupper($status),
                'isLinked' => $accountsService->isAccountLinked(),
                'isSubscribed' => ($status == 'inactive') ? 0 : 1,
                'urlAccountsCdn' => $accountsService->getAccountsCdn(),
                'urlBilling' => 'https://unpkg.com/@prestashopcorp/billing-cdc/dist/bundle.js',
                'prestashopVersion' => _PS_VERSION_,
                'moduleName' => $this->displayName,
                'moduleVersion' => $this->version,
                'phpVersion' => phpversion(),
                'databaseType' => Db::getInstance()->getLink()->getAttribute(PDO::ATTR_DRIVER_NAME),
                'databaseVersion' => Db::getInstance()->getVersion(),
                'active_tab' => $active_tab,
                'regionForbiddenToGetMarketplaces' => $this->regionForbiddenToGetMarketplaces,
            ])
                ->assign($this->getConfigurationFormVars())
                ->fetch($this->getLocalPath() . 'views/templates/admin/configuration.tpl');

            // clear cookies
            $this->context->cookie->__unset('custom_conf');
            $this->context->cookie->__unset('active_tab');

            return $this->html;
        } catch (Exception $e) {
            $this->context->controller->errors[] = $e->getMessage();
            return '';
        }
    }

    public function hookActionAdminControllerSetMedia($params)
    {
        if (Module::isEnabled($this->name)) {
            if ($this->context->controller->controller_name == 'AdminModules' && Tools::getValue('configure') == $this->name) {
                $jsLink = $this->getMediaLink('/public/js/configuration.js?v=' . $this->version);
                $this->context->controller->addJS($jsLink);
            } elseif ($this->context->controller->controller_name == 'ToolEAmazonMarketOrderImported') {
                $jsLink = $this->getMediaLink('/views/js/order/imported_order.js?v=' . $this->version);
                $this->context->controller->addJS($jsLink);
            } elseif ($this->context->controller->controller_name == 'AdminOrders') {
                $jsLink = $this->getMediaLink('/views/js/order/order_detail.js?v=' . $this->version);
                $this->context->controller->addJS($jsLink);
            }
        }
    }

    /**
     * Indicate that module is using new translation system
     */
    public function isUsingNewTranslationSystem()
    {
        return true;
    }

    /**
     * Get the Tos URL from the context language, if null, send default link value
     *
     * @return string
     */
    public function getTosLink($iso_lang)
    {
        switch ($iso_lang) {
            case 'fr':
                $url = 'https://toolecommerce.com/toole-tools-for-ecommerc/termsofservice-eng/';
                break;
            default:
                $url = 'https://toolecommerce.com/toole-tools-for-ecommerc/termsofservice-eng/';
                break;
        }

        return $url;
    }

    /**
     * Get the Tos URL from the context language, if null, send default link value
     *
     * @return string
     */
    public function getPrivacyLink($iso_lang)
    {
        switch ($iso_lang) {
            case 'fr':
                $url = 'https://toolecommerce.com/fr/privacy-policy-fr/';
                break;
            default:
                $url = 'https://toolecommerce.com/toole-tools-for-ecommerc/privacypolicy/';
                break;
        }

        return $url;
    }

    public function getHelperLink()
    {
        switch ($this->context->controller->controller_name) {
            case 'ToolEAmazonMarketCatalogFiltersCategories':
            case 'ToolEAmazonMarketCatalogFiltersManufacturers':
            case 'ToolEAmazonMarketCatalogFiltersSuppliers':
            case 'ToolEAmazonMarketCatalogFiltersProducts':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12935421768594-AMT-Filters-Tab-Streamlining-Your-Catalog';
                break;
            case 'ToolEAmazonMarketProductsImportedFromAmazon':
            case 'ToolEAmazonMarketProductSyncFromAmazon':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12935751954322-AMT-Amazon-Sync-Amazon-Prestashop-Seamlessly-Integrate-Your-Products';
                break;
            case 'ToolEAmazonMarketProductSyncFromPrestashop':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12935951276434-AMT-Prestashop-Sync-Prestashop-Amazon-Effortless-Integration-of-Your-Prestashop-Offers';
                break;
            case 'ToolEAmazonMarketLogsSummary':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12936004169746-AMT-Activity-Summaries-Comprehensive-Insights-at-Your-Fingertips';
                break;
            case 'ToolEAmazonMarketOrderImported':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12935188470034-Managing-your-Order-Importing-with-the-Amazon-Market-Tool-';
                break;
            case 'ToolEAmazonMarketOrderListing':
                $url = 'https://www.youtube.com/watch?v=9mQJBi7dZoI';
                break;
            case 'ToolEAmazonMarketFeed':
                $url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12936148275346-AMT-Feed-Tab-Comprehensive-Insights-into-Your-Feeds';
                break;
            default:
                $url = $this->help_center_url;
                break;
        }

        return $url;
    }

    public function getTooleLogo()
    {
        return 'https://toolecommerce.com/wp-content/uploads/2023/06/White-Logo.png';
    }

    public static function clearAllCached()
    {
        $module = Module::getInstanceByName('tooleamazonmarkettool');
        /*$module->clearCache('tab', 'homefeatured-tab', false);
        $module->clearCache('homefeatured', '', false);
        $module->clearCache('*', 'ps_featuredproducts', false);*/
    }

    protected function amazonAuthorization(): ?AmazonAuthCredentials
    {
        $amazonAuthCre = (new AmazonAuth($this, Context::getContext()))->amazonAuthorization();
        $this->log->setLog(sprintf('Amazon authorization: %s', $amazonAuthCre->region));
        if ($amazonAuthCre) {
            try {
                $amazonAuthCre->saveAmazonAuthCredentials();
                $connector = SaaSConnector::initHelperWithConnector($amazonAuthCre->region);
                $apiResult = $connector->getMarketplaceParticipations();
                $enableList = $connector->getAmazonConnector()->getAvailableMarketplaces();
                $enableList[] = $amazonAuthCre->marketplaceId;
                AmazonMarketConfiguration::saveAmzMarketplaces($apiResult->getAmazonData(), $enableList, $amazonAuthCre->region);
                Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_REGION, $amazonAuthCre->region);
                Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_MARKEPLACE, $amazonAuthCre->marketplaceId);
                $this->log->success(sprintf('Success: %s with region list enabled: %s', 'Authorize successfully', implode(', ', $enableList)));
            } catch (Exception $e) {
                if ($e->getCode() === Response::HTTP_FORBIDDEN) {
                    $this->regionForbiddenToGetMarketplaces[$amazonAuthCre->region] = true;
                }
                $this->html .= $this->displayError(
                    $this->trans(
                        'Error saving selected marketplace',
                        [],
                        'Modules.Tooleamazonmarkettool.Admin'
                    ) . ' [' . $e->getMessage() . ']'
                );
                $this->log->error(sprintf('Error: %s, details: %s', 'Error saving selected marketplace', $e->getMessage()));
            }
        }

        return $amazonAuthCre;
    }

    /**
     * Retrieve the service
     *
     * @param string $serviceName
     *
     * @return mixed
     */
    private function getService($serviceName)
    {
        return $this->container->getService($serviceName);
    }

    private function getConfigurationFormVars(): array
    {
        return (new ConfigurationLoad($this))->getTplVars();
    }

    private function getActiveTab(): string
    {
        if ($this->context->cookie->__get('active_tab')) {
            return $this->context->cookie->__get('active_tab');
        }

        if (Tools::getValue('active_tab')) {
            return Tools::getValue('active_tab');
        }

        return 'welcome';
    }

    public function getMediaLink(string $path): string
    {
        $link = _PS_MODULE_DIR_ . $this->name . $path;
        if (AmazonMarketConfiguration::get(Key::AMT_USE_EXTERNAL_ASSETS)) {
            $link = $this->external_assets_base_url . $path;
        }
        return $link;
    }
}
