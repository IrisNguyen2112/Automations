/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

$(document).ready(function () {
    // sync from prestashop
    $(document).on('click', '#table-product tr > td .btn-group a.btn-export', function (e) {
        const modalDialog = $('#toole-modal-dialog');

        window.location.href = $(this).data('href');
        modalDialog.fadeIn();
    });
});
