/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

$(document).ready(function () {
    const
        emptyState = $('#toole_empty_state'),
        refreshingState = $('#toole_refreshing_state'),
        msgZone = $('#toole-import-success'),
        errorZone = $('#toole-import-error'),
        warningZone = $('#toole-import-warning'),
        loader = $('#toole-import-loader'),
        lastReportState = $('#toole_last_report_request_state');

    $(document).on('click', '#toole_amazon_sync_refresh', function (e) {
        e.preventDefault();
        const url = $('#subtab-ToolEAmazonMarketProductSyncFromAmazon').attr('href');
        msgZone.empty();
        warningZone.empty();
        errorZone.empty();
        lastReportState.empty().hide();
        $('#toole_amazon_show_offers').parent().hide();
        doRequest(url, {
            ajax: 1,
            action: 'fetchData',
        }, () => {
            emptyState.hide();
            refreshingState.show();
            msgZone.hide();
            errorZone.hide();
            warningZone.hide();
        });
    });

    function doRequest(url, data, beforeSend) {
        $.ajax({
            url: url,
            type: 'POST',
            dataType: 'json',
            data: data,
            beforeSend: function () {
                loader.show();
                if (typeof beforeSend === 'function') {
                    beforeSend();
                }
            },
            complete: function () {
                loader.hide();
            },
            error: function (xhr, ajaxOptions, thrownError) {
                errorZone.append('An unexpected error occurred!' + '<br />')
                errorZone.show();
            },
            success: function (resp) {
                if (resp.hasOwnProperty('hasError') && resp.hasError) {
                    $.each(resp.errors, function (e, error) {
                        errorZone.append(error + '<br />');
                    });
                    errorZone.show();
                }
                if (resp.hasOwnProperty('hasWarning') && resp.hasWarning) {
                    $.each(resp.warnings, function (e, warning) {
                        warningZone.append(warning + '<br />');
                    });
                    warningZone.show();
                }
                if (resp.hasOwnProperty('hasMessage') && resp.hasMessage) {
                    $.each(resp.messages, function (m, msg) {
                        msgZone.append(msg + '<br />');
                    });
                    msgZone.show();
                }

                if (resp.isContinuous && resp.continue && resp.data.uuid) {
                    const nextData = Object.assign({}, data, resp.data);
                    setTimeout(function () {
                        doRequest(url, nextData, data);
                    }, 500)
                } else {
                    refreshingState.hide();
                    if (!resp.hasError && resp.data.statistics && resp.data.statistics.imported > 0) {
                        $('#toole_amazon_show_offers').parent().show();
                    }
                }
            },
        });
    }
});
