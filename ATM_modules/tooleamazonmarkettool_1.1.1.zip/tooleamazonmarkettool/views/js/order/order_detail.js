/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

$(document).ready(function () {
    const loader = $('#toole-loader');
    const fulfillBtn = $('#action_fullfill');
    const mpStatus = $('.mp_status');
    const successAlert = $('.success');
    const warningAlert = $('.warning');
    const errorAlert = $('.error');

    fulfillBtn.click(function () {
        const fulfillLink = $(this).data('fulfillLink');
        const orderId = $(this).data('orderId');
        
        $.ajax({
            url: fulfillLink,
            type: 'POST',
            dataType: 'json',
            data: {
                ajax: 1,
                action: 'fulfillment',
                id: orderId,
            },
            beforeSend: function () {
                loader.show();
                successAlert.empty();
                warningAlert.empty();
                errorAlert.empty();
                successAlert.hide();
                warningAlert.hide();
                errorAlert.hide();
            },
            success: function (res) {
                if (res?.hasMessage) {
                    const successMessages = res?.messages?.join('<br>') || '';
                    successAlert.html(successMessages);
                    successAlert.show();
                }
                if (res?.hasWarning) {
                    const warningMessages = res?.warnings?.join('<br>') || '';
                    warningAlert.html(warningMessages);
                    warningAlert.show();
                }
                fulfillBtn.attr('disabled', true);
                mpStatus.html(res?.data?.mp_status || '');
            },
            error: function (err) {
                if (err?.hasError) {
                    const errorMessages = err?.errors?.join('<br>') || '';
                    errorAlert.html(errorMessages);
                    errorAlert.show();
                }
                fulfillBtn.removeAttr('disabled', false);
            },
            complete: function () {
                loader.hide();
            }
        });
    });
});
