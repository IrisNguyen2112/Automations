/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

$(document).ready(function () {
    const addCustomFieldEl = $('#add_custom_fields');
    const addCustomFieldBtn = $('#add_custom_fields .panel-heading-action');
    const header = addCustomFieldEl.find('.panel-heading');
    const body = addCustomFieldEl.find('.panel-body');
    const footer = addCustomFieldEl.find('.panel-footer');
    const selectBox = addCustomFieldEl.find('.select-box');

    selectBox.chosen({width: '100%'});

    addCustomFieldBtn.on('click', function () {
        addCustomFieldEl.toggleClass('minimize-card');
        header.toggleClass('minimize-card');
        body.toggle();
        footer.toggle();
        selectBox.chosen({width: '100%'});
    })
});
