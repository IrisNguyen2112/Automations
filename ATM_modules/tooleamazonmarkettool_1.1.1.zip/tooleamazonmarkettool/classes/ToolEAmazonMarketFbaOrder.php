<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

class ToolEAmazonMarketFbaOrder extends ObjectModel
{
    public $id_shop;
    public $id_shop_group;
    public $id_entity;
    public $ps_order_id; // seller_fulfillment_order_id
    public $displayable_order_id;
    public $seller_fulfillment_order_id;
    public $displayable_order_date;
    public $displayable_order_comment;
    public $shipping_speed_category;
    public $fulfillment_action;
    public $received_date;
    public $fulfillment_order_status;
    public $status_updated_date;
    public $notification_emails;
    public $feature_constraints;
    public $date_add;
    public $date_upd;

    const SHIPPING_SPEED_STANDARD = 'Standard';
    const SHIPPING_SPEED_EXPEDITED = 'Expedited';
    const SHIPPING_SPEED_PRIORITY = 'Priority';
    const SHIPPING_SPEED_SCHEDULED_DELIVERY = 'ScheduledDelivery';

    const FULFILLMENT_ACTION_SHIP = 'Ship';
    const FULFILLMENT_ACTION_HOLD = 'Hold';

    const MCF_STATUS_NEW = 'New';
    const MCF_STATUS_RECEIVED = 'Received';
    const MCF_STATUS_PLANNING = 'Planning';
    const MCF_STATUS_PROCESSING = 'Processing';
    const MCF_STATUS_CANCELLED = 'Cancelled';
    const MCF_STATUS_COMPLETE = 'Complete';
    const MCF_STATUS_COMPLETE_PARTIALLED = 'CompletePartialled';
    const MCF_STATUS_UNFULFILLABLE = 'Unfulfillable';
    const MCF_STATUS_INVALID = 'Invalid';

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = [
        'table' => Database::TABLE_FBA_ORDERS,
        'primary' => 'id_fba_order',
        'multilang' => false,
        'multishop' => false,
        'fields' => [
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_shop_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_entity' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'ps_order_id' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'seller_fulfillment_order_id' => ['type' => self::TYPE_STRING, 'size' => 40, 'required' => true, 'shop' => false],
            'displayable_order_id' => ['type' => self::TYPE_STRING, 'size' => 40, 'required' => true, 'shop' => false],
            'displayable_order_date' => ['type' => self::TYPE_DATE, 'validate' => 'isDate', 'required' => true, 'shop' => false],
            'displayable_order_comment' => ['type' => self::TYPE_STRING, 'size' => 16777216, 'required' => true, 'shop' => false],
            'shipping_speed_category' => ['type' => self::TYPE_STRING, 'size' => 32, 'shop' => false],
            'fulfillment_action' => ['type' => self::TYPE_STRING, 'size' => 32, 'shop' => false],
            'received_date' => ['type' => self::TYPE_DATE, 'validate' => 'isDate', 'shop' => false],
            'fulfillment_order_status' => ['type' => self::TYPE_STRING, 'size' => 32, 'shop' => false],
            'status_updated_date' => ['type' => self::TYPE_DATE, 'validate' => 'isDate', 'shop' => false],
            'notification_emails' => ['type' => self::TYPE_STRING, 'size' => 16777216, 'shop' => false],
            'feature_constraints' => ['type' => self::TYPE_STRING, 'size' => 16777216, 'shop' => false],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate', 'copy_post' => false],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate', 'copy_post' => false],
        ],
    ];

    public function isPossibleCancel(): bool
    {
        return in_array($this->fulfillment_order_status, [
            '',
            self::MCF_STATUS_NEW,
            self::MCF_STATUS_RECEIVED,
            self::MCF_STATUS_PLANNING,
        ]);
    }

    public static function getOrdersNeedToUpdateStatus()
    {
        $sql = new DbQuery();
        $sql->select('o.seller_fulfillment_order_id as id, e.entity as marketplace');
        $sql->leftJoin(Database::TABLE_AMAZON_ENTITIES, 'e', 'e.id_entity = o.id_entity');
        $sql->from(Database::TABLE_FBA_ORDERS, 'o');
        $sql->where('o.`fulfillment_order_status` != "' . self::MCF_STATUS_COMPLETE . '"');
        $sql->where('o.`fulfillment_order_status` != "' . self::MCF_STATUS_CANCELLED . '"');
        $sql->where('o.`fulfillment_order_status` != "' . self::MCF_STATUS_UNFULFILLABLE . '"');
        $sql->where('o.`fulfillment_order_status` != "' . self::MCF_STATUS_INVALID . '"');

        return Db::getInstance()->executeS($sql);
    }

    public static function updateOrderStatus($orderId, $status, $statusUpdatedDate)
    {
        $sql = 'UPDATE `' . _DB_PREFIX_ . Database::TABLE_FBA_ORDERS . '`
				  SET  `fulfillment_order_status` = "' . pSQL($status) . '",
				  `status_updated_date` = "' . pSQL($statusUpdatedDate) . '"
				  WHERE `ps_order_id` = "' . $orderId . '"';

        return Db::getInstance()->execute($sql);
    }

    public static function getPsOrderIdBySellerFulfillmentOrderId($sellerFulfillmentOrderId)
    {
        $sql = 'SELECT `ps_order_id` FROM `' . _DB_PREFIX_ . Database::TABLE_FBA_ORDERS . '`
                WHERE `seller_fulfillment_order_id` = "' . pSQL($sellerFulfillmentOrderId) . '"';

        return Db::getInstance()->getValue($sql);
    }
}
