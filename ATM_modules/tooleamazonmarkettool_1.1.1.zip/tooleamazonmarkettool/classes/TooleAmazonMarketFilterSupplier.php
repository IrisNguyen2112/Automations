<?php
/**
 *  2023 TOOLE - Inter-soft.COM
 *  All rights reserved.
 *
 *  DISCLAIMER
 *
 *  Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketFilterSupplier extends ObjectModel
{
    public $id_supplier;
    public $id_shop;
    public $id_shop_group;
    public $id_entity;
    public $enabled_ps_amz;
    public $enabled_amz_ps;
    public $enabled_fba_ps;

    const IS_ENABLED = 1;

    const ENABLED_PS_AMZ = 1;
    const ENABLED_AMZ_PS = 2;
    const ENABLED_FBA_PS = 3;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = [
        'table' => Database::TABLE_FILTER_SUPPLIERS,
        'primary' => 'id_sync_supplier',
        'multilang' => false,
        'multishop' => false,
        'fields' => [
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_shop_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_supplier' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'id_entity' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'enabled_ps_amz' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
            'enabled_amz_ps' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
            'enabled_fba_ps' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
        ],
    ];

    public function save($null_values = false, $auto_date = true)
    {
        return parent::save($null_values, $auto_date);
    }

    public function delete()
    {
        return parent::delete();
    }

    /**
     * @param $type
     * @param $supplier_sync
     * @return int
     */
    public static function getEnabled($type, $supplier_sync): int
    {
        switch ($type) {
            case self::ENABLED_PS_AMZ:
                return (int) !$supplier_sync->enabled_ps_amz;
            case self::ENABLED_AMZ_PS:
                return (int) !$supplier_sync->enabled_amz_ps;
            case self::ENABLED_FBA_PS:
                return (int) !$supplier_sync->enabled_fba_ps;
            default:
                return 0;
        }
    }

    public static function updateEnabled(
        $id_supplier,
        $enabled = null,
        $type = self::ENABLED_PS_AMZ,
        $id_entity = null,
        $id_shop = null,
        $context = null
    ) {
        if (!$context) {
            $context = Context::getContext();
        }

        $return = true;

        $sql = new DbQuery();
        $sql->select('pq.id_sync_supplier');
        $sql->from(Database::TABLE_FILTER_SUPPLIERS, 'pq');

        $sql->where('pq.id_supplier=' . (int) $id_supplier);
        $sql->where('pq.id_shop=' . (int) $context->shop->id);
        $sql->where('pq.id_entity=' . (int) $id_entity);
        $id_sync_supplier = (int) Db::getInstance()->getValue($sql);

        if (!is_numeric($enabled) && !$id_sync_supplier) {
            $enabled = 1;
        } elseif (!is_numeric($enabled) && $id_sync_supplier) {
            $supplier_sync = new TooleAmazonMarketFilterSupplier($id_sync_supplier);
            $enabled = self::getEnabled($type, $supplier_sync);
        }
        $supplier_sync = new TooleAmazonMarketFilterSupplier($id_sync_supplier);
        $supplier_sync->id_supplier = (int) $id_supplier;
        $supplier_sync->id_shop = (int) $context->shop->id;
        $supplier_sync->id_shop_group = (int) $context->shop->id_shop_group;
        $supplier_sync->id_entity = (int) $id_entity;
        $supplier_sync->enabled_ps_amz = self::ENABLED_PS_AMZ === $type ? (int) $enabled : (int) $supplier_sync->enabled_ps_amz;
        $supplier_sync->enabled_amz_ps = self::ENABLED_AMZ_PS === $type ? (int) $enabled : (int) $supplier_sync->enabled_amz_ps;
        $supplier_sync->enabled_fba_ps = self::ENABLED_FBA_PS === $type ? (int) $enabled : (int) $supplier_sync->enabled_fba_ps;

        $return &= $supplier_sync->save();

        return $return;
    }

    public static function enableAll($ids, $id_shop, $id_shop_group, $entity_id): bool
    {
        try {
            $idsString = implode(',', $ids);
            $dataMap = array_map(function ($id_supplier) use ($id_shop, $id_shop_group, $entity_id) {
                $itemArr = [$id_shop, $id_shop_group, $id_supplier, $entity_id, 1, 1, 1];
                return '(' . implode(',', $itemArr) . ')';
            }, $ids);

            Db::getInstance()->execute('START TRANSACTION');
            Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` WHERE `id_shop` = ' . (int) $id_shop . ' AND `id_supplier` IN (' . $idsString . ') AND `id_entity` = ' . $entity_id . ' AND `id_shop_group` = ' . $id_shop_group . ';');
            Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` (`id_shop`, `id_shop_group`, `id_supplier`, `id_entity`, `enabled_ps_amz`, `enabled_amz_ps`, `enabled_fba_ps`) VALUE ' . implode(',', $dataMap));
            Db::getInstance()->execute('COMMIT');

            return true;
        } catch (\Exception $e) {
            Db::getInstance()->execute('ROLLBACK');
            return false;
        }
    }

    /**
     * @param $column
     * @param $supplierId
     * @param $shopId
     *
     * @return bool
     */
    public static function isEnableSync($column, $supplierId, $shopId, $entityId)
    {
        $sql = new DbQuery();
        $sql->from(Database::TABLE_FILTER_SUPPLIERS);
        $sql->select('count(*) as cnt');
        $sql->where('id_supplier = ' . (int) $supplierId);
        $sql->where('id_shop = ' . (int) $shopId);
        $sql->where('id_entity = ' . (int) $entityId);
        $sql->where("{$column} = " . self::IS_ENABLED);
        $res = Db::getInstance()->getRow($sql);

        return is_array($res) && $res['cnt'] > 0;
    }
}
