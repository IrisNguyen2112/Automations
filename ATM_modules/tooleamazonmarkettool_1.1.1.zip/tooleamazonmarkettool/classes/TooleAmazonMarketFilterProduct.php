<?php
/**
 *  2023 TOOLE - Inter-soft.COM
 *  All rights reserved.
 *
 *  DISCLAIMER
 *
 *  Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketFilterProduct extends ObjectModel
{
    public $id_product;
    public $id_shop;
    public $id_shop_group;
    public $id_entity;
    public $enabled;
    public $enabled_ps_amz;
    public $enabled_amz_ps;
    public $enabled_fba_ps;

    const IS_ENABLED = 1;

    const ENABLED_PS_AMZ = 1;
    const ENABLED_AMZ_PS = 2;
    const ENABLED_FBA_PS = 3;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = [
        'table' => Database::TABLE_FILTER_PRODUCTS,
        'primary' => 'id_sync_product',
        'multilang' => false,
        'multishop' => false,
        'fields' => [
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_shop_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_product' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'id_entity' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'enabled_ps_amz' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
            'enabled_amz_ps' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
            'enabled_fba_ps' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
        ],
    ];

    public function save($null_values = false, $auto_date = true)
    {
        return parent::save($null_values, $auto_date);
    }

    public function delete()
    {
        return parent::delete();
    }

    /**
     * @param $type
     * @param $product_sync
     * @return int
     */
    public static function getEnabled($type, $product_sync): int
    {
        switch ($type) {
            case self::ENABLED_PS_AMZ:
                return (int) !$product_sync->enabled_ps_amz;
            case self::ENABLED_AMZ_PS:
                return (int) !$product_sync->enabled_amz_ps;
            case self::ENABLED_FBA_PS:
                return (int) !$product_sync->enabled_fba_ps;
            default:
                return 0;
        }
    }

    public static function updateEnabled(
        $id_product,
        $enabled = null,
        $type = self::ENABLED_PS_AMZ,
        $id_entity = null,
        $id_shop = null,
        $context = null
    ) {
        if (!$context) {
            $context = Context::getContext();
        }

        $return = true;

        $sql = new DbQuery();
        $sql->select('pq.id_sync_product');
        $sql->from(Database::TABLE_FILTER_PRODUCTS, 'pq');

        $sql->where('pq.id_product=' . (int) $id_product);
        $sql->where('pq.id_shop=' . (int) $context->shop->id);
        $sql->where('pq.id_entity=' . (int) $id_entity);
        $id_sync_product = (int) Db::getInstance()->getValue($sql);

        if (!is_numeric($enabled) && !$id_sync_product) {
            $enabled = 1;
        } elseif (!is_numeric($enabled) && $id_sync_product) {
            $product_sync = new TooleAmazonMarketFilterProduct($id_sync_product);
            $enabled = self::getEnabled($type, $product_sync);
        }

        $product_sync = new TooleAmazonMarketFilterProduct($id_sync_product);
        $product_sync->id_product = (int) $id_product;
        $product_sync->id_shop = (int) $context->shop->id;
        $product_sync->id_shop_group = $context->shop->id_shop_group;
        $product_sync->id_entity = (int) $id_entity;
        $product_sync->enabled_ps_amz = self::ENABLED_PS_AMZ === $type ? (int) $enabled : (int) $product_sync->enabled_ps_amz;
        $product_sync->enabled_amz_ps = self::ENABLED_AMZ_PS === $type ? (int) $enabled : (int) $product_sync->enabled_amz_ps;
        $product_sync->enabled_fba_ps = self::ENABLED_FBA_PS === $type ? (int) $enabled : (int) $product_sync->enabled_fba_ps;

        $return &= $product_sync->save();

        return $return;
    }

    public static function enableAll($ids, $id_shop, $id_shop_group, $entity_id): bool
    {
        try {
            $idsString = implode(',', $ids);
            $dataMap = array_map(function ($id_product) use ($id_shop, $id_shop_group, $entity_id) {
                $itemArr = [$id_shop, $id_shop_group, $id_product, $entity_id, 1, 1, 1];
                return '(' . implode(',', $itemArr) . ')';
            }, $ids);

            Db::getInstance()->execute('START TRANSACTION');
            Db::getInstance()->execute('DELETE FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` WHERE `id_shop` = ' . (int) $id_shop . ' AND `id_product` IN (' . $idsString . ') AND `id_entity` = ' . $entity_id . ' AND `id_shop_group` = ' . $id_shop_group . ';');
            Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` (`id_shop`, `id_shop_group`, `id_product`, `id_entity`, `enabled_ps_amz`, `enabled_amz_ps`, `enabled_fba_ps`) VALUE ' . implode(',', $dataMap));
            Db::getInstance()->execute('COMMIT');

            return true;
        } catch (\Exception $e) {
            Db::getInstance()->execute('ROLLBACK');
            return false;
        }
    }

    /**
     * @param $column
     * @param $productId
     * @param $shopId
     *
     * @return bool
     */
    public static function isEnableSync($column, $productId, $shopId, $entityId)
    {
        $sql = new DbQuery();
        $sql->from(Database::TABLE_FILTER_PRODUCTS);
        $sql->select('count(*) as cnt');
        $sql->where('id_product = ' . (int) $productId);
        $sql->where('id_shop = ' . (int) $shopId);
        $sql->where('id_entity = ' . (int) $entityId);
        $sql->where("{$column} = " . self::IS_ENABLED);
        $res = Db::getInstance()->getRow($sql);

        return is_array($res) && $res['cnt'] > 0;
    }
}
