<?php
/**
 *  * TooleAmazonMarkettool
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use PrestaShop\ModuleLibServiceContainer\DependencyInjection\ServiceContainer;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\AmazonAuth\AmazonAuth;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\CatalogKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\ConfigurationLoad;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Install;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\ShippingKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Uninstall;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Log\Log;
use Toole\Module\SubscriptionManager\Service\Api\ServiceApiFactory;
use Toole\Module\SubscriptionManager\Service\Api\ServiceApiHelper;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\CreateStoreConfigurationResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\CreateStoreVersionsResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\CreateSubscriptionResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\GetSubscriptionResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\InstallModuleResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\UpdateStoreConfigurationResponse;
use Toole\Module\SubscriptionManager\Service\Api\v1\Response\ValidateSubscriptionResponse;
use Toole\Module\Utils\Utils;

if (!defined('_PS_VERSION_')) {
    exit;
}

$autoloadPath = __DIR__ . '/vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
}

class TooleAmazonMarketTool extends Module implements WidgetInterface
{
    const HOOKS = [
        'actionAdminControllerSetMedia',
        'actionFrontControllerSetMedia',
        'displayAdminOrder',
        'displayDashboardToolbarTopMenu',
    ];

    public static $ymlConfigPath;

    /**
     * @var ServiceContainer
     */
    private $container;

    /** @var string */
    private $html = '';

    /** @var Log */
    public $log;

    public function __construct()
    {
        $this->name = 'tooleamazonmarkettool';
        $this->tab = 'market_place';
        $this->version = '1.1.0';
        $this->author = 'Inter-Soft';
        $this->is_eu_compatible = 1;
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->tabClassName = 'AdminAmazonMarketplace';

        parent::__construct();

        $this->controllers = [
            'TooleAmazonMarketplaceFront',
        ];

        $this->displayName = $this->trans(
            'ToolE - Amazon Market Tool',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );
        $this->description = $this->trans(
            'AMT is the most reliable tool to succeed on Amazon designed exclusively for Prestashop by experienced Amazon sellers.',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );
        $this->ps_versions_compliancy = ['min' => '1.7.4', 'max' => _PS_VERSION_];
        $this->confirmUninstall = $this->trans(
            'Are you sure to uninstall this module?',
            [],
            'Modules.Tooleamazonmarkettool.Admin'
        );
        $this->secure_key = Tools::encrypt($this->name);
        $this->module_key = 'feb8213d46ffcc6165647bc46728424c';
        $this->support_email = 'support@toolecommerce.com';
        $this->help_center_url = 'https://helpcenter.toolecommerce.com/hc/en-us/articles/12583878761362';

        if ($this->container === null) {
            $this->container = new \PrestaShop\ModuleLibServiceContainer\DependencyInjection\ServiceContainer(
                $this->name,
                $this->getLocalPath()
            );
        }

        self::$ymlConfigPath = _PS_MODULE_DIR_ . $this->name;

        $this->log = new Log();
    }

    public function getContext()
    {
        return $this->context;
    }

    public function customConf()
    {
        return [
            1 => $this->trans('Settings updated', [], 'Modules.Tooleamazonmarkettool.Admin'),
        ];
    }

    public function getContextLink()
    {
        return $this->context->link;
    }

    public function install(): bool
    {
        if (false === (new Install($this))->run()) {
            return false;
        }

        $return = parent::install()
            && $this->getService('tooleamazonmarkettool.ps_accounts.installer')->install()
            && $this->registerHook(static::HOOKS);

        if ($return &&
            !Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SANDBOX') &&
            $api_helper = ServiceApiFactory::getApiHelper(ServiceApiFactory::V1, Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SERVICE_API_URL'), Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SERVICE_API_KEY'))) {
            /* @var InstallModuleResponse $install_response */
            $api_helper->installModule(
                $this->displayName,
                $this->version,
                $_SERVER['HTTP_HOST']
            );
        }
        return $return;
    }

    public function uninstall(): bool
    {
        return (new Uninstall($this))->run()
            && parent::uninstall();
    }

    public function renderWidget($hookName = null, array $configuration = [])
    {
        if ($hookName == null && isset($configuration['hook'])) {
            $hookName = $configuration['hook'];
        }
        $template = 'views/templates/hook/' . $hookName . '.tpl';

        isset($configuration['cache_id']) ? $cache_id = $configuration['cache_id'] : $cache_id = null;
        $variables = $this->getWidgetVariables($hookName, $configuration);
        if (isset($variables['cache_id'])) {
            $cache_id = $variables['cache_id'];
        }

        if (!$this->isCached($template, $this->getCacheId($hookName))) {
            $this->smarty->assign($variables);
        }

        return $this->fetch($this->getLocalPath() . $template, $cache_id);
    }

    public function getWidgetVariables($hookName = null, array $configuration = [])
    {
        if (in_array($hookName, ['displayDashboardToolbarTopMenu'])) {
            if (strpos($this->context->controller->controller_name, 'ToolEAmazonMarket') !== false) {
                $configuration['help_center_url'] = $this->getHelperLink();
            }

            if (in_array($this->context->controller->controller_name, ['ToolEAmazonMarketLogsSummary', 'ToolEAmazonMarketFeed'])) {
                unset($configuration['enable_marketplaces'], $configuration['enable_regions']);
            }
        }

        if ('displayAdminOrder' == $hookName) {
            $amzOrder = TooleAmazonMarketAmazonOrder::getOrderByPsOrderId($configuration['id_order']);
            $configuration['shop_logo'] = $this->getTooleLogo();
            $configuration['amz_order'] = $amzOrder;
            $configuration['is_fulfillable'] = !empty($amzOrder) && TooleAmazonMarketAmazonOrder::isFulfillableGlobal($amzOrder['mp_status'], $amzOrder['current_state']);
            $configuration['fulfill_link'] = $this->context->link->getAdminLink('ToolEAmazonMarketOrderImported', true) . '&action=fulfillment';
        }

        return $configuration;
    }

    public function getContent()
    {
        $active_tab = $this->getActiveTab();
        if (Tools::isSubmit('submitAdvanced')) {
            if (Tools::getValue('TOOLE_AMAZONMARKETTOOL_SERVICE_API_URL')) {
                Configuration::updateGlobalValue(
                    'TOOLE_AMAZONMARKETTOOL_SERVICE_API_URL',
                    rtrim(Tools::getValue('TOOLE_AMAZONMARKETTOOL_SERVICE_API_URL'), '/')
                );
            }
            if (Tools::getValue('TOOLE_AMAZONMARKETTOOL_SERVICE_API_KEY')) {
                Configuration::updateGlobalValue(
                    'TOOLE_AMAZONMARKETTOOL_SERVICE_API_KEY',
                    Tools::getValue('TOOLE_AMAZONMARKETTOOL_SERVICE_API_KEY')
                );
            }
            if (Tools::getValue('TOOLE_AMAZONMARKETTOOL_AMAZON_AUTH_API_URL')) {
                Configuration::updateGlobalValue(
                    'TOOLE_AMAZONMARKETTOOL_AMAZON_AUTH_API_URL',
                    rtrim(Tools::getValue('TOOLE_AMAZONMARKETTOOL_AMAZON_AUTH_API_URL'), '/')
                );
            }
            $this->html .= $this->displayConfirmation(
                $this->trans('Settings updated', [], 'Modules.Tooleamazonmarkettool.Admin')
            );
        }

        $billingService = $this->getService('tooleamazonmarkettool.ps_billings.service');
        $billingServiceContext = $this->getService('tooleamazonmarkettool.ps_billings.context_wrapper');

        $plan_id = false;
        // Retrieve the subscritpion for this module
        $subscription = $billingService->getCurrentSubscription();
        if ($subscription['success'] == false) {
            $status = 'inactive';
        } else {
            $status = $subscription['body']['status'];
        }
        /* @var ServiceApiHelper $api_helper */
        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new Exception('Problem');
        }

        if ($subscription['success']) {
            $plan_id = $subscription['body']['plan_id'];

            if ($status != 'inactive') {
                if (!Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                )) {
                    /* @var GetSubscriptionResponse $get_subscription_response */
                    try {
                        $get_subscription_response = $api_helper->getSubscription($subscription['body']['id']);
                        if ($get_subscription_response->getIsValid()) {
                            Configuration::updateValue(
                                Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID,
                                $get_subscription_response->getSubscriptionId()
                            );
                            Configuration::updateValue(
                                Key::CONFIG_PRESTASHOP_PLANID,
                                $get_subscription_response->getPlanId()
                            );
                            Configuration::updateValue(
                                Key::CONFIG_PRESTASHOP_STOREID,
                                $get_subscription_response->getStoreId()
                            );
                        } else {
                            throw new Exception('No subscription found.');
                        }
                    } catch (Exception $e) {
                        // need to wait until the subscription is updated on the server
                        $this->html .= $this->displayError(
                            $this->trans('No subscription information available', [], 'Modules.Tooleamazonmarkettool.Admin')
                        );
                        $customer = $billingService->getCurrentCustomer();
                        /* @var CreateSubscriptionResponse $create_response */
                        $create_response = $api_helper->createSubscription(
                            $subscription['body']['id'],
                            $customer['body']['cf_shop_id'],
                            isset($subscription['body']['plan_id']) ? $subscription['body']['plan_id'] : '',
                            isset($subscription['body']['customer_id']) ? $subscription['body']['customer_id'] : '',
                            isset($subscription['body']['created_at']) ? $subscription['body']['created_at'] : '',
                            isset($subscription['body']['activated_at']) ? $subscription['body']['activated_at'] : '',
                            isset($subscription['body']['started_at']) ? $subscription['body']['started_at'] : '',
                            isset($subscription['body']['next_billing_at']) ? $subscription['body']['next_billing_at'] : '',
                            isset($subscription['body']['trial_end']) ? $subscription['body']['trial_end'] : '',
                            isset($subscription['body']['updated_at']) ? $subscription['body']['updated_at'] : '',
                            $this->name,
                            'unconfirmed'
                        );
                        if ($create_response && !$create_response->getIsValid()) {
                            $this->html .= $this->displayError(
                                $this->trans('Fatal error creating subscription details.', [], 'Modules.Tooleamazonmarkettool.Admin')
                            );
                        }
                    }
                }

                if (!Configuration::get(
                    Key::CONFIG_PRESTASHOP_STOREID
                )) {
                    $this->html .= $this->displayError(
                        $this->trans('Processing subscription', [], 'Modules.Tooleamazonmarkettool.Admin')
                    );
                }
            }
        }

        $amazonRefreshToken = Tools::getValue('refresh_token');
        if ((Tools::isSubmit('submitConfiguration') || Tools::isSubmit('toole_amazon_authorization') || $amazonRefreshToken) && !Tools::isSubmit('submitAdvanced')) {
            /* @var ServiceApiHelper $api_helper */
            if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
                throw new Exception('Problem');
            }
            /* @var ValidateSubscriptionResponse $validate_response */
            $validate_response = false;
            try {
                $validate_response = $api_helper->validateSubscription(
                    Configuration::get(
                        Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                    ),
                    Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                    Configuration::get(
                        Key::CONFIG_PRESTASHOP_PLANID
                    )
                );
            } catch (Exception $e) {
                $this->html .= $this->displayError(
                    $this->trans('Unable to connect to subscription validation server, please contact support', [], 'Modules.Tooleamazonmarkettool.Admin')
                );
                return $this->html;
            }
            if ($validate_response && $validate_response->getIsValid()) {
                $returned = true;
                if (Tools::isSubmit('submitConfiguration')) {
                    $returned = $this->processSubmitConfiguration();
                }
                $this->amazonAuthorization();
                if (Tools::getValue('ps_authorizing') && Tools::getValue('region')) {
                    $active_tab = Tools::getValue('region');
                }

                if (is_array($returned)) {
                    if (count($returned) > 0) {
                        foreach ($returned as $err) {
                            $this->html .= $this->displayError($err);
                        }
                    } else {
                        $this->html .= $this->displayError(
                            $this->trans('Unable to save configuration', [], 'Modules.Tooleamazonmarkettool.Admin')
                        );
                    }
                } elseif ($returned == true) {
                    /* @var CreateStoreVersionsResponse $create_store_configuration_response */
                    $create_store_configuration_response = $api_helper->createStoreVersions(
                        Configuration::get(
                            Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                        ),
                        Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                        _PS_VERSION_,
                        $this->name,
                        $this->version,
                        phpversion(),
                        Db::getInstance()->getLink()->getAttribute(PDO::ATTR_DRIVER_NAME),
                        Db::getInstance()->getVersion()
                    );
                    if (!$create_store_configuration_response) {
                        throw new Exception($this->trans('Unable to save store configuration', [], 'Modules.Tooleamazonmarkettool.Admin'));
                    }
                    $this->html .= $this->displayConfirmation(
                        $this->trans('Settings updated', [], 'Modules.Tooleamazonmarkettool.Admin')
                    );

                    // set cookies
                    $this->context->cookie->__set('custom_conf', 1);
                    $this->context->cookie->__set('active_tab', $active_tab);
                    $this->context->cookie->write();

                    $admin_link = $this->context->link->getAdminLink(
                        'AdminModules',
                        true
                    ) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
                    Tools::redirect($admin_link);
                } else {
                    $this->html .= $this->displayError(
                        $this->trans('Unable to save configuration', [], 'Modules.Tooleamazonmarkettool.Admin')
                    );
                }
            } else {
                if ($validate_response && !$validate_response->getIsValid()) {
                    $this->html .= $this->displayError(
                        $validate_response->getMessage()
                    );
                }
                $this->html .= $this->displayError(
                    $this->trans('Unable to save configuration', [], 'Modules.Tooleamazonmarkettool.Admin')
                );
            }
        }

        $accountsInstaller = $this->getService('tooleamazonmarkettool.ps_accounts.installer');
        $accountsInstaller->install();

        try {
            $accountsFacade = $this->getService('tooleamazonmarkettool.ps_accounts.facade');
            $accountsService = $accountsFacade->getPsAccountsService();
            Media::addJsDef([
                'contextPsAccounts' => $accountsFacade->getPsAccountsPresenter()
                    ->present($this->name),
            ]);

            // Retrieve Account CDN
            $this->context->smarty->assign('urlAccountsVueCdn', $accountsService->getAccountsVueCdn());

            $billingFacade = $this->getService('tooleamazonmarkettool.ps_billings.facade');

            // Billing
            Media::addJsDef($billingFacade->present([
                'logo' => $this->getLocalPath() . 'views/img/partnerLogo.png',
                'tosLink' => $this->getTosLink($this->context->language->iso_code),
                'privacyLink' => $this->getPrivacyLink($this->context->language->iso_code),
                'emailSupport' => $this->support_email,
            ]));
            Media::addJsDef([
                'configModule' => json_encode(Utils::config(dirname(__FILE__), 'module')),
                'moduleVersion' => $this->version,
                'toole_moduleconfiguration_url' => $this->context->link->getAdminLink(
                    'AdminModules',
                    true
                ) . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name,
                'subscription_status' => $status,
            ]);

            $this->context->controller->addCSS(_PS_MODULE_DIR_ . $this->name . '/public/css/configuration.css');

            if (isset($this->customConf()[$this->context->cookie->__get('custom_conf')])) {
                $this->html .= $this->displayConfirmation(
                    $this->customConf()[$this->context->cookie->__get('custom_conf')]
                );
            }

            $this->html .= $this->context->smarty->assign([
                'configModule' => json_encode(Utils::config(dirname(__FILE__), 'module')),
                'loadingText' => $this->trans('Please wait, loading account details', [], 'Modules.Tooleamazonmarkettool.Admin'),
                'pathVendor' => sprintf('%sviews/app/js/vendor.%s.js', $this->getPathUri(), $this->version),
                'pathApp' => sprintf('%sviews/app/js/index.%s.js', $this->getPathUri(), $this->version),
                'status' => $status,
                'subscriptionId' => Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                ),
                'isPsSandbox' => $billingServiceContext->isSandbox(),
                'storeId' => Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                'subscriptionStatus' => strtoupper($status),
                'isLinked' => $accountsService->isAccountLinked(),
                'isSubscribed' => ($status == 'inactive') ? 0 : 1,
                'urlAccountsCdn' => $accountsService->getAccountsCdn(),
                'urlBilling' => 'https://unpkg.com/@prestashopcorp/billing-cdc/dist/bundle.js',
                'prestashopVersion' => _PS_VERSION_,
                'moduleName' => $this->displayName,
                'moduleVersion' => $this->version,
                'phpVersion' => phpversion(),
                'databaseType' => Db::getInstance()->getLink()->getAttribute(PDO::ATTR_DRIVER_NAME),
                'databaseVersion' => Db::getInstance()->getVersion(),
                'active_tab' => $active_tab,
            ])
                ->assign($this->getConfigurationFormVars())
                ->fetch($this->getLocalPath() . 'views/templates/admin/configuration.tpl');

            // clear cookies
            $this->context->cookie->__unset('custom_conf');
            $this->context->cookie->__unset('active_tab');

            return $this->html;
        } catch (Exception $e) {
            $this->context->controller->errors[] = $e->getMessage();
            return '';
        }
    }

    public function hookActionAdminControllerSetMedia($params)
    {
        if (
            Module::isEnabled($this->name) &&
            $this->context->controller->controller_name == 'AdminModules' &&
            Tools::getValue('configure') == $this->name
        ) {
            $this->context->controller->addJS(
                _PS_MODULE_DIR_ . $this->name . '/public/js/configuration.js'
            );
        }
    }

    /**
     * Indicate that module is using new translation system
     */
    public function isUsingNewTranslationSystem()
    {
        return true;
    }

    /**
     * Get the Tos URL from the context language, if null, send default link value
     *
     * @return string
     */
    public function getTosLink($iso_lang)
    {
        switch ($iso_lang) {
            case 'fr':
                $url = 'https://toolecommerce.com/toole-tools-for-ecommerc/termsofservice-eng/';
                break;
            default:
                $url = 'https://toolecommerce.com/toole-tools-for-ecommerc/termsofservice-eng/';
                break;
        }

        return $url;
    }

    /**
     * Get the Tos URL from the context language, if null, send default link value
     *
     * @return string
     */
    public function getPrivacyLink($iso_lang)
    {
        switch ($iso_lang) {
            case 'fr':
                $url = 'https://toolecommerce.com/fr/privacy-policy-fr/';
                break;
            default:
                $url = 'https://toolecommerce.com/toole-tools-for-ecommerc/privacypolicy/';
                break;
        }

        return $url;
    }

    public function getHelperLink()
    {
        switch ($this->context->controller->controller_name) {
            case 'ToolEAmazonMarketCatalogFiltersCategories':
            case 'ToolEAmazonMarketCatalogFiltersManufacturers':
            case 'ToolEAmazonMarketCatalogFiltersSuppliers':
            case 'ToolEAmazonMarketCatalogFiltersProducts':
                $url = 'https://www.youtube.com/watch?v=6mMMUm4H_Ts';
                break;
            case 'ToolEAmazonMarketProductsImportedFromAmazon':
            case 'ToolEAmazonMarketProductSyncFromAmazon':
                $url = 'https://www.youtube.com/watch?v=CEcj9AnGpc4';
                break;
            case 'ToolEAmazonMarketProductSyncFromPrestashop':
                $url = 'https://www.youtube.com/watch?v=PDOCMgErC24';
                break;
            case 'ToolEAmazonMarketLogsSummary':
                $url = 'https://www.youtube.com/watch?v=hkeP5rYCDzI';
                break;
            case 'ToolEAmazonMarketOrderImported':
            case 'ToolEAmazonMarketOrderListing':
                $url = 'https://www.youtube.com/watch?v=9mQJBi7dZoI';
                break;
            default:
                $url = $this->help_center_url;
                break;
        }

        return $url;
    }

    public function getTooleLogo()
    {
        return 'https://toolecommerce.com/wp-content/uploads/2023/06/White-Logo.png';
    }

    public static function clearAllCached()
    {
        $module = Module::getInstanceByName('tooleamazonmarkettool');
        /*$module->clearCache('tab', 'homefeatured-tab', false);
        $module->clearCache('homefeatured', '', false);
        $module->clearCache('*', 'ps_featuredproducts', false);*/
    }

    protected function amazonAuthorization(): void
    {
        $amazonAuthCre = (new AmazonAuth($this, Context::getContext()))->amazonAuthorization();
        if ($amazonAuthCre) {
            try {
                $amazonAuthCre->saveAmazonAuthCredentials();
                $connector = SaaSConnector::initHelperWithConnector($amazonAuthCre->region);
                $apiResult = $connector->getMarketplaceParticipations();
                $enableList = $connector->getAmazonConnector()->getAvailableMarketplaces();
                $enableList[] = $amazonAuthCre->marketplaceId;
                AmazonMarketConfiguration::saveAmzMarketplaces($apiResult->getAmazonData(), $enableList, $amazonAuthCre->region);
            } catch (Exception $e) {
                $this->html .= $this->displayError(
                    $this->trans(
                        'Error saving selected marketplace',
                        [],
                        'Modules.Tooleamazonmarkettool.Admin'
                    ) . ' [' . $e->getMessage() . ']'
                );
            }
        }
    }

    /**
     * Retrieve the service
     *
     * @param string $serviceName
     *
     * @return mixed
     */
    private function getService($serviceName)
    {
        return $this->container->getService($serviceName);
    }

    private function getConfigurationFormVars(): array
    {
        return (new ConfigurationLoad($this))->getTplVars();
    }

    private function processSubmitConfiguration()
    {
        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new Exception('Problem');
        }
        $custom_data = [
            CatalogKey::ENABLE_SYNC_FROM_AMZ => Tools::getValue(CatalogKey::ENABLE_SYNC_FROM_AMZ, null),
            CatalogKey::ENABLE_SYNC_FROM_PS => Tools::getValue(CatalogKey::ENABLE_SYNC_FROM_PS, null),
            OrderKey::CRON_ENABLE_IMPORT_ORDERS => Tools::getValue(OrderKey::CRON_ENABLE_IMPORT_ORDERS, null),
            OrderKey::ENABLE_FULFILL_ORDERS => Tools::getValue(OrderKey::ENABLE_FULFILL_ORDERS, null),
            OrderKey::IMPORT_ORDER_STATUS => Tools::getValue(OrderKey::IMPORT_ORDER_STATUS, null),
            OrderKey::FULFILL_ORDER_STATUS => Tools::getValue(OrderKey::FULFILL_ORDER_STATUS, null),
            CatalogKey::CRON_CATALOG_SYNC_FROM_PS_TIME => Tools::getValue(CatalogKey::CRON_CATALOG_SYNC_FROM_PS_TIME, null),
            CatalogKey::CRON_CATALOG_SYNC_FROM_AMZ_TIME => Tools::getValue(CatalogKey::CRON_CATALOG_SYNC_FROM_AMZ_TIME, null),
            OrderKey::CRON_ORDERS_IMPORT_TIME => Tools::getValue(OrderKey::CRON_ORDERS_IMPORT_TIME, null),
            OrderKey::CRON_ORDERS_FULFILL_TIME => Tools::getValue(OrderKey::CRON_ORDERS_FULFILL_TIME, null),
            OrderKey::INCOMING_CARRIERS => $this->buildMappingCarrier(OrderKey::INCOMING_CARRIERS),
            OrderKey::OUTGOING_CARRIERS => $this->buildMappingCarrier(OrderKey::OUTGOING_CARRIERS),
            Key::AMZ_AUTH_COMBO => $this->buildAmzMarketplaceCombo(),
            Key::CONFIG_CRON_TAB_FREQUENCY => [],
            ShippingKey::SHIPPING_TEMPLATES => $this->buildShippingRules(Tools::getValue(ShippingKey::SHIPPING_TEMPLATES, [])),
            OrderKey::CRON_IMPORT_ORDERS_ADVANCED => Tools::getValue(OrderKey::CRON_IMPORT_ORDERS_ADVANCED, []),
        ];

        $this->buildCronParamConfigurations($custom_data);

        if (!Configuration::get(
            Key::CONFIG_PRESTASHOP_STORECONFIGURATIONID
        )) {
            /* @var CreateStoreConfigurationResponse $create_store_configuration_response */
            $create_store_configuration_response = $api_helper->createStoreConfiguration(
                Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                ),
                Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                $custom_data
            );
            if (!$create_store_configuration_response) {
                return [
                    $this->trans(
                        'Unable to create store configuration',
                        [],
                        'Modules.Tooleamazonmarkettool.Admin'
                    ),
                ];
            }

            Configuration::updateValue(
                Key::CONFIG_PRESTASHOP_STORECONFIGURATIONID,
                $create_store_configuration_response->getStoreConfigurationId()
            );
        } else {
            /* @var UpdateStoreConfigurationResponse $update_store_configuration_response */
            $update_store_configuration_response = AmazonMarketConfiguration::updateStoreConfiguration($custom_data);
            if (!$update_store_configuration_response) {
                return [
                    $this->trans(
                        'Unable to update store configuration',
                        [],
                        'Modules.Tooleamazonmarkettool.Admin'
                    ),
                ];
            }
        }

        return true;
    }

    protected function buildCronParamConfigurations(&$custom_data): void
    {
        foreach (AmazonMarketConfiguration::$config_cron_params as $key => $cronData) {
            $minutes = $custom_data[$key] ?? $cronData['minutes'] ?? AmazonMarketConfiguration::CRON_TIME_MIN;
            $custom_data[Key::CONFIG_CRON_TAB_FREQUENCY][$key]['dependence'] = $cronData['dependence'];
            $custom_data[Key::CONFIG_CRON_TAB_FREQUENCY][$key]['minutes'] = $minutes;

            $params = ['action' => $cronData['action']];
            if ($cronData['dependence'] == OrderKey::CRON_ENABLE_IMPORT_ORDERS && $cronData['action'] == 'orderImport') {
                $advanced = $custom_data[OrderKey::CRON_IMPORT_ORDERS_ADVANCED];
                if (isset($advanced['statuses']) && $advanced['statuses'] != 'All') {
                    $params['order_statuses'] = $advanced['statuses'];
                }
            }
            $custom_data[Key::CONFIG_CRON_TAB_FREQUENCY][$key]['url'] = $this->context->link->getModuleLink(
                $this->name,
                $cronData['controller'],
                $params
            );
        }
    }

    /**
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    private function buildMappingCarrier($key): array
    {
        $carriers = Tools::getValue($key, []);
        foreach ($carriers as $k => $carrier) {
            if ($key === OrderKey::INCOMING_CARRIERS) {
                if (empty($carrier['amazon_carrier']) || empty($carrier['carrier'])) {
                    unset($carriers[$k]);
                }
            } elseif ($key === OrderKey::OUTGOING_CARRIERS) {
                if (empty($carrier['ps']) || empty($carrier['amazon'])) {
                    unset($carriers[$k]);
                }
            } else {
                return [];
            }
        }

        return array_values($carriers);
    }

    private function getActiveTab(): string
    {
        if ($this->context->cookie->__get('active_tab')) {
            return $this->context->cookie->__get('active_tab');
        }

        if (Tools::getValue('active_tab')) {
            return Tools::getValue('active_tab');
        }

        return 'welcome';
    }

    private function buildShippingRules(array $data)
    {
        if (!$data) {
            return null;
        }

        if (!isset($data['enable']) || $data['enable'] == '0') {
            return $data; // Configuration is turned off
        }

        if (!isset($data['rules']) || !is_array($data['rules'])) {
            return $data; // Shipping rules not found
        }

        $rules = $data['rules'];

        $newData = [];
        foreach (['price', 'weight'] as $ruleName) {
            $this->validateShippingRules($rules, $ruleName, $newData);
        }

        $data['rules'] = $newData;

        return $data;
    }

    private function validateShippingRules($rules, $ruleName, &$newData)
    {
        if (!isset($rules[$ruleName]) || !is_array($rules[$ruleName])) {
            return;
        }

        $validRules = [];
        foreach ($rules[$ruleName] as $rule) {
            $min = isset($rule['min']) ? trim($rule['min']) : null;
            $max = isset($rule['max']) ? trim($rule['max']) : null;
            $name = isset($rule['name']) ? trim($rule['name']) : null;
            if ($min == '' || $max == '' || empty($name)) {
                continue;
            }

            // add valid rule
            $validRules[] = $rule;
        }
        $newData[$ruleName] = $validRules;
    }

    private function buildAmzMarketplaceCombo()
    {
        $regionsWMkps = AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO);
        $enableRegions = Tools::getValue(Key::AMZ_AUTH_COMBO);

        if (!empty($regionsWMkps)) {
            foreach ($regionsWMkps as $region => &$regionData) {
                $regionData['enable'] = $enableRegions[$region]['enable'] ?? null;

                // processing update active region & marketplace
                if (!$regionData['enable'] && Configuration::get(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_REGION, null, $this->context->shop->id_shop_group, $this->context->shop->id) == $region) {
                    $availableRegions = array_keys(array_filter($enableRegions, function ($value) {
                        return $value['enable'];
                    }));

                    // update active region
                    $activeRegion = $availableRegions[0] ?? null;
                    Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_REGION, $activeRegion, false, $this->context->shop->id_shop_group, $this->context->shop->id);

                    // update active marketplace
                    $marketplaces = $regionsWMkps[$activeRegion]['marketplaces'];
                    $availableMkps = array_keys(array_filter($marketplaces, function ($value) {
                        return $value['isParticipating'] && $value['isEnable'];
                    }));

                    $activeMkp = $availableMkps[0] ?? null;
                    Configuration::updateValue(Key::CONFIG_PRESTASHOP_KEY_ACTIVE_MARKEPLACE, $activeMkp, false, $this->context->shop->id_shop_group, $this->context->shop->id);
                }

                if (!empty($regionData['marketplaces'])) {
                    array_walk($regionData['marketplaces'], function (&$mkpData, $idMkp) {
                        $mkpData['isEnable'] = Tools::getValue($idMkp) && $mkpData['isParticipating'];
                    });
                }
            }
        }

        return $regionsWMkps ?: [];
    }
}
