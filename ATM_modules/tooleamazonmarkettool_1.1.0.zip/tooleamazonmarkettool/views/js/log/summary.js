/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

$(document).ready(function () {
    const loading = $('#toole-modal-dialog');
    $(document).on('click', '.toole-summary-detail', function (e) {
        e.preventDefault();
        const id = $(this).data('id'),
            url = $('#subtab-ToolEAmazonMarketActivityLogsTab a').attr('href') + '&action=getDetails&ajax=1',
            title = $(this).closest('tr').find('.column-title').text();
        let summaryModal = $('#toole-summary-modal'),
            modalContent = $('#toole-summary-modal .modal-body .list-group'),
            modalTitle = $('#toole-summary-modal .modal-title');
        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            data: {
                id_log: id,
            },
            beforeSend: function () {
                // Modal hide
                loading.fadeIn();
                modalContent.empty();
                summaryModal.modal('hide');
            },
            success: function (data) {
                // Remove old Data
                if (data.length > 0) {
                    let content = '';
                    let messageClass;
                    data.forEach(function (detail) {
                        if (detail.type === '0') {
                            messageClass = '';
                        } else if (detail.type === '1') {
                            messageClass = 'list-group-item-success';
                        } else if (detail.type === '2') {
                            messageClass = 'list-group-item-danger';
                        } else {
                            messageClass = 'list-group-item-warning';
                        }
                        content += '<li class="list-group-item ' + messageClass + '">';
                        content +=
                            '<span><span class="summary-time">From:</span> &nbsp;' + detail.date_start + '&nbsp;&nbsp;&nbsp;<span class="summary-time">To:</span>&nbsp;' + detail.date_stop + '</span>' +
                            '</br><span>' + detail.message + '</span>';
                        if (detail.content_location) {
                            content += '</br>' + '<span><a href="' + detail.content_location + '">Download Feed</a></span>';
                        }
                        if (detail.result_location) {
                            content += '</br>' + '<span><a href="' + detail.result_location + '">Download Result</a></span>';
                        }
                        content += '</li>';
                    });
                    modalTitle.text(title);
                    modalContent.html(content);
                    setTimeout(function () {
                        summaryModal.modal();
                    }, 300);
                } else {
                    summaryModal.modal('hide');
                    alert('No report yet.')
                }
            },
            error: function (data) {
                console.log('error', data);
            },
            complete: function (data) {
                // modal show
                loading.fadeOut();
            }
        });
    });
});
