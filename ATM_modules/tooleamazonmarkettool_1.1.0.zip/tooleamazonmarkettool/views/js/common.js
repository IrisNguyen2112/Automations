/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

$(document).ready(function() {
    /*** show loading modal ***/
    /**
     * add class name `no-waiting-modal` to apply waiting modal
     */
    let btnList = [
        'table.table > tbody > tr > td > .btn-group > a:not(:target,.no-waiting-modal)',
        'table.table > tbody > tr > td .btn-group-action > .btn-group > a:not(:target,.no-waiting-modal, [data-style="no-waiting-modal"])',
        'table.table > tbody > tr > td .btn-group-action > .btn-group > ul.dropdown-menu > li > a:not(.unavailable,.no-waiting-modal)'
    ];

    btnList.map(item => {
        $(document).on('click', item , function (e) {
            $('#toole-modal-dialog').fadeIn();
        });
    });
    /*** end show loading modal ***/

    /*** render tooltips ***/
    $('.toole-tooltips').tooltip();
    /*** end render tooltips ***/

    /*** action change region ***/
    $(document).on('change', '.displayDashboardToolbarTopMenu select[name="toole_filter_zone"]', function () {
        $.ajax({
            url: $(this).data('action'),
            type: 'POST',
            dataType: 'json',
            data: {zone: $(this).val()},
            beforeSend: function () {
                $('#toole-modal-dialog').fadeIn();
            },
            success: function (data) {
                if (data && data.url) {
                    window.location.href = data.url;
                }
                $('#toole-modal-dialog').fadeOut();
            },
            error: function () {
                $('#toole-modal-dialog').fadeOut();
            },
            complete: function () {
                $('#toole-modal-dialog').fadeOut();
            }
        });
    });
    /*** end action change region ***/
});
