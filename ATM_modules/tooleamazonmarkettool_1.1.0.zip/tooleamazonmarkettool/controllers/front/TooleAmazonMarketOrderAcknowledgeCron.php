<?php
/**
 * TooleAmazonMarketOrderAcknowledgeCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderAcknowledge;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Constant;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketOrderAcknowledgeCronModuleFrontController extends TooleBaseFrontController
{
    public function __construct()
    {
        $this->active_region = Tools::getValue('region', Constant::MKP_REGION_EU);
        parent::__construct();
        $this->ajax = true;
    }

    /**
     * URL: http://hostname/index.php?action=acknowledge&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketOrderAcknowledgeCron&id_subscription=
     *
     * @return void
     * @throws PrestaShopDatabaseException|PrestaShopException
     */
    public function displayAjaxAcknowledge()
    {
        $this->module->log->setLog('Process Acknowledge Order request', true);
        $acknowledgeOrder = new OrderAcknowledge($this->saasHelper, $this->module);
        try {
            $acknowledgeOrder->doAcknowledge();
        } catch (Exception $e) {
            $this->module->log->error($e->getMessage());
            exit(AjaxResponseOnce::onlyAnError($e->getMessage()));
        }

        $response = new AjaxResponseOnce($acknowledgeOrder->getErrors(), $acknowledgeOrder->getWarnings(), $acknowledgeOrder->getConfirmations(), $acknowledgeOrder->getAckOrders());
        $this->module->log->extractFromAjaxResponse($response);
        exit($response);
    }
}
