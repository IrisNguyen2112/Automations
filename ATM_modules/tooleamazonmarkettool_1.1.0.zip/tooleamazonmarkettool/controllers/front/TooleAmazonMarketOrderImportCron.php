<?php
/**
 * TooleAmazonMarketOrderImportCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\Model;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderImport;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Constant;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketOrderImportCronModuleFrontController extends TooleBaseFrontController
{
    private $lastImportTime;
    public $logMsgs = [];
    public $errorMsgs = [];
    public $warningMsgs = [];
    public $importMessages = [];
    public $orders = [];
    public $order_statuses = [];

    protected $use_region = true;

    protected $lastUpdatedBefore;
    protected $apiDataCarrier = [];

    public function __construct()
    {
        $this->active_region = Tools::getValue('region', Constant::MKP_REGION_EU);
        parent::__construct();

        $this->ajax = true;
        $this->lastImportTime = Tools::getValue('last_import_time') ? Tools::getValue('last_import_time') : Configuration::get(OrderKey::CONFIG_LAST_ORDER_IMPORT_TIME);
        $this->order_statuses = Tools::getValue('order_statuses') ? explode(',', Tools::getValue('order_statuses')) : $this->resolveInputStatus();

        if (!AmazonMarketConfiguration::get(OrderKey::CRON_ENABLE_IMPORT_ORDERS)) {
            exit(new AjaxResponseOnce(['This feature is not enabled'], [], [], null));
        }
    }

    /**
     * URL: http://hostname/index.php?action=orderImport&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketOrderImportCron&id_subscription=
     *
     * @return void
     */
    public function displayAjaxOrderImport()
    {
        $this->module->log->setLog('Process Import Amazon Order Request', true);
        $this->module->log->message(sprintf('Import Order From Amazon %s', $this->active_region));
        $orders = $this->getOrderListApi();
        $amazonOrderIds = [];
        foreach ($orders as $order) {
            if ($order instanceof Exception) {
                $this->logMsgs[] = $order->getMessage() ?: 'An unexpected error has occurred';
                $this->errorMsgs[] = $order->getMessage() ?: $this->trans(
                    'An unexpected error has occurred',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
                continue;
            }
            if (!$order instanceof Model\Order) {
                continue;
            }

            // Skip Pending & Canceled status
            if (in_array($order->getOrderStatus(), [Model\Order::ORDER_STATUS_PENDING, Model\Order::ORDER_STATUS_CANCELED])) {
                $this->warningMsgs[] = sprintf($this->trans(
                    'Skipped order %s - Invalid order status %s',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ), $order->getAmazonOrderId(), $order->getOrderStatus());
            }

            // Rare case when super old order has been updated for some reasons
            $purchaseDate = new DateTime($order->getPurchaseDate());
            $updateDate = new DateTime($order->getLastUpdateDate());
            if ($purchaseDate->modify('+90 days') < $updateDate) {
                $this->warningMsgs[] = $this->trans(
                    'Skipped too old order: %order_id%, purchased at: %purchased%, updated at: %updated%',
                    ['%order_id%' => $order->getAmazonOrderId(), '%purchased%' => $order->getPurchaseDate(), '%updated%' => $order->getLastUpdateDate()],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
            }

            $amazonOrderIds[] = $order->getAmazonOrderId();
        }
        $this->module->log->message(sprintf('%s orders to import', count($amazonOrderIds)));

        try {
            $amazonImport = new OrderImport($amazonOrderIds, $this->saasHelper, $this->module, $this->context->currency, true);
            $amazonImport->importOrders();
            $this->saveUpperCapTime();

            $response = new AjaxResponseOnce(
                array_merge($this->errorMsgs, $amazonImport->getErrors()),
                array_merge($this->warningMsgs, $amazonImport->getWarnings()),
                array_merge($this->importMessages, $amazonImport->getConfirmations()),
                $amazonImport->getResultOrders()
            );
            $this->module->log->extractFromAjaxResponse($response)->message($amazonImport->getDebugs());
        } catch (Exception $exception) {
            $response = AjaxResponseOnce::onlyAnError($exception->getMessage());
            $this->module->log->extractFromAjaxResponse($response);
        }

        exit($response);
    }

    private function getOrderListApi(): Generator
    {
        $statuses = $this->order_statuses;
        $lastUpdateAfter = date('c', strtotime('now - 1 hour'));
        $lastUpdateBefore = date('c', time() - (60 * 4)); // Now - 4 minutes
        if ($this->lastImportTime) {
            $lastUpdateAfter = $this->lastImportTime;
        }

        $lastUpdateAfter = gmdate('Y-m-d\TH:i:s\Z', strtotime($lastUpdateAfter));
        $this->lastUpdatedBefore = gmdate('Y-m-d\TH:i:s\Z', strtotime($lastUpdateBefore));

        $this->module->log->message(sprintf(
            'Fetching orders from %s to %s. Status %s',
            $lastUpdateAfter,
            $this->lastUpdatedBefore,
            implode(', ', $statuses)
        ));

        return $this->saasHelper->getOrdersAll(
            [],
            null,
            null,
            $lastUpdateAfter,
            $this->lastUpdatedBefore,
            $statuses,
            null,
            null,
            100,
            20,
            null,
            $this->apiDataCarrier
        );
    }

    protected function saveUpperCapTime()
    {
        $upperCap = $this->lastUpdatedBefore;
        if ($this->apiDataCarrier && $this->apiDataCarrier['last_updated_before']) {
            // API return the different upper cap than the one in the request
            $upperCap = $this->apiDataCarrier['last_updated_before'];
        }
        Configuration::updateValue(OrderKey::CONFIG_LAST_ORDER_IMPORT_TIME, $upperCap);
    }

    private function resolveInputStatus(): array
    {
        return [
            Model\Order::ORDER_STATUS_UNSHIPPED,
            Model\Order::ORDER_STATUS_PARTIALLY_SHIPPED,
            Model\Order::ORDER_STATUS_SHIPPED,
        ];
        // 2023-05-31: Remove the advanced option to choose the status to import
    }
}
