<?php
/**
 * ToolEAmazonMarketOrderListingController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\Model;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketOrderListingController extends TooleBaseAdminController
{
    public static $errorMsgs = [];
    public static $warningMsgs = [];
    public static $orders = [];

    public function __construct()
    {
        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'tools_amazon_order/';
        $this->tpl_folder = 'tools_amazon_order/';
        $this->bootstrap = true;
        $this->class_name = 'ToolEAmazonMarketOrderListing';

        $this->bulk_actions = [
            'import' => [
                'text' => $this->trans(
                    'Import',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'icon' => 'icon-trash',
            ],
        ];

        $lastImport = AmazonMarketConfiguration::get(OrderKey::CONFIG_LAST_ORDER_IMPORT_TIME);
        if (!empty($lastImport)) {
            $this->informations[] = sprintf('%s: %s', $this->trans('Last Imported By Cron', [], 'Modules.Tooleamazonmarkettool.Admin'), $lastImport);
        }
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);

        $this->context->controller->addCSS(_PS_MODULE_DIR_ . $this->module->name . '/views/css/order/order.css');
        $this->context->controller->addJS(_PS_MODULE_DIR_ . $this->module->name . '/views/js/order/order.js');
        Media::addJsDef(['tooleImportController' => $this->context->link->getAdminLink('ToolEAmazonMarketOrderImport')]);
        Media::addJsDefL(
            'toole_unexpected_error',
            $this->trans(
                'An unexpected error has occurred, please contact support.',
                [],
                'Modules.Tooleamazonmarkettool.Admin'
            )
        );
    }

    public function renderList()
    {
        parent::renderList();

        /**
         * Order List
         */
        $tpl = $this->context->smarty->createTemplate(
            $this->getTemplatePath() . 'order/order-table.tpl'
        );
        return $tpl->assign($this->tpl_list_vars)->assign([
            'is_ps17' => !version_compare(_PS_VERSION_, '1.7', '<'),
            'list' => $this->_list,
            'past_selectable' => 0,
            'imgPath' => $this->images,
            'amzStatuses' => [
                'All' => 'All',
                'Shipped' => Model\Order::ORDER_STATUS_SHIPPED,
                'Unshipped' => Model\Order::ORDER_STATUS_UNSHIPPED,
                'PartiallyShipped' => Model\Order::ORDER_STATUS_PARTIALLY_SHIPPED,
            ],
        ])->fetch();
    }

    public function ajaxProcessFetchOrder()
    {
        $this->module->log->setLog('Fetch Amazon Orders');
        $orders = $this->getOrderListApi();
        $nextToken = '';
        if ($orders instanceof Model\OrdersList) {
            foreach ($orders->getOrders() as $order) {
                if ($order->getIsReplacementOrder()) {
                    self::$warningMsgs[] = sprintf(
                        $this->trans('Order ID (%s) has been replaced by ID (%s)', [], 'Modules.Tooleamazonmarkettool.Admin'),
                        $order->getAmazonOrderId(),
                        $order->getReplacedOrderId()
                    );
                    continue;
                }
                $this->displayOrder($order);
            }
            $nextToken = $orders->getNextToken();
        }

        $this->module->log->success(sprintf('%s orders fetched', count(self::$orders)));

        exit(json_encode([
            'orders' => self::$orders,
            'count' => count(self::$orders),
            'error' => count(self::$errorMsgs) > 0,
            'errors' => self::$errorMsgs,
            'warning' => count(self::$warningMsgs) > 0,
            'warnings' => self::$warningMsgs,
            'next_token' => $nextToken,
        ]));
    }

    private function getOrderListApi(): ?Model\OrdersList
    {
        if ($nextToken = Tools::getValue('next_token')) {
            $date1 = null;
            $date2 = null;
            $statuses = null;
        } else {
            $dateFormat = 'Y-m-d\TH:i:s\Z';
            $date1 = str_replace('-', '/', Tools::getValue('from'));
            $date2 = str_replace('-', '/', Tools::getValue('to'));
            if (date('Ymd', strtotime($date2)) >= date('Ymd') || empty($date2)) {
                $date1 = gmdate($dateFormat, strtotime($date1));
                $date2 = gmdate($dateFormat, strtotime('now - 15 min'));
            } else {
                $date1 = gmdate($dateFormat, strtotime($date1 . ' 00:00:00'));
                $date2 = gmdate($dateFormat, strtotime($date2 . ' 23:59:59'));
            }
            $statuses = $this->resolveInputOrderStatus(Tools::getValue('status'));
            $nextToken = null;
        }

        $this->module->log->message(sprintf(
            'Fetch orders from %s to %s. Status %s',
            $date1,
            $date2,
            is_array($statuses) ? implode(', ', $statuses) : ''
        ));

        try {
            $amzResponse = $this->saasHelper->getOrders(
                [],
                $date1,
                $date2,
                null,
                null,
                $statuses,
                null,
                null,
                100,
                $nextToken
            );

            return $amzResponse->getAmazonData();
        } catch (Exception $exception) {
            self::$errorMsgs[] = $exception->getMessage();
            $this->module->log->error($exception->getMessage());

            return null;
        }
    }

    private function resolveInputOrderStatus($status): array
    {
        $availableStatuses = [
            Model\Order::ORDER_STATUS_UNSHIPPED,
            Model\Order::ORDER_STATUS_PARTIALLY_SHIPPED,
            Model\Order::ORDER_STATUS_SHIPPED,
        ];
        if ($status == 'All' || !in_array($status, $availableStatuses)) {
            return $availableStatuses;
        }

        return [$status];
    }

    private function displayOrder(Model\Order $order)
    {
        $amzOrderId = $order->getAmazonOrderId();
        $psOrder = TooleAmazonMarketAmazonOrder::isExistingImportedOrderByThisModule($amzOrderId);
        $psOrderId = $psOrder ? $psOrder->id : 0;
        $formatPrice = $this->formatPrice($order->getOrderTotal()->getAmount(), $order->getOrderTotal()->getCurrencyCode());
        self::$orders[$amzOrderId] = [
            'id' => $amzOrderId,
            'flag_src' => "{$this->images}geo_flags/{$order->getMarketplaceId()}.png",
            'date' => Tools::displayDate(date('Y-m-d H:i:s', strtotime($order->getPurchaseDate()))),
            'imported' => (bool) $psOrderId,
            'ps_id' => $psOrderId,
            'ps_url' => !$psOrderId ? '' :
                $this->context->link->getAdminLink('AdminOrders', true, [], ['id_order' => $psOrderId, 'vieworder' => 1]),
            'status' => $order->getOrderStatus(),
            'pending' => $order->getOrderStatus() == Model\Order::ORDER_STATUS_PENDING,
            'canceled' => $order->getOrderStatus() == Model\Order::ORDER_STATUS_CANCELED,
            'customer' => htmlspecialchars($order->getShippingAddress()->getName()),
            'shipping' => $order->getShipServiceLevel(),
            'is_prime' => $order->getIsPrime(),
            'fulfillment' => $order->getFulfillmentChannel(),
            'quantity' => $order->getNumberOfItemsUnshipped() + $order->getNumberOfItemsShipped(),
            'total' => $formatPrice ? $formatPrice['price'] : $order->getOrderTotal()->getAmount(),
            'currency' => $formatPrice ? $formatPrice['currency'] : $order->getOrderTotal()->getCurrencyCode(),
        ];
    }

    private function formatPrice($totalPrice, $currency): ?array
    {
        $displayCurrency = $currency;
        $displayPrice = $totalPrice;

        /*$originCur = new Currency($this->context->currency->id);
        $currencyFrom = Currency::getIdByIsoCode($currency);
        if (!$currencyFrom) {
            return null;
        }
        $toCur = new Currency($currencyFrom);
        if (!Validate::isLoadedObject($toCur)) {
            return null;
        }

        if (Tools::strtoupper($this->context->currency->iso_code) != Tools::strtoupper($currency)) {
            $displayCurrency = sprintf('%s &gt; %s', $displayCurrency, $this->context->currency->iso_code);
            $displayPrice = Tools::convertPriceFull($totalPrice, $toCur, $originCur);
        }*/
        return [
            'price' => $displayPrice,
            'currency' => $displayCurrency,
        ];
    }
}
