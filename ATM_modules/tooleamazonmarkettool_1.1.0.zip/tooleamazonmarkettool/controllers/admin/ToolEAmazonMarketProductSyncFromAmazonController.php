<?php
/**
 * ToolEAmazonMarketProductSyncFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\ReportType;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\CatalogSyncFromAmazon;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\CatalogKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Log\Log;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponse;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketProductSyncFromAmazonController extends TooleBaseAdminController
{
    private $entityId;

    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'catalog/amazon_sync/';
        $this->tpl_folder = 'catalog/amazon_sync/';
        $this->bootstrap = true;
        $this->class_name = 'ToolEAmazonMarketProductSyncFromAmazon';
        $this->module->log = new Log(Tools::getValue('logId', null));
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);
    }

    public function postProcess()
    {
        if (Tools::isSubmit('submitBulksyncAll' . $this->table)) {
            $ids = Tools::getValue('idBox');
            if (!empty($ids) && $this->entityId) {
                foreach ($ids as $id) {
                    TooleAmazonMarketAmazonProduct::syncProduct($id, $this->entityId);
                }
            }
            $this->redirectAdminToole();
        }
        parent::postProcess();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $this->context->controller->addCSS(_PS_MODULE_DIR_ . $this->module->name . '/views/css/catalog/amazon_sync.css');
        $this->context->controller->addJS(_PS_MODULE_DIR_ . $this->module->name . '/views/js/catalog/amazon_sync.js');
    }

    public function renderList()
    {
        $lastStatistic = Configuration::get(Key::LAST_STATISTICS_REPORT_DATA, null, $this->shop_id_group, $this->shop_id);
        if ($lastStatistic) {
            $lastStatistic = json_decode($lastStatistic);
            $lastReport = $lastStatistic->{ReportType::GET_MERCHANT_LISTINGS_ALL_DATA['name']} ?? null;
            $statistic = $lastReport->{$this->active_marketplace} ?? null;

            if ($statistic) {
                $flow = new CatalogSyncFromAmazon($this->module, $this->saasHelper, Tools::getShopDomain(), null, ReportType::GET_MERCHANT_LISTINGS_ALL_DATA);

                // add warning for inactive item count
                $flow->addWarningForInactiveItemCount($statistic->inactiveItemCount);

                // add Warning For Rejected Not Exist Count
                $flow->addWarningForRejectedNotExistCount($statistic->rejectedNotExist);

                // add Warning For Rejected Not Enable Sync Count
                $flow->addWarningForRejectedNotEnableSyncCount($statistic->rejectedNotEnableSync);

                // add warning / confirmation for imported offers
                $flow->addNotificationsForImportedOffers($statistic->imported);
                $lastFetch = AmazonMarketConfiguration::get(CatalogKey::LAST_FETCH_CATALOG_REPORT);
                if ($lastFetch) {
                    $lastFetch = date('Y-m-d H:i:s', $lastFetch);
                    $infos[] = $this->trans('The last statistic report was fetched at %refreshDate%', ['%refreshDate%' => $lastFetch], 'Modules.Tooleamazonmarkettool.Admin');
                }
                $lastReportMsgs = [
                    'infos' => $infos ?? [],
                    'errors' => $flow->getErrors(),
                    'warnings' => $flow->getWarnings(),
                    'confirmations' => $flow->getConfirmations(),
                ];
            }
        }

        return $this->context->smarty->createTemplate(
            $this->getTemplatePath() . 'catalog/amazon_sync/manual_sync.tpl'
        )->assign([
            'img_loader' => $this->images . 'loading.gif',
            'imported_tab' => $this->context->link->getAdminLink(
                'ToolEAmazonMarketProductsImportedFromAmazon'
            ),
            'lastReportMsgs' => $lastReportMsgs ?? [],
        ])->fetch();
    }

    public function ajaxProcessFetchData()
    {
        $this->module->log->setLog('Refresh the offer list from Amazon.');
        $uuid = Tools::getValue('uuid', '');
        $additionalParams = Tools::getValue('params', []);
        if ($uuid) {
            // All subsequence calls must wait for the report to complete
            sleep(15);
        }

        $reportType = ReportType::GET_MERCHANT_LISTINGS_ALL_DATA;
        $flow = new CatalogSyncFromAmazon($this->module, $this->saasHelper, Tools::getShopDomain(), $uuid, $reportType, null, $this->entityId, $additionalParams);
        try {
            if ($flow->requestReport()) {
                $this->module->log->message([
                    'Processing data, please wait.',
                    sprintf('uuid: %s', $flow->getReportResult()->getUuid()),
                    'action: parseData',
                    sprintf('resourceUrl: %s', $flow->getReportResult()->getDocumentUrl()),
                    sprintf('contentType: %s', $reportType['contentType']),
                    sprintf('compressAlgorithm: %s', $flow->getReportResult()->getDocumentCompressionAlgorithm()),
                ]);
                exit(new AjaxResponse(
                    [], [],
                    [$this->trans('Processing data, please wait.', [], 'Modules.Tooleamazonmarkettool.Admin')],
                    true,
                    true,
                    [
                        'uuid' => $flow->getReportResult()->getUuid(),
                        'action' => 'parseData',
                        'resourceUrl' => $flow->getReportResult()->getDocumentUrl(),
                        'contentType' => $reportType['contentType'],
                        'compressAlgorithm' => $flow->getReportResult()->getDocumentCompressionAlgorithm(),
                        'data' => $flow->getReportResult()->getData(),
                    ]
                ));
            }

            $this->module->log->message([
                'Retrieving data, please wait.',
                sprintf('uuid: %s', $flow->getReportResult()->getUuid()),
            ]);
            exit(new AjaxResponse(
                [],
                [],
                [$this->trans('Retrieving data, please wait.', [], 'Modules.Tooleamazonmarkettool.Admin')],
                true,
                true,
                [
                    'uuid' => $flow->getReportResult()->getUuid(),
                    'logId' => $this->module->log->getScheduler(),
                ]
            ));
        } catch (Exception $exception) {
            $this->module->log->error(sprintf('Failed to retrieve data from Amazon: %s', $exception->getMessage()));
            exit(new AjaxResponse(
                [$this->trans('Failed to retrieve data from Amazon', [], 'Modules.Tooleamazonmarkettool.Admin'), $exception->getMessage()],
                [], [], true, false, null
            ));
        }
    }

    public function ajaxProcessParseData()
    {
        $this->module->log->setLog('Processing product list');
        $data = Tools::getValue('data');
        $contentType = Tools::getValue('contentType');
        $uuid = Tools::getValue('uuid');
        if (!$data) {
            $this->module->log->error('Invalid request');
            exit(new AjaxResponse(
                [$this->trans('Invalid request', [], 'Modules.Tooleamazonmarkettool.Admin')],
                [], [], true, false, null
            ));
        }
        $page = (int) $data['next_page'] ?? null;

        $flow = new CatalogSyncFromAmazon($this->module, $this->saasHelper, Tools::getShopDomain(), $uuid, ReportType::GET_MERCHANT_LISTINGS_ALL_DATA, null, $this->entityId);
        try {
            $flow->importAmazonOffers($data['data'] ?? []); // parse data

            if ($page > 0) { // get parse data with next_page
                $response = new AjaxResponse(
                    $flow->getErrors(),
                    $flow->getWarnings(),
                    $flow->getConfirmations(),
                    true,
                    false,
                    [
                        'statistics' => $flow->getStatistic(),
                    ]
                );
                $this->module->log->extractFromAjaxResponse($response);

                $statistics = $flow->updateStatistics($flow->getStatistic(), $data['statistic'] ?? []);
                exit(new AjaxResponse(
                    $flow->getErrors(),
                    $flow->getWarnings(),
                    $flow->getConfirmations(),
                    true,
                    true,
                    [
                        'uuid' => $uuid,
                        'action' => 'fetchData',
                        'contentType' => $contentType,
                        'params' => ['page' => $page, 'statistic' => $statistics],
                    ]
                ));
            }
        } catch (Exception $exception) {
            $this->module->log->error($exception->getMessage());
            exit(new AjaxResponse([$exception->getMessage()], [], [], true, false, null));
        }

        /* storage last statistic report data */
        $flow->storageLastStatisticReportData($this->active_marketplace, $data['statistic'] ?? []);

        $response = new AjaxResponse(
            $flow->getErrors(),
            $flow->getWarnings(),
            $flow->getConfirmations(),
            true,
            false,
            [
                'statistics' => $flow->getStatistic(),
            ]
        );
        $this->module->log->extractFromAjaxResponse($response);

        AmazonMarketConfiguration::updateValue(CatalogKey::LAST_FETCH_CATALOG_REPORT, time());

        exit($response);
    }
}
