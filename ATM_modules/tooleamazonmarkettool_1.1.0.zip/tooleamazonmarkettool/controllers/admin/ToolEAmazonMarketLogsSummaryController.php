<?php
/**
 *  2023 TOOLE - Inter-soft.COM
 *  All rights reserved.
 *
 *  DISCLAIMER
 *
 *  Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketLogsSummaryController extends TooleBaseAdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->context = Context::getContext();
        $this->bootstrap = true;
        $this->list_no_link = true;
        $this->class_name = 'ToolEAmazonMarketLogsSummary';
        $this->multishop = true;
        $this->override_folder = 'logs/summaries/';
        $this->tpl_folder = 'logs/summaries/';

        $this->table = Database::TABLE_LOGS;
        $this->list_id = 'id';
        $this->identifier = 'id';

        $this->_join =
            'LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '` ld ON (ld.id_log = a.id)';

        $this->_select = ' IF(a.is_cron_mode = 1, "Yes", "No") as is_cron_mode
            ,COUNT(CASE WHEN ld.type = 0 THEN 1 END) AS total_message
            ,COUNT(CASE WHEN ld.type = 1 THEN 1 END) AS total_success
            ,COUNT(CASE WHEN ld.type = 2 THEN 1 END) AS total_error
            ,COUNT(CASE WHEN ld.type = 3 THEN 1 END) AS total_warning
        ';
        $this->_orderBy = 'date_add';
        $this->_orderWay = 'DESC';
        $this->_group = 'GROUP BY a.id';
        $this->fields_list = [
            'id' => [
                'title' => $this->trans(
                    'Id',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'center',
                'class' => 'fixed-width-sm',
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
                'filter_key' => 'a!id',
                'order_key' => 'a!id',
            ],
            'title' => [
                'title' => $this->trans(
                    'Title',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'align' => 'center',
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
                'filter_key' => 'a!title',
                'order_key' => 'a!title',
            ],
            'is_cron_mode' => [
                'title' => $this->trans(
                    'Cron Mode',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'align' => 'center',
                'orderby' => true,
                'search' => false,
                'order_key' => 'a!is_cron_mode',
            ],
            'total_message' => [
                'title' => $this->trans(
                    'Messages',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'align' => 'center',
                'orderby' => false,
                'search' => false,
            ],
            'total_success' => [
                'title' => $this->trans(
                    'Successes',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'align' => 'center',
                'orderby' => false,
                'search' => false,
            ],
            'total_error' => [
                'title' => $this->trans(
                    'Errors',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'align' => 'center',
                'orderby' => false,
                'search' => false,
            ],
            'total_warning' => [
                'title' => $this->trans(
                    'Warnings',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'align' => 'center',
                'orderby' => false,
                'search' => false,
            ],
            'date_add' => [
                'title' => $this->trans(
                    'Created date',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                ),
                'width' => 'auto',
                'orderby' => true,
                'search' => true,
                'type' => 'datetime',
                'filter_key' => 'a!date_add',
                'order_key' => 'a!date_add',
            ],
        ];
        $this->addRowAction('detail');
    }

    public function renderList()
    {
        $tpl = $this->createTemplate('modal.tpl');
        return parent::renderList() . $tpl->fetch();
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $this->context->controller->addCSS(_PS_MODULE_DIR_ . $this->module->name . '/views/css/log/summary.css');
        $this->context->controller->addJS(_PS_MODULE_DIR_ . $this->module->name . '/views/js/log/summary.js');
    }

    /**
     * @throws SmartyException
     */
    public function displayDetailLink($token, $id): string
    {
        $tpl = $this->createTemplate('detail_link.tpl');
        $tpl->assign([
            'action' => $this->trans(
                'Detail',
                [],
                'Modules.Tooleamazonmarkettool.Admin'
            ),
            'id' => $id,
        ]);
        return $tpl->fetch();
    }

    public function ajaxProcessGetDetails(): void
    {
        $id = Tools::getValue('id_log');
        $sql = new DbQuery();
        $sql->from(Database::TABLE_LOG_DETAILS, 'ld');
        $sql->select('ld.`id_feed`, ld.`message`, ld.`type`, ld.`date_start`, ld.`date_stop`');
        $sql->where('id_log = ' . $id);
        try {
            $details = Db::getInstance()->executeS($sql);
            foreach ($details as $k => $detail) {
                if ($detail['id_feed']) {
                    $feed = new TooleAmazonMarketAmazonFeed($detail['id_feed']);
                    if (Validate::isLoadedObject($feed)) {
                        if ($feed->content_location) {
                            $details[$k]['content_location'] = $this->context->link->getAdminLink('ToolEAmazonMarketFeed') .
                                $this->submit_action . '&id=' . $feed->id . '&action=downloadFeed';
                        }
                        if ($feed->result_location) {
                            $details[$k]['result_location'] = $this->context->link->getAdminLink('ToolEAmazonMarketFeed') .
                                $this->submit_action . '&id=' . $feed->id . '&action=downloadResult';
                        }
                    }
                }
            }
            exit(json_encode($details));
        } catch (Exception $e) {
            exit(json_encode([]));
        }
    }
}
