<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param TooleAmazonMarketTool $module
 *
 * @return bool
 */
function upgrade_module_1_0_3($module)
{
    $result = true;
    $listFields = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '`');

    if (is_array($listFields)) {
        $isFieldIsMappedExist = false;

        foreach ($listFields as $field) {
            if ($field['Field'] === 'id_product') {
                $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` DROP COLUMN `id_product`');
            }

            if ($field['Field'] === 'id_product_attribute') {
                $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` DROP COLUMN `id_product_attribute`');
            }

            if ($field['Field'] === 'is_mapped') {
                $isFieldIsMappedExist = true;
            }
        }

        if (!$isFieldIsMappedExist) {
            $result &= (bool) Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` ADD COLUMN `is_mapped` tinyint(1) DEFAULT NULL AFTER `amz_product_desc`');
        }
    }

    return $result;
}
