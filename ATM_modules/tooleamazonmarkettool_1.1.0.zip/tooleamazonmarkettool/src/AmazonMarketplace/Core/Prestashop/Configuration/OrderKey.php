<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

if (!defined('_PS_VERSION_')) {
    exit;
}

class OrderKey extends Key
{
    const CRON_ENABLE_IMPORT_ORDERS = 'TOOLE_AMAZON_MARKET_ENABLE_IMPORT_ORDERS';
    const CRON_IMPORT_ORDERS_ADVANCED = self::CRON_ENABLE_IMPORT_ORDERS . '_ADVANCED';
    const ENABLE_ACKNOWLEDGE_ORDERS = 'TOOLE_AMAZON_MARKET_ENABLE_ACKNOWLEDGE_ORDERS'; /* depend on import orders */
    const IMPORT_ORDER_STATUS = 'TOOLE_AMAZON_MARKET_IMPORT_ORDER_STATUS';
    const INCOMING_CARRIERS = 'TOOLE_AMAZON_MARKET_ORDER_INCOMING_CARRIERS';

    const ENABLE_FULFILL_ORDERS = 'TOOLE_AMAZON_MARKET_ENABLE_FULFILL_ORDERS';
    const FULFILL_ORDER_STATUS = 'TOOLE_AMAZON_MARKET_FULFILL_ORDER_STATUS';
    const FULFILL_BACKOFF_DAY = 'TOOLE_AMAZON_MARKET_FULFILL_BACKOFF_DAY'; /* days to go back when fulfill order, not implemented yet */
    const OUTGOING_CARRIERS = 'TOOLE_AMAZON_MARKET_ORDER_OUTGOING_CARRIERS';

    // Shared config name
    const CRON_ORDERS_IMPORT_TIME = 'TOOLE_AMT_CRON_ORDERS_IMPORT_TIME';
    const CRON_ORDERS_FULFILL_TIME = 'TOOLE_AMT_CRON_ORDERS_FULFILL_TIME';
    const CRON_ORDERS_ACKNOWLEDGE_TIME = 'TOOLE_AMT_CRON_ORDERS_ACKNOWLEDGE_TIME';

    const CONFIG_LAST_ORDER_IMPORT_TIME = 'TOOLE_AMT_CONFIG_LAST_TIME_IMPORT_ORDER';
}
