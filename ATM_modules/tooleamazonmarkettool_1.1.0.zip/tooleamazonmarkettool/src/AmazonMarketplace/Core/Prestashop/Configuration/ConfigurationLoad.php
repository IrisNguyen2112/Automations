<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

use Carrier;
use CarrierCore;
use Configuration;
use Context;
use OrderState;
use PrestaShopBundle\Translation\TranslatorComponent;
use Toole\Module\Amazon\Client\Model\Order;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\Rule;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\RuleByPrice;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\RuleByWeight;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\FulfillmentCarrierDefault;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\FulfillmentCarrierWithShippingMethod;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\OrderImportCarrierExpress;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\OrderImportCarrierStandard;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Url;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use TooleAmazonMarketTool;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ConfigurationLoad
{
    /**
     * @var TooleAmazonMarketTool
     */
    protected $module;

    /** @var Context */
    protected $context;

    /** @var TranslatorComponent|null */
    protected $translator;

    public function __construct(TooleAmazonMarketTool $module)
    {
        $this->module = $module;
        $this->context = $module->getContext();
        $this->translator = $this->module->getTranslator();
    }

    public function getTplVars(): array
    {
        return [
            'url' => $this->module->getContextLink()->getAdminLink('AdminModules', true, [], [
                'configure' => $this->module->name,
                'tab_module' => $this->module->tab,
                'module_name' => $this->module->name,
            ]),
            'images_url' => Url::getModuleUrl($this->module->name) . 'views/img/',
            'help_center_url' => $this->module->help_center_url,
            'welcome_image_url' => $this->getModuleWelcomeImage(),
            'languages' => $this->context->controller->getLanguages(),
            'fields_constant' => $this->getModuleConfigFieldsConstant(),
            'defined_fields' => $this->getModuleConfigDefinedFields(),
            'fields_value' => $this->getModuleConfigFieldsValues(),
            'account' => [
                'regionsWMkps' => Region::getAllRegionsWithMkps(),
                'authorizedRegions' => AmazonMarketConfiguration::getAmazonAccountAuthorization(),
                // ToolEAmazonMarketAdminConfigController
                'controller' => $this->context->link->getAdminLink('ToolEAmazonMarketAdminConfig'),
            ],
            'orders' => [
                'carriers' => [
                    'ps_carriers' => Carrier::getCarriers($this->context->language->id, false, false, false, null, CarrierCore::ALL_CARRIERS),
                    'incoming_amazon_carriers' => array_merge(
                        OrderImportCarrierStandard::CARRIER_CODES,
                        OrderImportCarrierExpress::CARRIER_CODES
                    ),
                    'outgoing_amazon_carriers' => FulfillmentCarrierDefault::CARRIER_CODES,
                    'carrier_need_shipping_method' => $this->resolveCarrierNeedShippingMethod(),
                ],
            ],
            'TOOLE_AMAZONMARKETTOOL_SERVICE_API_URL' => Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SERVICE_API_URL'),
            'TOOLE_AMAZONMARKETTOOL_SERVICE_API_KEY' => Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SERVICE_API_KEY'),
            'TOOLE_AMAZONMARKETTOOL_AMAZON_AUTH_API_URL' => Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_AMAZON_AUTH_API_URL'),
        ];
    }

    protected function getModuleConfigDefinedFields(): array
    {
        return [
            'order_state_list' => OrderState::getOrderStates($this->context->language->id),
            'catalog_sync_time_options' => AmazonMarketConfiguration::$catalog_sync_time_options,
            'order_sync_time_options' => AmazonMarketConfiguration::$order_sync_time_options,
            'amz_order_statuses' => [
                'All' => 'All',
                'Shipped' => Order::ORDER_STATUS_SHIPPED,
                'Unshipped' => Order::ORDER_STATUS_UNSHIPPED,
                'PartiallyShipped' => Order::ORDER_STATUS_PARTIALLY_SHIPPED,
            ],
        ];
    }

    protected function getModuleConfigFieldsValues(): array
    {
        $minCronTime = AmazonMarketConfiguration::CRON_TIME_MIN;
        $moduleConfigs = [
            CatalogKey::ENABLE_SYNC_FROM_AMZ => AmazonMarketConfiguration::get(CatalogKey::ENABLE_SYNC_FROM_AMZ) ?: 0,
            CatalogKey::ENABLE_SYNC_FROM_PS => AmazonMarketConfiguration::get(CatalogKey::ENABLE_SYNC_FROM_PS) ?: 0,
            OrderKey::CRON_ENABLE_IMPORT_ORDERS => AmazonMarketConfiguration::get(OrderKey::CRON_ENABLE_IMPORT_ORDERS) ?: 0,
            OrderKey::ENABLE_FULFILL_ORDERS => AmazonMarketConfiguration::get(OrderKey::ENABLE_FULFILL_ORDERS) ?: 0,
            OrderKey::IMPORT_ORDER_STATUS => AmazonMarketConfiguration::get(OrderKey::IMPORT_ORDER_STATUS),
            OrderKey::FULFILL_ORDER_STATUS => AmazonMarketConfiguration::get(OrderKey::FULFILL_ORDER_STATUS),
            CatalogKey::CRON_CATALOG_SYNC_FROM_AMZ_TIME => AmazonMarketConfiguration::get(CatalogKey::CRON_CATALOG_SYNC_FROM_AMZ_TIME, null, null, $minCronTime),
            CatalogKey::CRON_CATALOG_SYNC_FROM_PS_TIME => AmazonMarketConfiguration::get(CatalogKey::CRON_CATALOG_SYNC_FROM_PS_TIME, null, null, $minCronTime),
            OrderKey::CRON_ORDERS_IMPORT_TIME => AmazonMarketConfiguration::get(OrderKey::CRON_ORDERS_IMPORT_TIME, null, null, $minCronTime),
            OrderKey::CRON_ORDERS_FULFILL_TIME => AmazonMarketConfiguration::get(OrderKey::CRON_ORDERS_FULFILL_TIME, null, null, $minCronTime),
            ShippingKey::SHIPPING_TEMPLATES => $this->getShippingTemplates(),
            OrderKey::CRON_IMPORT_ORDERS_ADVANCED => $this->getImportOrderAdvanced(),
            Key::AMZ_AUTH_COMBO => AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO, null, null, []),
        ];

        return array_merge($moduleConfigs,
            ['hasAScheduledTask' => $this->hasOneScheduledTaskAtLeast($moduleConfigs)],
            $this->getConfigurationCarriers(OrderKey::OUTGOING_CARRIERS),
            $this->getConfigurationCarriers(OrderKey::INCOMING_CARRIERS)
        );
    }

    private function getModuleConfigFieldsConstant(): array
    {
        return [
            'enable_sync_from_amz' => CatalogKey::ENABLE_SYNC_FROM_AMZ,
            'enable_sync_from_ps' => CatalogKey::ENABLE_SYNC_FROM_PS,
            'config_cron_from_amz_time' => CatalogKey::CRON_CATALOG_SYNC_FROM_AMZ_TIME,
            'config_cron_from_ps_time' => CatalogKey::CRON_CATALOG_SYNC_FROM_PS_TIME,
            'enable_import_orders' => OrderKey::CRON_ENABLE_IMPORT_ORDERS,
            'enable_fulfill_orders' => OrderKey::ENABLE_FULFILL_ORDERS,
            'cron_import_orders_advanced' => OrderKey::CRON_IMPORT_ORDERS_ADVANCED,
            'incoming_carriers' => OrderKey::INCOMING_CARRIERS,
            'outgoing_carriers' => OrderKey::OUTGOING_CARRIERS,
            'import_order_status' => OrderKey::IMPORT_ORDER_STATUS,
            'fulfill_order_status' => OrderKey::FULFILL_ORDER_STATUS,
            'config_cron_import_order_time' => OrderKey::CRON_ORDERS_IMPORT_TIME,
            'config_cron_fulfill_order_time' => OrderKey::CRON_ORDERS_FULFILL_TIME,
            'shipping_templates' => ShippingKey::SHIPPING_TEMPLATES,
            'auth_combo' => Key::AMZ_AUTH_COMBO,
        ];
    }

    private function getModuleWelcomeImage(): string
    {
        $iso_code = $this->context->language->iso_code;
        $base_url = Url::getModuleUrl($this->module->name) . 'views/img/';
        if (file_exists(_PS_ROOT_DIR_ . $base_url . 'module-features-' . $iso_code . '.png')) {
            return $base_url . 'module-features-' . $iso_code . '.png';
        }
        return $base_url . 'module-features.png';
    }

    private function getConfigurationCarriers($key): array
    {
        $carriers = AmazonMarketConfiguration::get($key);

        if ($carriers) {
            $carrierList = $carriers;
        }
        return [$key => $carrierList ?? []];
    }

    private function resolveCarrierNeedShippingMethod(): array
    {
        $result = [];
        foreach (FulfillmentCarrierWithShippingMethod::CARRIERS as $carriers) {
            foreach ($carriers as $carrier) {
                if (!isset($result[$carrier['carrier']])) {
                    $result[$carrier['carrier']] = $carrier['method'];
                } else {
                    $result[$carrier['carrier']] = array_unique(array_merge($result[$carrier['carrier']], $carrier['method']));
                }
            }
        }
        return $result;
    }

    public function getShippingTemplates(): array
    {
        $rulePrice = [];
        $ruleWeight = [];
        $stConfig = AmazonMarketConfiguration::get(ShippingKey::SHIPPING_TEMPLATES, null, null, []);
        $stConfig = is_array($stConfig) ? $stConfig : [];
        $rules = $stConfig['rules'] ?? [];

        foreach ($rules as $ruleType => $rulesByType) {
            foreach ($rulesByType as $ruleId => $rule) {
                if ($ruleType == Rule::TYPE_WEIGHT) {
                    $ruleWeight[$ruleId] = new RuleByWeight($rule['min'] ?? 0, $rule['max'] ?? 0, $rule['unit'] ?? '', $rule['name'] ?? '');
                } else {
                    $rulePrice[$ruleId] = new RuleByPrice($rule['min'] ?? 0, $rule['max'] ?? 0, $rule['name'] ?? '');
                }
            }
        }

        return [
            'enable' => $stConfig['enable'] ?? false,
            'types' => [
                Rule::TYPE_PRICE => [
                    'displayType' => $this->translator->trans('Price', [], 'Modules.Tooleamazonmarkettool.Admin'),
                    'requireUnit' => false,
                ],
                Rule::TYPE_WEIGHT => [
                    'displayType' => $this->translator->trans('Weight', [], 'Modules.Tooleamazonmarkettool.Admin'),
                    'requireUnit' => true,
                ],
            ],
            'use_type' => $stConfig['use_type'] ?? Rule::TYPE_PRICE,
            'use_unit' => $stConfig['use_unit'] ?? Configuration::get('PS_WEIGHT_UNIT'),
            'rules' => [
                Rule::TYPE_PRICE => $rulePrice,
                Rule::TYPE_WEIGHT => $ruleWeight,
            ],
        ];
    }

    private function getImportOrderAdvanced(): array
    {
        $config = AmazonMarketConfiguration::get(OrderKey::CRON_IMPORT_ORDERS_ADVANCED) ?: [];

        if ($config && is_array($config)) {
            return $config;
        }

        return [];
    }

    private function hasOneScheduledTaskAtLeast(array $moduleConfigs): int
    {
        if ($moduleConfigs[CatalogKey::ENABLE_SYNC_FROM_PS]) {
            return 1;
        }
        if ($moduleConfigs[CatalogKey::ENABLE_SYNC_FROM_AMZ]) {
            return 1;
        }
        if ($moduleConfigs[OrderKey::CRON_ENABLE_IMPORT_ORDERS]) {
            return 1;
        }
        if ($moduleConfigs[OrderKey::ENABLE_FULFILL_ORDERS]) {
            return 1;
        }

        return 0;
    }
}
