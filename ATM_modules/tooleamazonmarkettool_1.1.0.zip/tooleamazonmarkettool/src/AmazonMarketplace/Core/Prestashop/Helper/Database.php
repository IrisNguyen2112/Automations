<?php
/**
 * TooleAmazonMarketPlaceTools
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Helper;

use Db;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Database
{
    const TABLE_AMAZON_ORDERS = 'toole_amt_amazon_orders';
    const TABLE_FILTER_PRODUCTS = 'toole_amt_filter_products';
    const TABLE_FILTER_MANUFACTURERS = 'toole_amt_filter_manufacturers';
    const TABLE_FILTER_SUPPLIERS = 'toole_amt_filter_suppliers';
    const TABLE_FILTER_CATEGORIES = 'toole_amt_filter_categories';
    const TABLE_AMAZON_PRODUCTS = 'toole_amt_amazon_products';
    const TABLE_FEEDS = 'toole_amt_feeds';
    const TABLE_LOGS = 'toole_amt_logs';
    const TABLE_MESSAGES = 'toole_amt_messages';
    const TABLE_LOG_DETAILS = 'toole_amt_log_details';
    const TABLE_AMAZON_ENTITIES = 'toole_amt_entities';

    protected static $tableList = [];

    public static function tableExists($table, bool $use_cache = true): bool
    {
        if (isset(self::$tableList[$table]) && $use_cache) {
            return self::$tableList[$table];
        }

        $query_result = Db::getInstance()->executeS('SHOW TABLES FROM `' . pSQL(_DB_NAME_) . '`', true, false);
        if (!is_array($query_result) || !count($query_result)) {
            return false;
        }

        $tables = [];
        foreach ($query_result as $row) {
            foreach ($row as $columnAsTableName) {
                $tables[$columnAsTableName] = true;
            }
        }
        self::$tableList = $tables;

        return isset(self::$tableList[$table]) && self::$tableList[$table];
    }
}
