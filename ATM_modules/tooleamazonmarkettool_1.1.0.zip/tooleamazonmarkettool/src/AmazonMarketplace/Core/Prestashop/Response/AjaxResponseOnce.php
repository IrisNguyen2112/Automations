<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Response;

if (!defined('_PS_VERSION_')) {
    exit;
}

class AjaxResponseOnce extends AjaxResponse
{
    public function __construct(array $errors, array $warnings, array $messages, $data)
    {
        parent::__construct($errors, $warnings, $messages, false, false, $data);
    }

    public static function onlyAnError($error): AjaxResponseOnce
    {
        return new self([$error], [], [], null);
    }
}
