<?php
/**
 * FulfillmentCarrierWithShippingMethod
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  AmazonMarketConfiguration
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant;

use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Constant;

if (!defined('_PS_VERSION_')) {
    exit;
}

class FulfillmentCarrierWithShippingMethod
{
    const FR = [
        [
            'carrier' => '4PX',
            'method' => ['4PX-Global Express', '4PX-PostLink priority Registered Mail-Li', '4PX-PostLink Standard Registered Mail-Li', '4PX-PostLink Standard2 Registered Mail-Li', '4PX-PostLink Economy Registered Mail-Li', '4PX-PostLink Economy SRM Registered Mail-Li', '4PX-PostLink Standard Ordinary Mail-Li', '4PX-PostLink Standard large letter Ordinary Mail-Li', '4PX-PostLink Economy large letter Ordinary Mail-Li', '4PX-PostLink priority Registered Mail-NOLi', '4PX-PostLink Standard Registered Mail-NOLi', '4PX-PostLink Economy Registered Mail-NOLi', '4PX-PostLink Economy2 Ordinary Mail-Li', '4PX-PostLink Economy2 Registered Mail-Li'],
        ],
        [
            'carrier' => 'China Post',
            'method' => ['China Post e-Courier Packet', 'E courier', 'EMS', 'E-packet', 'Airmail Registered', 'Airmail'],
        ],
        [
            'carrier' => 'Chronopost',
            'method' => ['Chrono 18', 'Chrono 13', 'Chronopost INTL', 'Chrono Express', 'Chrono Classic'],
        ],
        [
            'carrier' => 'COLIS PRIVE',
            'method' => ['Next', 'Trace'],
        ],
        [
            'carrier' => 'Colissimo',
            'method' => ['COLISSIMO Livraison \u00e0 domicile sans signature', 'COLISSIMO Livraison \u00e0 domicile avec signature', 'COLISSIMO Livraison en point relais', 'COLISSIMO EXPERT INTERNATIONAL'],
        ],
        [
            'carrier' => 'DASCHER',
            'method' => ['Targo speed', 'Targo fix', 'Targo flex', 'Targo on site', 'Targo on site plus', 'Targo on site premium'],
        ],
        [
            'carrier' => 'DB Schenker',
            'method' => ['Fretlink'],
        ],
        [
            'carrier' => 'DHL eCommerce',
            'method' => ['PKW-Parcel International Direct-Semi', 'PLT-Parcel International Direct-Standard', 'PLE-Parcel International Direct-Expedited', 'PKG-Packet International Economy', 'PKD-Packet International Standard', 'PPS-Packet Plus International'],
        ],
        [
            'carrier' => 'DPD',
            'method' => ['Predict', 'PDP relais', 'DPD Classique', 'DPD Classique'],
        ],
        [
            'carrier' => 'FRANCE EXPRESS',
            'method' => ['Inter express'],
        ],
        [
            'carrier' => 'GEODIS',
            'method' => ['Livraison en point relais', 'Livraison Same Day', 'Livraison \u00e0 domicile sur rendez vous'],
        ],
        [
            'carrier' => 'GLS',
            'method' => ['Business parcel', 'Flex Delivery', 'Shop Delivery', 'Express', 'Euro Business parcel'],
        ],
        [
            'carrier' => 'Heppner',
            'method' => ['Star date', 'Star plan', 'Star priority', 'Star care'],
        ],
        [
            'carrier' => 'JCEX',
            'method' => ['Jia-Packet', 'EUB', 'Europe-DHL', 'Europe-DPD', 'Europe-UPS', 'UPS Worldwide Saver', 'UPS Worldwide Expedited', 'Fedex IE', 'Fedex IP', 'TNT', 'JP International Express', 'CA International Express', 'US International Express'],
        ],
        [
            'carrier' => 'Kuehne Nagel',
            'method' => ['KN Eurolink envois 1kg jusqu\u00e0 trois palettes', 'KN Eurolink Classic', 'KN Eurolink First', 'KN Eurolink Fix'],
        ],
        [
            'carrier' => 'La Poste',
            'method' => ['Lettre suivie', 'Lettre verte', 'Ecopli', 'Lettre prioritaire', 'Lettre recommand\u00e9e avec AR', 'Lettre recommand\u00e9e sans AR', 'Lettre expert', 'Frequenceo', 'Delivengo'],
        ],
        [
            'carrier' => 'Self Delivery',
            'method' => ['Self Delivery'],
        ],
        [
            'carrier' => 'SF Express',
            'method' => ['E-Commerce Ordinary Parcel-Standard', 'E-Commerce Registered Parcel-Standard', 'E-Commerce Ordinary Parcel-Economy', 'E-Commerce Registered Parcel-Economy', 'E-Commerce Ordinary Parcel-Special Line', 'E-Commerce Registered Parcel-Special Line', 'E-Commerce Express Standard', 'E-Commerce Express Priority', 'E-Commerce Express CD', 'E-Commerce Registered Parcel-LA', 'E-Commerce Registered Parcel-LU Post', 'E-Commerce Ordinary Parcel-BPost', 'Standard Express', 'Economy Express'],
        ],
        [
            'carrier' => 'SFC',
            'method' => ['SFC Global Line-no battery', 'SFC Global Line-with battery'],
        ],
        [
            'carrier' => 'TNT',
            'method' => ['Express National', 'Express National Relais'],
        ],
        [
            'carrier' => 'UPS',
            'method' => ['Standard', 'Express Saver'],
        ],
        [
            'carrier' => 'VIR',
            'method' => ['Livraison à domicile', 'Livraison en point relais'],
        ],
        [
            'carrier' => 'WanB Express',
            'method' => ['WANB EXPRESS', 'WANB Smart Track', 'WANB Semi Track', 'WANB Post Smart', 'WANB Post Economy'],
        ],
        [
            'carrier' => 'XPO',
            'method' => ['Standard'],
        ],
        [
            'carrier' => 'Yanwen',
            'method' => ['AIR ECONOMY MAIL', 'AIR REGISTERED MAIL', 'Direct Line Tracked Packet', 'Direct Line Express'],
        ],
        [
            'carrier' => 'YDH',
            'method' => ['YDH Express Service', 'YDH Standard Service', 'YDH Economy Service'],
        ],
        [
            'carrier' => 'Yun Express',
            'method' => ['YunExpress Global Direct line (standard)-Tracked', 'YunExpress Global Direct line with Battery-Tracked', 'YunExpress Global Direct line non Battery-Tracked', 'YunExpress Global line (standard)-Untracked', 'YunExpress Global Direct line-battery-Untracked', 'YunExpress Global Direct line-no battery-Untracked', 'YunExpress JP Direct Line', 'YunExpress DE SRM Direct Line', 'YunExpress ME Direct Line', 'YunExpress ME Direct Line-DDP'],
        ],
    ];

    const ES = [
        [
            'carrier' => '4PX',
            'method' => ['4PX-Global Express', '4PX-PostLink priority Registered Mail-Li', '4PX-PostLink Standard Registered Mail-Li', '4PX-PostLink Standard2 Registered Mail-Li', '4PX-PostLink Economy Registered Mail-Li', '4PX-PostLink Economy SRM Registered Mail-Li', '4PX-PostLink Standard Ordinary Mail-Li', '4PX-PostLink Standard large letter Ordinary Mail-Li', '4PX-PostLink Economy large letter Ordinary Mail-Li', '4PX-PostLink priority Registered Mail-NOLi', '4PX-PostLink Standard Registered Mail-NOLi', '4PX-PostLink Economy Registered Mail-NOLi', '4PX-PostLink Economy2 Ordinary Mail-Li', '4PX-PostLink Economy2 Registered Mail-Li'],
        ],
        [
            'carrier' => 'China Post',
            'method' => ['China Post e-Courier Packet', 'E courier', 'EMS', 'E-packet', 'Airmail Registered', 'Airmail'],
        ],
        [
            'carrier' => 'Correos',
            'method' => ['Paq Today', 'Paq Premium', 'Paq Estandar', 'Paq Light', 'Paq Retorno', 'Paq Retorno Premium', 'Correo Ordinario', 'Mail Plus'],
        ],
        [
            'carrier' => 'Correos Express',
            'method' => ['Paq24', 'Paq14', 'Paq10', 'PaqEmpresa', 'ePaq', 'Baleares Exp', 'Canarias Exp', 'CanariasAero', 'CanariasMaritimo', 'EquiPaq 24'],
        ],
        [
            'carrier' => 'DHL',
            'method' => ['DHL Express', 'Parcel', 'International Mail', 'DHL Express Domestic', 'International Express'],
        ],
        [
            'carrier' => 'DHL eCommerce',
            'method' => ['PKW-Parcel International Direct-Semi', 'PLT-Parcel International Direct-Standard', 'PLE-Parcel International Direct-Expedited', 'PKG-Packet International Economy', 'PKD-Packet International Standard', 'PPS-Packet Plus International'],
        ],
        [
            'carrier' => 'Envialia',
            'method' => ['24', '72'],
        ],
        [
            'carrier' => 'GLS',
            'method' => ['Business Parcel', '14 Service', '10 Service', 'Economy'],
        ],
        [
            'carrier' => 'JCEX',
            'method' => ['Jia-Packet', 'EUB', 'Europe-DHL', 'Europe-DPD', 'Europe-UPS', 'UPS Worldwide Saver', 'UPS Worldwide Expedited', 'Fedex IE', 'Fedex IP', 'TNT', 'JP International Express', 'CA International Express', 'US International Express'],
        ],
        [
            'carrier' => 'MRW',
            'method' => ['Urgente 8:30', 'Urgente 10', 'Urgente 12', 'Urgente 14', 'Urgente 19', 'Urgente BAG 19'],
        ],
        [
            'carrier' => 'Nacex',
            'method' => ['eNacex', 'eNacexShop', 'Plusbag', 'Pluspack', '19h', 'eNacex', 'eNacexShop', 'Plusbag', 'Pluspack', '19h'],
        ],
        [
            'carrier' => 'Self Delivery',
            'method' => ['Self Delivery'],
        ],
        [
            'carrier' => 'Seur',
            'method' => ['SEUR 24', 'SEUR FRIO', 'SEUR SAME DAY', 'SEUR e-Devoluciones', 'SEUR 8 30', 'SEUR 10', 'SEUR 13:30'],
        ],
        [
            'carrier' => 'SF Express',
            'method' => ['E-Commerce Ordinary Parcel-Standard', 'E-Commerce Registered Parcel-Standard', 'E-Commerce Ordinary Parcel-Economy', 'E-Commerce Registered Parcel-Economy', 'E-Commerce Ordinary Parcel-Special Line', 'E-Commerce Registered Parcel-Special Line', 'E-Commerce Express Standard', 'E-Commerce Express Priority', 'E-Commerce Express CD', 'E-Commerce Registered Parcel-LA', 'E-Commerce Registered Parcel-LU Post', 'E-Commerce Ordinary Parcel-BPost', 'Standard Express', 'Economy Express'],
        ],
        [
            'carrier' => 'SFC',
            'method' => ['SFC Global Line-no battery', 'SFC Global Line-with battery'],
        ],
        [
            'carrier' => 'TIPSA',
            'method' => ['Urgente 10 horas', 'Urgente 14 Horas', 'Economy', 'TIPSA Canarias urgente', 'TIPSA Canarias carga', 'TIPSA Canarias MR-Mar\u00edtimo', 'TIPSA Baleares urgente', 'TIPSA Baleares carga', 'Servicio Ceuta y Melilla'],
        ],
        [
            'carrier' => 'WanB Express',
            'method' => ['WANB EXPRESS', 'WANB Smart Track', 'WANB Semi Track', 'WANB Post Smart', 'WANB Post Economy'],
        ],
        [
            'carrier' => 'Yanwen',
            'method' => ['AIR ECONOMY MAIL', 'AIR REGISTERED MAIL', 'Direct Line Packet', 'Direct Line Express'],
        ],
        [
            'carrier' => 'YDH',
            'method' => ['YDH Express Service', 'YDH Standard Service', 'YDH Economy Service'],
        ],
        [
            'carrier' => 'Yun Express',
            'method' => ['YunExpress Global Direct line (standard)-Tracked', 'YunExpress Global Direct line with Battery-Tracked', 'YunExpress Global Direct line non Battery-Tracked', 'YunExpress Global line (standard)-Untracked', 'YunExpress Global Direct line-battery-Untracked', 'YunExpress Global Direct line-no battery-Untracked', 'YunExpress JP Direct Line', 'YunExpress DE SRM Direct Line', 'YunExpress ME Direct Line', 'YunExpress ME Direct Line-DDP'],
        ],
    ];

    const DE = [
        [
            'carrier' => '4PX',
            'method' => ['4PX-Global Express', '4PX-PostLink priority Registered Mail-Li', '4PX-PostLink Standard Registered Mail-Li', '4PX-PostLink Standard2 Registered Mail-Li', '4PX-PostLink Economy Registered Mail-Li', '4PX-PostLink Economy SRM Registered Mail-Li', '4PX-PostLink Standard Ordinary Mail-Li', '4PX-PostLink Standard large letter Ordinary Mail-Li', '4PX-PostLink Economy large letter Ordinary Mail-Li', '4PX-PostLink priority Registered Mail-NOLi', '4PX-PostLink Standard Registered Mail-NOLi', '4PX-PostLink Economy Registered Mail-NOLi', '4PX-PostLink Economy2 Ordinary Mail-Li', '4PX-PostLink Economy2 Registered Mail-Li'],
        ],
        [
            'carrier' => 'AT Post',
            'method' => ['Paket Oesterreich', 'Premium Select Oesterreich', 'Paket Premium Oesterreich', 'Kleinpaket Oesterreich', 'Premium Light Oesterreich', 'Next Day Fresh', 'Inland Weinpaket Prepaid', 'Paket Light Int. boxable', 'Paket Light Int. Non boxable', 'Paket (Plus) International', 'Post Express', 'Post Express International', 'Paket Premium International', 'Combi-Freight Oesterreich', 'Combi-Freight International', 'Easy Return Solution', 'Paket Oesterreich', 'Paket International', 'Paketmarke (Standard)', 'Express Paketmarke ', 'Post Express', 'Post Express International', 'Brief S', 'Brief S Einschreiben', 'Brief M', 'Brief M Einschreiben', 'Paeckchen S', 'Paeckchen M', 'Paeckchen S mit Sendungsverfolgung', 'Paeckchen M mit Sendungsverfolgung', 'Brief International', 'Brief International Einschreiben', 'Brief International Plus', 'Brief International Plus Einschrieben'],
        ],
        [
            'carrier' => 'China Post',
            'method' => ['China Post e-Courier Packet', 'E courier', 'EMS', 'E-packet', 'Airmail Registered', 'Airmail'],
        ],
        [
            'carrier' => 'Deutsche Post',
            'method' => ['Warenpost', 'Warenpost International', 'Standardbrief', 'Kompaktbrief', 'Grossbrief', 'Maxibrief', 'Standardbrief Einschreiben', 'Kompaktbrief Einschreiben', 'Grossbrief Einschreiben', 'Maxibrief Einschreiben', 'Standardbrief International', 'Kompaktbrief International', 'Grossbrief International', 'Maxibrief International', 'Standardbrief Einschreiben International', 'Kompaktbrief Einschreiben International', 'Grossbrief Einschreiben International', 'Maxibrief Einschreiben International', 'Bucher-\/Warensendung', 'Standardbrief Prio', 'Kompaktbrief Prio', 'Grossbrief Prio', 'Maxibrief Prio', 'Paeckchen'],
        ],
        [
            'carrier' => 'DHL',
            'method' => ['Paket', 'Prio', 'EuroPaket', 'Paket International', 'Express', 'Warenpost'],
        ],
        [
            'carrier' => 'DHL eCommerce',
            'method' => ['Parcel International Direct-Semi', 'Parcel International Direct-Standard', 'Parcel International Direct-Expedited', 'Packet International Economy', 'Packet International Standard', 'Packet Plus International', 'PKW-Parcel International Direct-Semi', 'PLT-Parcel International Direct-Standard', 'PLE-Parcel International Direct-Expedited', 'PKG-Packet International Economy', 'PKD-Packet International Standard', 'PPS-Packet Plus International'],
        ],
        [
            'carrier' => 'DPD',
            'method' => ['DPD Prio', 'DPD Classic', 'DPD Express', 'Classic', 'Prio', 'Express', 'Classic'],
        ],
        [
            'carrier' => 'GLS',
            'method' => ['BusinessParcel', 'BusinessSmallParcel', 'EuroBusinessParcel', 'EuroBusinessSmallParcel', 'ExpressParcel', 'EuroExpressParcel', 'GlobalExpressParcel'],
        ],
        [
            'carrier' => 'Hermes',
            'method' => ['Eilservice', 'Standard', 'Paeckchen', 'S-Paket', 'M-Paket', 'L-Paket', 'XL-Paket', 'XXL-Paket'],
        ],
        [
            'carrier' => 'JCEX',
            'method' => ['Jia-Packet', 'EUB', 'Europe-DHL', 'Europe-DPD', 'Europe-UPS', 'UPS Worldwide Saver', 'UPS Worldwide Expedited', 'Fedex IE', 'Fedex IP', 'TNT', 'JP International Express', 'CA International Express', 'US International Express'],
        ],
        [
            'carrier' => 'Royal Mail',
            'method' => ['Royal Mail 2nd Class', 'Royal Mail Special Delivery Guaranteed', 'Royal Mail Tracked 24', 'Royal Mail Tracked 48'],
        ],
        [
            'carrier' => 'Self Delivery',
            'method' => ['Self Delivery'],
        ],
        [
            'carrier' => 'Seur',
            'method' => ['SEUR 24'],
        ],
        [
            'carrier' => 'SF Express',
            'method' => ['E-Commerce Ordinary Parcel-Standard', 'E-Commerce Registered Parcel-Standard', 'E-Commerce Ordinary Parcel-Economy', 'E-Commerce Registered Parcel-Economy', 'E-Commerce Ordinary Parcel-Special Line', 'E-Commerce Registered Parcel-Special Line', 'E-Commerce Express Standard', 'E-Commerce Express Priority', 'E-Commerce Express CD', 'E-Commerce Registered Parcel-LA', 'E-Commerce Registered Parcel-LU Post', 'E-Commerce Ordinary Parcel-BPost', 'Standard Express', 'Economy Express'],
        ],
        [
            'carrier' => 'SFC',
            'method' => ['SFC Global Line-no battery', 'SFC Global Line-with battery'],
        ],
        [
            'carrier' => 'UPS',
            'method' => ['Standard', 'Express Saver'],
        ],
        [
            'carrier' => 'WanB Express',
            'method' => ['WANB EXPRESS', 'WANB Smart Track', 'WANB Semi Track', 'WANB Post Smart', 'WANB Post Economy'],
        ],
        [
            'carrier' => 'Yanwen',
            'method' => ['AIR ECONOMY MAIL', 'AIR REGISTERED MAIL', 'Direct Line Packet', 'Direct Line Express'],
        ],
        [
            'carrier' => 'YDH',
            'method' => ['YDH Express Service', 'YDH Standard Service', 'YDH Economy Service'],
        ],
        [
            'carrier' => 'Yun Express',
            'method' => ['YunExpress Global Direct line (standard)-Tracked', 'YunExpress Global Direct line with Battery-Tracked', 'YunExpress Global Direct line non Battery-Tracked', 'YunExpress Global line (standard)-Untracked', 'YunExpress Global Direct line-battery-Untracked', 'YunExpress Global Direct line-no battery-Untracked', 'YunExpress JP Direct Line', 'YunExpress DE SRM Direct Line', 'YunExpress ME Direct Line', 'YunExpress ME Direct Line-DDP'],
        ],
    ];

    const IT = [
        [
            'carrier' => '4PX',
            'method' => ['4PX-Global Express', '4PX-PostLink priority Registered Mail-Li', '4PX-PostLink Standard Registered Mail-Li', '4PX-PostLink Standard2 Registered Mail-Li', '4PX-PostLink Economy Registered Mail-Li', '4PX-PostLink Economy SRM Registered Mail-Li', '4PX-PostLink Standard Ordinary Mail-Li', '4PX-PostLink Standard large letter Ordinary Mail-Li', '4PX-PostLink Economy large letter Ordinary Mail-Li', '4PX-PostLink priority Registered Mail-NOLi', '4PX-PostLink Standard Registered Mail-NOLi', '4PX-PostLink Economy Registered Mail-NOLi', '4PX-PostLink Economy2 Ordinary Mail-Li', '4PX-PostLink Economy2 Registered Mail-Li'],
        ],
        [
            'carrier' => 'Arco Spedizioni',
            'method' => ['Standard', 'Express'],
        ],
        [
            'carrier' => 'Bartolini',
            'method' => ['BRT Express'],
        ],
        [
            'carrier' => 'BRT',
            'method' => ['BRT Express'],
        ],
        [
            'carrier' => 'Ceva',
            'method' => ['Standard – HB', 'Standard'],
        ],
        [
            'carrier' => 'China Post',
            'method' => ['China Post e-Courier Packet', 'E courier', 'EMS', 'E-packet', 'Airmail Registered', 'Airmail'],
        ],
        [
            'carrier' => 'DHL',
            'method' => ['DHL Express', 'Parcel', 'International Mail'],
        ],
        [
            'carrier' => 'DHL eCommerce',
            'method' => ['Parcel International Direct-Semi', 'Parcel International Direct-Standard', 'Parcel International Direct-Expedited', 'Packet International Economy', 'Packet International Standard', 'Packet Plus International', 'PKW-Parcel International Direct-Semi', 'PLT-Parcel International Direct-Standard', 'PLE-Parcel International Direct-Expedited', 'PKG-Packet International Economy', 'PKD-Packet International Standard', 'PPS-Packet Plus International'],
        ],
        [
            'carrier' => 'Energo',
            'method' => ['Standard'],
        ],
        [
            'carrier' => 'FAST EST',
            'method' => ['Standard'],
        ],
        [
            'carrier' => 'FERCAM',
            'method' => ['Home Delivery'],
        ],
        [
            'carrier' => 'GLS',
            'method' => ['National Express', 'Safe Plus', 'Express International', 'International Parcel'],
        ],
        [
            'carrier' => 'JCEX',
            'method' => ['Jia-Packet', 'EUB', 'Europe-DHL', 'Europe-DPD', 'Europe-UPS', 'UPS Worldwide Saver', 'UPS Worldwide Expedited', 'Fedex IE', 'Fedex IP', 'TNT', 'JP International Express', 'CA International Express', 'US International Express'],
        ],
        [
            'carrier' => 'Liccardi',
            'method' => ['Express'],
        ],
        [
            'carrier' => 'Milkman',
            'method' => ['Standard'],
        ],
        [
            'carrier' => 'Nexive',
            'method' => ['Express', 'Economy', 'Slim', 'International'],
        ],
        [
            'carrier' => 'Poste Italiane',
            'method' => ['Poste Delivery Express', 'Poste Delivery Standard', 'Poste Delivery Web', 'Lettera \u2013 Posta1', 'Lettera \u2013 Posta4'],
        ],
        [
            'carrier' => 'SDA',
            'method' => ['Express', 'INTERNAZIONALE ESPRESSO'],
        ],
        [
            'carrier' => 'Self Delivery',
            'method' => ['Self Delivery'],
        ],
        [
            'carrier' => 'SF Express',
            'method' => ['E-Commerce Ordinary Parcel-Standard', 'E-Commerce Registered Parcel-Standard', 'E-Commerce Ordinary Parcel-Economy', 'E-Commerce Registered Parcel-Economy', 'E-Commerce Ordinary Parcel-Special Line', 'E-Commerce Registered Parcel-Special Line', 'E-Commerce Express Standard', 'E-Commerce Express Priority', 'E-Commerce Express CD', 'E-Commerce Registered Parcel-LA', 'E-Commerce Registered Parcel-LU Post', 'E-Commerce Ordinary Parcel-BPost', 'Standard Express', 'Economy Express'],
        ],
        [
            'carrier' => 'SFC',
            'method' => ['SFC Global Line-no battery', 'SFC Global Line-with battery'],
        ],
        [
            'carrier' => 'TNT',
            'method' => ['TNT Express National', 'TNT Economy Express National', 'TNT Express', 'TNT Economy Express'],
        ],
        [
            'carrier' => 'WanB Express',
            'method' => ['WANB EXPRESS', 'WANB Smart Track', 'WANB Semi Track', 'WANB Post Smart', 'WANB Post Economy'],
        ],
        [
            'carrier' => 'Yanwen',
            'method' => ['AIR ECONOMY MAIL', 'AIR REGISTERED MAIL', 'Direct Line Tracked Packet', 'Direct Line Express'],
        ],
        [
            'carrier' => 'YDH',
            'method' => ['YDH Express Service', 'YDH Standard Service', 'YDH Economy Service'],
        ],
        [
            'carrier' => 'Yun Express',
            'method' => ['YunExpress Global Direct line (standard)-Tracked', 'YunExpress Global Direct line with Battery-Tracked', 'YunExpress Global Direct line non Battery-Tracked', 'YunExpress Global line (standard)-Untracked', 'YunExpress Global Direct line-battery-Untracked', 'YunExpress Global Direct line-no battery-Untracked', 'YunExpress JP Direct Line', 'YunExpress DE SRM Direct Line', 'YunExpress ME Direct Line', 'YunExpress ME Direct Line-DDP'],
        ],
        [
            'carrier' => 'Zust Ambrosetti',
            'method' => ['Standard', 'Premium'],
        ],
    ];

    const UK = [
        [
            'carrier' => '4PX',
            'method' => ['4PX-Global Express', '4PX-PostLink Economy large letter Ordinary Mail-Li', '4PX-PostLink Economy Registered Mail-Li', '4PX-PostLink Economy Registered Mail-NOLi', '4PX-PostLink Economy SRM Registered Mail-Li', '4PX-PostLink Economy2 Ordinary Mail-Li', '4PX-PostLink Economy2 Registered Mail-Li', '4PX-PostLink priority Registered Mail-Li', '4PX-PostLink priority Registered Mail-NOLi', '4PX-PostLink Standard large letter Ordinary Mail-Li', '4PX-PostLink Standard Ordinary Mail-Li', '4PX-PostLink Standard Registered Mail-Li', '4PX-PostLink Standard Registered Mail-NOLi', '4PX-PostLink Standard2 Registered Mail-Li'],
        ],
        [
            'carrier' => 'Amazon Shipping',
            'method' => ['Amazon Shipping One-Day Tracked', 'Amazon Shipping Standard Tracked'],
        ],
        [
            'carrier' => 'Arrow XL',
            'method' => ['Dedicated', 'Lite', 'Platinum', 'Standard'],
        ],
        [
            'carrier' => 'BJS',
            'method' => ['Choice-of-day delivery', 'Next day delivery'],
        ],
        [
            'carrier' => 'China Post',
            'method' => ['China Post e-Courier Packet', 'E courier', 'EMS', 'E-packet', 'Airmail Registered', 'Airmail'],
        ],
        [
            'carrier' => 'DHL',
            'method' => ['DHL Express', 'Parcel', 'International Mail'],
        ],
        [
            'carrier' => 'DHL eCommerce',
            'method' => ['Parcel International Direct-Semi', 'Parcel International Direct-Standard', 'Parcel International Direct-Expedited', 'Packet International Economy', 'Packet International Standard', 'Packet Plus International', 'PKW-Parcel International Direct-Semi', 'PLT-Parcel International Direct-Standard', 'PLE-Parcel International Direct-Expedited', 'PKG-Packet International Economy', 'PKD-Packet International Standard', 'PPS-Packet Plus International'],
        ],
        [
            'carrier' => 'DPD',
            'method' => ['DPD Classic', 'DPD Express', 'ExpressPak Next Day', 'ExpressPak Saturday', 'Parcel Next Day', 'Parcel Saturday'],
        ],
        [
            'carrier' => 'DX Freight',
            'method' => ['DX Courier', 'DX Freight', 'DX Secure'],
        ],
        [
            'carrier' => 'GLS',
            'method' => ['Parcel'],
        ],
        [
            'carrier' => 'Hermes',
            'method' => ['(Next day)', 'Standard Courier collection', 'Standard drop off', 'Standard Two Day drop off'],
        ],
        [
            'carrier' => 'JCEX',
            'method' => ['Jia-Packet', 'EUB', 'Europe-DHL', 'Europe-DPD', 'Europe-UPS', 'UPS Worldwide Saver', 'UPS Worldwide Expedited', 'Fedex IE', 'Fedex IP', 'TNT', 'JP International Express', 'CA International Express', 'US International Express'],
        ],
        [
            'carrier' => 'Panther',
            'method' => ['Premium Two Man Delivery', 'Standard Two Man Delivery'],
        ],
        [
            'carrier' => 'Parcelforce',
            'method' => ['International Parcel', 'UK Parcel'],
        ],
        [
            'carrier' => 'Post NL',
            'method' => ['Domestic mail', 'Domestic parcel', 'International mail', 'International parcel'],
        ],
        [
            'carrier' => 'Royal Mail',
            'method' => ['Royal Mail 1st Class', 'Royal Mail 1st Class Signed For', 'Royal Mail 1st Class Stamps/Franking', 'Royal Mail 24', 'Royal Mail 2nd Class', 'Royal Mail 2nd Class Signed For', 'Royal Mail 2nd Class Stamps/Franking', 'Royal Mail 48', 'Royal Mail Special Delivery Guaranteed', 'Royal Mail Tracked 24', 'Royal Mail Tracked 24 (LBT)', 'Royal Mail Tracked 48', 'Royal Mail Tracked 48 (LBT)', 'Stamps/Franking'],
        ],
        [
            'carrier' => 'Self Delivery',
            'method' => ['Self Delivery'],
        ],
        [
            'carrier' => 'SF Express',
            'method' => ['E-Commerce Ordinary Parcel-Standard', 'E-Commerce Registered Parcel-Standard', 'E-Commerce Ordinary Parcel-Economy', 'E-Commerce Registered Parcel-Economy', 'E-Commerce Ordinary Parcel-Special Line', 'E-Commerce Registered Parcel-Special Line', 'E-Commerce Express Standard', 'E-Commerce Express Priority', 'E-Commerce Express CD', 'E-Commerce Registered Parcel-LA', 'E-Commerce Registered Parcel-LU Post', 'E-Commerce Ordinary Parcel-BPost', 'Standard Express', 'Economy Express'],
        ],
        [
            'carrier' => 'SFC',
            'method' => ['SFC Global Line-no battery', 'SFC Global Line-with battery'],
        ],
        [
            'carrier' => 'TNT',
            'method' => ['Express', 'International economy', 'Same day'],
        ],
        [
            'carrier' => 'Tuffnells',
            'method' => ['Databag', 'Economy service', 'Fast4ward', 'Next day delivery', 'Offshore delivery', 'Saturday delivery'],
        ],
        [
            'carrier' => 'WanB Express',
            'method' => ['WANB EXPRESS', 'WANB Smart Track', 'WANB Semi Track', 'WANB Post Smart', 'WANB Post Economy'],
        ],
        [
            'carrier' => 'XDP',
            'method' => ['Economy service', 'Overnight parcels'],
        ],
        [
            'carrier' => 'Yanwen',
            'method' => ['AIR ECONOMY MAIL', 'AIR REGISTERED MAIL', 'Direct Line Express', 'Direct Line Packet'],
        ],
        [
            'carrier' => 'YDH',
            'method' => ['YDH Express Service', 'YDH Standard Service', 'YDH Economy Service'],
        ],
        [
            'carrier' => 'Yodel',
            'method' => ['International', 'Offshore', 'Xpect', 'Xpert', 'Xpress'],
        ],
        [
            'carrier' => 'Yun Express',
            'method' => ['YunExpress Global Direct line (standard)-Tracked', 'YunExpress Global Direct line with Battery-Tracked', 'YunExpress Global Direct line non Battery-Tracked', 'YunExpress Global line (standard)-Untracked', 'YunExpress Global Direct line-battery-Untracked', 'YunExpress Global Direct line-no battery-Untracked', 'YunExpress JP Direct Line', 'YunExpress DE SRM Direct Line', 'YunExpress ME Direct Line', 'YunExpress ME Direct Line-DDP'],
        ],
    ];

    const AU = [
        [
            'carrier' => 'Australia Post-Consignment',
            'method' => ['International Post International Courier', 'International Post International Economy Air', 'International Post International Express', 'International Post International Standard', 'Letter Post Express Post letter', 'Letter Post Ordinary letter', 'Letter Post Registered Post', 'Parcel Post Express Post parcel', 'Parcel Post Regular parcel'],
        ],
        [
            'carrier' => 'Australia Post-ArticleID',
            'method' => ['International Post International Courier', 'International Post International Economy Air', 'International Post International Express', 'International Post International Standard', 'Letter Post Express Post letter', 'Letter Post Ordinary letter', 'Letter Post Registered Post', 'Parcel Post Express Post parcel', 'Parcel Post Regular parcel'],
        ],
        [
            'carrier' => 'China Post',
            'method' => ['China Post e-Courier Packet', 'China Post e-Courier Priority', 'China Post e-EMS', 'China Post ePacket', 'China Post Ordinary Airmail', 'China Post Registered Airmail'],
        ],
        [
            'carrier' => 'Fastway',
            'method' => ['National parcel', 'National satchel'],
        ],
        [
            'carrier' => '4PX',
            'method' => ['4PX-Global Express', '4PX-PostLink Economy large letter Ordinary Mail-Li', '4PX-PostLink Economy Registered Mail-Li', '4PX-PostLink Economy Registered Mail-NOLi', '4PX-PostLink Economy SRM Registered Mail-Li', '4PX-PostLink Economy2 Ordinary Mail-Li', '4PX-PostLink Economy2 Registered Mail-Li', '4PX-PostLink priority Registered Mail-Li', '4PX-PostLink priority Registered Mail-NOLi', '4PX-PostLink Standard large letter Ordinary Mail-Li', '4PX-PostLink Standard Ordinary Mail-Li', '4PX-PostLink Standard Registered Mail-Li', '4PX-PostLink Standard Registered Mail-NOLi', '4PX-PostLink Standard2 Registered Mail-Li', '4PX-SingPost Ordinary Mail Plus'],
        ],
        [
            'carrier' => 'Aramex',
            'method' => ['National Parcel', 'National Satchel'],
        ],
        [
            'carrier' => 'Couriers Please',
            'method' => ['Domestic parcel', 'Domestic Priority', 'Domestic Saver'],
        ],
        [
            'carrier' => 'DHL',
            'method' => ['Express', 'International Economy', 'International Mail', 'Parcel'],
        ],
        [
            'carrier' => 'FedEx',
            'method' => ['International Economy', 'International First', 'International Priority'],
        ],
        [
            'carrier' => 'SF Express',
            'method' => ['E-Commerce Ordinary Parcel-Standard', 'E-Commerce Registered Parcel-Standard', 'E-Commerce Ordinary Parcel-Economy', 'E-Commerce Registered Parcel-Economy', 'E-Commerce Ordinary Parcel-Special Line', 'E-Commerce Registered Parcel-Special Line', 'E-Commerce Express Standard', 'E-Commerce Express Priority', 'E-Commerce Express CD', 'E-Commerce Registered Parcel-LA', 'E-Commerce Registered Parcel-LU Post', 'E-Commerce Ordinary Parcel-BPost', 'Standard Express', 'Economy Express'],
        ],
        [
            'carrier' => 'Self Delivery',
            'method' => ['Self Delivery'],
        ],
        [
            'carrier' => 'StarTrack-ArticleID',
            'method' => ['Express', 'Immediate Priority', 'Standard'],
        ],
        [
            'carrier' => 'StarTrack-Consignment',
            'method' => ['Express', 'Immediate Priority', 'Standard'],
        ],
        [
            'carrier' => 'Toll',
            'method' => ['Express Parcel', 'Standard Parcel'],
        ],
        [
            'carrier' => 'Yanwen',
            'method' => ['AIR ECONOMY MAIL', 'AIR REGISTERED MAIL', 'Direct Line Express', 'Direct Line Tracked Packet', 'Yanwen Air Economy Mail General', 'Yanwen Air Economy Mail Special', 'Yanwen Air Register Mail General', 'Yanwen Air Register Mail Special', 'Yanwen Air Track Packet General', 'Yanwen Air Track Packet Special', 'Yanwen Air Untrack Packet General', 'Yanwen Air Untrack Packet Special', 'Yanwen Direct Line Express General', 'Yanwen Direct Line Express Special'],
        ],
        [
            'carrier' => 'Sendle',
            'method' => ['Premium', 'Pro', 'Standard'],
        ],
    ];

    const CARRIERS = [
        Constant::MKP_FR => self::FR,
        Constant::MKP_ES => self::ES,
        Constant::MKP_DE => self::DE,
        Constant::MKP_IT => self::IT,
        Constant::MKP_UK => self::UK,
        Constant::MKP_AU => self::AU,
    ];
}
