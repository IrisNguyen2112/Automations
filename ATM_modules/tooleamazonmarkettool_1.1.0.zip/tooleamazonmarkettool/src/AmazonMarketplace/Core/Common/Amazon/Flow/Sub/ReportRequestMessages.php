<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\Sub;

trait ReportRequestMessages
{
    public function addWarningForInactiveItemCount(int $inactiveItemCount): void
    {
        if ($inactiveItemCount == 1) {
            $this->warnings[] = $this->translator->trans('1 inactive item has been filtered out', [], 'Modules.Tooleamazonmarkettool.Admin');
        } elseif ($inactiveItemCount > 1) {
            $this->warnings[] = $this->translator->trans('%inactiveNum% inactive items have been filtered out', ['%inactiveNum%' => $inactiveItemCount], 'Modules.Tooleamazonmarkettool.Admin');
        }
    }

    public function addWarningForRejectedNotExistCount(int $rejectedNotExistCount): void
    {
        if (!$rejectedNotExistCount) {
            $this->warnings[] = $this->translator->trans('1 Amazon offer has been ignored because it does not exist in Prestashop', ['%notExist%' => $rejectedNotExistCount], 'Modules.Tooleamazonmarkettool.Admin');
        } elseif ($rejectedNotExistCount > 1) {
            $this->warnings[] = $this->translator->trans('%notExist% Amazon offers have been ignored because they do not exist in Prestashop', ['%notExist%' => $rejectedNotExistCount], 'Modules.Tooleamazonmarkettool.Admin');
        }
    }

    public function addWarningForRejectedNotEnableSyncCount(int $rejectedNotEnableSyncCount): void
    {
        if (1 === $rejectedNotEnableSyncCount) {
            $this->warnings[] = $this->translator->trans('1 Amazon offer has been ignored because sync is not enabled for this product.', ['%notEnable%' => $rejectedNotEnableSyncCount], 'Modules.Tooleamazonmarkettool.Admin');
        } elseif ($rejectedNotEnableSyncCount > 1) {
            $this->warnings[] = $this->translator->trans('%notEnable% Amazon offers have been ignored because sync is not enabled.', ['%notEnable%' => $rejectedNotEnableSyncCount], 'Modules.Tooleamazonmarkettool.Admin');
        }
    }

    public function addNotificationsForImportedOffers(int $importedOffers): void
    {
        if ($importedOffers < 1) {
            $this->warnings[] = $this->translator->trans('No offers have been imported', [], 'Modules.Tooleamazonmarkettool.Admin');
        } elseif ($importedOffers == 1) {
            $this->confirmations[] = $this->translator->trans('1 Amazon offer has been imported', [], 'Modules.Tooleamazonmarkettool.Admin');
        } else {
            $this->confirmations[] = $this->translator->trans('%importedNum% Amazon offers have been imported', ['%importedNum%' => $importedOffers], 'Modules.Tooleamazonmarkettool.Admin');
        }
    }
}
