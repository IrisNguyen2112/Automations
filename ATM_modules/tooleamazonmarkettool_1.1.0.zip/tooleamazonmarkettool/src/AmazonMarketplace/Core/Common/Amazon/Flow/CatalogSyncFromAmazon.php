<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Configuration;
use Context;
use Module;
use Toole\Module\Amazon\Client\V2\Model\ReportRequest\ParsedReport;
use Toole\Module\Amazon\Client\V2\Model\ReportRequest\ReportResponse;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\Sub\MerchantListingAllDataReportParser;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\Sub\ReportRequest;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\Sub\ReportRequestMessages;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Report;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\SubscriptionManager\Service\Api\v2\ServiceAPIV2Helper;
use TooleAmazonMarketAmazonProduct;
use Tools;

if (!defined('_PS_VERSION_')) {
    exit;
}

class CatalogSyncFromAmazon implements IFlowRequireReport
{
    use MerchantListingAllDataReportParser;
    use ReportRequestMessages;

    /** @var ReportRequest */
    protected $subFlowReportRequest;

    protected $domain;
    protected $uuid;
    protected $reportType;
    protected $dataStartTime;
    protected $idLang;
    protected $idShop;
    protected $idEntity;
    protected $idShopGroup;

    private $offersImportedFromReport = 0;
    private $offersRejectedNotExist = 0;
    private $offersRejectedNotEnableSync = 0;
    private $offersSynced = 0;
    private $inactiveItemCount = 0;

    // Result indicator
    private $translator;
    private $errors = [];
    private $warnings = [];
    private $confirmations = [];

    public function __construct(Module $module, ServiceAPIV2Helper $saasHelper, $domain, $uuid, $reportType, $dataStartTime = null, $idEntity = null, $additionalParams = null)
    {
        $this->translator = $module->getTranslator();
        $this->domain = $domain;
        $this->uuid = $uuid;
        $this->reportType = $reportType;
        $this->dataStartTime = $dataStartTime;

        $this->subFlowReportRequest = new ReportRequest($saasHelper, $domain, $uuid, $reportType, $dataStartTime, $additionalParams);

        $this->idLang = Context::getContext()->language->id;
        $this->idShop = Context::getContext()->shop->id;
        $this->idEntity = $idEntity;
        $this->idShopGroup = Context::getContext()->shop->id_shop_group;
    }

    public function requestReport(): bool
    {
        return $this->subFlowReportRequest->requestReport();
    }

    public function getReportResult(): ReportResponse
    {
        return $this->subFlowReportRequest->getReportResult();
    }

    public function getParseReportResult(): ParsedReport
    {
        return $this->subFlowReportRequest->getParseReportResult();
    }

    public function fetchReport($resourceUrl, $compressAlgorithm, $contentType)
    {
        return Report::fetchReport($resourceUrl, $compressAlgorithm, $contentType);
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public function getWarnings(): array
    {
        return $this->warnings;
    }

    public function getConfirmations(): array
    {
        return $this->confirmations;
    }

    public function getStatistic(): array
    {
        return [
            'uuid' => $this->uuid,
            'imported' => $this->offersImportedFromReport,
            'rejectedNotExist' => $this->offersRejectedNotExist,
            'rejectedNotEnableSync' => $this->offersRejectedNotEnableSync,
            'synced' => $this->offersSynced,
            'inactiveItemCount' => $this->inactiveItemCount,
        ];
    }

    public function importAmazonOffers($offers): void
    {
        $importedOffers = 0;
        $result = $this->buildMerchantListingAllDataReport($offers);

        if ($inactiveItemCount = $result['inactiveItemCount']) {
            $this->inactiveItemCount = $inactiveItemCount;

            // add warning for inactive item count
            $this->addWarningForInactiveItemCount($inactiveItemCount);
        }

        foreach ($offers as $item) {
            $checkSku = trim(Tools::substr($item['sku'], 0, 32));

            if (!empty($checkSku)) {
                $oldProduct = TooleAmazonMarketAmazonProduct::getTooleProductBySku($checkSku, $this->idEntity);
                TooleAmazonMarketAmazonProduct::saveTooleProduct([
                    'sku' => $checkSku,
                    'id_entity' => $this->idEntity,
                    'qty' => $item['qty'],
                    'price' => $item['price'],
                    'name' => $item['name'],
                ], $oldProduct ? $oldProduct['id'] : null);
                ++$importedOffers;
            }
        }

        // add warning / confirmation for imported offers
        $this->addNotificationsForImportedOffers($importedOffers);

        $this->offersImportedFromReport = $importedOffers;
    }

    public function syncAmazonOffers(): void
    {
        $rejectedNotExistCount = 0;
        $rejectedNotEnableSyncCount = 0;
        $offersSyncedCount = 0;

        $productIds = TooleAmazonMarketAmazonProduct::getTooleProductsNotSync($this->idEntity);

        if (!empty($productIds)) {
            foreach ($productIds as $product) {
                $syncProduct = TooleAmazonMarketAmazonProduct::syncProduct($product['id'], $this->idEntity);
                [$offersSynced, $rejectedNotEnableSync, $rejectedNotExist] = array_values($syncProduct);
                if ($offersSynced) {
                    ++$offersSyncedCount;
                }
                if ($rejectedNotEnableSync) {
                    ++$rejectedNotEnableSyncCount;
                }
                if ($rejectedNotExist) {
                    ++$rejectedNotExistCount;
                }
            }
        }

        // add Warning For Rejected Not Exist Count
        $this->addWarningForRejectedNotExistCount($rejectedNotExistCount);

        // add Warning For Rejected Not Enable Sync Count
        $this->addWarningForRejectedNotEnableSyncCount($rejectedNotEnableSyncCount);

        $this->offersRejectedNotEnableSync = $rejectedNotEnableSyncCount;
        $this->offersRejectedNotExist = $rejectedNotExistCount;
        $this->offersSynced = $offersSyncedCount;
    }

    public function doTheSync($mrkId)
    {
        $isContinuous = false;
        $this->requestReport();
        $report = $this->getReportResult();
        $reportData = $this->getParseReportResult();

        if (!empty($report->getDocumentUrl())) {
            $this->importAmazonOffers($reportData->getData());

            if ($reportData->getHasMore()) {
                $isContinuous = true;
            }
        } else {
            $isContinuous = true;
            $this->uuid = $report->getUuid();
        }

        if ($this->offersImportedFromReport > 0) {
            $this->syncAmazonOffers();
        }

        if (!$isContinuous) {
            /* storage last statistic report data */
            $this->storageLastStatisticReportData($mrkId, $reportData->getStatistic());
        }

        return $isContinuous;
    }

    public function storageLastStatisticReportData($mkpId, $lastStatistic = [])
    {
        $reportData = $this->buildLastStatisticReportData($mkpId, $lastStatistic);

        if ($reportData) {
            Configuration::updateValue(Key::LAST_STATISTICS_REPORT_DATA, $reportData, false, $this->idShopGroup, $this->idShop);
        }
    }

    public function buildLastStatisticReportData($mkpId, $lastStatistic = [])
    {
        $reportDataOld = Configuration::get(Key::LAST_STATISTICS_REPORT_DATA, $this->idLang, $this->idShop, $this->idShopGroup);
        $reportTypeName = $this->reportType['name'];
        $reportDataNew = $this->updateStatistics($this->getStatistic(), $lastStatistic);

        if (!$reportDataOld) {
            return json_encode([$reportTypeName => [$mkpId => $reportDataNew]]);
        }
        $reportData = json_decode($reportDataOld, true);
        $reportData[$reportTypeName][$mkpId] = $reportDataNew;

        return json_encode($reportData);
    }

    public function updateStatistics(array $newStatistics, array $lastStatistic): array
    {
        if (!$lastStatistic) {
            return $newStatistics;
        }

        if (!$newStatistics) {
            return [];
        }

        foreach ($newStatistics as $key => $statistic) {
            if ($key !== 'uuid') {
                $newStatistics[$key] += (int) $lastStatistic[$key];
            }
        }

        return $newStatistics;
    }
}
