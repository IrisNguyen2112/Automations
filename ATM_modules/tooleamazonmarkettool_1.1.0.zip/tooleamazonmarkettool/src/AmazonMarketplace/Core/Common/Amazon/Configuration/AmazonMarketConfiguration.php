<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration;

use Configuration;
use Exception;
use Toole\Module\AmazonMarketplace\Core\Common\AmazonAuth\AmazonAuthCredentials;
use Toole\Module\AmazonMarketplace\Core\Common\Service\SaaSConnector;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\CatalogKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Constant;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v2\Response\CreateStoreConfigurationResponse;
use Toole\Module\SubscriptionManager\Service\Api\v2\Response\DeleteStoreConfigurationResponse;
use Toole\Module\SubscriptionManager\Service\Api\v2\Response\GetStoreConfigurationResponse;
use Toole\Module\SubscriptionManager\Service\Api\v2\Response\UpdateStoreConfigurationResponse;
use Tools;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class AmazonMarketConfiguration
{
    const CRON_TIME_MIN = 30;

    public static $offer_feed_options = [
        'EXTENDED_DATA' => 1,
        'SEND_IMAGES' => 2,
        'DISPLAY_XML' => 3,
        'SEND_ENTIRE_CATALOG' => 4,
        'NO_PRICE' => 5,
    ];

    public static $products_synchronization_options = [
        'EXTENDED_DATA' => 'Extended data',
        'NO_PRICE' => 'No Price',
    ];

    public static $catalog_sync_time_options = [15, 30, 45, 60, 120];
    public static $order_sync_time_options = [30, 60, 90, 120, 150, 180];

    public static $config_cron_params = [
        CatalogKey::CRON_CATALOG_SYNC_FROM_AMZ_TIME => [
            'dependence' => CatalogKey::ENABLE_SYNC_FROM_AMZ,
            'controller' => 'TooleAmazonMarketCatalogSyncFromAmzCron',
            'action' => 'stockSync',
        ],
        CatalogKey::CRON_CATALOG_SYNC_FROM_PS_TIME => [
            'dependence' => CatalogKey::ENABLE_SYNC_FROM_PS,
            'controller' => 'TooleAmazonMarketCatalogSyncFromPsCron',
            'action' => 'export',
        ],
        OrderKey::CRON_ORDERS_IMPORT_TIME => [
            'dependence' => OrderKey::CRON_ENABLE_IMPORT_ORDERS,
            'controller' => 'TooleAmazonMarketOrderImportCron',
            'action' => 'orderImport',
        ],
        OrderKey::CRON_ORDERS_FULFILL_TIME => [
            'dependence' => OrderKey::ENABLE_FULFILL_ORDERS,
            'controller' => 'TooleAmazonMarketOrderFulfillCron',
            'action' => 'orderFulfill',
        ],
        /* depend on import orders */
        OrderKey::CRON_ORDERS_ACKNOWLEDGE_TIME => [
            'dependence' => OrderKey::CRON_ENABLE_IMPORT_ORDERS,
            'controller' => 'TooleAmazonMarketOrderAcknowledgeCron',
            'action' => 'acknowledge',
        ],
        Key::CRON_FETCH_FEED_SUBMISSION_RESULT_TIME => [
            'dependence' => null,
            'controller' => 'TooleAmazonMarketGetFeedSubmissionResultCron',
            'action' => 'getFeedSubmissionResult',
            'minutes' => Key::FETCH_FEED_SUBMISSION_RESULT_DEFAULT_MINUTES,
        ],
    ];

    private static $configuration = false;

    public static function getStoreConfiguration()
    {
        if (self::$configuration) {
            return self::$configuration;
        }

        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new \Exception('Problem');
        }

        /* @var GetStoreConfigurationResponse $get_store_configuration_response */
        try {
            $get_store_configuration_response = $api_helper->getStoreConfiguration(
                Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                ),
                Configuration::get(Key::CONFIG_PRESTASHOP_STOREID)
            );
            if ($get_store_configuration_response && !$get_store_configuration_response->isSuccess()) {
                return [];
            }
            if ($configuration = $get_store_configuration_response->getStoreConfiguration()) {
                return $configuration['configuration'];
            }

            return [];
        } catch (Exception $e) {
            return [];
        }
    }

    public static function updateStoreConfiguration($custom_data)
    {
        self::$configuration = false;

        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new Exception('Problem');
        }

        /* @var UpdateStoreConfigurationResponse $update_store_configuration_response */
        try {
            $update_store_configuration_response = $api_helper->updateStoreConfiguration(
                Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                ),
                Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                $custom_data
            );
            if ($update_store_configuration_response && !$update_store_configuration_response->isSuccess()) {
                return [];
            }

            if (!empty($update_store_configuration_response)) {
                $configuration = json_decode($update_store_configuration_response->getResponse(), true)['configuration'] ?? false;
                self::$configuration = $configuration;
            }

            return $update_store_configuration_response;
        } catch (Exception $e) {
            return [];
        }
    }

    public static function get(
        $configuration_key,
        $id_shop_group = null,
        $id_shop = null,
        $default = false
    ) {
        if (!Validate::isConfigName($configuration_key)) {
            exit(Tools::displayError('Not a configuration name!'));
        }

        if (self::$configuration === false) {
            self::$configuration = self::getStoreConfiguration();
        }

        if (!isset(self::$configuration[$configuration_key])) {
            if ($default) {
                return $default;
            } else {
                return false;
            }
        }

        $configuration_value = self::$configuration[$configuration_key];
        $isStdClass = false;

        // Check if variable is a stdClass Object
        if (!empty($configuration_value)) {
            $isStdClass = is_object($configuration_value);
            if (!$isStdClass && is_array($configuration_value) && count($configuration_value) > 0) {
                $arrayWOnlyFirstChild = array_slice($configuration_value, 0, 1);
                $firstChild = array_shift($arrayWOnlyFirstChild);
                $isStdClass = is_object($firstChild);
            }
        }

        if ($isStdClass) {
            // Convert object to array
            $configuration_value = json_decode(json_encode($configuration_value), true);
        }

        return $configuration_value;
    }

    public static function updateValue(
        $configuration_key,
        $configuration_value,
        $json = false,
        $id_shop_group = null,
        $id_shop = null
    ) {
        if (!Validate::isConfigName($configuration_key)) {
            exit(Tools::displayError('Not a configuration name!'));
        }

        if (!self::$configuration) {
            self::$configuration = self::getStoreConfiguration();
        }

        if ($json && is_array($configuration_value)) {
            $configuration_value = json_encode($configuration_value, JSON_FORCE_OBJECT);
        }

        self::$configuration[$configuration_key] = $configuration_value;

        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new Exception('Problem');
        }

        if (!Configuration::get(
            Key::CONFIG_PRESTASHOP_STORECONFIGURATIONID
        )) {
            /* @var CreateStoreConfigurationResponse $create_store_configuration_response */
            $create_store_configuration_response = $api_helper->createStoreConfiguration(
                Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                ),
                Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                self::$configuration
            );
            if (!$create_store_configuration_response) {
                throw new Exception('Unable to save store configuration');
            }

            Configuration::updateValue(
                Key::CONFIG_PRESTASHOP_STORECONFIGURATIONID,
                $create_store_configuration_response->getStoreConfigurationId()
            );
        } else {
            /* @var UpdateStoreConfigurationResponse $update_store_configuration_response */
            $update_store_configuration_response = $api_helper->updateStoreConfiguration(
                Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                ),
                Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
                self::$configuration
            );
            if (!$update_store_configuration_response) {
                throw new Exception('Unable to get store configuration');
            }
        }

        return true;
    }

    public static function deleteByName(
        $configuration_key,
        $id_shop_group = null,
        $id_shop = null
    ) {
        if (!Validate::isConfigName($configuration_key)) {
            exit(Tools::displayError('Not a configuration name!'));
        }

        if (!self::$configuration) {
            self::$configuration = self::getStoreConfiguration();
        }

        unset(self::$configuration[$configuration_key]);

        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new Exception('Problem');
        }

        /* @var UpdateStoreConfigurationResponse $update_store_configuration_response */
        $update_store_configuration_response = $api_helper->updateStoreConfiguration(
            Configuration::get(
                Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
            ),
            Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
            self::$configuration
        );
        if (!$update_store_configuration_response) {
            throw new Exception('Unable to get store configuration');
        }
    }

    public static function deleteAll(
        $id_shop_group = null,
        $id_shop = null
    ) {
        if (!$api_helper = SaaSConnector::initHelperWithoutConnector()) {
            throw new Exception('Problem');
        }

        try {
            /* @var DeleteStoreConfigurationResponse $delete_store_configuration_response */
            $delete_store_configuration_response = $api_helper->deleteStoreConfiguration(
                Configuration::get(
                    Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID
                ),
                Configuration::get(Key::CONFIG_PRESTASHOP_STOREID)
            );
            /*if (!$delete_store_configuration_response) {
                 TODO - log but not fail
            }*/
        } catch (Exception $e) {
            return true;
        }

        return true;
    }

    public static function saveAmzMarketplaces($listMkpParticipation, $enableList = [], $region = Constant::MKP_REGION_EU)
    {
        $participationList = [];
        $regionsWMkps = Region::getAllRegionsWithMkps();
        $regionsWMkpsOld = AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO);

        // enable for AMZ ToolE
        if (!empty($regionsWMkpsOld)) {
            foreach ($regionsWMkpsOld as $regionWMkpsData) {
                if (!empty($regionWMkpsData['marketplaces'])) {
                    foreach ($regionWMkpsData['marketplaces'] as $idMkp => $marketplaceData) {
                        if ($marketplaceData['isEnable']) {
                            $enableList[] = $idMkp;
                        }
                    }
                }
            }
        }

        if (!empty($listMkpParticipation)) {
            foreach ($listMkpParticipation as $mkp) {
                if ($mkp->getParticipation()->getIsParticipating()) {
                    $participationList[] = $mkp->getMarketplace()->getId();
                }
            }
        }

        if ($region && isset($regionsWMkps[$region]) && !empty($regionsWMkps[$region]['marketplaces'])) {
            $regionData = $regionsWMkps[$region];
            foreach ($regionData['marketplaces'] as $mkpId => $mkpName) {
                $item = [
                    'name' => $mkpName,
                    'isParticipating' => in_array($mkpId, $participationList, true),
                    'isEnable' => in_array($mkpId, $enableList, true),
                    'currency' => self::availableAmazonCurrencies()[$mkpId] ?: self::availableAmazonCurrencies()[Constant::MKP_FR],
                ];
                $regionsWMkpsOld[$region]['marketplaces'][$mkpId] = $item;
            }
        }

        return AmazonMarketConfiguration::updateValue(Key::AMZ_AUTH_COMBO, $regionsWMkpsOld);
    }

    public static function getAmazonAccountAuthorization()
    {
        $authorizedRegions = AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO) ?: [];

        return array_combine(array_keys($authorizedRegions), array_map(function ($regionCode, $regionData) {
            return new AmazonAuthCredentials(
                $regionData['marketplaceId'],
                $regionData['sellerId'],
                $regionData['refreshToken'],
                $regionCode,
                $regionData['enable'] ?? false,
                $regionData['marketplaces'] ?? []
            );
        }, array_keys($authorizedRegions), array_values($authorizedRegions)));
    }

    public static function availableAmazonCurrencies()
    {
        return [
            Constant::MKP_FR => 'EUR',
            Constant::MKP_ES => 'EUR',
            Constant::MKP_DE => 'EUR',
            Constant::MKP_IT => 'EUR',
            Constant::MKP_UK => 'GBP', // GBP
            Constant::MKP_NL => 'EUR',
            Constant::MKP_SE => 'SEK',    // Swede,
            Constant::MKP_PL => 'PLN',
            Constant::MKP_EG => 'EGP',
            Constant::MKP_TR => 'TRY',
            Constant::MKP_SA => 'SAR',    // Saudi Arabi,
            Constant::MKP_AE => 'AED',
            Constant::MKP_IN => 'INR',
            Constant::MKP_BE => 'BYN',
            Constant::MKP_ZA => 'ZAR',
            // North America
            Constant::MKP_CA => 'CAD',
            Constant::MKP_US => 'USD',
            Constant::MKP_MX => 'MXN',
            Constant::MKP_BR => 'BRL',
            // Far East
            Constant::MKP_SG => 'SGD',
            Constant::MKP_AU => 'AUD',
            Constant::MKP_JP => 'JPY',
        ];
    }
}
