<?php
/**
 * OrderFulfillment
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Exception;
use Module;
use mysqli_result;
use OrderState;
use PDOStatement;
use PrestaShop\PrestaShop\Adapter\Entity\Db;
use PrestaShopDatabaseException;
use PrestaShopException;
use Symfony\Contracts\Translation\TranslatorInterface;
use Toole\Module\Amazon\Client\Model\Order;
use Toole\Module\Amazon\Client\V2\Model\OrdersFulfillment\OrdersFulfillmentResponse;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\OutgoingCarrierMapping;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\FulfillmentCarrierDefault;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Constant\FulfillmentCarrierWithShippingMethod;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\OrderKey;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Carrier as PsCarrierHelper;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v2\ServiceAPIV2Helper;
use TooleAmazonMarketAmazonFeed;
use TooleAmazonMarketAmazonOrder;
use TooleAmazonMarketTool;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class OrderFulfillment
{
    private $cronMode;
    private $teOrderIds;
    private $psSentState;

    private $errors = [];
    private $orderErrorIds = [];
    private $warnings = [];
    private $confirmations = [];
    protected $debugs = [];
    private $shippingData = [];
    /** @var TooleAmazonMarketTool */
    protected $module;
    private $delay;
    /** @var OutgoingCarrierMapping[] */
    private $outgoingCarrierMapping = [];

    /** @var TranslatorInterface */
    protected $translator;
    /** @var ServiceAPIV2Helper */
    protected $saasHelper;

    const BACKOFF_DEFAULT = 7; // a week

    public function __construct(ServiceAPIV2Helper $saasHelper, $teOrderIds, Module $module, $cronMode = false)
    {
        $this->saasHelper = $saasHelper;
        $this->teOrderIds = $teOrderIds;
        $this->module = $module;
        $this->cronMode = $cronMode;
        $this->psSentState = AmazonMarketConfiguration::get(OrderKey::FULFILL_ORDER_STATUS);
        $this->delay = self::BACKOFF_DEFAULT;
        $this->translator = $module->getTranslator();

        $carrierMapping = AmazonMarketConfiguration::get(OrderKey::OUTGOING_CARRIERS, null, null, []);
        foreach ($carrierMapping as $mapping) {
            if (isset($mapping['ps'], $mapping['amazon']) && $mapping['ps'] && $mapping['amazon']) {
                $this->outgoingCarrierMapping[] = new OutgoingCarrierMapping($mapping['ps'],
                    $mapping['custom_value'] ?: $mapping['amazon'],
                    $mapping['custom_method'] ?: $mapping['shipping_service']);
            }
        }
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public function getWarnings(): array
    {
        return $this->warnings;
    }

    public function getConfirmations(): array
    {
        return $this->confirmations;
    }

    public function getDebugs(): array
    {
        return $this->debugs;
    }

    public function getShipmentData(): array
    {
        return $this->shippingData;
    }

    /**
     * @throws PrestaShopException
     * @throws PrestaShopDatabaseException
     */
    public function doFulfill()
    {
        $region = Region::getRegionNameByCode($this->saasHelper->getAmazonConnector()->getRegion());
        $this->module->log->message(sprintf('Amazon %s', $region));

        $this->module->log->message(sprintf(
            'Fulfill order by %s. Order State: %s. Delay: %s',
            $this->cronMode ? 'Cron' : 'Manual',
            $this->psSentState,
            $this->delay
        ));

        if (!$this->psSentState) {
            if ($this->cronMode) {
                $this->errors[] = 'Order status is empty';
            } else {
                $this->errors[] = $this->translator->trans(
                    'Order status is empty',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
            }

            return;
        }

        $orderState = new OrderState($this->psSentState);
        if (!Validate::isLoadedObject($orderState)) {
            if ($this->cronMode) {
                $this->errors[] = 'Order status is invalid';
            } else {
                $this->errors[] = $this->translator->trans(
                    'Order status is invalid',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
            }

            return;
        }

        $mrkIds = $this->saasHelper->getAmazonConnector()->getAvailableMarketplaces();
        $orders = $this->getOrders($mrkIds);
        if (empty($orders)) {
            if ($this->cronMode) {
                $this->warnings[] = 'No orders yet. Please check Order Status or Tracking Number/Shipping Carrier has been entered or not.';
            } else {
                $this->warnings[] = $this->translator->trans(
                    'No orders yet. Please check Order Status or Tracking Number/Shipping Carrier has been entered or not.',
                    [],
                    'Modules.Tooleamazonmarkettool.Admin'
                );
            }

            return;
        }

        $shippingData = $this->getShippingData($orders);

        try {
            $apiResult = $this->saasHelper->ordersFulfill($shippingData);
        } catch (Exception $exception) {
            $this->errors[] = $this->translator->trans('Unable to fulfill order', [], 'Modules.Amazonmarkettool.Admin');
            $this->errors[] = $exception->getMessage();
            return;
        }

        /** @var OrdersFulfillmentResponse $response */
        $response = $apiResult->getAmazonData();
        $totalItemExported = $response->getTotalItems();
        $totalFeeds = $response->getTotalFeeds();
        $feeds = $response->getFeeds();
        if ($totalItemExported < 1 || $totalFeeds < 1 || !count($feeds)) {
            if ($this->cronMode) {
                $this->warnings[] = 'Export done but no item was processed.';
            } else {
                $this->warnings[] = $this->translator->trans('Export done but no item was processed.', [], 'Modules.Amazonmarkettool.Admin');
            }
            return;
        }

        foreach ($feeds as $feed) {
            $idFeed = TooleAmazonMarketAmazonFeed::saveRecord([
                'marketplace_id' => $feed->getMarketplaces()[0],
                'feed_type' => $feed->getFeedType(),
                'feed_id' => $feed->getFeedId(),
                'status' => TooleAmazonMarketAmazonFeed::SENT_STATUS,
                'content_location' => $feed->getContentLocation(),
            ]);
            $this->module->log->message(
                $this->translator->trans('Sent Feed (%feed_id%) - (%feed_type%) successfully.', ['%feed_id%' => $feed->getFeedId(), '%feed_type%' => $feed->getFeedType()], 'Modules.Amazonmarkettool.Admin'),
                $idFeed
            );
        }

        $this->confirmations[] = sprintf(
            $this->translator->trans('Orders fulfilled successfully. Sent %d item(s), received %d feeds(s)', [], 'Modules.Amazonmarkettool.Admin'),
            $totalItemExported, $totalFeeds
        );

        foreach ($orders as $order) {
            if (!in_array($order['mp_order_id'], $this->orderErrorIds)) {
                TooleAmazonMarketAmazonOrder::updateMarketplaceStatus($order['mp_order_id'], Order::ORDER_STATUS_SHIPPED);
            }
        }

        $this->shippingData = $shippingData;
        $this->module->log->message(
            'Fulfilled the order(s).'
        )
            ->success($this->translator->trans(
                'Fulfilled the order(s).',
                [],
                'Modules.Tooleamazonmarkettool.Admin'
            ));
    }

    private function getShippingData($orders): array
    {
        $result = [];
        foreach ($orders as $order) {
            if (empty($order['tracking_number'])) {
                if ($this->cronMode) {
                    $this->errors[] = sprintf('Skip %s - Missing tracking number', $order['mp_order_id']);
                } else {
                    $this->errors[] = sprintf(
                        $this->translator->trans(
                            'Skip %s - Missing tracking number',
                            [],
                            'Modules.Tooleamazonmarkettool.Admin'
                        ),
                        $order['mp_order_id']
                    );
                }
                $this->orderErrorIds[] = $order['mp_order_id'];
                continue;
            }
            $outgoingMapping = $this->getAmazonCarrier($order['id_carrier']);
            if (!$outgoingMapping) {
                if ($this->cronMode) {
                    $this->warnings[] = sprintf(
                        'Skip %s - No outgoing carrier mapping for PS carrier ID %s',
                        $order['mp_order_id'],
                        $order['id_carrier']
                    );
                } else {
                    $this->warnings[] = sprintf(
                        $this->translator->trans(
                            'Skip %s - No outgoing carrier mapping for PS carrier ID %d',
                            [],
                            'Modules.Tooleamazonmarkettool.Admin'
                        ),
                        $order['mp_order_id'],
                        $order['id_carrier']
                    );
                }

                $this->orderErrorIds[] = $order['mp_order_id'];
                continue;
            }
            $result[$order['marketplace_id']][] = [
                'placed_at' => $this->getDate(strtotime($order['date_place'])),
                'timestamp' => $this->getDate(strtotime($order['date_ship'])),
                'order_id' => $order['mp_order_id'],
                'shipping_number' => $order['tracking_number'],
                'carrier' => $outgoingMapping->amazonCarrier,
                'carrier_name' => $outgoingMapping->amazonCarrier,
                'shipping_method' => in_array($order['marketplace_id'],
                    array_keys(FulfillmentCarrierWithShippingMethod::CARRIERS)) ? $outgoingMapping->shippingMethod : '',
                'is_amazon_carrier' => $this->isAmzCarrier($outgoingMapping->amazonCarrier),
            ];
        }

        return $result;
    }

    private function getAmazonCarrier($psCarrierId): ?OutgoingCarrierMapping
    {
        $psCarrierId = PsCarrierHelper::getIdCurrentlyUsing($psCarrierId);
        foreach ($this->outgoingCarrierMapping as $mapping) {
            $psMappingId = PsCarrierHelper::getIdCurrentlyUsing($mapping->psIdCarrier);
            if ($psCarrierId === $psMappingId) {
                return $mapping;
            }
        }

        return null;
    }

    /**
     * @return array|bool|mysqli_result|PDOStatement|resource|null
     * @throws PrestaShopDatabaseException
     */
    private function getOrders($mrkIds = [])
    {
        if (!$this->cronMode) {
            $cdtLimitOrders = 'mp.`id_order` IN (' . implode(',', $this->teOrderIds) . ')';
        } else {
            $cdtLimitOrders = 'o.`date_add` > DATE_ADD(NOW(), INTERVAL -' . (int) $this->delay . ' DAY)';
        }
        $conditionMrkIds = '';
        if ($mrkIds) { // query by marketplaces
            $conditionMrkIds = ' AND mp.`marketplace_id` IN ("' . implode('","', $mrkIds) . '")';
        }
        $cdtStatus = '("' . Order::ORDER_STATUS_UNSHIPPED . '", "' . Order::ORDER_STATUS_PARTIALLY_SHIPPED . '")';
        $subLastChangeToShipped = 'SELECT h1.* FROM `' . _DB_PREFIX_ . 'order_history` h1
            LEFT JOIN `' . _DB_PREFIX_ . 'order_history` h2 ON h1.`id_order` = h2.`id_order` AND h1.`date_add` < h2.`date_add`
            WHERE h1.id_order_state = ' . (int) $this->psSentState . '
            AND h2.id_order_history IS NULL
        ';

        $sql = '
            SELECT
                o.`id_order`, o.`id_lang`, o.`id_carrier`, oc.`tracking_number`, mp.`mp_order_id`, mp.`marketplace_id`, mp.`shipping_services`,
                o.`date_add` AS `date_place`, poh.`date_add` AS `date_ship`
            FROM `' . _DB_PREFIX_ . 'orders` o
            JOIN `' . _DB_PREFIX_ . 'order_carrier` oc ON (o.`id_order` = oc.`id_order`) AND (o.`id_carrier` = oc.`id_carrier`)
            JOIN `' . _DB_PREFIX_ . 'toole_amt_amazon_orders` mp ON (o.`id_order` = mp.`ps_order_id`)
            JOIN (' . $subLastChangeToShipped . ') poh ON o.`id_order` = poh.`id_order`
            WHERE o.`module` = "tooleamazonmarkettool"
            AND oc.`tracking_number` > ""
            AND mp.`mp_status` IN ' . $cdtStatus . '
            AND ' . $cdtLimitOrders . $conditionMrkIds . '
            ORDER BY o.`id_order`';

        $this->debugs[] = $sql;

        return Db::getInstance()->executeS($sql);
    }

    private function getDate($dateAdd): string
    {
        $timestamp = $dateAdd - 600; // sub 10 minutes  --> fix FulfillmentDate error
        if (!$timestamp || !is_numeric($timestamp)) {
            $timestamp = time() - 5400;
            if (!date_default_timezone_get()) {
                date_default_timezone_set('Europe/Helsinki');
            }
        }

        return gmdate('c', $timestamp);
    }

    private function isAmzCarrier($carrier): bool
    {
        return in_array($carrier, FulfillmentCarrierDefault::CARRIER_CODES);
    }
}
