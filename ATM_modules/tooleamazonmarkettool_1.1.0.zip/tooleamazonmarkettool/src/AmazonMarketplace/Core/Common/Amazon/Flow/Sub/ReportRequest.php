<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\Sub;

use PrestaShop\PrestaShop\Core\Foundation\IoC\Exception;
use Toole\Module\Amazon\Client\V2\Model\ReportRequest\ParsedReport;
use Toole\Module\Amazon\Client\V2\Model\ReportRequest\ReportResponse;
use Toole\Module\SubscriptionManager\Service\Api\v2\ServiceAPIV2Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ReportRequest
{
    private $domain;
    private $uuid;
    private $reportType;
    private $dataStartTime;
    private $reportOptions = null;
    private $testcase = null;
    private $additionalParams = null;
    private $mrkIds = [];

    /** @var ReportResponse */
    private $reportResult;
    /** @var ParsedReport */
    private $parseReportResult;
    /** @var ServiceAPIV2Helper */
    protected $saasHelper;

    public function __construct(ServiceAPIV2Helper $saasHelper, $domain, $uuid, $reportType, $dataStartTime = null, $additionalParams = null)
    {
        $this->saasHelper = $saasHelper;
        $this->domain = $domain;
        $this->uuid = $uuid;
        $this->reportType = $reportType;
        $this->dataStartTime = $dataStartTime;
        $this->additionalParams = $additionalParams;
        $this->mrkIds = $this->saasHelper->getAmazonConnector()->getAvailableMarketplaces();
    }

    public function requestReport(): bool
    {
        $apiResult = $this->saasHelper->requestReport(
            $this->domain,
            $this->uuid,
            $this->mrkIds,
            $this->reportType['name'],
            $this->dataStartTime,
            $this->reportOptions,
            $this->additionalParams,
            $this->testcase
        );

        /** @var ReportResponse $report */
        $report = $apiResult->getAmazonData();
        $this->reportResult = $report;
        if ($report->isProcessFailed()) {
            throw new Exception('Report ends unexpectedly!');
        }

        // Is not ended
        if (!$report->isEnded()) {
            return false;
        }

        // Processed successfully
        if ($report->isProcessed() && $report->getDocumentUrl()) {
            /** @var ParsedReport $reportData */
            $reportData = $report->getData();
            $this->parseReportResult = $reportData;

            return true;
        }

        // Unexpected
        throw new Exception('Unexpected state!');
    }

    public function getParseReportResult(): ParsedReport
    {
        return $this->parseReportResult;
    }

    public function getReportResult(): ReportResponse
    {
        return $this->reportResult;
    }
}
