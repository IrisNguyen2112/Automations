<?php
/**
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Service;

use Configuration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Connector;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Constant;
use Toole\Module\SubscriptionManager\Service\Api\v2\ServiceApiFactory;

if (!defined('_PS_VERSION_')) {
    exit;
}

class SaaSConnector
{
    const VERSION = ServiceApiFactory::V2;

    public static function initHelperWithoutConnector()
    {
        return ServiceApiFactory::getApiHelperWithoutConnector(
            self::VERSION,
            Configuration::getGlobalValue(Key::SERVICE_API_URL),
            Configuration::getGlobalValue(Key::SERVICE_API_KEY),
            false
        );
    }

    public static function initHelperWithConnector($connectorInRegion = Constant::MKP_REGION_EU, $connectorInMarketplaces = [], $renew = false)
    {
        return ServiceApiFactory::getApiHelperWithConnector(
            self::VERSION,
            Configuration::getGlobalValue(Key::SERVICE_API_URL),
            Configuration::getGlobalValue(Key::SERVICE_API_KEY),
            false,
            self::initAmazonConnector($connectorInRegion, $connectorInMarketplaces),
            $renew
        );
    }

    protected static function initAmazonConnector($connectorInRegion = Constant::MKP_REGION_EU, $connectorInMarketplaces = []): Connector
    {
        $amzAuthCombo = AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO);

        $marketplaces = [];
        if (!empty($connectorInMarketplaces) && !empty($amzAuthCombo)) {
            foreach ($connectorInMarketplaces as $connectorInMarketplace) {
                if (isset($amzAuthCombo[$connectorInRegion]['marketplaces'][$connectorInMarketplace])) {
                    $marketplaces[$connectorInMarketplace] = $amzAuthCombo[$connectorInRegion]['marketplaces'][$connectorInMarketplace];
                }
            }
        } else {
            $marketplaces = $amzAuthCombo[$connectorInRegion]['marketplaces'] ?? [];
        }

        $availableMarketplaces = [];
        foreach ($marketplaces as $key => $marketplace) {
            if ($marketplace['isParticipating'] && $marketplace['isEnable']) {
                $availableMarketplaces[] = $key;
            }
        }

        $connector = new Connector(
            AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO) ?: [],
            $availableMarketplaces,
            $connectorInRegion
        );

        $connector->setBillingInfo(
            Configuration::getGlobalValue(Key::SERVICE_API_KEY),
            Configuration::get(Key::CONFIG_PRESTASHOP_STOREID),
            Configuration::get(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID)
        );

        return $connector;
    }
}
