<?php
/**
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\AmazonAuth;

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;

if (!defined('_PS_VERSION_')) {
    exit;
}

class AmazonAuthCredentials
{
    public $marketplaceId;
    public $sellerId;
    public $refreshToken;
    public $region;
    public $name;
    public $enable;
    public $marketplaces;

    public function __construct($marketplaceId, $sellerId, $refreshToken, $region, $enable = true, $marketplaces = [])
    {
        $this->marketplaceId = $marketplaceId;
        $this->sellerId = $sellerId;
        $this->refreshToken = $refreshToken;
        $this->region = $region;
        $this->enable = $enable;
        $this->name = Region::getRegionNameByCode($region);
        $this->marketplaces = $marketplaces;
    }

    public function saveAmazonAuthCredentials()
    {
        $authCredentials[$this->region] = [
            'marketplaceId' => $this->marketplaceId,
            'sellerId' => $this->sellerId,
            'refreshToken' => $this->refreshToken,
            'name' => $this->name,
            'enable' => $this->enable,
        ];

        $authCredentialsOld = AmazonMarketConfiguration::get(Key::AMZ_AUTH_COMBO);
        $authCredentialsOld = !is_array($authCredentialsOld) ? [] : $authCredentialsOld;

        return AmazonMarketConfiguration::updateValue(
            Key::AMZ_AUTH_COMBO,
            array_merge($authCredentialsOld, $authCredentials)
        );
    }
}
