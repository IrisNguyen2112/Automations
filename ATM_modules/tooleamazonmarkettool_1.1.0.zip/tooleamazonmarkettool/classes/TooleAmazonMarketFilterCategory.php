<?php
/**
 *  2023 TOOLE - Inter-soft.COM
 *  All rights reserved.
 *
 *  DISCLAIMER
 *
 *  Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketFilterCategory extends ObjectModel
{
    public $id_category;
    public $id_shop;
    public $id_shop_group;
    public $id_entity;
    public $enabled_ps_amz;
    public $enabled_amz_ps;

    const IS_ENABLED = 1;

    const ENABLED_PS_AMZ = 1;
    const ENABLED_AMZ_PS = 2;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = [
        'table' => Database::TABLE_FILTER_CATEGORIES,
        'primary' => 'id_sync_category',
        'multilang' => false,
        'multishop' => false,
        'fields' => [
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_shop_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_category' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'id_entity' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'enabled_ps_amz' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
            'enabled_amz_ps' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
        ],
    ];

    public function save($null_values = false, $auto_date = true)
    {
        return parent::save($null_values, $auto_date);
    }

    public function delete()
    {
        return parent::delete();
    }

    public static function updateEnabled(
        $id_category,
        $enabled = null,
        $type = self::ENABLED_PS_AMZ,
        $id_entity = null,
        $id_shop = null,
        $context = null
    ) {
        if (!$context) {
            $context = Context::getContext();
        }

        $return = true;

        $sql = new DbQuery();
        $sql->select('pq.id_sync_category');
        $sql->from(Database::TABLE_FILTER_CATEGORIES, 'pq');

        $sql->where('pq.id_category=' . (int) $id_category);
        $sql->where('pq.id_shop=' . (int) $context->shop->id);
        $sql->where('pq.id_entity=' . (int) $id_entity);
        $id_sync_category = (int) Db::getInstance()->getValue($sql);

        if (!is_numeric($enabled) && !$id_sync_category) {
            $enabled = 1;
        } elseif (!is_numeric($enabled) && $id_sync_category) {
            $category_sync = new TooleAmazonMarketFilterCategory($id_sync_category);
            $enabled = self::ENABLED_PS_AMZ === $type ? (int) !$category_sync->enabled_ps_amz : (int) !$category_sync->enabled_amz_ps;
        }
        $category_sync = new TooleAmazonMarketFilterCategory($id_sync_category);
        $category_sync->id_category = (int) $id_category;
        $category_sync->id_shop = (int) $context->shop->id;
        $category_sync->id_shop_group = (int) $context->shop->id_shop_group;
        $category_sync->id_entity = (int) $id_entity;
        $category_sync->enabled_ps_amz = self::ENABLED_PS_AMZ === $type ? (int) $enabled : (int) $category_sync->enabled_ps_amz;
        $category_sync->enabled_amz_ps = self::ENABLED_AMZ_PS === $type ? (int) $enabled : (int) $category_sync->enabled_amz_ps;

        $return &= $category_sync->save();

        return $return;
    }

    public static function enableAll($id_shop = null)
    {
        if (!$id_shop) {
            $id_shop = Context::getContext()->shop->id;
        }

        Db::getInstance()->execute(
            'DELETE FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` WHERE `id_shop` = ' . (int) $id_shop
        );

        $categories = Db::getInstance()->executeS('SELECT id_category FROM `' . _DB_PREFIX_ . 'category`');

        if (!empty($categories)) {
            $ids = array_column($categories, 'id_category');

            $values = array_map(function ($item) use ($id_shop) {
                $item = [$item, $id_shop, 1, 1];

                return '(' . implode(', ', $item) . ')';
            }, $ids);

            $columns = implode(', ', ['id_category', 'id_shop', 'enabled_ps_amz', 'enabled_amz_ps']);
            if ($values) {
                $sql = 'INSERT INTO `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` (' . $columns . ') VALUES ' . implode(', ', $values);
                return Db::getInstance()->execute($sql);
            }
        }

        return false;
    }

    /**
     * @param $column
     * @param array $catIds
     * @param $shopId
     *
     * @return false|string
     */
    public static function isEnableSync($column, $catIds, $shopId, $entityId)
    {
        $sql = new DbQuery();
        $sql->from(Database::TABLE_FILTER_CATEGORIES);
        $sql->select('count(*) as cnt');
        $sql->where('id_category IN (' . implode(',', $catIds) . ')');
        $sql->where('id_shop = ' . (int) $shopId);
        $sql->where('id_entity = ' . (int) $entityId);
        $sql->where("{$column} = " . self::IS_ENABLED);
        $res = Db::getInstance()->getRow($sql);

        return is_array($res) && $res['cnt'] > 0;
    }
}
