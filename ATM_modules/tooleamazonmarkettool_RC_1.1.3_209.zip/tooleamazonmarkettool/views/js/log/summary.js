/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */
$(document).ready(function () {
    const loading = $('#toole-modal-dialog');
    const paginationSummary = $('.pagination-summary');
    let selected_now_id = null;
    const defaultPagination = {
        page: 1,
        pageCount: 0,
        pageSize: 20,
        rowCount: 0,
    }
    let pagination = Object.assign({}, defaultPagination);

    function getQueryString(sParam) {
        var sPageURL = window.location.search.substring(1),
            sURLVariables = sPageURL.split('&'),
            sParameterName,
            i;
        for (i = 0; i < sURLVariables.length; i++) {
            sParameterName = sURLVariables[i].split('=');
            if (sParameterName[0] === sParam) {
                return typeof sParameterName[1] === undefined ? null : decodeURIComponent(sParameterName[1]);
            }
        }

        return null;
    }

    function removeQueryString(params) {
        var current_url = location.href;
        var href = new URL(current_url);
        href.searchParams.delete(params);
        window.history.replaceState({}, document.title, href);
    }

    if (getQueryString('id-log')) {
        $('input[name="idFilter_a!id"]').val(getQueryString('id-log'));
        removeQueryString('id-log');
        $('#submitFilterButtonid').click();
    } else {
        $('input[name="idFilter_a!id"]').val("");
    }

    function renderDetailPagination() {
        if (Object.keys(pagination).length <= 0 || pagination.pageCount <= 1) {
            paginationSummary.html('');
            return;
        }

        let classPrev = 'page-item';
        let classNext = 'page-item';
        if (pagination.page === 1) {
            classPrev = 'page-item disabled';
        }
        if (pagination.page === pagination.pageCount) {
            classNext = 'page-item disabled';
        }

        paginationSummary.html(
            `<nav aria-label="Summaries detail pagination">
                <ul class="pagination">
                    <li class="${classPrev}">
                        <a role="button" class="page-previous" aria-label="Previous">
                            <span aria-hidden="true" >&laquo;</span>
                            <span class="sr-only" >Previous</span>
                        </a>
                    </li>
                    <li class="page-item" disabled>
                        <a class="number" disabled>${pagination.page}/${pagination.pageCount}</a>
                    </li>
                    <li class="${classNext}">
                        <a role="button" class="page-next" aria-label="Next">
                            <span aria-hidden="true" >&raquo;</span>
                            <span class="sr-only" >Next</span>
                        </a>
                    </li>
                </ul>
            </nav>`
        );
    }

    function renderMessage(detail, content) {
        let messageClass;
        if (detail.type === 0) {
            messageClass = '';
        } else if (detail.type === 1) {
            messageClass = 'list-group-item-success';
        } else if (detail.type === 2) {
            messageClass = 'list-group-item-danger';
        } else {
            messageClass = 'list-group-item-warning';
        }
        content += '<li class="list-group-item ' + messageClass + '">';
        content +=
            '<span><span class="summary-time">From:</span> &nbsp;' + detail.date_start + '&nbsp;&nbsp;&nbsp;<span class="summary-time">To:</span>&nbsp;' + detail.date_stop + '</span>' +
            '</br><span>' + detail.message + '</span>';
        if (detail.content_location) {
            content += '</br>' + '<span><a href="' + detail.content_location + '">Download Feed</a></span>';
        }
        if (detail.result_location) {
            content += '</br>' + '<span><a href="' + detail.result_location + '">Download Result</a></span>';
        }
        content += '</li>';

        return content;
    }

    function highlightAndDisableButtonNextBack(button_selected) {
        if (button_selected.is(':last-child')) {
            $('.btn-back').prop('disabled', false);
            $('.btn-next').prop('disabled', true);
        } else if (button_selected.is(':first-child')) {
            $('.btn-back').prop('disabled', true);
            $('.btn-next').prop('disabled', false);
        } else {
            $('.btn-next').prop('disabled', false);
            $('.btn-back').prop('disabled', false);
        }
        $('.toole-summary-detail').parents('tr').find('td').css('background', 'white');
        $(button_selected).find('td').css('background', '#f3f3f3');
    }

    function loadAjaxApi(modalContent, modalTitle, summaryModal, url, id, title) {
        $.ajax({
            url: url,
            type: 'GET',
            dataType: 'json',
            data: {
                id_log: id,
                action: 'getDetails',
                limit: pagination.pageSize,
                ajax: 1,
                page: pagination.page,
            },
            beforeSend: function () {
                // Modal hide
                loading.fadeIn();
                modalContent.empty();
                summaryModal.modal('hide');
            },
            success: function (data) {
                if (data?.pagination?.rowCount > 0) {
                    let content = '';
                    pagination = Object.assign({}, data.pagination);
                    data.details.forEach(function (detail) {
                        content = renderMessage(detail, content);
                    });
                    modalContent.html(content);
                } else {
                    pagination = Object.assign({}, defaultPagination);
                    summaryModal.modal('hide');
                    modalContent.html('No report yet.');
                }
                modalTitle.text(title);
                renderDetailPagination();
                summaryModal.modal();
            },
            error: function (data) {
                console.log('error', data);
            },
            complete: function () {
                // modal show
                loading.fadeOut();
            }
        });
    }

    function setupConfSummary(button_selected) {
        const id = $(button_selected).data('id'),
            url = window.location.href,
            title = id + ' - ' + $(button_selected).closest('tr').find('.column-title').text();
        let summaryModal = $('#toole-summary-modal'),
            modalContent = $('#toole-summary-modal .modal-body .list-group'),
            modalTitle = $('#toole-summary-modal .modal-title');
        loadAjaxApi(modalContent, modalTitle, summaryModal, url, id, title);
    }

    function renderDisplay(button_selected) {
        highlightAndDisableButtonNextBack(button_selected);
        let id_selected_next = $(button_selected).find('td').closest('.column-id').text().trim();
        setupConfSummary('#' + id_selected_next);
        selected_now_id = id_selected_next;
    }

    $(document).on('click', '.toole-summary-detail', function (e) {
        e.preventDefault();
        pagination = Object.assign({}, defaultPagination);
        highlightAndDisableButtonNextBack($(this).parents('tr'))
        selected_now_id = $(this).data('id');
        setupConfSummary(this);
    });
    $(document).keydown(function (e) {
        setTimeout(function () {
            if ($('#toole-summary-modal').hasClass('in')) {
                if (e.keyCode === 40 && !($('#' + selected_now_id).parents('tr').is(':last-child'))) {
                    e.preventDefault();
                    pagination = Object.assign({}, defaultPagination);
                    renderDisplay($('#' + selected_now_id).parents('tr').next());
                } else if (e.keyCode === 38 && !($('#' + selected_now_id).parents('tr').is(':first-child'))) {
                    e.preventDefault();
                    pagination = Object.assign({}, defaultPagination);
                    renderDisplay($('#' + selected_now_id).parents('tr').prev());
                }
                if (e.keyCode === 39) {
                    e.preventDefault();
                    if (pagination.page < pagination.pageCount) {
                        pagination.page = pagination.page + 1;
                        setupConfSummary('#' + selected_now_id);
                    }
                } else if (e.keyCode === 37) {
                    e.preventDefault();
                    if (pagination.page > 1) {
                        pagination.page = pagination.page - 1;
                        setupConfSummary('#' + selected_now_id);
                    }
                }
            }
        }, 150);
    })
    $(document).on('click', '.btn-next', function (e) {
        e.preventDefault();
        renderDisplay($('#' + selected_now_id).parents('tr').next());
    });
    $(document).on('click', '.btn-back', function (e) {
        e.preventDefault();
        renderDisplay($('#' + selected_now_id).parents('tr').prev());
    });
    $(document).on('click', '.page-next', function (e) {
        e.preventDefault();
        if (pagination.page < pagination.pageCount) {
            pagination.page = pagination.page + 1;
            setupConfSummary('#' + selected_now_id);
        }
    });
    $(document).on('click', '.page-previous', function (e) {
        e.preventDefault();
        if (pagination.page > 1) {
            pagination.page = pagination.page - 1;
            setupConfSummary('#' + selected_now_id);
        }
    });
});
