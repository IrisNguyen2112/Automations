/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

$(document).ready(function () {
    const loader = $('#toole-loader');
    const fulfillBtn = $('#action_fullfill');
    const cancelBtn = $('#action_cancel');
    const mpStatus = $('.mp_status');
    const successAlert = $('.success');
    const warningAlert = $('.warning');
    const errorAlert = $('.error');
    const selectCancelReasonModal = $('#select-cancel-reason-modal');

    fulfillBtn.click(function () {
        const fulfillLink = $(this).data('fulfillLink');
        const orderId = $(this).data('orderId');

        $.ajax({
            url: fulfillLink,
            type: 'POST',
            dataType: 'json',
            data: {
                ajax: 1,
                action: 'fulfillment',
                id: orderId,
            },
            beforeSend: function () {
                loader.show();
                successAlert.empty();
                warningAlert.empty();
                errorAlert.empty();
                successAlert.hide();
                warningAlert.hide();
                errorAlert.hide();
            },
            success: function (res) {
                if (res?.hasMessage) {
                    const successMessages = res?.messages?.join('<br>') || '';
                    successAlert.html(successMessages);
                    successAlert.show();
                }
                if (res?.hasWarning) {
                    const warningMessages = res?.warnings?.join('<br>') || '';
                    warningAlert.html(warningMessages);
                    warningAlert.show();
                }
                fulfillBtn.attr('disabled', true);
                mpStatus.html(res?.data?.mp_status || '');
            },
            error: function (err) {
                if (err?.hasError) {
                    const errorMessages = err?.errors?.join('<br>') || '';
                    errorAlert.html(errorMessages);
                    errorAlert.show();
                }
                fulfillBtn.removeAttr('disabled', false);
            },
            complete: function () {
                loader.hide();
            }
        });
    });

    cancelBtn.on('click', function () {
        selectCancelReasonModal.modal('show');
        let url = $(this).data('cancel-link');
        let orderId = $(this).data('orderId');
        selectCancelReasonModal.find('#select-cancel-reason-form').on('submit', function (e) {
            e.preventDefault();
            $.ajax({
                url: url,
                type: 'post',
                dataType: 'json',
                data: {
                    ajax: 1,
                    action: 'cancelOrder',
                    id: orderId,
                    cancel_reason_name: $(this).find('select[name="cancel_reason_name"]').val(),
                },
                beforeSend: function () {
                    selectCancelReasonModal.modal('hide');
                    loader.show();
                    successAlert.empty();
                    warningAlert.empty();
                    errorAlert.empty();
                    successAlert.hide();
                    warningAlert.hide();
                    errorAlert.hide();
                },
                success: function (res) {
                    if (res?.hasMessage) {
                        const successMessages = res?.messages?.join('<br>') || '';
                        successAlert.html(successMessages);
                        successAlert.show();
                    }
                    if (res?.hasWarning) {
                        const warningMessages = res?.warnings?.join('<br>') || '';
                        warningAlert.html(warningMessages);
                        warningAlert.show();
                    }
                    cancelBtn.attr('disabled', true);
                    mpStatus.html(res?.data?.mp_status || '');
                },
                error: function (err) {
                    if (err?.hasError) {
                        const errorMessages = err?.errors?.join('<br>') || '';
                        errorAlert.html(errorMessages);
                        errorAlert.show();
                    }
                    cancelBtn.removeAttr('disabled', false);
                },
                complete: function () {
                    loader.hide();
                }
            });

            return false;
        });
    });
});
