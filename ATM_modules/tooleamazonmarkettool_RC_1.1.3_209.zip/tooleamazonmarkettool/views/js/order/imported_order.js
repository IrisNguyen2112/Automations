/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

function sendBulkAction(form, action) {

    String.prototype.splice = function(index, remove, string) {
        return (this.slice(0, index) + string + this.slice(index + Math.abs(remove)));
    };

    var form_action = $(form).attr('action');

    if (form_action.replace(/(?:(?:^|\n)\s+|\s+(?:$|\n))/g,'').replace(/\s+/g,' ') == '')
        return false;

    if (action === 'submitBulkcancelMultitoole_amt_amazon_orders') {
        const selectCancelReasonModal = $('#select-cancel-reason-modal');
        selectCancelReasonModal.modal('show');

        let url = '';
        if (form_action.indexOf('#') == -1)
            url = form_action + '&' + action;
        else
            url = form_action.splice(form_action.lastIndexOf('&'), 0, '&' + action);

        const formCancelReason = selectCancelReasonModal.find('#select-cancel-reason-form');

        let orderIds = [];
        $(form).serializeArray().map(function (item, index) {
            if (item.name === 'toole_amt_amazon_ordersBox[]') {
                orderIds.push(parseInt(item.value));
            }
        });

        const successAlert = $('.alert-success');
        const warningAlert = $('.alert-warning');
        formCancelReason.on('submit', function (e) {
            e.preventDefault();
            $.ajax({
                url: url,
                type: 'POST',
                dataType: 'json',
                data: {
                    action,
                    toole_amt_amazon_ordersBox: orderIds,
                    cancel_reason_name: formCancelReason.find('select[name="cancel_reason_name"]').val(),
                },
                beforeSend: function () {
                    selectCancelReasonModal.modal('hide');
                    $('#toole-modal-dialog').fadeIn();
                },
                success: function (res) {
                    if (res?.hasMessage) {
                        if (res?.data?.redirect) {
                            location.href = res?.data?.redirect;
                        }
                    }
                    if (res?.hasWarning) {
                        const warningMessages = res?.warnings?.join('<br>') || '';
                        warningAlert.html(warningMessages);
                        warningAlert.show();
                    }
                    if (res?.hasError) {
                        const errorMessages = res?.errors?.join('<br>') || '';
                        warningAlert.html(errorMessages);
                        warningAlert.show();
                    }
                },
                complete: function () {
                    selectCancelReasonModal.modal('hide');
                    $('#toole-modal-dialog').fadeOut();
                }
            });
        });
        return;
    }

    if (form_action.indexOf('#') == -1)
        $(form).attr('action', form_action + '&' + action);
    else
        $(form).attr('action', form_action.splice(form_action.lastIndexOf('&'), 0, '&' + action));

    $(form).submit();
}

$(document).ready(function () {
    const addCustomFieldEl = $('#add_custom_fields');
    const addCustomFieldBtn = $('#add_custom_fields .panel-heading-action');
    const header = addCustomFieldEl.find('.panel-heading');
    const body = addCustomFieldEl.find('.panel-body');
    const footer = addCustomFieldEl.find('.panel-footer');
    const selectBox = addCustomFieldEl.find('.select-box');
    const orderTable = $('#table-toole_amt_amazon_orders');
    const cancelBtn = orderTable.find('.cancel-order-to-amazon');
    const selectCancelReasonModal = $('#select-cancel-reason-modal');

    selectBox.chosen({width: '100%'});

    addCustomFieldBtn.on('click', function () {
        addCustomFieldEl.toggleClass('minimize-card');
        header.toggleClass('minimize-card');
        body.toggle();
        footer.toggle();
        selectBox.chosen({width: '100%'});
    });

    cancelBtn.each(function() {
        $(this).on('click', function () {
            selectCancelReasonModal.modal('show');
            selectCancelReasonModal.find('#select-cancel-reason-form').attr('action', $(this).data('href'));

        });
    });
});
