<?php
/**
 * TooleAmazonMarketAmazonOrderItem
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketAmazonOrderItem extends ObjectModel
{
    public $id_order_item;
    public $id_order;
    public $ps_order_detail_id;
    public $asin;
    public $seller_sku;
    public $order_item_id;
    public $quantity;
    public $item_price;
    public $shipping_price;
    public $item_tax;
    public $shipping_tax;
    public $date_add;
    public $date_upd;

    public static $definition = [
        'table' => Database::TABLE_ORDER_ITEMS,
        'primary' => 'id_order_item',
        'multilang' => false,
        'multishop' => false,
        'fields' => [
            'id_order_item' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'ps_order_detail_id' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'asin' => ['type' => self::TYPE_STRING, 'size' => 32, 'required' => true],
            'seller_sku' => ['type' => self::TYPE_STRING, 'size' => 64, 'required' => true],
            'order_item_id' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true],
            'quantity' => ['type' => self::TYPE_INT, 'required' => true],
            'item_price' => ['type' => self::TYPE_FLOAT, 'required' => true],
            'shipping_price' => ['type' => self::TYPE_FLOAT, 'required' => false],
            'item_tax' => ['type' => self::TYPE_FLOAT, 'required' => false],
            'shipping_tax' => ['type' => self::TYPE_FLOAT, 'required' => false],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate', 'copy_post' => false],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate', 'copy_post' => false],
        ],
    ];
}
