<?php
/**
 *  2023 TOOLE - Inter-soft.COM
 *  All rights reserved.
 *
 *  DISCLAIMER
 *
 *  Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketAmazonEntity extends ObjectModel
{
    public $entity;
    public $name;
    public $iso_code;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = [
        'table' => Database::TABLE_AMAZON_ENTITIES,
        'primary' => 'id_entity',
        'multilang' => false,
        'multishop' => false,
        'fields' => [
            'entity' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
            'name' => ['type' => self::TYPE_STRING, 'size' => 255, 'required' => true, 'shop' => false],
            'iso_code' => ['type' => self::TYPE_STRING, 'size' => 3, 'required' => false, 'shop' => false],
        ],
    ];

    public static function findOneIdByEntity($entity)
    {
        $sql = 'SELECT ae.`id_entity` FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` ae
                WHERE ae.`entity` = "' . pSQL($entity) . '"';

        return Db::getInstance()->getValue($sql);
    }

    public static function saveEntity($entity, $name)
    {
        $sql = 'INSERT INTO `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` (`entity`, `name`)
                VALUES ("' . pSQL($entity) . '", "' . pSQL($name) . '")
                ON DUPLICATE KEY UPDATE `entity` = VALUES(`entity`)';

        return Db::getInstance()->execute($sql);
    }

    public static function seedIsoCode(): void
    {
        $isoCodes = [
            'AU' => 'Australia',
            'BE' => 'Belgium',
            'BR' => 'Brazil',
            'CA' => 'Canada',
            'EG' => 'Egypt',
            'FR' => 'France',
            'DE' => 'Germany',
            'IN' => 'India',
            'IT' => 'Italy',
            'JP' => 'Japan',
            'MX' => 'Mexico',
            'NL' => 'Netherlands',
            'PL' => 'Poland',
            'SA' => 'Saudi Arabia',
            'SG' => 'Singapore',
            'ZA' => 'South Africa',
            'ES' => 'Spain',
            'SE' => 'Sweden',
            'TR' => 'Turkey',
            'AE' => 'United Arab Emirates',
            'GB' => 'United Kingdom',
            'US' => 'United States',
        ];

        foreach ($isoCodes as $code => $country) {
            Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` ae SET ae.`iso_code` = "' . $code . '" WHERE ae.`name` = "' . $country . '"');
        }
    }
}
