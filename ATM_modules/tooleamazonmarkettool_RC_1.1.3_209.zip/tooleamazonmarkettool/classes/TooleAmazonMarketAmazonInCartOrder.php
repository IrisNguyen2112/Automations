<?php
/**
 * TooleAmazonMarketAmazonInCartOrder
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketAmazonInCartOrder extends ObjectModel
{
    public $id;
    public $id_entity;
    public $id_shop;
    public $id_shop_group;
    public $mp_order_id;
    public $date_add;
    public $date_upd;

    public static $definition = [
        'table' => Database::TABLE_IN_CART_ORDERS,
        'primary' => 'id',
        'multilang' => false,
        'multishop' => true,
        'fields' => [
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_entity' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'id_shop_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'mp_order_id' => ['type' => self::TYPE_STRING, 'size' => 32, 'required' => true],
            'date_add' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
            'date_upd' => ['type' => self::TYPE_DATE, 'validate' => 'isDate'],
        ],
    ];

    /**
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public static function findByMpOrderId($mp_order_id)
    {
        $sql = new DbQuery();
        $sql->select('ico.*');
        $sql->from(Database::TABLE_IN_CART_ORDERS, 'ico');
        $sql->where('ico.mp_order_id = "' . $mp_order_id . '"');

        $inCartOrder = Db::getInstance()->getRow($sql);

        if (!$inCartOrder) {
            return false;
        }

        $inCartOrder = new self($inCartOrder['id'] ?? null);

        if (!Validate::isLoadedObject($inCartOrder)) {
            return false;
        }

        return $inCartOrder;
    }

    /**
     * @throws PrestaShopDatabaseException
     */
    public function getInCartItems()
    {
        $sql = new DbQuery();
        $sql->select('icot.*');
        $sql->from(Database::TABLE_IN_CART_ORDER_ITEMS, 'icot');
        $sql->innerJoin(Database::TABLE_IN_CART_ORDERS, 'ico', 'ico.id = icot.id_in_cart_order');
        $sql->where('icot.id_in_cart_order = ' . $this->id);
        return Db::getInstance()->executeS($sql);
    }

    /**
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public static function create($data = [])
    {
        if (empty($data)) {
            return false;
        }

        $inCartOrder = new self();
        $inCartOrder->id_entity = $data['id_entity'] ?? null;
        $inCartOrder->id_shop = $data['id_shop'] ?? null;
        $inCartOrder->id_shop_group = $data['id_shop_group'] ?? null;
        $inCartOrder->mp_order_id = $data['mp_order_id'] ?? null;
        $inCartOrder->add();

        return $inCartOrder;
    }
}
