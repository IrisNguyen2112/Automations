<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param TooleAmazonMarketTool $module
 *
 * @return bool
 * @throws PrestaShopDatabaseException
 */
function upgrade_module_1_1_3($module)
{
    $result = true;

    $amazonProducts = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '`');
    if (!in_array('asin', array_column($amazonProducts, 'Field'))) {
        $result &= Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` ADD COLUMN `asin` VARCHAR( 32 ) NULL AFTER `sku`;');
    }

    // Create table for amazon in-cart orders
    $sqlCreateInCartOrderTable = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_IN_CART_ORDERS . '` (
                `id` INT unsigned NOT NULL AUTO_INCREMENT,
                `id_entity` INT unsigned DEFAULT NULL,
                `id_shop` INT unsigned DEFAULT NULL,
                `id_shop_group` INT unsigned DEFAULT NULL,
                `mp_order_id` VARCHAR(32) NOT NULL,
                `date_add` DATETIME NOT NULL,
	            `date_upd` TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;';

    $result &= Db::getInstance()->execute($sqlCreateInCartOrderTable);

    $sqlCreateInCartOrderItemTable = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_IN_CART_ORDER_ITEMS . '` (
                `id` INT unsigned NOT NULL AUTO_INCREMENT,
                `id_in_cart_order` INT unsigned NOT NULL,
                `id_product` INT unsigned NOT NULL,
                `id_product_attribute` INT unsigned NOT NULL,
                `quantity` INT unsigned NOT NULL,
                `date_add` DATETIME NOT NULL,
	            `date_upd` TIMESTAMP,
                PRIMARY KEY (`id`)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;';

    $result &= Db::getInstance()->execute($sqlCreateInCartOrderItemTable);

    return $result;
}
