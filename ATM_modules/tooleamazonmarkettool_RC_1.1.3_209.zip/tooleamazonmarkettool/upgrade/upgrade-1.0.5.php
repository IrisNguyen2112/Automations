<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param TooleAmazonMarketTool $module
 *
 * @return bool
 */
function upgrade_module_1_0_5($module)
{
    $result = true;
    $sqlCreateMkps = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` (
                `id_entity` INT unsigned NOT NULL auto_increment,
                `entity` VARCHAR(50) NOT NULL,
                `name` TEXT NOT NULL,
                PRIMARY KEY (`id_entity`),
                CONSTRAINT unique_entity UNIQUE (entity)
            ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8;';

    $result &= (bool) Db::getInstance()->execute($sqlCreateMkps);

    if ($result) {
        $regions = Region::getAllRegionsWithMkps();
        foreach ($regions as $regionId => $region) {
            TooleAmazonMarketAmazonEntity::saveEntity($regionId, $region['name']);
            foreach ($region['marketplaces'] as $mkpId => $mkpName) {
                TooleAmazonMarketAmazonEntity::saveEntity($mkpId, $mkpName);
            }
        }

        $listAmzProducts = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '`');
        if (!in_array('id_entity', array_column($listAmzProducts, 'Field'))) {
            Db::getInstance()->execute('TRUNCATE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '`');
            $sqlAlterAmzProduct = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '`
                ADD COLUMN `id_entity` INT unsigned NOT NULL AFTER `id_shop`,
                ADD CONSTRAINT fk_amz_products_entity FOREIGN KEY (id_entity) REFERENCES ' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '(id_entity)';
            $result &= (bool) Db::getInstance()->execute($sqlAlterAmzProduct);
        }

        $listProductFields = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '`');
        if (!in_array('id_entity', array_column($listProductFields, 'Field'))) {
            Db::getInstance()->execute('TRUNCATE `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '`');
            $sqlAlterProduct = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '`
                ADD COLUMN `id_entity` INT unsigned NOT NULL AFTER `id_shop`,
                ADD CONSTRAINT fk_products_entity FOREIGN KEY (id_entity) REFERENCES ' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '(id_entity)';
            $result &= (bool) Db::getInstance()->execute($sqlAlterProduct);
        }

        $listManufacturerFields = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '`');
        if (!in_array('id_entity', array_column($listManufacturerFields, 'Field'))) {
            Db::getInstance()->execute('TRUNCATE `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '`');
            $sqlAlterManufacturer = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '`
                ADD COLUMN `id_entity` INT unsigned NOT NULL AFTER `id_shop`,
                ADD CONSTRAINT fk_manufacturers_entity FOREIGN KEY (id_entity) REFERENCES ' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '(id_entity)';
            $result &= (bool) Db::getInstance()->execute($sqlAlterManufacturer);
        }

        $listCategoryFields = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '`');
        if (!in_array('id_entity', array_column($listCategoryFields, 'Field'))) {
            Db::getInstance()->execute('TRUNCATE `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '`');
            $sqlAlterCategory = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '`
                ADD COLUMN `id_entity` INT unsigned NOT NULL AFTER `id_shop`,
                ADD CONSTRAINT fk_categories_entity FOREIGN KEY (id_entity) REFERENCES ' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '(id_entity)';
            $result &= (bool) Db::getInstance()->execute($sqlAlterCategory);
        }

        $listSupplyFields = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '`');
        if (!in_array('id_entity', array_column($listSupplyFields, 'Field'))) {
            Db::getInstance()->execute('TRUNCATE `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '`');
            $sqlAlterSupply = 'ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '`
                ADD COLUMN `id_entity` INT unsigned NOT NULL AFTER `id_shop`,
                ADD CONSTRAINT fk_supplies_entity FOREIGN KEY (id_entity) REFERENCES ' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '(id_entity)';
            $result &= (bool) Db::getInstance()->execute($sqlAlterSupply);
        }
    }

    // register hook: displayDashboardToolbarTopMenu
    $isHookable = Db::getInstance()->executeS('SELECT `a`.* FROM `' . _DB_PREFIX_ . 'hook_module` a LEFT JOIN `' . _DB_PREFIX_ . 'hook` h ON `h`.`id_hook` = `a`.`id_hook` WHERE `h`.`name` = "displayDashboardToolbarTopMenu" AND `a`.`id_module` = ' . $module->id);
    if (!$isHookable) {
        $result &= $module->registerHook('displayDashboardToolbarTopMenu');
    }

    return $result;
}
