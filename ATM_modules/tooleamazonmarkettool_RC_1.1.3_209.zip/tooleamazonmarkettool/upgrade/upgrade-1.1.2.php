<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param TooleAmazonMarketTool $module
 *
 * @return bool
 */
function upgrade_module_1_1_2($module)
{
    $result = true;

    $sqlCreateMkps = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_ORDER_ITEMS . '` (
        `id_order_item` int unsigned NOT NULL AUTO_INCREMENT,
        `id_order` int unsigned DEFAULT NULL,
        `ps_order_detail_id` int unsigned DEFAULT NULL,
        `asin` varchar(32) NOT NULL,
        `seller_sku` varchar(64) NOT NULL,
        `order_item_id` varchar(255) NOT NULL,
        `quantity` int NOT NULL,
        `item_price` DECIMAL(20,2) NOT NULL,
        `shipping_price` DECIMAL(20,2) NULL DEFAULT NULL,
        `item_tax` DECIMAL(20,2)  NULL DEFAULT NULL,
        `shipping_tax` DECIMAL(20,2)  NULL DEFAULT NULL,
        `date_add` DATETIME NOT NULL,
        `date_upd` TIMESTAMP,
        PRIMARY KEY (`id_order_item`)
    ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;';

    return $result && Db::getInstance()->execute($sqlCreateMkps);
}
