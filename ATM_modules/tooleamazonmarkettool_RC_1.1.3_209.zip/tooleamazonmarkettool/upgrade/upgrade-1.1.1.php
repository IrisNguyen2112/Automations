<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Install;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * @param TooleAmazonMarketTool $module
 *
 * @return bool
 * @throws PrestaShopDatabaseException
 */
function upgrade_module_1_1_1($module)
{
    $result = true;

    $filterCategories = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '`');
    if (!in_array('enabled_fba_ps', array_column($filterCategories, 'Field'))) {
        $result = $result && Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` ADD COLUMN `enabled_fba_ps` TINYINT(1) NOT NULL DEFAULT 0;');
    }
    $filterManufacturers = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '`');
    if (!in_array('enabled_fba_ps', array_column($filterManufacturers, 'Field'))) {
        $result = $result && Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` ADD COLUMN `enabled_fba_ps` TINYINT(1) NOT NULL DEFAULT 0;');
    }
    $filterProducts = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '`');
    if (!in_array('enabled_fba_ps', array_column($filterProducts, 'Field'))) {
        $result = $result && Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` ADD COLUMN `enabled_fba_ps` TINYINT(1) NOT NULL DEFAULT 0;');
    }
    $filterSuppliers = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '`');
    if (!in_array('enabled_fba_ps', array_column($filterSuppliers, 'Field'))) {
        $result = $result && Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` ADD COLUMN `enabled_fba_ps` TINYINT(1) NOT NULL DEFAULT 0;');
    }
    $amazonOrders = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '`');
    if (!in_array('is_access_point', array_column($amazonOrders, 'Field'))) {
        $result = $result && Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '` ADD COLUMN `is_access_point` TINYINT(1) NULL DEFAULT 0;');
    }
    $amazonProducts = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '`');
    if (!in_array('type', array_column($amazonProducts, 'Field'))) {
        $result = $result && Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` ADD COLUMN `type` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_mapped`;');
    }

    // create table for fba order
    $sqlCreateMkps = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . Database::TABLE_FBA_ORDERS . '` (
        `id_fba_order` int unsigned NOT NULL AUTO_INCREMENT,
        `id_entity` int unsigned DEFAULT NULL,
        `id_shop` int unsigned DEFAULT NULL,
        `id_shop_group` int unsigned DEFAULT NULL,
        `ps_order_id` int unsigned NOT NULL,
        `seller_fulfillment_order_id` varchar(40) DEFAULT NULL,
        `displayable_order_id` varchar(40) DEFAULT NULL,
        `displayable_order_date` datetime NOT NULL,
        `displayable_order_comment` text NOT NULL,
        `shipping_speed_category` varchar(32) NOT NULL,
        `fulfillment_action` varchar(32) NOT NULL,
        `received_date` datetime NOT NULL,
        `fulfillment_order_status` varchar(32) NOT NULL,
        `status_updated_date` datetime NOT NULL,
        `notification_emails` text NOT NULL,
        `feature_constraints` text NOT NULL,
        `date_add` DATETIME NOT NULL,
        `date_upd` TIMESTAMP,
        PRIMARY KEY (`id_fba_order`)
    ) ENGINE=`' . _MYSQL_ENGINE_ . '` DEFAULT CHARSET=UTF8MB4;';

    $result = $result && Db::getInstance()->execute($sqlCreateMkps);

    $filterCategories = Db::getInstance()->executeS('SHOW FIELDS FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '`');
    if (!in_array('iso_code', array_column($filterCategories, 'Field'))) {
        $result = $result && Db::getInstance()->execute('ALTER TABLE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` ADD COLUMN `iso_code` VARCHAR(3) NULL DEFAULT NULL;');

        if ($result) {
            TooleAmazonMarketAmazonEntity::seedIsoCode();
        }
    }

    // register hook: displayAdminListBefore
    $isHookable = Db::getInstance()->executeS('SELECT `a`.* FROM `' . _DB_PREFIX_ . 'hook_module` a LEFT JOIN `' . _DB_PREFIX_ . 'hook` h ON `h`.`id_hook` = `a`.`id_hook` WHERE `h`.`name` = "displayAdminListBefore" AND `a`.`id_module` = ' . $module->id);
    if (!$isHookable) {
        $result = $result && $module->registerHook('displayAdminListBefore');
    }

    return $result && (new Install($module))->installTabs();
}
