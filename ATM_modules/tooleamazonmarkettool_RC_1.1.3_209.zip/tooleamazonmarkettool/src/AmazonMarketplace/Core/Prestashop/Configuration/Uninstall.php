<?php
/**
 * Uninstall
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Uninstall
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

use Configuration;
use Db;
use Tab;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use TooleAmazonMarketTool;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Uninstall
{
    /**
     * @var TooleAmazonMarketTool
     */
    protected $module;

    public function __construct(TooleAmazonMarketTool $module)
    {
        $this->module = $module;
    }

    public function run(): bool
    {
        return $this->uninstallTabs() && $this->removeGlobalVars();
    }

    public function dropTables(): bool
    {
        $sql = [
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ORDERS . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_FEEDS . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_LOGS . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_MESSAGES . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_LOG_DETAILS . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_IN_CART_ORDERS . '`',
            'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . Database::TABLE_IN_CART_ORDER_ITEMS . '`',
        ];

        $result = true;
        foreach ($sql as $query) {
            $result = $result && Db::getInstance()->execute($query);
        }

        return $result;
    }

    public function uninstallTabs(): bool
    {
        $uninstallTabCompleted = true;
        $moduleTabs = Tab::getCollectionFromModule($this->module->name)->getAll();
        /** @var Tab $moduleTab */
        foreach ($moduleTabs as $moduleTab) {
            $uninstallTabCompleted = $uninstallTabCompleted && $moduleTab->delete();
        }

        return $uninstallTabCompleted;
    }

    private function removeConfiguration()
    {
        AmazonMarketConfiguration::deleteAll();
        Configuration::deleteByName(Key::CONFIG_PRESTASHOP_STORECONFIGURATIONID);

        if (Configuration::getGlobalValue(Key::CONFIG_PRESTASHOP_SANDBOX)) {
            Configuration::deleteByName(Key::CONFIG_PRESTASHOP_SUBSCRIPTIONID);
            Configuration::deleteByName(Key::CONFIG_PRESTASHOP_PLANID);
            Configuration::deleteByName(Key::CONFIG_PRESTASHOP_STOREID);
        }
        Configuration::deleteByName(Key::CONFIG_PRESTASHOP_SANDBOX);

        return true;
    }

    private function removeGlobalVars(): bool
    {
        return true;
    }
}
