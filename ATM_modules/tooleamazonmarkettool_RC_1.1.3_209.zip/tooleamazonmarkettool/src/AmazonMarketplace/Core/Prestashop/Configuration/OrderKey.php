<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

if (!defined('_PS_VERSION_')) {
    exit;
}

class OrderKey extends Key
{
    const CONFIG_IMPORTED_ORDERS_OPTIONAL_COLUMNS = 'TOOLE_AMT_CONFIG_IMPORTED_ORDERS_OPTIONAL_COLUMNS';
}
