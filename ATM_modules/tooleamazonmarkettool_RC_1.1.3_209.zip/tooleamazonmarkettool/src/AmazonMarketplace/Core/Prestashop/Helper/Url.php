<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Helper;

use Context;
use PrestaShopException;
use Shop;
use ShopUrl;
use Tools;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Url
{
    /**
     * @throws PrestaShopException
     */
    public static function getModuleUrl($module, $with_virtual_url = true): string
    {
        $context = Context::getContext();
        $url = __PS_BASE_URI__ . basename(_PS_MODULE_DIR_) . '/' . $module . '/';

        if ($with_virtual_url) {
            if (method_exists('ShopUrl', 'getShopUrls') && Shop::isFeatureActive()) {
                $shop_url = ShopUrl::getShopUrls($context->shop->id)->where('main', '=', 1)->getFirst();

                if ($shop_url instanceof ShopUrl && Tools::strlen($shop_url->virtual_uri)) {
                    $url = $shop_url->physical_uri . $shop_url->virtual_uri . basename(_PS_MODULE_DIR_) . '/' . $module . '/';
                }
            }
        }

        return $url;
    }
}
