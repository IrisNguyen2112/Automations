<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Helper;

use PrestaShop\PrestaShop\Adapter\Entity\Db;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Carrier
{
    public static function getIdCurrentlyUsing($idCarrier): string
    {
        return Db::getInstance()->getValue('
            SELECT c1.id_carrier FROM ' . _DB_PREFIX_ . 'carrier c1
            WHERE c1.deleted = 0
                AND c1.id_reference IN (
                    SELECT c2.id_reference FROM ' . _DB_PREFIX_ . 'carrier c2
                    WHERE c2.id_carrier = ' . (int) $idCarrier . '
                )
        ');
    }
}
