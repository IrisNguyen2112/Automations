<?php
/**
 * RuleByPrice
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate;

class RuleByPrice extends Rule
{
    public function __construct($min, $max, $name)
    {
        parent::__construct($min, $max, $name, self::TYPE_PRICE);
    }

    public function validateInput($inputValue): bool
    {
        return $this->validateMinMax($inputValue);
    }
}
