<?php
/**
 *  OutgoingCarrierMapping
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes;

if (!defined('_PS_VERSION_')) {
    exit;
}

class OutgoingCarrierMapping
{
    public $psIdCarrier;
    public $amazonCarrier;
    public $shippingMethod;

    public function __construct($psIdCarrier, $amazonCarrier, $shippingMethod)
    {
        $this->psIdCarrier = $psIdCarrier;
        $this->amazonCarrier = $amazonCarrier;
        $this->shippingMethod = $shippingMethod;
    }
}
