<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Currency;
use Db;
use DbQuery;
use Exception;
use Module;
use PrestaShopDatabaseException;
use PrestaShopException;
use StockAvailable;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Product as HelperProduct;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;
use TooleAmazonMarketAmazonInCartOrder;
use TooleAmazonMarketAmazonInCartOrderItem;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class InCartOrder extends OrderImport
{
    protected $entityId;
    protected $idShopGroup;

    public function __construct(ServiceAPIV3Helper $saasHelper, Module $module, $entityId, $idShop, $idShopGroup)
    {
        parent::__construct([true], $saasHelper, $module, new Currency(), $idShop, true);
        $this->entityId = $entityId;
        $this->idShopGroup = $idShopGroup;
    }

    public function resolveStock($order)
    {
        try {
            $this->resolveStockLogic($order);
            $this->confirmations[] = sprintf('Handle stock of Amazon Order (%s) successfully', $order['AmazonOrderId']);
        } catch (Exception $exception) {
            $this->errors[] = $exception->getMessage();
            $this->debugs[] = $exception->getTraceAsString();
        }
    }

    /**
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     * @throws Exception
     */
    public function resolveStockLogic($order)
    {
        $inCartOrder = TooleAmazonMarketAmazonInCartOrder::findByMpOrderId($order['AmazonOrderId']);
        $amazonOrderItemAPIResult = $this->saasHelper->getOrderItems($order['AmazonOrderId']);
        $amazonOrderItems = $this->getAllOrderItems($amazonOrderItemAPIResult, $order['AmazonOrderId']);

        if (!empty($inCartOrder)) {
            $inCartItems = $inCartOrder->getInCartItems();
            $this->revertStock($inCartItems);
            $this->confirmations[] = sprintf('Reverted the stock of Amazon Order %s (ID in in-cart order table: %s)', $order['AmazonOrderId'], $inCartOrder->id);
        } else {
            $inCartOrder = TooleAmazonMarketAmazonInCartOrder::create([
                'id_entity' => $this->entityId,
                'id_shop' => $this->id_shop,
                'id_shop_group' => $this->idShopGroup,
                'mp_order_id' => $order['AmazonOrderId'],
            ]);
        }

        if (empty($amazonOrderItems)) {
            throw new Exception(sprintf('Order %s not have nay item', $order['AmazonOrderId']));
        }

        foreach ($amazonOrderItems as $item) {
            $SKU = trim((string) $item->getSellerSKU());
            $product = HelperProduct::findProductBySku($SKU, false, $this->idLang, 'reference', $this->id_shop);
            $quantity = $item->getQuantityOrdered();

            if (!Validate::isLoadedObject($product)) {
                throw new Exception('Cannot load the product ' . $SKU);
            }

            if (!$product->active) {
                throw new Exception('Inactive product ' . $SKU);
            }

            if (isset($product->available_for_order) && !$product->available_for_order) {
                throw new Exception(sprintf('Unavailable product %s', $SKU));
            }

            // Product Combinations
            $combinations = $product->getAttributeCombinations($this->idLang);
            $id_product_attribute = 0;
            foreach ($combinations as $combination) {
                if (trim($combination['reference']) == $SKU) {
                    $id_product_attribute = (int) $combination['id_product_attribute'];

                    break;
                }
            }

            StockAvailable::updateQuantity($product->id, $id_product_attribute, -$quantity);

            $inCartOrderItem = new TooleAmazonMarketAmazonInCartOrderItem();
            $inCartOrderItem->id_product = $product->id;
            $inCartOrderItem->id_product_attribute = $id_product_attribute;
            $inCartOrderItem->id_in_cart_order = $inCartOrder->id;
            $inCartOrderItem->quantity = $quantity;
            $inCartOrderItem->add();

            $this->confirmations[] = sprintf('Resolved the stock of product %s with attribute product %s and quantity %s', $product->id, $id_product_attribute, $quantity);
        }
    }

    /**
     * @throws PrestaShopDatabaseException
     * @throws PrestaShopException
     */
    public function revertStock($inCartItems = [])
    {
        if (empty($inCartItems)) {
            return;
        }

        foreach ($inCartItems as $item) {
            StockAvailable::updateQuantity($item['id_product'], $item['id_product_attribute'], $item['quantity']);
            $inCartOrderItem = new TooleAmazonMarketAmazonInCartOrderItem($item['id']);
            $inCartOrderItem->delete();

            $this->confirmations[] = sprintf('Reverted the stock of product %s with attribute product %s and quantity %s', $item['id_product'], $item['id_product_attribute'], $item['quantity']);
        }
    }

    public function resolveStockOutDate($currentOrderIds = [])
    {
        $sql = new DbQuery();
        $sql->select('ico.*');
        $sql->from(Database::TABLE_IN_CART_ORDERS, 'ico');
        $sql->where('ico.id_entity = ' . $this->entityId);
        $sql->where('ico.id_shop = ' . $this->id_shop);
        $sql->where('ico.id_shop_group = ' . $this->idShopGroup);
        $sql->where('ico.mp_order_id NOT IN ("' . implode('","', $currentOrderIds) . '")');

        try {
            $nonExistsOrders = Db::getInstance()->executeS($sql);

            if (empty($nonExistsOrders)) {
                return;
            }

            foreach ($nonExistsOrders as $order) {
                $inCartOrder = new TooleAmazonMarketAmazonInCartOrder($order['id']);
                if (!Validate::isLoadedObject($inCartOrder)) {
                    continue;
                }
                $inCartItems = $inCartOrder->getInCartItems();
                $this->revertStock($inCartItems);
                $inCartOrder->delete();

                $this->confirmations[] = sprintf('Reverted the stock of Amazon Order %s (ID in in-cart order table: %s)', $order['mp_order_id'], $order['id']);
            }
        } catch (Exception $exception) {
            $this->errors[] = $exception->getMessage();
            $this->debugs[] = $exception->getTraceAsString();
        }
    }
}
