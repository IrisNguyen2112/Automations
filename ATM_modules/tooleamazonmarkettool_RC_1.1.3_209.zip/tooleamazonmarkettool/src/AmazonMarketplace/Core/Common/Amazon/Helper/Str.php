<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Str
{
    public static function noAccents($str)
    {
        $str = mb_convert_encoding($str, 'HTML-ENTITIES', 'UTF-8');
        $searches = ['&szlig;', '&(..)lig;', '&([aouAOU])uml;', '&(.)[^;]*;'];
        $replacements = ['ss', '\\1', '\\1e', '\\1'];
        foreach ($searches as $key => $search) {
            $str = mb_ereg_replace($search, $replacements[$key], $str);
        }

        return $str;
    }

    public static function fixEncoding($mixed)
    {
        if (is_array($mixed)) {
            foreach ($mixed as $key => $value) {
                $mixed[$key] = self::fixEncoding($value);
            }
        } elseif (is_string($mixed)) {
            return mb_convert_encoding($mixed, 'UTF-8', 'UTF-8');
        }

        return $mixed;
    }
}
