<?php
/**
 * Payment
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes;

use Cart;
use Configuration;
use Currency;
use Customer;
use Db;
use Order;
use OrderCarrier;
use OrderDetail;
use OrderHistory;
use Product;
use StockAvailable;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Cart as TeCart;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\OrderProduct as TeProduct;
use TooleAmazonMarketAmazonOrder;
use Tools;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Payment
{
    /** @var Cart */
    protected $psCart;
    /** @var TeCart */
    protected $teCart;
    /** @var TooleAmazonMarketAmazonOrder */
    protected $teOrder;

    protected $idOrderState;
    protected $moduleName;
    protected $paymentMethod;
    protected $withTax;
    protected $idWarehouse;
    protected $dateAdd;
    protected $idShop;
    protected $idShopGroup;
    protected $isPaid;

    public function __construct(Cart $cart, TeCart $teCart, TooleAmazonMarketAmazonOrder $teOrder, $idOrderState, $moduleName, $paymentMethod, $dateAdd, $idShop, $idShopGroup, $withTax = true, $isPaid = false)
    {
        $this->psCart = $cart;
        $this->teCart = $teCart;
        $this->teOrder = $teOrder;
        $this->idOrderState = $idOrderState;
        $this->moduleName = $moduleName;
        $this->paymentMethod = $paymentMethod;
        $this->dateAdd = $dateAdd;
        $this->idWarehouse = (int) Configuration::get('AMAZON_WAREHOUSE');
        $this->idShop = $idShop;
        $this->idShopGroup = $idShopGroup;
        $this->withTax = $withTax;
        $this->isPaid = $isPaid;
    }

    public function payOrder()
    {
        // 1. Validate
        $customer = new Customer($this->psCart->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            return false;
        }

        // 2. Insert order
        $priceTotalProduct = self::sanityPrice($this->teCart->calPriceTotalProducts(false));
        $priceTotalProductWt = $this->withTax ? self::sanityPrice($this->teCart->calPriceTotalProducts(true)) : $priceTotalProduct;
        $priceShipping = self::sanityPrice($this->teCart->calPriceTotalShipping(false));
        $priceShippingWt = $this->withTax ? self::sanityPrice($this->teCart->calPriceTotalShipping(true)) : $priceShipping;
        $priceWrap = self::sanityPrice($this->teCart->calPriceGiftWrap(false));
        $priceWrapWt = $this->withTax ? self::sanityPrice($this->teCart->calPriceGiftWrap(true)) : $priceWrap;
        $priceTotal = self::sanityPrice($this->teCart->calPriceTotal(false));
        $priceTotalWt = $this->withTax ? self::sanityPrice($this->teCart->calPriceTotal(true)) : $priceTotal;
        // Prevent duplicates - we already checked it earlier

        $order = new Order();
        $order->id_carrier = $this->psCart->id_carrier;
        $order->id_customer = $this->psCart->id_customer;
        $order->id_address_invoice = $this->psCart->id_address_invoice;
        $order->id_address_delivery = $this->psCart->id_address_delivery;
        $order->id_currency = $this->psCart->id_currency;
        $order->id_lang = $this->psCart->id_lang;
        $order->id_cart = $this->psCart->id;
        $order->secure_key = $this->resolveOrderSecureKey($customer);
        $order->payment = Tools::substr($this->paymentMethod, 0, 32);
        $order->module = $this->moduleName;
        $order->recyclable = (bool) Configuration::get('PS_RECYCLABLE_PACK');

        $order->total_products = $priceTotalProduct;
        $order->total_products_wt = $priceTotalProductWt;
        $order->total_discounts = 0;
        $order->total_shipping = $priceTotalWt;
        $order->total_wrapping = $priceWrap;
        $order->total_wrapping_tax_incl = $priceWrapWt;
        $order->total_wrapping_tax_excl = $priceWrap;
        $order->total_paid_real = $priceTotalWt;
        $order->total_paid = $priceTotalWt;

        $order->delivery_number = 0;
        $order->carrier_tax_rate = $this->teCart->getShippingTaxRate();
        $order->round_mode = Configuration::get('PS_PRICE_ROUND_MODE');
        $order->round_type = Configuration::get('PS_ROUND_TYPE');
        $order->reference = Order::generateReference();

        $order->total_paid_tax_excl = $priceTotal;
        $order->total_paid_tax_incl = $priceTotalWt;
        $order->total_shipping_tax_excl = $priceShipping;
        $order->total_shipping_tax_incl = $priceShippingWt;
        $order->total_paid_real = 0;
        $order->current_state = (int) $this->idOrderState;
        if ($this->idShop && $this->idShopGroup) {
            $order->id_shop = $this->idShop;
            $order->id_shop_group = $this->idShopGroup;
        } else {
            $order->id_shop = 1;
            $order->id_shop_group = 1;
        }

        $order->date_add = $this->dateAdd;
        $order->date_upd = $this->dateAdd;

        $null_date = '0000-00-00 00:00:00';
        $order->invoice_date = $null_date;
        $order->delivery_date = $null_date;

        $currency = new Currency($order->id_currency);
        $order->conversion_rate = $currency->conversion_rate ?: 1;
        $order->round_mode = Configuration::get('PS_PRICE_ROUND_MODE');
        $order->round_type = Configuration::get('PS_ROUND_TYPE');
        $order->gift = false;
        $order->gift_message = '';

        if ($order->validateFields(false, true) !== true) {
            return false;
        }
        $order->add(false, null);
        if (!Validate::isLoadedObject($order)) {
            return false;
        }

        // Add order payment if paid, set invoice later below
        if ($this->isPaid) {
            $order->addOrderPayment($order->total_paid, $this->paymentMethod);
        }

        $this->teOrder->ps_order_id = $order->id;
        $this->teOrder->save();

        $update_stocks = (bool) Configuration::get('PS_STOCK_MANAGEMENT');
        $products = $this->psCart->getProducts();
        foreach ($products as $product) {
            $SKU = trim((string) $product['reference']);
            $id_product = (int) $product['id_product'];
            $id_product_attribute = (int) $product['id_product_attribute'] ?: null;

            $productQuantity = Product::getRealQuantity($id_product, $id_product_attribute, $this->idWarehouse, $order->id_shop);
            $quantityInStock = $productQuantity - $product['cart_quantity'];
            if ($update_stocks) {
                StockAvailable::updateQuantity($id_product, $id_product_attribute, $product['cart_quantity'] * -1, $order->id_shop);
            }

            $amzItemBySku = $this->teCart->products[$SKU];
            $this->addProductToOrder($order, $product, $amzItemBySku, $quantityInStock);
        }

        $order_carrier = new OrderCarrier();
        $order_carrier->id_order = (int) $order->id;
        $order_carrier->date_add = $this->dateAdd;
        $order_carrier->date_upd = $this->dateAdd;
        $order_carrier->id_carrier = $order->id_carrier;
        $order_carrier->tracking_number = '';
        $order_carrier->weight = $order->getTotalWeight();
        $order_carrier->shipping_cost_tax_excl = $order->total_shipping_tax_excl;
        $order_carrier->shipping_cost_tax_incl = $order->total_shipping_tax_incl;
        $order_carrier->add(false);

        // add order history & set invoice
        $this->processingUpdateCurrentState($order, $order->current_state, 1);

        Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'order_payment` SET `date_add` = "' . pSQL($this->dateAdd) . '" WHERE `order_reference` = "' . pSQL($order->reference) . '"');

        if (Configuration::get('PS_ADVANCED_STOCK_MANAGEMENT')) {
            foreach ($products as $product) {
                if (StockAvailable::dependsOnStock((int) $product['id_product'])) {
                    StockAvailable::synchronize((int) $product['id_product'], $order->id_shop);
                }
            }
        }

        return $order->id;
    }

    /**
     * As same as Order::setCurrentState(), without the mail sending
     * @param Order $order
     * @param $id_order_state
     * @param $id_employee
     * @return bool
     * @throws \PrestaShopDatabaseException
     * @throws \PrestaShopException
     */
    protected function processingUpdateCurrentState(Order $order, $id_order_state, $id_employee = 1): bool
    {
        if (empty($id_order_state)) {
            return false;
        }
        $history = new OrderHistory();
        $history->id_order = (int) $order->id;
        $history->id_employee = (int) $id_employee;
        $history->id_order_state = $id_order_state;
        $history->add();

        $use_existings_payment = !$order->hasInvoice();
        $history->changeIdOrderState((int) $id_order_state, $order, $use_existings_payment);
        $res = Db::getInstance()->getRow('
            SELECT `invoice_number`, `invoice_date`, `delivery_number`, `delivery_date`
            FROM `' . _DB_PREFIX_ . 'orders`
            WHERE `id_order` = ' . (int) $order->id);
        $order->invoice_date = $res['invoice_date'];
        $order->invoice_number = $res['invoice_number'];
        $order->delivery_date = $res['delivery_date'];
        $order->delivery_number = $res['delivery_number'];
        $order->update();

        return true;
    }

    protected function resolveOrderSecureKey(Customer $customer): string
    {
        if ($customer->secure_key) {
            return pSQL($customer->secure_key);
        }

        return md5(time());
    }

    protected function sanityPrice($price): float
    {
        return Tools::ps_round(max(0, $price), 2);
    }

    protected function addProductToOrder(Order $order, $psProduct, TeProduct $amazonProduct, $quantityInStock): OrderDetail
    {
        $unit_price_tax_excl = $amazonProduct->getUnitPriceTaxExcl($order->id_address_delivery, $this->teCart->getPriceDisplayMethod());

        $order_detail = new OrderDetail();
        $order_detail->date_add = $this->dateAdd;
        $order_detail->date_upd = $this->dateAdd;
        $order_detail->id_order = (int) $order->id;
        $order_detail->product_name = $this->getProductName($psProduct, $amazonProduct);
        $order_detail->product_id = (int) $psProduct['id_product'];
        $order_detail->product_attribute_id = (int) $psProduct['id_product_attribute'] ?: null;
        $order_detail->product_quantity = (int) $amazonProduct->quantity;
        $order_detail->product_quantity_in_stock = (int) $quantityInStock;
        $order_detail->product_price = (float) $unit_price_tax_excl;
        $order_detail->product_ean13 = $psProduct['ean13'] ?: null;
        $order_detail->product_upc = $psProduct['upc'] ?: null;
        $order_detail->product_reference = trim((string) $psProduct['reference']);
        $order_detail->product_supplier_reference = $psProduct['supplier_reference'] ?: null;
        $order_detail->product_weight = Tools::ps_round($psProduct['id_product_attribute'] && $psProduct['weight_attribute'] ? $psProduct['weight_attribute'] : $psProduct['weight'], 4);
        $order_detail->tax_rate = 0;
        $order_detail->id_tax_rules_group = 0;
        $order_detail->ecotax = $psProduct['ecotax'];
        $order_detail->total_price_tax_incl = $amazonProduct->getTotalPriceTaxIncl();
        $order_detail->total_price_tax_excl = $amazonProduct->getTotalPriceTaxExcl($order->id_address_delivery, $this->teCart->getPriceDisplayMethod());
        $order_detail->unit_price_tax_incl = $amazonProduct->getUnitPriceTaxIncl();
        $order_detail->unit_price_tax_excl = $unit_price_tax_excl;
        $order_detail->tax_computation_method = $this->teCart->getPriceDisplayMethod();
        $order_detail->original_product_price = (float) $unit_price_tax_excl;
        $order_detail->purchase_supplier_price = isset($psProduct['wholesale_price']) ? Tools::ps_round((float) $psProduct['wholesale_price'], 2) : 0;
        $order_detail->id_shop = (int) $order->id_shop;
        $order_detail->id_warehouse = $this->idWarehouse;

        $order_detail->add(false);

        return $order_detail;
    }

    protected function getProductName($psProduct, $amazonProduct): string
    {
        $product_name = $psProduct['name'] . ((isset($psProduct['attributes']) && $psProduct['attributes'] != null) ? ' - ' . $psProduct['attributes'] : '');
        $product_name = trim($product_name);

        if (empty($product_name) || !Tools::strlen($product_name) || Tools::strlen($product_name) <= 3) {
            $product_name = isset($amazonProduct['name']) ? (string) $amazonProduct['name'] : 'unknown';
        }

        return $product_name;
    }
}
