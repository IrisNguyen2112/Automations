<?php
/**
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\AmazonAuth;

use Configuration;
use Context;
use Module;
use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Tools;

class AmazonAuth
{
    /** @var Module */
    protected $module;
    protected $context;
    protected $submitMkpThatTriggersAuth = 'toole_auth_mkp';
    protected $submitThatTriggersAuth = 'toole_amazon_authorization';

    public function __construct(Module $module, Context $context)
    {
        $this->module = $module;
        $this->context = $context;
    }

    public function amazonAuthorization(): ?AmazonAuthCredentials
    {
        $region = Tools::getValue('active_tab');
        $authMkpId = Tools::getValue($this->submitMkpThatTriggersAuth)[$region] ?? AmazonConstant::MKP_REGION_EU;

        // Begin the authorization flow
        if (Tools::isSubmit($this->submitThatTriggersAuth) && $authMkpId) {
            $authEndpoint = Configuration::getGlobalValue(Key::SERVICE_AMAZON_AUTH_URL);
            $returnUrl = $this->module->getContextLink()->getAdminLink('AdminModules', true, [], ['configure' => $this->module->name]);
            $authRegion = Region::searchRegionByMkp($authMkpId);
            $this->redirectToLogin($authEndpoint, $authMkpId, $returnUrl, ['ps_authorizing' => 1, 'region' => $authRegion, 'module' => $this->module->name]);
        }

        if (Tools::getValue('ps_authorizing')) {
            // The authorization returning
            $returnMkpId = Tools::getValue('mkp');
            $sellerId = Tools::getValue('selling_partner_id');
            $refreshToken = Tools::getValue('refresh_token');
            $region = Tools::getValue('region');

            return $this->callbackValidation($returnMkpId, $sellerId, $refreshToken, $region);
        }

        return null;
    }

    protected function redirectToLogin($endpoint, $mkpId, $returnUrl, $additionalQueries = [])
    {
        $queries = array_merge($additionalQueries, [
            'mkp' => $mkpId,
            'redirect' => $returnUrl,
        ]);
        $destination = $endpoint . '?' . http_build_query($queries);

        Tools::redirect($destination);
        exit;
    }

    protected function callbackValidation($mkp, $sellerId, $refreshToken, $region): ?AmazonAuthCredentials
    {
        if ($mkp && $sellerId && $refreshToken && $region) {
            return new AmazonAuthCredentials($mkp, $sellerId, $refreshToken, $region);
        }

        return null;
    }
}
