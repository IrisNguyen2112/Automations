<?php
/**
 *  2023 TOOLE - Inter-soft.COM
 *  All rights reserved.
 *
 *  DISCLAIMER
 *
 *  Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 */

use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketCatalogFiltersSuppliersController extends TooleBaseAdminController
{
    private $entityId;

    public function __construct()
    {
        $this->use_region = false;

        parent::__construct();
        $this->context = Context::getContext();

        $this->override_folder = 'catalog/filters/';
        $this->tpl_folder = 'catalog/filters/';
        $this->bootstrap = true;
        $this->table = 'supplier';
        $this->identifier = 'id_supplier';
        $this->submit_action = 'submitAdd' . $this->table;
        $this->class_name = 'ToolEAmazonMarketCatalogFiltersSuppliers';
        $this->lang = false;
        $this->deleted = false;
        $this->colorOnBackground = false;

        $this->explicitSelect = true;
        $this->addRowAction('view');
        $this->addRowAction('preview');
        if (!Tools::getValue('id_supplier')) {
            $this->multishop_context_group = false;
        }
        $this->imageType = 'gif';
        $this->fieldImageSettings = [
            'name' => 'icon',
            'dir' => 'os',
        ];
        $this->_defaultOrderBy = $this->identifier = 'id_supplier';
        $this->deleted = false;
        $this->_orderBy = null;
        $this->list_no_link = true;
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);

        $this->_join =
            ' JOIN `' . _DB_PREFIX_ . 'supplier_shop` sa ON
            (a.`id_supplier` = sa.`id_supplier` AND sa.id_shop = ' . $this->shop_id . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` ss ON
            (ss.id_supplier = a.`id_supplier` AND ss.id_shop = ' . $this->shop_id . ' AND ss.id_entity = ' . $this->entityId . ')
            LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` ae ON
            (ss.id_entity = ae.`id_entity`)';

        $this->bulk_actions = [
            'enableAmzToPs' => [
                'text' => $this->module->l('Amazon - Enable selected'),
                'confirm' => $this->module->l('Enable selected items?'),
                'icon' => 'icon-check',
            ],
            'disableAmzToPs' => [
                'text' => $this->module->l('Amazon -  Disable selected'),
                'confirm' => $this->module->l('Disable selected items?'),
                'icon' => 'icon-times',
            ],
            'divider' => [
                'text' => 'divider',
            ],
            'enablePsToAmz' => [
                'text' => $this->module->l('Prestashop - Enable selected'),
                'confirm' => $this->module->l('Enable selected items?'),
                'icon' => 'icon-check',
            ],
            'disablePsToAmz' => [
                'text' => $this->module->l('Prestashop - Disable selected'),
                'confirm' => $this->module->l('Disable selected items?'),
                'icon' => 'icon-times',
            ],
            'divider2' => [
                'text' => 'divider',
            ],
            'enableFbaToPs' => [
                'text' => $this->module->l('FBA - Enable selected'),
                'confirm' => $this->module->l('Enable selected items?'),
                'icon' => 'icon-check',
            ],
            'disableFbaToPs' => [
                'text' => $this->module->l('FBA -  Disable selected'),
                'confirm' => $this->module->l('Disable selected items?'),
                'icon' => 'icon-times',
            ],
            'divider3' => [
                'text' => 'divider',
            ],
            'enableAll' => [
                'text' => $this->module->l('ENABLE ALL'),
                'confirm' => $this->module->l('Enable all suppliers?'),
                'icon' => 'icon-check',
            ],
        ];

        $this->fields_list = [];
        $this->fields_list['id_supplier'] = [
            'title' => $this->module->l('Id'),
            'align' => 'text-center',
            'class' => 'fixed-width-sm',
        ];
        $this->fields_list['name'] = [
            'title' => $this->module->l('Name'),
            'width' => 'auto',
            'filter_key' => 'a!name',
        ];

        $this->fields_list['enabled_amz_ps'] = [
            'title' => $this->module->l('Amazon Sync'),
            'align' => 'text-center',
            'active' => 'submitUpdateEnabledAmzToPs',
            'type' => 'bool',
            'ajax' => false,
            'orderby' => false,
            'search' => false,
        ];

        $this->fields_list['enabled_ps_amz'] = [
            'title' => $this->module->l('Prestashop Sync'),
            'align' => 'text-center',
            'active' => 'submitUpdateEnabledPsToAmz',
            'type' => 'bool',
            'ajax' => false,
            'orderby' => false,
            'search' => false,
        ];

        $this->fields_list['enabled_fba_ps'] = [
            'title' => $this->module->l('FBA Sync'),
            'align' => 'text-center',
            'active' => 'submitUpdateEnabledFbaToPs',
            'type' => 'bool',
            'ajax' => false,
            'orderby' => false,
            'search' => false,
        ];

        $this->toolbar_title = $this->module->l('Amazon Suppliers');

        $this->warningCatalogFilter();
    }

    public function getList(
        $id_lang,
        $orderBy = null,
        $orderWay = null,
        $start = 0,
        $limit = null,
        $id_lang_shop = null
    ) {
        $id_lang_shop = Shop::isFeatureActive() && Shop::getContext() == Shop::CONTEXT_SHOP ?
            (int) $this->context->shop->id : 'sa.id_shop';
        parent::getList($id_lang, $orderBy, $orderWay, $start, $limit, $id_lang_shop);
    }

    public function postProcess()
    {
        if (Tools::isSubmit($this->table . 'Orderby') || Tools::isSubmit($this->table . 'Orderway')) {
            $this->filter = true;
        } elseif (Tools::isSubmit('submitUpdateEnabledPsToAmz' . $this->table)) {
            TooleAmazonMarketFilterSupplier::updateEnabled(Tools::getValue('id_supplier'), null,
                TooleAmazonMarketFilterManufacturer::ENABLED_PS_AMZ, $this->entityId);
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitUpdateEnabledAmzToPs' . $this->table)) {
            TooleAmazonMarketFilterSupplier::updateEnabled(Tools::getValue('id_supplier'), null,
                TooleAmazonMarketFilterManufacturer::ENABLED_AMZ_PS, $this->entityId);
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitUpdateEnabledFbaToPs' . $this->table)) {
            TooleAmazonMarketFilterSupplier::updateEnabled(Tools::getValue('id_supplier'), null, TooleAmazonMarketFilterManufacturer::ENABLED_FBA_PS, $this->entityId);
            $this->redirectAdminToole();
        } elseif ((Tools::isSubmit('submitBulkenablePsToAmz' . $this->table) || Tools::isSubmit('submitBulkenableAmzToPs' . $this->table) || Tools::isSubmit('submitBulkenableFbaToPs' . $this->table)) && Tools::getValue($this->table . 'Box')) {
            $type = $this->getType();
            foreach ((array) Tools::getValue($this->table . 'Box') as $id_supplier) {
                TooleAmazonMarketFilterSupplier::updateEnabled($id_supplier, 1, $type, $this->entityId);
            }
            $this->redirectAdminToole();
        } elseif (Tools::isSubmit('submitBulkenableAll' . $this->table) && Tools::getValue($this->table . 'Box')) {
            TooleAmazonMarketFilterSupplier::enableAll(Tools::getValue($this->table . 'Box'), $this->shop_id, $this->shop_id_group, $this->entityId);
            $this->redirectAdminToole();
        } elseif ((Tools::isSubmit('submitBulkdisablePsToAmz' . $this->table) || Tools::isSubmit('submitBulkdisableAmzToPs' . $this->table) || Tools::isSubmit('submitBulkdisableFbaToPs' . $this->table)) && Tools::getValue($this->table . 'Box')) {
            $type = $this->getType();
            foreach ((array) Tools::getValue($this->table . 'Box') as $id_supplier) {
                TooleAmazonMarketFilterSupplier::updateEnabled($id_supplier, 0, $type, $this->entityId);
            }
            $this->redirectAdminToole();
        }

        return parent::postProcess();
    }

    public function displayPreviewLink($token, $id)
    {
        $tpl = $this->createTemplate('list_action_preview.tpl');
        $tpl->assign([
            'href' => $this->context->link->getSupplierLink(
                $id,
                null,
                null,
                null,
                $this->context->language->id
            ),
            'id_supplier' => $id,
        ]);

        return $tpl->fetch();
    }

    public function displayViewLink($token, $id)
    {
        $tpl = $this->createTemplate('list_action_cs_view.tpl');

        $tpl->assign([
            'href' => $this->context->link->getAdminLink('AdminSuppliers', true, ['id_supplier' => (int) $id]),
        ]);

        return $tpl->fetch();
    }

    public function getType()
    {
        switch (true) {
            case Tools::isSubmit('submitBulkenablePsToAmz' . $this->table):
            case Tools::isSubmit('submitBulkdisablePsToAmz' . $this->table):
                return TooleAmazonMarketFilterSupplier::ENABLED_PS_AMZ;
            case Tools::isSubmit('submitBulkenableFbaToPs' . $this->table):
            case Tools::isSubmit('submitBulkdisableFbaToPs' . $this->table):
                return TooleAmazonMarketFilterSupplier::ENABLED_FBA_PS;
            default:
                return TooleAmazonMarketFilterSupplier::ENABLED_AMZ_PS;
        }
    }
}
