<?php
/**
 * ToolEAmazonMarketProductSyncFromFbaController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\ReportType;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketProductSyncFromFbaController extends ToolEAmazonMarketProductSyncFromAmazonController
{
    public function __construct()
    {
        $this->isFBA = true;
        $this->reportTypeName = 'FBA';
        $this->importedCtl = 'ToolEAmazonMarketProductsImportedFromFba';
        $this->reportTypeAmazonApi = ReportType::GET_FBA_MYI_ALL_INVENTORY_DATA;
        $this->lastFetchReport = ConfigurationConstant::AMT_START_TIME_REPORT_FBA_MYI_ALL_INVENTORY_DATA;
        parent::__construct();
    }
}
