<?php
/**
 * ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  ToolEAmazonMarketProductsImportedFromAmazonController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ToolEAmazonMarketProductsImportedFromFbaController extends ToolEAmazonMarketProductsImportedFromAmazonController
{
    public function __construct()
    {
        $this->isFBA = true;
        $this->productType = TooleAmazonMarketAmazonProduct::FBA_PRODUCT;
        $this->lastFetchReport = ConfigurationConstant::AMT_START_TIME_REPORT_FBA_MYI_ALL_INVENTORY_DATA;
        parent::__construct();
        $this->toolbar_title = $this->module->l('FBA Products');
        $this->fields_list['sku']['title'] = $this->module->l('FBA SKU');
    }
}
