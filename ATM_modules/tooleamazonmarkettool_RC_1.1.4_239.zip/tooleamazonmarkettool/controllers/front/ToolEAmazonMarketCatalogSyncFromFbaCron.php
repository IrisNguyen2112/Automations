<?php
/**
 * TooleAmazonMarketCatalogSyncFromAmzCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\ReportType;
use Toole\Module\Amazon\Client\V4\Constant\CronConstant;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketCatalogSyncFromFbaCronModuleFrontController extends TooleamazonmarkettoolTooleAmazonMarketCatalogSyncFromAmzCronModuleFrontController
{
    public function __construct()
    {
        $this->use_region = false;
        $this->active_marketplace = Tools::getValue('mkp_id', '');
        $this->isFBA = true;
        $this->syncType = 'FBA';
        $this->cronConfigKey = CronConstant::CRON_AMT_TYPE_CATALOG_SYNC_FROM_FBA;
        $this->reportTypeAmazonApi = ReportType::GET_FBA_MYI_ALL_INVENTORY_DATA;

        parent::__construct();
    }
}
