<?php
/**
 * TooleAmazonMarketInCartOrderCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\Model;
use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\Amazon\Client\V4\Constant\CronConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\InCartOrder;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketInCartOrderCronModuleFrontController extends TooleBaseFrontController
{
    protected $logMsgs = [];
    protected $errorMsgs = [];
    protected $warningMsgs = [];
    protected $messages = [];
    protected $orders = [];
    protected $order_statuses = [];
    protected $use_region = true;
    protected $entityId;
    protected $inCartOrders = [];

    public function __construct()
    {
        $this->active_region = Tools::getValue('region', AmazonConstant::MKP_REGION_EU);
        parent::__construct();
        $this->ajax = true;
        $this->order_statuses = [Model\Order::ORDER_STATUS_PENDING];
        $cronConfig = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_CONFIG_CRON);
        $enableConfig = $cronConfig[CronConstant::CRON_AMT_TYPE_SUPERVISE_IN_CART_ORDERS]['enable'];
        $this->entityId = TooleAmazonMarketAmazonEntity::findOneIdByEntity($this->active_marketplace);
        $this->inCartOrders = Tools::getValue('inCartOrders', []);

        if (!$enableConfig) {
            exit(new AjaxResponseOnce(['This feature is not enabled'], [], [], null));
        }
    }

    /**
     * URL: http://hostname/index.php?action=holdStock&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketInCartOrderCron&id_subscription=
     *
     * @return void
     */
    public function displayAjaxHoldStock()
    {
        $this->module->log->setLog('Process Hold Stock For In-Cart Order Request', true);
        $this->module->log->message(sprintf('Hold Stock For In-Cart Order From Amazon %s', $this->active_region));

        $flow = new InCartOrder($this->saasHelper, $this->module, $this->entityId, $this->context->shop->id, $this->context->shop->id_shop_group);
        $resultOrderIds = [];
        $count = 0;

        try {
            foreach ($this->inCartOrders as $order) {
                if ($order instanceof Exception) {
                    $this->logMsgs[] = $order->getMessage() ?: 'An unexpected error has occurred!';
                    $this->errorMsgs[] = $order->getMessage() ?: $this->trans('An unexpected error has occurred!', [], 'Modules.Tooleamazonmarkettool.Admin');
                    continue;
                }

                $flow->resolveStock($order);

                ++$count;
                $resultOrderIds[] = $order['AmazonOrderId'];
            }

            $flow->resolveStockOutDate($resultOrderIds);

            $response = new AjaxResponseOnce(
                array_merge($this->errorMsgs, $flow->getErrors()),
                array_merge($this->warningMsgs, $flow->getWarnings()),
                array_merge($this->messages, $flow->getConfirmations()),
                ['logId' => $this->module->log->getScheduler(), 'orders' => $resultOrderIds]
            );

            $this->module->log->message(sprintf('The stock of %s orders has been handled!', $count));
            $this->module->log->extractFromAjaxResponse($response)->message($flow->getDebugs());
        } catch (Exception $exception) {
            $response = AjaxResponseOnce::onlyAnError($exception->getMessage());
            $this->module->log->extractFromAjaxResponse($response);
        }

        exit($response);
    }
}
