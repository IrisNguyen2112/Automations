<?php
/**
 * TooleAmazonMarketOrderImportCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\Amazon\Client\Model;
use Toole\Module\Amazon\Client\V3\AmazonConstant;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\Amazon\Client\V4\Constant\CronConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\OrderImport;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Response\AjaxResponseOnce;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketOrderImportCronModuleFrontController extends TooleBaseFrontController
{
    private $lastImportTime;
    public $logMsgs = [];
    public $errorMsgs = [];
    public $warningMsgs = [];
    public $importMessages = [];
    public $orders = [];
    public $order_statuses = [];

    protected $use_region = true;

    protected $apiDataCarrier = [];

    public function __construct()
    {
        $this->active_region = Tools::getValue('region', AmazonConstant::MKP_REGION_EU);
        parent::__construct();

        $this->ajax = true;
        $this->lastImportTime = Tools::getValue('last_import_time');
        $this->order_statuses = Tools::getValue('order_statuses') ? explode(',', Tools::getValue('order_statuses')) : $this->resolveInputStatus();

        $cronConfig = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_CONFIG_CRON);
        $enableImport = $cronConfig[CronConstant::CRON_AMT_TYPE_ORDERS_IMPORT]['enable'];
        if (!$enableImport) {
            exit(new AjaxResponseOnce(['This feature is not enabled'], [], [], null));
        }
    }

    /**
     * URL: http://hostname/index.php?action=orderImport&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketOrderImportCron&id_subscription=
     *
     * @return void
     */
    public function displayAjaxOrderImport()
    {
        $this->module->log->setLog('Process Import Amazon Order Request', true);
        $this->module->log->message(sprintf('Import Order From Amazon %s', $this->active_region));
        $orders = $this->getOrderListApi();
        $amazonOrderIds = [];
        foreach ($orders as $order) {
            if ($order instanceof Exception) {
                $this->logMsgs[] = $order->getMessage() ?: 'An unexpected error has occurred';
                $this->errorMsgs[] = $order->getMessage() ?: $this->module->l('An unexpected error has occurred');
                continue;
            }
            if (!$order instanceof Model\Order) {
                continue;
            }

            // Skip Pending & Canceled status
            if (in_array($order->getOrderStatus(), [Model\Order::ORDER_STATUS_PENDING, Model\Order::ORDER_STATUS_CANCELED])) {
                $this->warningMsgs[] = sprintf(
                    $this->module->l('Skipped order %s - Invalid order status %s'),
                    $order->getAmazonOrderId(),
                    $order->getOrderStatus()
                );
            }

            // Rare case when super old order has been updated for some reasons
            $purchaseDate = new DateTime($order->getPurchaseDate());
            $updateDate = new DateTime($order->getLastUpdateDate());
            if ($purchaseDate->modify('+90 days') < $updateDate) {
                $this->warningMsgs[] = sprintf(
                    $this->module->l('Old order not imported: %d, purchased at: %s, updated at: %s'),
                    $order->getAmazonOrderId(),
                    $order->getPurchaseDate(),
                    $order->getLastUpdateDate()
                );
            }

            $amazonOrderIds[] = $order->getAmazonOrderId();
        }
        $this->module->log->message(sprintf('%s orders to import', count($amazonOrderIds)));

        if (!empty($amazonOrderIds)) {
            try {
                $amazonImport = new OrderImport($amazonOrderIds, $this->saasHelper, $this->module, $this->context->currency, $this->context->shop->id, true);
                $amazonImport->importOrders();
                $response = new AjaxResponseOnce(
                    array_merge($this->errorMsgs, $amazonImport->getErrors()),
                    array_merge($this->warningMsgs, $amazonImport->getWarnings()),
                    array_merge($this->importMessages, $amazonImport->getConfirmations()),
                    ['logId' => $this->module->log->getScheduler(), 'orders' => $amazonImport->getResultOrders()]
                );
                $this->module->log->extractFromAjaxResponse($response)->message($amazonImport->getDebugs());
            } catch (Exception $exception) {
                $response = AjaxResponseOnce::onlyAnError($exception->getMessage());
                $this->module->log->extractFromAjaxResponse($response);
            }
        } else {
            $response = AjaxResponseOnce::onlyAnError('No Orders have been selected');
            $this->module->log->warning('No Orders have been selected');
        }

        exit($response);
    }

    private function getOrderListApi(): Generator
    {
        $statuses = $this->order_statuses;
        $lastUpdateAfter = gmdate('Y-m-d\TH:i:s\Z', strtotime('now - 1 hour'));
        $lastUpdateBefore = gmdate('Y-m-d\TH:i:s\Z', time() - (60 * 4)); // Now - 4 minutes
        if ($this->lastImportTime) {
            // Date time from SaaS is always UTC and 'Y-m-d H:i:s' format
            $lastImportTime = DateTime::createFromFormat('Y-m-d H:i:s', $this->lastImportTime, new DateTimeZone('UTC'));
            $lastUpdateAfter = $lastImportTime->format('Y-m-d\TH:i:s\Z');
        }

        $this->module->log->message(sprintf(
            'Fetching orders from %s to %s. Status %s. Server Last Import: %s',
            $lastUpdateAfter,
            $lastUpdateBefore,
            implode(', ', $statuses),
            $this->lastImportTime
        ));

        return $this->saasHelper->getOrdersAll(
            [],
            null,
            null,
            $lastUpdateAfter,
            $lastUpdateBefore,
            $statuses,
            null,
            null,
            100,
            20,
            null,
            $this->apiDataCarrier,
            false
        );
    }

    private function resolveInputStatus(): array
    {
        return [
            Model\Order::ORDER_STATUS_UNSHIPPED,
            Model\Order::ORDER_STATUS_PARTIALLY_SHIPPED,
            Model\Order::ORDER_STATUS_SHIPPED,
        ];
        // 2023-05-31: Remove the advanced option to choose the status to import
    }
}
