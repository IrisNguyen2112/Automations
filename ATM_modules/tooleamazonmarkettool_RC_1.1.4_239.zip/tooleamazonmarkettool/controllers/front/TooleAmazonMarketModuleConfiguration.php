<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * TooleAmazonMarketModuleConfiguration
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */
class TooleamazonmarkettoolTooleAmazonMarketModuleConfigurationModuleFrontController extends TooleBaseFrontController
{
    /** @var AmazonMarketConfiguration */
    protected $amzAdminConfiguration;

    public function __construct()
    {
        parent::__construct();
        $this->ajax = true;
        $this->amzAdminConfiguration = new AmazonMarketConfiguration();
    }

    /**
     * Return all configuration as JSON
     * URL: http://hostname/index.php?action=getConfiguration&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketModuleConfiguration
     * @return void
     */
    public function displayAjaxGetConfiguration()
    {
        try {
            $configuration = $this->amzAdminConfiguration::getAll();
            $parseConfiguration = array_map(function ($config) {
                $config['value'] = json_decode($config['value']);
                return $config;
            }, $configuration);

            $json = json_encode([
                'result' => $parseConfiguration,
                'errors' => null,
            ]);
        } catch (Exception $e) {
            $json = json_encode([
                'result' => null,
                'errors' => $e->getMessage(),
                'exception' => $e,
            ]);
        }

        exit($json);
    }
}
