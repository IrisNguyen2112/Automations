<?php
/**
 * TooleAmazonMarketGetFeedSubmissionResultCron
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\PsGetFeedSubmissionResult;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleamazonmarkettoolTooleAmazonMarketGetFeedSubmissionResultCronModuleFrontController extends TooleBaseFrontController
{
    public function __construct()
    {
        parent::__construct();
        $this->ajax = true;
    }

    /**
     * URL: http://hostname/index.php?action=getFeedSubmissionResult&fc=module&module=tooleamazonmarkettool&controller=TooleAmazonMarketGetFeedSubmissionResultCron&id_subscription=
     * @throws Exception
     */
    public function displayAjaxGetFeedSubmissionResult(): void
    {
        exit(json_encode(PsGetFeedSubmissionResult::getFeedSubmissionResult()));
    }
}
