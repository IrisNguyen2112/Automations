<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper;

use Combination;
use Context;
use Currency;
use Db;
use DbQuery;
use Exception;
use mysqli_result;
use PDOStatement;
use PrestaShop\Decimal\Number;
use PrestaShopDatabaseException;
use Product as PsProduct;
use Shop;
use Toole\Module\Amazon\Client\V2\Model\CatalogSync\CatalogSyncItem;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\Rule;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\RuleByPrice;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\Configuration\ShippingTemplate\RuleByWeight;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Classes\PsSyncProduct;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Product as PsProductHelper;
use TooleAmazonMarketFilterCategory;
use TooleAmazonMarketFilterManufacturer;
use TooleAmazonMarketFilterProduct;
use TooleAmazonMarketFilterSupplier;
use Tools;
use Validate;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Product
{
    const SYNC_TYPE_ENABLED_AMZ_PS = 'enabled_amz_ps';
    const SYNC_TYPE_ENABLED_PS_AMZ = 'enabled_ps_amz';
    const SYNC_TYPE_ENABLED_FBA_PS = 'enabled_fba_ps';

    public static function searchBySku($id_lang, $sku, $onlyActive, $onlyFirst)
    {
        // Build the query
        $sql = new DbQuery();
        $sql->select('p.`id_product`, pl.`name`, p.`active`, p.`reference`, stock.`quantity`, pa.`id_product_attribute`, pa.`reference` as `pa_reference`');
        $sql->from('product', 'p');
        $sql->join(Shop::addSqlAssociation('product', 'p'));
        $sql->leftJoin('product_lang', 'pl', '
			p.`id_product` = pl.`id_product`
			AND pl.`id_lang` = ' . (int) $id_lang . Shop::addSqlRestrictionOnLang('pl')
        );
        $sql->leftJoin('product_attribute', 'pa', 'pa.`id_product` = p.`id_product`');
        $sql->join(PsProduct::sqlStock('p', 0));

        $where = 'p.`reference` LIKE \'' . pSQL($sku) . '\'';
        if (Combination::isFeatureActive()) {
            $where .= ' OR pa.`reference` LIKE \'' . pSQL($sku) . '\'';
        }
        if ($onlyActive) {
            $where = "p.`active` = 1 AND ($where)";
        }
        $sql->where($where);

        $sql->orderBy('pl.`name` ASC');

        // Get result
        if ($onlyFirst) {
            return Db::getInstance()->getRow($sql);
        }

        return Db::getInstance()->executeS($sql);
    }

    public static function isAllowToSync($column, $productId, $langId, $shopId, $entityId): bool
    {
        /**
         * Application sync 2 ways. From PS -> Amazon and vice versa
         */
        $product = new PsProduct($productId, false, $langId, $shopId);

        if (Validate::isLoadedObject($product)) {
            // Product
            if (TooleAmazonMarketFilterProduct::isEnableSync($column, $productId, $shopId, $entityId)) {
                return true;
            }

            // Categories
            $categories = $product->getCategories();
            if ($categories && TooleAmazonMarketFilterCategory::isEnableSync($column, $categories, $shopId, $entityId)) {
                return true;
            }

            // Supplier
            $supplierId = $product->id_supplier;
            if ($supplierId && TooleAmazonMarketFilterSupplier::isEnableSync($column, $supplierId, $shopId, $entityId)) {
                return true;
            }

            // Manufacturer
            $manufacturerId = $product->id_manufacturer;
            if ($manufacturerId && TooleAmazonMarketFilterManufacturer::isEnableSync($column, $manufacturerId, $shopId, $entityId)) {
                return true;
            }
        }

        return false;
    }

    public static function findProductBySku($SKU = null, $full = false, $id_lang = null, $reference = 'reference', $id_shop = null)
    {
        $id_product_attribute = null;

        // get combination first
        $sql = 'SELECT p.`id_product`, p.`id_product_attribute` FROM `' . _DB_PREFIX_ . 'product_attribute` p '
            . self::productAttributeShopAssociation($id_shop)
            . 'WHERE `' . $reference . '` = "' . pSQL(trim($SKU)) . '"';

        $result = Db::getInstance()->getRow($sql);

        if (!$result || !$result['id_product']) {
            $sql = 'SELECT p.`id_product` FROM `' . _DB_PREFIX_ . 'product` p ';
            $sql .= $id_shop ? ' JOIN `' . _DB_PREFIX_ . 'product_shop` ps on (ps.`id_shop` = ' . (int) $id_shop . ' and ps.`id_product` = p.`id_product`) ' : null;
            $sql .= 'WHERE `' . $reference . '` = "' . pSQL(trim($SKU)) . '"';
            $result = Db::getInstance()->getRow($sql);
            if (!$result || !$result['id_product']) {
                return null;
            }
        } else {
            $id_product_attribute = (int) $result['id_product_attribute'];
        }

        $product = new \Product((int) $result['id_product'], $full, $id_lang, $id_shop);
        if (Validate::isLoadedObject($product)) {
            $product->id_product_attribute = $id_product_attribute;

            return $product;
        }

        return null;
    }

    protected static function productAttributeShopAssociation($id_shop): string
    {
        if (Shop::isFeatureActive()) {
            return ' JOIN `' . _DB_PREFIX_ . 'product_attribute_shop` ps on (ps.`id_shop` = ' . (int) $id_shop . ' AND ps.`id_product` = p.`id_product` AND ps.`id_product_attribute` = p.`id_product_attribute`) ';
        }

        return '';
    }

    /**
     * @param $langId
     * @param $isActive
     * @param $since
     * @return array|bool|mysqli_result|PDOStatement|resource|null
     * @throws PrestaShopDatabaseException
     */
    public static function marketplaceGetAllProducts($langId, $entity, $isActive = false, $since = false)
    {
        if ($since) {
            $dateRange = ' AND (p.`date_add` >= "' . pSQL($since) . '" OR p.`date_upd` >= "' . pSQL($since) . '") ';
        } else {
            $dateRange = '';
        }
        $sql = 'SELECT p.`id_product` FROM `' . _DB_PREFIX_ . 'product` p
                INNER JOIN `' . _DB_PREFIX_ . 'product_shop` product_shop ON product_shop.id_product = p.id_product ' . Shop::addSqlRestrictionOnLang('product_shop') . '
                LEFT JOIN `' . _DB_PREFIX_ . 'category_product` c ON (c.`id_product` = p.`id_product`)
                LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (p.`id_product` = pl.`id_product`)
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` tmsp ON (tmsp.id_product = p.id_product AND tmsp.id_entity = ' . (int) $entity . ')
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` tmsc ON (tmsc.id_category = c.id_category AND tmsc.id_entity = ' . (int) $entity . ')
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` tmsm ON (tmsm.id_manufacturer = p.id_manufacturer AND tmsm.id_entity = ' . (int) $entity . ')
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` tmss ON (tmss.id_supplier = p.id_supplier AND tmss.id_entity = ' . (int) $entity . ')
                WHERE pl.`id_lang` = ' . (int) $langId . $dateRange . ($isActive ? ' AND p.`active` = 1' : '') . '
                AND (tmsp.`enabled_ps_amz` = 1 OR tmsc.`enabled_ps_amz` = 1 OR tmsm.`enabled_ps_amz` = 1 OR tmss.`enabled_ps_amz` = 1)
                GROUP by p.id_product ORDER BY p.date_add desc ';

        return Db::getInstance()->executeS($sql);
    }

    public static function marketplaceGetCycleSyncProducts($langId, $entity)
    {
        $sql = 'SELECT p.`id_product`, pl.`name` FROM `' . _DB_PREFIX_ . 'product` p
                INNER JOIN `' . _DB_PREFIX_ . 'product_shop` product_shop ON product_shop.id_product = p.id_product ' . Shop::addSqlRestrictionOnLang('product_shop') . '
                INNER JOIN `' . _DB_PREFIX_ . Database::TABLE_AMAZON_ENTITIES . '` ae
                LEFT JOIN `' . _DB_PREFIX_ . 'category_product` c ON (c.`id_product` = p.`id_product`)
                LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (p.`id_product` = pl.`id_product`)
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` tmsp ON (tmsp.id_product = p.id_product AND tmsp.id_entity = ae.id_entity)
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` tmsc ON (tmsc.id_category = c.id_category AND tmsc.id_entity = ae.id_entity)
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` tmsm ON (tmsm.id_manufacturer = p.id_manufacturer AND tmsm.id_entity = ae.id_entity)
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` tmss ON (tmss.id_supplier = p.id_supplier AND tmss.id_entity = ae.id_entity)
                WHERE pl.`id_lang` = ' . (int) $langId . ' AND p.`active` = 1' . '
                AND (ae.entity = "' . $entity . '")
                AND ((tmsp.`enabled_ps_amz` = 1 AND tmsp.`enabled_amz_ps` = 1)
                    OR (tmsc.`enabled_ps_amz` = 1 AND tmsc.`enabled_amz_ps` = 1)
                    OR (tmsm.`enabled_ps_amz` = 1 AND tmsm.`enabled_amz_ps` = 1)
                    OR (tmss.`enabled_ps_amz` = 1 AND tmss.`enabled_amz_ps` = 1)
                )
                GROUP by p.id_product';

        return Db::getInstance()->executeS($sql);
    }

    public static function getProductDataForFeeds($productId, $productAttributeId, $shippingTemplates, $storeWeighUnit, Context $context, $isUseImage = true, $currencyCode = ''): ?PsSyncProduct
    {
        $isCombination = false;
        $productAttribute = null;
        $product = new PsProduct($productId, false, $context->language->id, $context->shop->id, $context);
        if (!Validate::isLoadedObject($product)) {
            throw new Exception('Cannot load product');
        }
        if (!empty($productAttributeId)) {
            $productAttribute = $product->getAttributeCombinationsById($productAttributeId, $context->language->id);
            if (empty($productAttribute)) {
                throw new Exception('Cannot load combination');
            }
            $isCombination = true;
        }

        $psSyncProduct = new PsSyncProduct();
        if ($isCombination) {
            $combination = (object) $productAttribute[0];
            $psSyncProduct->setParent(trim($product->reference));
        } else {
            $combinations = $product->getAttributeCombinations($context->language->id);
            if (!empty($combinations)) { // Has combinations
                $combinationsReference = [];
                foreach ($combinations as $combinationItem) {
                    $combinationsReference[] = trim($combinationItem['reference']);
                }
                $psSyncProduct->setChildren($combinationsReference);
            }
        }

        $price = $isCombination ? $combination->price : $product->price;
        $weight = $isCombination ? $combination->weight : $product->weight;

        $tax_rate = $product->getTaxesRate();
        if ($tax_rate) {
            $productPrice = new Number((string) $price);
            $productPriceIncluded = $productPrice->times(new Number((string) (1 + ($tax_rate / 100))));

            // price with tax rate
            $price = $productPriceIncluded->toPrecision($productPriceIncluded->getPrecision());
        }

        if ($currencyCode && $currencyCode != $context->currency->iso_code) {
            $currencyDefault = new Currency($context->currency->id);
            $currencyTo = Currency::getIdByIsoCode($currencyCode);
            if (!$currencyTo) {
                return null;
            }
            $toCur = new Currency($currencyTo);
            $price = Tools::convertPriceFull($price, $currencyDefault, $toCur);
        } else {
            $currencyCode = $context->currency->iso_code;
        }

        $psSyncProduct->setExternalId($productId)->setProductIdType(CatalogSyncItem::PRODUCT_ID_TYPE_EAN)
            ->setSku($isCombination ? $combination->reference : $product->reference)
            ->setEan($isCombination ? $combination->ean13 : $product->ean13)
            ->setTitle($product->name)
            ->setQuantity(max(0, PsProduct::getRealQuantity($product->id, $productAttributeId ?: 0)))
            ->setPrice(Tools::ps_round($price, 2))
            ->setCurrency($currencyCode)
            ->setSale(PsProductHelper::getSale($product, $productAttributeId, $context))
            ->setShippingTemplate(self::resolveShippingTemplate($shippingTemplates, $price, $weight, $storeWeighUnit));
        if ($isUseImage) {
            $baseUrl = sprintf('%s://%s%s', 'http', htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8'), __PS_BASE_URI__);
            $psSyncProduct->setRawImages(PsProductHelper::getImageUrls($product, $productAttributeId, $context->language->id, $context, $baseUrl));
        }
        // Restock
        $restockDate = $isCombination ? $combination->available_date : $product->available_date;
        if (Validate::isDate($restockDate)) {
            $psDateRestock = strtotime($restockDate);
            $dateNow = time();
            if ($psDateRestock && $psDateRestock + 86400 > $dateNow) {
                $psSyncProduct->setRestockDate(gmdate('Y-m-d', $psDateRestock));
            }
        }

        if (!$psSyncProduct->validateTitle()) {
            throw new Exception('Product title is not valid');
        }
        if (!$psSyncProduct->validateSku()) {
            throw new Exception('Product SKU is not valid');
        }
        if (!$psSyncProduct->validateProductTypeAndCode()) {
            throw new Exception('Product EAN is not valid');
        }
        if (!$psSyncProduct->validateConditionType()) {
            throw new Exception('Product condition type is not valid');
        }
        if (!$psSyncProduct->validateConditionNote()) {
            throw new Exception('Product condition note is not valid');
        }
        if (!$psSyncProduct->validatePrice()) {
            throw new Exception('Product price is not valid');
        }
        if (!$psSyncProduct->validateQuantity()) {
            throw new Exception('Product quantity is not valid');
        }

        return $psSyncProduct;
    }

    protected static function resolveShippingTemplate($shippingTemplates, $price, $weight, $storeWeightUnit): string
    {
        if ($shippingTemplates['enable']) {
            if ($shippingTemplates['use_type'] == Rule::TYPE_WEIGHT) {
                /** @var RuleByWeight[] $rules */
                $rules = $shippingTemplates['rules'][Rule::TYPE_WEIGHT];
                foreach ($rules as $rule) {
                    if ($rule->validateInput($weight, $storeWeightUnit)) {
                        return $rule->name;
                    }
                }
            } else {
                /** @var RuleByPrice[] $rules */
                $rules = $shippingTemplates['rules'][Rule::TYPE_PRICE];
                foreach ($rules as $rule) {
                    if ($rule->validateInput($price)) {
                        return $rule->name;
                    }
                }
            }
        }

        return '';
    }
}
