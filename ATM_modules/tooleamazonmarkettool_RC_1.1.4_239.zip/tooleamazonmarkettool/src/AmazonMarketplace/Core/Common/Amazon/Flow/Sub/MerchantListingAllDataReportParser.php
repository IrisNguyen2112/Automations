<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\Sub;

use PrestaShop\PrestaShop\Core\Foundation\IoC\Exception;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Str;
use Tools;

trait MerchantListingAllDataReportParser
{
    public static $expected = [
        'en' => [
            'item-name',
            'seller-sku',
            'price',
            'quantity',
            'listing-id',
            'product-id',
            'product-id-type',
            'item-note',
            'item-condition',
            'status',
            'status',
            'status',
        ],
        'fr' => [
            'nom-produit',
            'sku-vendeur',
            'prix',
            'quantite',
            'id-produit',
            'asin1',
            'type-id-produit',
            'note-etat-article',
            'etat-produit',
            'status',
            'statut',
            'etat',
        ],
        'it' => [
            'nome dell\'articolo',
            'sku venditore',
            'prezzo',
            'quantita',
            'identificativo del prodotto',
            'tipo di identificativo del prodotto',
            'note sull\'articolo',
            'condizione dell\'articolo',
            'stato',
        ],
        'es' => [
            'titulo del producto',
            'sku del vendedor',
            'precio',
            'cantidad',
            'identificador del producto',
            'tipo de identificador de producto',
            'nota sobre el producto',
            'estado del producto',
            'status',
        ],
        'cn' => [
            '商品名称' /* product name */,
            '卖家 SKU' /* Seller SKU */,
            '价格' /* price */,
            '数量' /* quantity */,
            '商品编码' /* product_id */,
            '商品编码类型' /* product id type */,
            '商品备注' /* condition note */,
            '商品状况' /* condition code */,
            '卖家配送组' /* merchant shipping group */,
            'asin1',
            '状态', /* status */
        ],
        'de' => [
            'artikelbezeichnung',
            'haendler-sku',
            'preis',
            'menge',
            'produkt-id',
            'produkt-id-typ',
            'anmerkung zum artikel',
            'artikelzustand',
            'handlerversandgruppe',
            'asin 1',
            'status',
        ],
    ];

    public static $conditions = [
        11 => 'New',
        1 => 'UsedLikeNew',
        2 => 'UsedVeryGood',
        3 => 'UsedGood',
        4 => 'UsedAcceptable',
        5 => 'CollectibleLikeNew',
        6 => 'CollectibleVeryGood',
        7 => 'CollectibleGood',
        8 => 'CollectibleAcceptable',
        98 => 'Refurbished', // condition code unknown yet
        99 => 'Club', // condition code unknown yet
    ];

    private $inactiveItemCount = 0;

    /**
     * @throws Exception
     */
    public function parseReport($reportContent): array
    {
        $lines = explode("\n", $reportContent);
        if (!is_array($lines) || !count($lines)) {
            throw new Exception('Empty data!');
        }

        $header = array_shift($lines);
        if (!Tools::strlen($header)) {
            throw new Exception('No header, file might be corrupted!');
        }

        $scores = [];
        $columns = explode("\t", Str::noAccents(Tools::strtolower($header)));
        foreach (self::$expected as $key => $expected) {
            $scores[$key] = count(array_diff($columns, $expected));
        }
        asort($scores);
        $found = key($scores);
        if (!$found) {
            throw new Exception('Cannot detect the format!');
        }

        $columns_keys = array_flip($columns);
        $offers = [];
        foreach ($lines as $line) {
            if (empty($line)) {
                continue;
            }
            $result = explode("\t", Str::fixEncoding(rtrim($line)));
            if (!isset($result[0]) || !Tools::strlen($result[0])) {
                continue;
            }

            $values = [];
            // We got
            // item-name	listing-id	seller-sku	price	quantity	open-date	product-id-type	item-note	item-condition	will-ship-internationally	expedited-shipping	product-id	pending-quantity	fulfillment-channel	merchant-shipping-group
            foreach (self::$expected[$found] as $key => $to_search) {
                if (isset($columns_keys[$to_search]) && isset(self::$expected[$found][$key])) {
                    $column_name = self::$expected['en'][$key];
                    $target_key = $columns_keys[$to_search];
                    $exists = isset($result[$target_key]);
                    $values[$column_name] = $exists ? $result[$target_key] : '';
                }
            }

            if (!count($values)) {
                continue;
            }

            // We get
            // Cells referenced by self::$expected
            $condition_id = (int) $values['item-condition'];

            $item_name = trim(addslashes($values['item-name']));
            $seller_sku = trim(addslashes($values['seller-sku']));
            $qty = (int) $values['quantity'];
            $price = (float) $values['price'];
            $product_id = (string) $values['product-id'];
            $product_id_type = (string) $values['product-id-type'];
            $condition = self::$conditions[$condition_id] ?? null;
            $active = isset($values['status']) ? ((string) $values['status']) : '';
            $item_node = (string) $values['item-note'];

            if (isset($values['listing-id'])) {
                $listing_id = (string) $values['listing-id'];
            } elseif (isset($values['asin1'])) {
                $listing_id = (string) $values['asin1'];
            } else {
                $listing_id = (string) $values['product-id'];
            }

            if (!str_contains($active, 'Active') || $qty <= 0) {
                ++$this->inactiveItemCount;

                continue;
            }

            $offers[$seller_sku] = [
                'name' => $item_name,
                'sku' => $seller_sku,
                'qty' => $qty,
                'price' => $price,
                'condition' => $condition,
                'listing-id' => $listing_id,
                'product-id' => $product_id,
                'product-id-type' => $product_id_type,
                'item-note' => $item_node,
            ];
        }

        return $offers;
    }

    public function getInActiveItemCount(): int
    {
        return $this->inactiveItemCount;
    }

    private function buildMerchantListingAllDataReport(&$offers)
    {
        $inactiveItemCount = 0;
        foreach ($offers as $key => $row) {
            $active = isset($row['status']) ? ((string) $row['status']) : '';
            $qty = (int) $row['qty'];
            if (!str_contains($active, 'Active') || $qty <= 0) {
                ++$inactiveItemCount;
                unset($offers[$key]);
            }
        }

        return ['inactiveItemCount' => $inactiveItemCount];
    }
}
