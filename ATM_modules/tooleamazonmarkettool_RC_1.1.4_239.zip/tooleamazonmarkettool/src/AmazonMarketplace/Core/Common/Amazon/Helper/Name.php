<?php
/**
 * AmazonHelperName
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper;

use Tools;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Name
{
    public static function parseAmazonName($fullName): array
    {
        $fullName = preg_replace('/[0-9!<>,;?=+()@#"°*`{}_^$%:¤\[\]\/|.。\\\\]|(?!^)[。.](?:\s|$)/u', '', $fullName);
        $breakDownCompany = self::breakDownCompanyInName($fullName);
        $breakDownName = self::breakDownName($breakDownCompany['remain']);

        return [
            'company' => $breakDownCompany['company'],
            'firstname' => $breakDownName['firstname'],
            'lastname' => $breakDownName['lastname'],
        ];
    }

    protected static function breakDownCompanyInName($name): array
    {
        if (preg_match('/(.+)[\s,-]+[C\/O;:|\-,]+[\s,-]+(.+)/i', $name, $co)) {
            return ['company' => trim(end($co)), 'remain' => trim($co[1])];
        }

        if (preg_match('/([^(]+)[\s,:;-]+\((.+)\)$/', $name, $parenthesis)) {
            return ['company' => trim(end($parenthesis)), 'remain' => trim($parenthesis[1])];
        }

        if (preg_match('/([^\[]+)[\s,:;-]+\[(.+)]$/', $name, $squareBrackets)) {
            return ['company' => trim(end($squareBrackets)), 'remain' => trim($squareBrackets[1])];
        }

        if (preg_match('/(.+)[\s,-]+[PO\/;:|\-,]+[\s,-]+(.+)/i', $name, $po)) {
            return ['company' => trim(end($po)), 'remain' => trim($po[1])];
        }

        return ['company' => '', 'remain' => $name];
    }

    protected static function breakDownName($name): array
    {
        $firstName = trim(mb_substr($name, 0, mb_strpos($name, ' ')));
        $lastName = trim(mb_substr($name, mb_strpos($name, ' ')));

        $firstName = str_replace('&', ' and ', $firstName);
        $lastName = str_replace('&', ' and ', $lastName);
        $firstName = str_replace('.', ' ', $firstName);
        $lastName = str_replace('.', ' ', $lastName);

        if (empty($firstName) && empty($lastName)) {
            $firstName = 'unknown';
            $lastName = 'unknown';
        } elseif (empty($firstName)) {
            $firstName = $lastName;
        } elseif (empty($lastName)) {
            $lastName = $firstName;
        }

        $firstname = Tools::ucfirst(mb_substr($firstName, 0, 32));
        $lastname = Tools::ucfirst(mb_substr($lastName, 0, 32));

        return ['firstname' => $firstname, 'lastname' => $lastname];
    }
}
