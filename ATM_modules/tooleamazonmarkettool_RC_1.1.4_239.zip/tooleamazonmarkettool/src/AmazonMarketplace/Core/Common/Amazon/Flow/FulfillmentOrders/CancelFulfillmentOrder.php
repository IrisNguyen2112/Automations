<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\FulfillmentOrders;

use Exception;
use Order;
use PrestaShopDatabaseException;
use PrestaShopException;
use Symfony\Component\Translation\TranslatorInterface;
use Toole\Module\Amazon\Client\V3\Model\FulfillmentOrder\CancelFulfillmentOrderResponse;
use Toole\Module\Amazon\Client\V3\Model\FulfillmentOrder\FulfillmentOrderStatus;
use Toole\Module\Amazon\Client\V4\Constant\ConfigurationConstant;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Configuration\AmazonMarketConfiguration;
use Toole\Module\SubscriptionManager\Service\Api\v2\AmazonConnector\Region;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;
use ToolEAmazonMarketFbaOrder;

class CancelFulfillmentOrder extends FulfillmentOrderFlow
{
    /* @var ServiceAPIV3Helper */
    protected $saasHelper;
    protected $fbaOrderIds;
    protected $marketplaceId;
    protected $context;
    protected $module;
    protected $cronMode = false;
    /** @var TranslatorInterface */
    protected $translator;

    /**
     * @throws Exception
     */
    public function __construct(ServiceAPIV3Helper $saasHelper, array $fbaOrderIds, string $marketplaceId, \Context $context, \Module $module, $cronMode = false)
    {
        $this->saasHelper = $saasHelper;
        $this->fbaOrderIds = $fbaOrderIds;
        $this->marketplaceId = $marketplaceId;
        $this->context = $context;
        $this->module = $module;
        $this->cronMode = $cronMode;
        $this->translator = $this->module->getTranslator();
        $this->isSandbox = (bool) \Configuration::getGlobalValue('TOOLE_AMAZONMARKETTOOL_SANDBOX');
        if (!Region::searchRegionByMkp($marketplaceId)) {
            throw new Exception(sprintf($this->module->l('Unknown marketplace %s'), $marketplaceId));
        }
    }

    /**
     * @throws PrestaShopException
     * @throws PrestaShopDatabaseException
     */
    public function doCancel()
    {
        $this->module->log->message(sprintf('FBA - Cancel fulfillment order by %s', $this->cronMode ? 'Cron' : 'Manual'));

        $fbaConfig = AmazonMarketConfiguration::get(ConfigurationConstant::AMT_CONFIG_FBA_SETTINGS) ?? [];
        $fbaCancelledOrderStatus = $fbaConfig[ConfigurationConstant::AMT_FBA_CANCELLED_ORDER_STATUS] ?? null;

        foreach ($this->fbaOrderIds as $fbaOrderId) {
            $fbaOrder = new ToolEAmazonMarketFbaOrder($fbaOrderId);

            try {
                $apiResult = $this->saasHelper->cancelFulfillmentOrder($fbaOrder->seller_fulfillment_order_id, null, $this->isSandbox);
            } catch (Exception $exception) {
                $this->errors[] = $this->module->l('Unable to cancel fulfill order', [], 'Modules.Amazonmarkettool.Admin');
                $this->errors[] = $exception->getMessage();

                return;
            }

            /** @var CancelFulfillmentOrderResponse $response */
            $response = $apiResult->getAmazonData();
            if ($response->getErrors()) {
                $this->errors[] = $this->module->l('Failed to cancel fulfillment Order', [], 'Modules.Amazonmarkettool.Admin');

                foreach ($response->getErrors() as $error) {
                    $this->errors[] = $error->getMessage();
                }

                return;
            }

            // storage FBA order
            $fbaOrder->fulfillment_order_status = FulfillmentOrderStatus::CANCELLED;
            $fbaOrder->update();

            // update ps order
            $psOrder = new Order($fbaOrder->ps_order_id);
            $psOrder->setCurrentState($fbaCancelledOrderStatus);
            $psOrder->update();

            $this->warning[] = $this->module->l('Cancel Fulfillment Order Successfully', [], 'Modules.Amazonmarkettool.Admin');

            $this->module->log->message(sprintf('FBA - Cancel fulfillment order #%s successful', $fbaOrderId));
        }
    }
}
