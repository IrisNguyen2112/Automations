<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Toole\Module\Amazon\Client\V3\Model\ReportRequest\ReportResponse;

interface IFlowRequireReport
{
    public function requestReport(): bool;

    public function getReportResult(): ReportResponse;

    public function fetchReport($resourceUrl, $compressAlgorithm, $contentType);

    // Dynamic return type, for further improvement
    public function parseReport($reportContent);
}
