<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow;

use Configuration;
use Context;
use Module;
use PrestaShopException;
use Toole\Module\Amazon\Client\V2\Model\ReportRequest\ParsedReport;
use Toole\Module\Amazon\Client\V3\Model\ReportRequest\ReportResponse;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\Sub\MerchantListingAllDataReportParser;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\Sub\ReportRequest;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Flow\Sub\ReportRequestMessages;
use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Report;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration\Key;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Log\Log;
use Toole\Module\SubscriptionManager\Service\Api\v3\ServiceAPIV3Helper;
use TooleAmazonMarketAmazonProduct;
use Tools;

if (!defined('_PS_VERSION_')) {
    exit;
}

class CatalogSyncFromAmazon implements IFlowRequireReport
{
    use MerchantListingAllDataReportParser;
    use ReportRequestMessages;

    /** @var ReportRequest */
    protected $subFlowReportRequest;

    protected $domain;
    protected $uuid;
    protected $reportType;
    protected $dataStartTime;
    protected $idLang;
    protected $idShop;
    protected $idEntity;
    protected $idShopGroup;
    protected $isFBA;

    protected $offersImportedFromReport = 0;
    protected $offersRejectedNotExist = 0;
    protected $offersRejectedNotEnableSync = 0;
    protected $offersSynced = 0;
    private $inactiveItemCount = 0;

    // Result indicator
    protected $translator;
    protected $module;
    protected $errors = [];
    protected $warnings = [];
    protected $confirmations = [];
    /* @var Log $log */
    protected $log;

    public function __construct(Module $module, ServiceAPIV3Helper $saasHelper, $domain, $uuid, $reportType, $dataStartTime = null, $idEntity = null, $isFBA = false, $additionalParams = null, $cronMode = false)
    {
        $this->translator = $module->getTranslator();
        $this->module = $module;
        $this->domain = $domain;
        $this->uuid = $uuid;
        $this->reportType = $reportType;
        $this->dataStartTime = $dataStartTime;
        $this->log = $module->log;

        $this->subFlowReportRequest = new ReportRequest($saasHelper, $domain, $uuid, $reportType, $dataStartTime, $additionalParams);

        $this->idLang = Context::getContext()->language->id;
        $this->idShop = Context::getContext()->shop->id;
        $this->idEntity = $idEntity;
        $this->idShopGroup = Context::getContext()->shop->id_shop_group;
        $this->isFBA = $isFBA;
    }

    public function requestReport(): bool
    {
        return $this->subFlowReportRequest->requestReport();
    }

    public function getReportResult(): ReportResponse
    {
        return $this->subFlowReportRequest->getReportResult();
    }

    public function getParseReportResult(): ParsedReport
    {
        return $this->subFlowReportRequest->getParseReportResult();
    }

    public function fetchReport($resourceUrl, $compressAlgorithm, $contentType)
    {
        return Report::fetchReport($resourceUrl, $compressAlgorithm, $contentType);
    }

    public function getErrors(): array
    {
        return $this->errors;
    }

    public function getWarnings(): array
    {
        return $this->warnings;
    }

    public function getConfirmations(): array
    {
        return $this->confirmations;
    }

    public function getStatistic(): array
    {
        return [
            'uuid' => $this->uuid,
            'imported' => $this->offersImportedFromReport,
            'rejectedNotExist' => $this->offersRejectedNotExist,
            'rejectedNotEnableSync' => $this->offersRejectedNotEnableSync,
            'synced' => $this->offersSynced,
            'inactiveItemCount' => $this->inactiveItemCount,
        ];
    }

    /**
     * @throws PrestaShopException
     */
    public function importAmazonOffers($offers): void
    {
        $importedOffers = 0;
        $productType = $this->isFBA ? TooleAmazonMarketAmazonProduct::FBA_PRODUCT : TooleAmazonMarketAmazonProduct::AMAZON_PRODUCT;

        if ($this->isFBA) {
            $result = $offers;
        } else {
            $result = $this->buildMerchantListingAllDataReport($offers);
        }

        if (isset($result['inactiveItemCount']) && $inactiveItemCount = $result['inactiveItemCount']) {
            $this->inactiveItemCount = $inactiveItemCount;

            // add warning for inactive item count
            if ($inactiveItemCount == 1) {
                $this->warnings[] = $this->module->l('1 inactive item has been filtered out');
            } elseif ($inactiveItemCount > 1) {
                $this->warnings[] = sprintf(
                    $this->module->l('%d inactive items have been filtered out'),
                    $inactiveItemCount
                );
            }
        }

        foreach ($offers as $item) {
            $checkSku = trim(Tools::substr($item['sku'], 0, 32));

            if (!empty($checkSku)) {
                $productId = null;
                $oldProduct = TooleAmazonMarketAmazonProduct::getTooleProductBySku($checkSku, $this->idEntity, $productType);

                if (!empty($oldProduct)) {
                    $productId = $oldProduct['id'];
                }

                $amazonProduct = new TooleAmazonMarketAmazonProduct($productId);
                $amazonProduct->id_shop = $this->idShop;
                $amazonProduct->id_shop_group = $this->idShopGroup;
                $amazonProduct->id_entity = $this->idEntity;
                $amazonProduct->sku = $checkSku;
                $amazonProduct->asin = $item['product-id'];
                $amazonProduct->qty = $item['qty'];
                $amazonProduct->price = $item['price'];
                $amazonProduct->amz_product_name = $item['name'];
                $amazonProduct->is_mapped = null;
                $amazonProduct->type = $productType;
                $amazonProduct->save();

                ++$importedOffers;
            }
        }

        // add warning / confirmation for imported offers
        // $this->addNotificationsForImportedOffers($importedOffers);
        if ($importedOffers < 1) {
            $this->warnings[] = $this->module->l('No offers have been imported');
        } elseif ($importedOffers == 1) {
            $this->confirmations[] = $this->module->l('1 Amazon offer has been imported');
        } else {
            $this->confirmations[] = sprintf($this->module->l('%d Amazon offers have been imported'), $importedOffers);
        }

        $this->offersImportedFromReport = $importedOffers;
    }

    public function syncAmazonOffers($mrkId): void
    {
        $rejectedNotExistCount = 0;
        $rejectedNotEnableSyncCount = 0;
        $offersSyncedCount = 0;
        $productType = $this->isFBA ? TooleAmazonMarketAmazonProduct::FBA_PRODUCT : TooleAmazonMarketAmazonProduct::AMAZON_PRODUCT;

        $productIds = TooleAmazonMarketAmazonProduct::getTooleProductsNotSync($this->idEntity, $productType);

        if (!empty($productIds)) {
            $this->log->message(sprintf('Start bulk synchronizing all amazon products - Marketplace ID #%s', $mrkId));
            foreach ($productIds as $product) {
                $syncProduct = TooleAmazonMarketAmazonProduct::syncProduct($product['id'], $this->idEntity, $productType, $this->log);
                [$offersSynced, $rejectedNotEnableSync, $rejectedNotExist] = array_values($syncProduct);
                if ($offersSynced) {
                    ++$offersSyncedCount;
                }
                if ($rejectedNotEnableSync) {
                    ++$rejectedNotEnableSyncCount;
                }
                if ($rejectedNotExist) {
                    ++$rejectedNotExistCount;
                }
            }
        }

        // add Warning For Rejected Not Exist Count
        if (!$rejectedNotExistCount) {
            $this->warnings[] = $this->module->l('1 Amazon offer has been ignored because it does not exist in Prestashop');
        } elseif ($rejectedNotExistCount > 1) {
            $this->warnings[] = sprintf(
                $this->module->l('%d Amazon offers have been ignored because they do not exist in Prestashop'),
                $rejectedNotExistCount
            );
        }

        // add Warning For Rejected Not Enable Sync Count
        if ($rejectedNotEnableSyncCount === 1) {
            $this->warnings[] = $this->module->l('1 Amazon offer has been ignored because sync is not enabled for this product.');
        } elseif ($rejectedNotEnableSyncCount > 1) {
            $this->warnings[] = sprintf(
                $this->module->l('%d Amazon offers have been ignored because sync is not enabled.'),
                $rejectedNotEnableSyncCount
            );
        }

        $this->offersRejectedNotEnableSync = $rejectedNotEnableSyncCount;
        $this->offersRejectedNotExist = $rejectedNotExistCount;
        $this->offersSynced = $offersSyncedCount;
    }

    public function doTheSync($mrkId): bool
    {
        $isContinuous = false;
        $this->requestReport();
        $report = $this->getReportResult();
        $reportData = $this->getParseReportResult();

        if (!empty($report->getDocumentUrl())) {
            $this->importAmazonOffers($reportData->getData());

            if ($reportData->getHasMore()) {
                $isContinuous = true;
            }
        } elseif ($report->isProcessFailed()) {
            $this->uuid = $report->getUuid();
        } else {
            $isContinuous = true;
            $this->uuid = $report->getUuid();
        }

        if ($this->offersImportedFromReport > 0) {
            $this->syncAmazonOffers($mrkId);
        }

        if (!$isContinuous) {
            /* storage last statistic report data */
            $this->storageLastStatisticReportData($mrkId, $reportData->getStatistic());
        }

        return $isContinuous;
    }

    public function storageLastStatisticReportData($mkpId, $lastStatistic = [])
    {
        $reportData = $this->buildLastStatisticReportData($mkpId, $lastStatistic);

        if ($reportData) {
            Configuration::updateValue(Key::LAST_STATISTICS_REPORT_DATA, $reportData, false, $this->idShopGroup, $this->idShop);
        }
    }

    public function buildLastStatisticReportData($mkpId, $lastStatistic = [])
    {
        $reportDataOld = Configuration::get(Key::LAST_STATISTICS_REPORT_DATA, $this->idLang, $this->idShop, $this->idShopGroup);
        $reportTypeName = $this->reportType['name'];
        $reportDataNew = $this->updateStatistics($this->getStatistic(), $lastStatistic);

        if (!$reportDataOld) {
            return json_encode([$reportTypeName => [$mkpId => $reportDataNew]]);
        }
        $reportData = json_decode($reportDataOld, true);
        $reportData[$reportTypeName][$mkpId] = $reportDataNew;

        return json_encode($reportData);
    }

    public function updateStatistics(array $newStatistics, array $lastStatistic): array
    {
        if (!$lastStatistic) {
            return $newStatistics;
        }

        if (!$newStatistics) {
            return [];
        }

        foreach ($newStatistics as $key => $statistic) {
            if ($key !== 'uuid') {
                $newStatistics[$key] += (int) $lastStatistic[$key];
            }
        }

        return $newStatistics;
    }
}
