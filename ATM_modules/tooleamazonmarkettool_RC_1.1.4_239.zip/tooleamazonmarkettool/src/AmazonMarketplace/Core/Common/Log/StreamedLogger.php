<?php
/**
 *  configuration.js
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Common\Log;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Logger to use when the messages can be seen as soon as they are created.
 * For instance, in a CLI context.
 */
class StreamedLogger extends Logger
{
    /**
     * @var int Minimum criticity of level to display
     */
    protected $filter = self::INFO;

    /**
     * @var resource File handler of standard output
     */
    protected $out;

    /**
     * @var resource File handler of standard error
     */
    protected $err;

    public function __construct()
    {
        $this->out = fopen('php://stdout', 'w');
        $this->err = fopen('php://stderr', 'w');
    }

    public function __destruct()
    {
        fclose($this->out);
        fclose($this->err);
    }

    /**
     * Check the verbosity allows the message to be displayed.
     *
     * @param int $level
     *
     * @return bool
     */
    public function isFiltered($level)
    {
        return $level < $this->filter;
    }

    /**
     * {@inherit}.
     */
    public function log($level, $message, array $context = [])
    {
        if (empty($message)) {
            return;
        }

        $log = self::$levels[$level] . ' - ' . $message . PHP_EOL;

        if ($level > self::ERROR) {
            fwrite($this->err, $log);
        }

        if (!$this->isFiltered($level)) {
            fwrite($this->out, $log);
        }
    }

    public function getFilter()
    {
        return $this->filter;
    }

    /**
     * Set the verbosity of the logger.
     *
     * @param int $filter
     *
     * @return $this
     */
    public function setFilter($filter)
    {
        if (!array_key_exists($filter, self::$levels)) {
            throw new \Exception('Unknown level ' . $filter);
        }
        $this->filter = $filter;

        return $this;
    }
}
