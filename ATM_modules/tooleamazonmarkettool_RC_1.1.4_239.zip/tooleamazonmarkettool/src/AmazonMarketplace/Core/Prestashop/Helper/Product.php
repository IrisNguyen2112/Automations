<?php
/**
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 *
 * @author    Toole <support@toole.com>
 * @copyright 2023 TOOLE - Inter-soft.com
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Helper;

use Configuration;
use Context;
use Image;
use SpecificPrice;
use Toole\Module\Amazon\Client\V2\Model\CatalogSync\Sale;
use Tools;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Product
{
    public static function getImageUrl($imageId, $productId, $baseUrl): string
    {
        $image_type = null;
        $ext = 'jpg';
        $imageObj = new Image($imageId);

        if (method_exists($imageObj, 'getExistingImgPath')) {
            $imgPath = $imageObj->getExistingImgPath();
            $imageUrl = $imgPath;
        } else {
            $imageUrl = $productId . '-' . $imageId;
        }

        if (method_exists('ImageType', 'getFormatedName')) {
            $image_type = Configuration::get('AMAZON_IMAGE_TYPE');
        }

        if (Tools::strlen($image_type)) {
            $imageUrl = sprintf('%s-%s.%s', $imageUrl, $image_type, $ext);
        } else {
            $imageUrl = sprintf('%s.%s', $imageUrl, $ext);
        }

        $file_image = _PS_PROD_IMG_DIR_ . $imageUrl;
        if (!file_exists($file_image)) {
            return '';
        }

        // E.g: hostname/img/p/.....
        return $baseUrl . ltrim(str_replace(_PS_ROOT_DIR_, '', _PS_PROD_IMG_DIR_), '/') . $imageUrl;
    }

    public static function getSale(\Product $product, $productAttributeId, Context $context, $useSales = true): ?Sale
    {
        if (!$useSales) {
            return null;
        }

        $specificPrice = SpecificPrice::getSpecificPrice(
            $product->id, $context->shop->id, $context->currency->id,
            $context->country->id, Configuration::get('PS_CUSTOMER_GROUP'),
            1, $productAttributeId ?: null, 0, 0, 1
        );

        if (
            $product->on_sale
            && $specificPrice
            && isset($specificPrice['reduction_type'])
            && isset($specificPrice['from'])
            && isset($specificPrice['to'])
            && (int) $specificPrice['from']
            && (int) $specificPrice['to']
        ) {
            // ISO 8601
            $dateStart = date('c', strtotime($specificPrice['from']));
            $dateEnd = date('c', strtotime($specificPrice['to']));

            $salePrice = $product->getPrice(true, $productAttributeId ?: null);
            $salePrice = Tools::ps_round($salePrice, 2);

            return new Sale(['start' => $dateStart, 'end' => $dateEnd, 'price' => $salePrice]);
        }

        return null;
    }

    public static function getImageUrls(\Product $product, $id_product_attribute, $id_lang, $context, $baseUrl): array
    {
        $image_set = [];
        $images = $product->getImages($id_lang, $context);
        if (is_array($images) && count($images)) {
            foreach ($images as $image) {
                $image_set[] = $image['id_image'];
            }
        }

        $id_images = [];
        if ((int) $id_product_attribute) {
            $images = $product->getCombinationImages($id_lang);
            if (is_array($images) && count($images)) {
                $id_images = array_column($images, 'id_image');
            } else {
                $images = $product->getImages($id_lang, $context);
                if (is_array($images) && count($images)) {
                    $id_images = array_column($images, 'id_image');
                }
            }
        } else {
            $images = $product->getImages($id_lang, $context);
            if (is_array($images) && count($images)) {
                $id_images = array_column($images, 'id_image');
            }
        }
        if ($cover = \Product::getCover($product->id, $context)) {
            array_unshift($id_images, (int) $cover['id_image']);
        }
        $id_images = array_unique($id_images);

        $images = [];
        foreach ($id_images as $id_image) {
            if (in_array($id_image, $image_set)) { // multistore workaround: getCombinationImages returns images from other shops
                $images[] = self::getImageUrl($id_image, $product->id, $baseUrl);
            }
        }

        return $images;
    }
}
