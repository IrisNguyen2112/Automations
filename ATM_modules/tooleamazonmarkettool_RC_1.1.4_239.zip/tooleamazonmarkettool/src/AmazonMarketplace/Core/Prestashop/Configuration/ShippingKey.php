<?php
/**
 * ShippingKey
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketplace
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Configuration;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ShippingKey extends Key
{
    // Just 1 config to rule them all
    const SHIPPING_TEMPLATES = 'TOOLE_AMAZON_MARKET_SHIPPING_TEMPLATES';
}
