<?php
/**
 * AmazonMarketplaceConfigurationAdminController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  AmazonMarketplaceConfigurationAdminController
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

/**
 *  * AmazonMarketplaceConfigurationAdminController
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  Class
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */
namespace Toole\Module\AmazonMarketplace\Core\Prestashop\Controller;

use Configuration;
use Doctrine\Common\Cache\CacheProvider;
use Language;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\Request;

if (!defined('_PS_VERSION_')) {
    exit;
}

class AmazonMarketplaceConfigurationAdminController extends FrameworkBundleAdminController
{
    /**
     * @var CacheProvider
     */
    private $cache;

    /**
     * @var int|null
     */
    private $shopId;

    public function __construct(CacheProvider $cache, $shopId)
    {
        $this->cache = $cache;
        $this->shopId = $shopId;
    }

    public function configurationAction(Request $request)
    {
        $generalFormDataHandler = $this->get(
            'Toole\Module\AmazonMarketplace\Core\Prestashop\Form\AmazonMarketplaceGeneralDataHandler'
        );
        $generalForm = $generalFormDataHandler->getForm();

        $resultHandleForm = null;

        if ($generalForm->isSubmitted() && $generalForm->isValid()) {
            $errors = $generalFormDataHandler->save($generalForm->getData());
            if (empty($errors)) {
                $this->addFlash('success',
                    $this->trans('Successful update.', 'Admin.Notifications.Success')
                );
                return $this->redirectToRoute('amazonmarketplace_configuration');
            }
            $this->flashErrors($errors);
        }

        return $this->render('@Modules/tooleamazonmarketplace/views/templates/admin/configuration.html.twig', [
            'configurationGeneralForm' => $generalForm->createView(),
            'resultHandleForm' => $resultHandleForm,
            'enableSidebar' => true,
            'help_link' => $this->generateSidebarLink('AmazonMarketplaceConfigurationAdminController'),
        ]);
    }

    /**
     * handleForm
     *
     * @param array $datas
     *
     * @return bool
     */
    private function handleForm($datas)
    {
        $result = true;
        $defaultLanguageId = (int) Configuration::get('PS_LANG_DEFAULT');

        if (isset($datas['AmazonMarketplacePageName'])) {
            foreach ($datas['AmazonMarketplacePageName'] as $langID => $value) {
                if (empty($value) && $langID != $defaultLanguageId) {
                    $value = $datas['AmazonMarketplacePageName'][$defaultLanguageId];
                }
                $result = $result && Configuration::updateValue(
                    'amazonmarketplace_AmazonMarketplacePageName',
                    [$langID => $value]
                );
            }
        }

        if ($result === true) {
            $this->addFlash('success', $this->trans('Successful update.', 'Admin.Notifications.Success'));
        }

        return $result;
    }

    /**
     * getWishlistConfigurationDatas
     *
     * @return array
     */
    private function getConfigurationDatas()
    {
        $languages = Language::getLanguages(true);
        $amazonmarketplaceNames = [];

        foreach ($languages as $lang) {
            $amazonmarketplaceNames[$lang['id_lang']] = Configuration::get(
                'amazonmarketplace_AmazonMarketplacePageName',
                $lang['id_lang']
            );
        }

        $datas = [
            'AmazonMarketplacePageName' => $amazonmarketplaceNames,
        ];

        return $datas;
    }
}
