<?php
/**
 * TooleAmazonMarketAmazonProduct
 *
 * @author    Toole
 * @copyright 2023 TOOLE - Inter-soft
 * @license   license.txt
 * @category  TooleAmazonMarketTool
 *
 * 2023 TOOLE - Inter-soft - All rights reserved.
 *
 * DISCLAIMER
 * Changing this file will render any support provided by us null and void.
 */

use Toole\Module\AmazonMarketplace\Core\Common\Amazon\Helper\Product as ProductHelper;
use Toole\Module\AmazonMarketplace\Core\Prestashop\Helper\Database;

if (!defined('_PS_VERSION_')) {
    exit;
}

class TooleAmazonMarketAmazonProduct extends ObjectModel
{
    public $id;
    public $id_shop;
    public $id_shop_group;
    public $id_entity;
    public $sku;
    public $asin;
    public $price;
    public $qty;
    public $amz_product_name;
    public $amz_product_desc;
    public $is_synced;
    public $is_mapped;
    public $type;

    const MAPPING_INITIAL = null;
    const MAPPING_NOT_EXIST_ON_PS = 0;
    const MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED = 1;
    const MAPPING_EXIST_ON_PS_AND_ENABLED = 2;
    const AMAZON_PRODUCT = 0;
    const FBA_PRODUCT = 1;

    public static $definition = [
        'table' => Database::TABLE_AMAZON_PRODUCTS,
        'primary' => 'id',
        'multilang' => false,
        'fields' => [
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_entity' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'id_shop_group' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'sku' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'asin' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'qty' => ['type' => self::TYPE_INT, 'validate' => 'isInt'],
            'price' => ['type' => self::TYPE_FLOAT, 'validate' => 'isFloat'],
            'amz_product_name' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'amz_product_desc' => ['type' => self::TYPE_STRING, 'validate' => 'isString'],
            'is_synced' => ['type' => self::TYPE_INT, 'validate' => 'isBool'],
            'is_mapped' => ['type' => self::TYPE_INT, 'validate' => 'isInt'],
            'type' => ['type' => self::TYPE_INT, 'validate' => 'isInt'],
        ],
    ];

    public function __construct($id = null, $id_lang = null)
    {
        parent::__construct($id, $id_lang);
        $this->idLang = $id_lang;
    }

    public static function commonDbQuery($entityId, $type, $select = 'pa.*'): DbQuery
    {
        $sql = new DbQuery();
        $sql->select($select);
        $sql->from(Database::TABLE_AMAZON_PRODUCTS, 'pa');
        $sql->where('pa.id_entity = ' . (int) $entityId);
        $sql->where('pa.id_shop = ' . (int) Context::getContext()->shop->id);
        $sql->where('pa.id_shop_group = ' . (int) Context::getContext()->shop->id_shop_group);
        $sql->where('pa.type = ' . (int) $type);

        return $sql;
    }

    /**
     * @param $id
     * @param $entityId
     * @param int $type
     * @return array|bool|object|null
     */
    public static function getTooleProductById($id, $entityId, int $type = self::AMAZON_PRODUCT)
    {
        $sql = new DbQuery();
        $sql->select('p.`sku`, p.`qty`, p.`price`, p.`amz_product_name`, p.`amz_product_desc`, p.`is_synced`, p.`is_mapped`');
        $sql->from(Database::TABLE_AMAZON_PRODUCTS, 'p');
        $sql->where('p.`id` = \'' . pSQL($id) . '\'');
        $sql->where('p.`id_entity` = ' . (int) $entityId);
        $sql->where('p.`type` = ' . (int) $type);

        return Db::getInstance()->getRow($sql);
    }

    /**
     * @param $entityId
     * @param int $type
     * @return array|bool|mysqli_result|PDOStatement|resource|null
     * @throws PrestaShopDatabaseException
     */
    public static function getTooleProductsNotSync($entityId, int $type = self::AMAZON_PRODUCT)
    {
        $sql = self::commonDbQuery($entityId, $type, 'pa.id, pa.sku');
        $sql->where('pa.is_synced = 0');

        return Db::getInstance()->executeS($sql);
    }

    public static function processSyncProduct($product, $amzProduct, $shopId, $isCombination = false, int $type = self::AMAZON_PRODUCT, $log)
    {
        $idProductAttribute = $isCombination ? $product['id_product_attribute'] : 0;

        StockAvailable::setQuantity(
            $product['id_product'],
            $idProductAttribute,
            $amzProduct['qty'],
            $shopId
        );

        if (self::FBA_PRODUCT !== $type) {
            $psProduct = new Product($product['id_product']);
            if (Validate::isLoadedObject($psProduct)) {
                if ($idProductAttribute && Combination::isFeatureActive()) {
                    $psCombination = new Combination($idProductAttribute);
                    if (Validate::isLoadedObject($psCombination)) {
                        $psCombination->price = $amzProduct['price'];
                        $psCombination->save();
                        $log->success(sprintf('Combination Product (ID: %s, Quantity: %s, Price: %s) has been synchronized', $idProductAttribute, $amzProduct['qty'], $amzProduct['price']));
                    }
                } else {
                    $psProduct->price = $amzProduct['price'];
                    $psProduct->save();
                    $log->success(sprintf('Product (ID: %s, Quantity: %s, Price: %s) has been synchronized', $product['id_product'], $amzProduct['qty'], $amzProduct['price']));
                }
            }
        }
    }

    /**
     * @param $productId
     * @throws PrestaShopException
     */
    public static function syncProduct($productId, $entityId, int $type = self::AMAZON_PRODUCT, $log): array
    {
        $rejectedNotExist = 0;
        $rejectedNotEnableSync = 0;
        $offersSynced = 0;
        $context = Context::getContext();
        $amzProduct = self::getTooleProductById($productId, $entityId, $type);
        $syncType = self::FBA_PRODUCT === $type ? ProductHelper::SYNC_TYPE_ENABLED_FBA_PS : ProductHelper::SYNC_TYPE_ENABLED_AMZ_PS;

        if ($amzProduct && $amzProduct['is_synced'] == 0) {
            $psProducts = ProductHelper::searchBySku($context->language->id, $amzProduct['sku'], true, false);

            if (!empty($psProducts)) {
                $parentUpdated = [];
                foreach ($psProducts as $product) {
                    if (!ProductHelper::isAllowToSync($syncType, $product['id_product'], $context->language->id, $context->shop->id, $entityId)) {
                        ++$rejectedNotEnableSync;
                    } else {
                        ++$offersSynced;
                        $isCombination = $product['pa_reference'] === $amzProduct['sku'];
                        $isSimpleOrParent = $product['reference'] === $amzProduct['sku'];

                        if ($isCombination || ($isSimpleOrParent && !isset($parentUpdated[$product['id_product']]))) {
                            self::processSyncProduct($product, $amzProduct, $context->shop->id, $isCombination, $type, $log);
                            if ($isSimpleOrParent) {
                                $parentUpdated[$product['id_product']] = true;
                            }
                        }
                    }
                }

                $mappingStatus = !$offersSynced ? self::MAPPING_EXIST_ON_PS_BUT_NOT_ENABLED : self::MAPPING_EXIST_ON_PS_AND_ENABLED;
            } else {
                $mappingStatus = self::MAPPING_NOT_EXIST_ON_PS;
                ++$rejectedNotExist;
            }

            // Mark as Synced and confirm existence in Prestashop
            $isSynced = self::MAPPING_EXIST_ON_PS_AND_ENABLED === $mappingStatus ? 1 : 0;
            $sql = 'UPDATE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` ap SET
            ap.`is_synced` = ' . $isSynced . ',
            ap.`is_mapped` = ' . $mappingStatus . ',
            ap.`date_upd` = "' . pSQL(date('Y-m-d H:i:s')) . '" WHERE ap.`id` = ' . pSQL($productId);
            Db::getInstance()->execute($sql);
        }

        return [
            'rejectedNotExist' => $rejectedNotExist > 0,
            'rejectedNotEnableSync' => $rejectedNotEnableSync > 0,
            'offersSynced' => $offersSynced > 0,
        ];
    }

    /**
     * @param $sku
     * @param $entityId
     * @param int $type
     * @return array|bool|object|null
     */
    public static function getTooleProductBySku($sku, $entityId, int $type = self::AMAZON_PRODUCT)
    {
        $sql = self::commonDbQuery($entityId, $type);
        $sql->where('pa.sku LIKE \'' . pSQL($sku) . '\'');

        return Db::getInstance()->getRow($sql);
    }

    public static function getTooleProductsWithMappingStatus($entityId, $type = self::AMAZON_PRODUCT)
    {
        $columnType = self::FBA_PRODUCT === $type ? 'enabled_fba_ps' : 'enabled_amz_ps';
        $sql = 'SELECT pa.*,
                CASE
                    WHEN tmsp.' . $columnType . ' = 1 OR tmsc.' . $columnType . ' = 1 OR tmsm.' . $columnType . ' = 1 OR tmss.' . $columnType . ' = 1 THEN "2"
                    WHEN pa.sku = p.reference OR pa.sku = pat.reference THEN "1"
                ELSE "0"
                END AS mapping_status
                FROM `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` pa
                LEFT JOIN `' . _DB_PREFIX_ . 'product` p ON pa.sku = p.reference
                LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute` pat ON pa.sku = pat.reference
                LEFT JOIN `' . _DB_PREFIX_ . 'category_product` c ON (c.`id_product` = p.`id_product`)
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_PRODUCTS . '` tmsp ON (tmsp.id_product = p.id_product) AND tmsp.`id_entity` = ' . (int) $entityId . '
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_CATEGORIES . '` tmsc ON (tmsc.id_category = c.id_category) AND tmsc.`id_entity` = ' . (int) $entityId . '
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_MANUFACTURERS . '` tmsm ON (tmsm.id_manufacturer = p.id_manufacturer) AND tmsm.`id_entity` = ' . (int) $entityId . '
                LEFT JOIN `' . _DB_PREFIX_ . Database::TABLE_FILTER_SUPPLIERS . '` tmss ON (tmss.id_supplier = p.id_supplier) AND tmss.`id_entity` = ' . (int) $entityId . '
                WHERE pa.`id_entity` = ' . (int) $entityId . '
                AND pa.`id_shop` = ' . (int) Context::getContext()->shop->id . '
                AND pa.`id_shop_group` = ' . (int) Context::getContext()->shop->id_shop_group . '
                AND pa.`type` = ' . (int) $type . '
                GROUP by pa.sku';

        return Db::getInstance()->executeS($sql);
    }

    public static function markAsNotSyncAndUpdateMappingStatus($id, $status): bool
    {
        $sql = 'UPDATE `' . _DB_PREFIX_ . Database::TABLE_AMAZON_PRODUCTS . '` ap SET
            ap.`is_synced` = 0,
            ap.`is_mapped` = ' . (int) $status . '
            WHERE ap.`id` = ' . pSQL($id);

        return Db::getInstance()->execute($sql);
    }
}
